﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;




namespace MMIE
{
    public partial class CustomerBalanceRefund : BasePage
    {
        private Currency objCurrency = new Currency();
       private CurrencyBO objCurrencyBO = new CurrencyBO();
       protected void PagePermission()
       {
           if (LoginToken != null)
           {
               btnSaveAmount.Enabled = LoginToken.IsAddOn;
               //btnPrintReceipt.Enabled = LoginToken.IsPrintOn;

               
           }
       }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            PagePermission();
            
            if(!IsPostBack)
            {
                ViewState["CustomerID"] = null;
                BindCurrencyDropDown();            

              
            }

            
        }

        protected void BindCurrencyDropDown()
        {
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("Select Currency", "0"));
                ddlCurrency.SelectedIndex = 1;

               

            }
            catch (Exception ex)
            {

                lblError.Text = "Error : " + ex.Message;
            }

        }
        private void BindCustomer(int id)
        {
            try
            {

                CustomerBO objCustomerBO = new CustomerBO();
                Customer objCustomer = new Customer();
                objCustomer.CustomerID = id;

                objCustomer = objCustomerBO.GetCustomerByID(objCustomer);
                if (objCustomer != null)
                {
                    txtCustomer.Text = objCustomer.CustomerName;
                    txtPhone.Text = objCustomer.CustomerPhone;
                    txtFaxno.Text = objCustomer.CustomerFax;
                    txtEmail.Text = objCustomer.CustomerEmail;
                    txtAddress.Text = objCustomer.CustomerAddress;
                    txtCity.Text = objCustomer.CityName;
                    txtCountry.Text = objCustomer.CountryName;
                    txtWebsite.Text = objCustomer.CustomerWebsite;
                    lblOpeningBalance.Text = objCustomer.OpeningBalance.ToString(".00");
                    lblOpeningBalanceUSD.Text = Convert.ToString(objCustomer.OpeningBalanceUSD);

                    //            txtStreet.Text=objCustomer.a


                    if (objCustomer.StatusType)
                    {
                        rbtStatus.SelectedIndex = 0;

                    }
                    else
                    {
                        rbtStatus.SelectedIndex = 1;
                    }

                    rbtStatus.Enabled = false;
                    lblCreditLimit.Text = objCustomer.MaxCreditLimit.ToString();
                    lblCreditLimitUSD.Text = objCustomer.MaxCreditLimitUSD.ToString() ;

                    //  txtCustomer.ReadOnly = true;
                    txtPhone.ReadOnly = true;
                    txtFaxno.ReadOnly = true;
                    txtEmail.ReadOnly = true;
                    txtAddress.ReadOnly = true;
                    txtCity.ReadOnly = true;
                    txtCountry.ReadOnly = true;
                    txtWebsite.ReadOnly = true;
                    ViewState["CustomerID"] = objCustomer.CustomerID;
                    ViewState["OpeningBalance"] = objCustomer.OpeningBalance;
                    ViewState["OpeningBalanceUSD"] = objCustomer.OpeningBalanceUSD;

                }
                BindDepositTransaction();
               // BindCurrencyDropDown();
            }
            catch (Exception ex)
            {

                lblError.Text = "Error while fetching Customer Record : " + ex.Message;
            }
        }

        private void ClearAll()
        {

            ViewState["CustomerID"] = null;
            ViewState["OpeningBalance"] = 0;
            ViewState["OpeningBalanceUSD"] = 0;
            txtPhone.Text= "";
            txtFaxno.Text = "";
            txtEmail.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            txtCountry.Text = "";
            txtWebsite.Text = "";
            txtAmount.Text = "";
            lblAmountUSD.Text = "";
            lblCreditLimit.Text = "";
            lblCreditLimitUSD.Text = "";
            txtCustomer.Text = "";
            lblOpeningBalance.Text = "";
            lblOpeningBalanceUSD.Text = "";
            
        }

        protected void btnSaveAmount_Click(object sender, EventArgs e)
        {
            try
            {

                DepositTransaction objDeposit = new DepositTransaction();
                DepositTransactionBO objDeositBO = new DepositTransactionBO();
                //   CurrencyBO objCurrencyBO = new CurrencyBO();

                if (ddlCurrency.SelectedIndex > 0)
                {
                    objCurrency = objCurrencyBO.GetCurrencyByID(Convert.ToInt32(ddlCurrency.SelectedValue.ToString()));
                    objDeposit.Rate = objCurrency.Rate;
                    objDeposit.CurrencyID = objCurrency.CurrencyID;
                    objDeposit.FinancialYearID = LoginToken.FinancialYearID;
                    objDeposit.DepositID = 0;
                    if (ViewState["CustomerID"] != null)
                    {
                        objDeposit.CustomerID = (int)ViewState["CustomerID"];
                    }
                    else
                    {
                        lblError.Text = "Please select customer and try again!";
                        return;

                    }
                    objDeposit.CompanyID = LoginToken.CompanyID;
                    objDeposit.IsActive = true;
                    objDeposit.AddedBy = LoginToken.LoginId;
                    decimal Amount = Convert.ToDecimal(txtAmount.Text);
                    //decimal AmountUSD = (Amount / objCurrency.Rate);

                    if (ddlCurrency.SelectedValue== "1")
                    {
                        objDeposit.Amount = Amount;
                        objDeposit.AmountUSD = 0;
                        objDeposit.ClosingAmount = ((decimal)ViewState["OpeningBalance"] + Amount);
                    }
                                       
                    else if (ddlCurrency.SelectedValue== "2")
                    {
                        objDeposit.Amount = 0;
                        objDeposit.AmountUSD = Amount;
                        objDeposit.ClosingAmountUSD = ((decimal)ViewState["OpeningBalanceUSD"] + Amount);
                    }
                    else if(ddlCurrency.SelectedIndex>0)
                    {

                        lblError.Text = "No Deposit facility is avaliable for " + ddlCurrency.SelectedValue.ToString();
                        return;
                    }
                    
                    objDeposit.Remarks = txtRemarks.Text;
                    objDeposit.ActionType = 1;
                    objDeposit.TType = "CR";
                    objDeposit.OrderNo = txtOrderNo.Text;
                    objDeposit.PaymentMode = "Deposit";

                    int result = objDeositBO.DebitAmount(objDeposit);
                    if (result > 0)
                    {
                        ViewState["TransactionID"] = result;
                        hdntransactionid.Value = ViewState["TransactionID"].ToString();
                        lblError.Text = "Transaction Successfull";
                        //btnPrintReceipt.Enabled = true;
                        txtAmount.Text = "";
                        txtRemarks.Text = "";
                        lblAmountUSD.Text = "";
                        
                        txtOrderNo.Text = "";

                    }
                    BindCustomer((int)ViewState["CustomerID"]);
                    BindDepositTransaction();

                }
                else
                {
                    lblError.Text = "Please Select A Currency";
                }

            }
            catch (Exception ex)
            {

                lblError.Text = "Error : " + ex.Message;
            }
                
        }


        private void BindDepositTransaction()
        {
            try
            {

                DepositTransactionBO objDepositBO = new DepositTransactionBO();
                List<DepositTransaction> lstDeposit = new List<DepositTransaction>();

                if (ViewState["CustomerID"] != null)
                {
                    lstDeposit = objDepositBO.GetDepositTransactionList((int)ViewState["CustomerID"]);

                }

                grdDepositTransaction.DataSource = lstDeposit;
                ddlCurrency.SelectedValue = "1";
                grdDepositTransaction.DataBind();
            }
            catch (Exception ex)
            {

                lblError.Text = "Error on fetching Deposit list: " + ex.Message;
            }
        }

        protected void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtCustomer_TextChanged(object sender, EventArgs e)
        {
            try
            {


                string GetCustomerId = (txtCustomer.Text).Trim();
                int id = 0;
                string[] SplitGetCustomerId = GetCustomerId.Split('-');

                if (SplitGetCustomerId.Length > 1)
                {

                    id = Convert.ToInt32(SplitGetCustomerId[0]);

                }

                if (id > 0)
                    BindCustomer(id);

            }
            catch (Exception ex)
            {

                lblError.Text = "Error while fetching Customer Record: " + ex.Message;
            }
        }

       


        
        protected void ddlCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlCurrency.SelectedIndex > 0 && txtAmount.Text.Length > 0)
                {
                    int i = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());
                    if (i > 0)
                    {
                        objCurrency = objCurrencyBO.GetCurrencyByID(i);
                    }
                    decimal amount = Convert.ToDecimal(txtAmount.Text);
                    lblAmountUSD.Text = ((amount / objCurrency.Rate).ToString(".00")) ;
                }
            }
            catch (FormatException)
            {
                lblError.Text = "Enter A Valid Amount";

            }
            catch (Exception ex)
            {
                lblError.Text = "Error : " + ex.Message;

            }


        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            ClearAll();
            lblError.Text = "";
            txtAmount.Text = "";
            lblAmountUSD.Text = "";
            grdDepositTransaction.DataSource = null;
            grdDepositTransaction.DataBind();
           //btnPrintReceipt.Enabled = false;
           ViewState["TransactionID"] = null;
        }

        protected void grdDepositTransaction_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdDepositTransaction.PageIndex = e.NewPageIndex;
            BindDepositTransaction();
        }

        
    }
    
}