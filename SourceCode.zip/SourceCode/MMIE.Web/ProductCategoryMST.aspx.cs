﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;
namespace MMIE
{
    public partial class ProductCategoryMST : BasePage
    {
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsPrintOn;

            }
        }

        
        protected void Page_Load(object sender, EventArgs e)
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            if (!IsPostBack)
            {
                BindDropDownControl(ddlGroupname, mstlookup.GetLookupsList(LookupNames.Group));
                ddlGroupname.Items.Insert(0, "Select Group");
                ViewState["IsEdit"] = false;
            }
            PagePermission();
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records Please contact to your System Administrator";
                return;

            }
            try
            {

                ProductCategory objProductCategory = new ProductCategory();
                ProductCategoryBO objProductCategoryBO = new ProductCategoryBO();

                objProductCategory.ProductCategoryName = txtProductCategoryName.Text;
                objProductCategory.GroupID =Convert.ToInt32(ddlGroupname.SelectedValue);


                if (rbtStatus.SelectedIndex == 1)
                {
                    objProductCategory.IsActive = false;


                }
                else
                {
                    objProductCategory.IsActive = true;

                }


                if (ViewState["ProductCategoryID"] != null)
                {

                    objProductCategory.ProductCategoryID = Convert.ToInt32(ViewState["ProductCategoryID"].ToString());
                    objProductCategory.ActionType = 2;
                    objProductCategory.LastModBy = LoginToken.LoginId;
                    objProductCategory.CompanyID = LoginToken.CompanyID;
                    objProductCategory.FinancialYearID = LoginToken.FinancialYearID;

                }
                else
                {

                    objProductCategory.ProductCategoryID = 0;
                    objProductCategory.ActionType = 1;
                    objProductCategory.AddedBy = LoginToken.LoginId;
                    objProductCategory.CompanyID = LoginToken.CompanyID;
                    objProductCategory.FinancialYearID = LoginToken.FinancialYearID;

                }


                if (objProductCategoryBO.SaveProductCategory(objProductCategory))
                {
                    if (ViewState["ProductCategoryID"] != null)
                        lblError.Text = "ProductCategory Updated Successfully";
                    else
                        lblError.Text = "ProductCategory Added Successfully";

                    ViewState["ProductCategoryID"] = null;
                    ViewState["IsEdit"] = false;
                    txtProductCategoryName.Text="";
                    ddlGroupname.SelectedIndex = 0;
                    BindProductCategoryList();


                }

            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While saving record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 


        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtProductCategoryName.Text = "";
            rbtStatus.SelectedIndex = 0;
            ddlGroupname.SelectedIndex = 0;
            ViewState["ProductCategoryID"] = null;
            lblError.Text = "";
            ViewState["IsEdit"] = false;
            grdProductCategoryList.DataSource = null;
            grdProductCategoryList.DataBind();

        }


        // updated by ankit
        private void BindProductCategoryList()
        {
            try
            {
                ProductCategory objCategory = new ProductCategory();
                ProductCategoryBO objProductCategoryBO = new ProductCategoryBO();
                List<ProductCategory> lstProductCategory = new List<ProductCategory>();
                objCategory.ProductCategoryName = txtProductCategoryName.Text.Trim();
                if (ddlGroupname.SelectedIndex != 0)
                    objCategory.GroupID = Convert.ToInt32(ddlGroupname.SelectedValue);
                else
                    objCategory.GroupID = 0;
                if (rbtStatus.SelectedIndex != 0)
                    objCategory.IsActive = false;
                else
                    objCategory.IsActive = true;
                lstProductCategory = objProductCategoryBO.GerSearchProductCategory(objCategory);
                grdProductCategoryList.DataSource = lstProductCategory;
                grdProductCategoryList.DataBind();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While fetching product category list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 

        }


      

        protected void grdProductCategoryList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdProductCategoryList.PageIndex = e.NewPageIndex;
                lblError.Text = "";
                BindProductCategoryList();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While goes to next page : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 
        }

        protected void grdProductCategoryList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "REdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());

                    GridViewRow gr = grdProductCategoryList.Rows[id];

                    Label lblProductCategoryName = (Label)gr.Cells[2].FindControl("lblProductCategoryName");
                    CheckBox chkIsActive = (CheckBox)gr.Cells[3].FindControl("chkIsActive");
                    LinkButton lblProductCategoryID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");
                    Label grupid = (Label)gr.Cells[3].FindControl("lblGrouptypeId");
                    txtProductCategoryName.Text = lblProductCategoryName.Text;
                    if (grupid.Text !=Convert.ToString(0))
                        ddlGroupname.SelectedValue = grupid.Text;
                    else
                        ddlGroupname.SelectedIndex = 0;
                    ViewState["ProductCategoryID"] = lblProductCategoryID.Text;
                    ViewState["IsEdit"] = true;
                    if (chkIsActive.Checked)
                    {
                        rbtStatus.SelectedIndex = 0;

                    }
                    else
                    {
                        rbtStatus.SelectedIndex = 1;

                    }

                    //Label lblID = (Label)grdUnit.Rows[e.RowIndex].FindControl("lblUnitID");
                    //TextBox txtBoxUnit = (TextBox)grdUnit.Rows[e.RowIndex].FindControl("txtUnitName");



                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While fetching product category record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 



        }

        // added by ankit
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindProductCategoryList();
        }
    }
}