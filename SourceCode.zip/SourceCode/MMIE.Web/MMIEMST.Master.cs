﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using MMIE.Web;

using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using System.Web.Security;
using MMIE.Web;

namespace MMIE
{
	public partial class MMIEMST : System.Web.UI.MasterPage
	{
        //  BaseMasterPage
        LoginToken objLoginToken;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                objLoginToken = (LoginToken)Session["LoginToken"];
                if (objLoginToken != null)
                {
                    //lblCompany.Text = objLoginToken.CompanyName;


                    lblUserID.Text = objLoginToken.LoginId;
                    lblFinancialYear.Text = objLoginToken.FinancialYearName;
                    lblLocation.Text = objLoginToken.CompanyAddress;

                    lblTimeNow.Text = DateTime.Now.ToString("MM/dd/yyyy");

                    lblCompany.Text = objLoginToken.CompanyName;
                    lblPhoneNo.Text = objLoginToken.CompanyPhoneSTDCode + "-" + objLoginToken.CompanyPhoneNo;
                    if (objLoginToken.CompanyPhoneAltNo == null || objLoginToken.CompanyPhoneAltNo == "")
                    {
                        lblPhoneNo.Text += "";
                    }
                    else
                    {
                        lblPhoneNo.Text += ", " + objLoginToken.CompanyPhoneAltNo;
                    }
                    if (objLoginToken.CompanyMobileNo == null || objLoginToken.CompanyMobileNo == "")
                    {
                        lblCompanyMobile.Text = "";
                        lblCompanyMobileTitle.Visible = true;
                    }
                    else
                    {
                        lblCompanyMobile.Text = objLoginToken.CompanyMobileNo;
                        lblCompanyMobileTitle.Visible = true;
                    }
                    if (objLoginToken.CompanyFaxNo == null || objLoginToken.CompanyFaxNo == "")
                    {
                        lblCompanyFax.Text = "";
                        lblCompanyFaxTitle.Visible = false;
                    }
                    else
                    {
                        lblCompanyFax.Text = objLoginToken.CompanyFaxNo;
                        lblCompanyFaxTitle.Visible = true;
                    }
                    if (objLoginToken.CompanyEmailID == null || objLoginToken.CompanyEmailID == "")
                    {
                        lblEmailID.Text = "";
                        lblEmailTitle.Visible = false;
                    }
                    else
                    {
                        lblEmailID.Text = "<a href=\"mailto:" + objLoginToken.CompanyEmailID + "\">" + objLoginToken.CompanyEmailID + "</a>";
                        lblEmailTitle.Visible = false;
                    }
                    if (objLoginToken.CompanyWebsite == null || objLoginToken.CompanyWebsite == "")
                    {
                        lblCompanyWebsite.Text = "";
                        lblWebsiteTitle.Visible = false;
                    }
                    else
                    {
                        lblCompanyWebsite.Text = "<a href=\"" + objLoginToken.CompanyWebsite + " \" target=\"_blank\" >" + objLoginToken.CompanyWebsite + "</a>";
                       // lblWebsiteTitle.Visible = true;
                    }

                    //Bind Navigation (Menu) control
                    BindNavigationControl();
                }
                else
                {
                    Response.Redirect("~/Login.aspx", true);
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }

        }

        protected void lnkLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            FormsAuthentication.SignOut();
            Response.Redirect("~/Login.aspx");
        }

        protected void BindNavigationControl()
        {

            //xmlDataSource1.Data = WebCommon.GetMenuData();

            string xmlData = "";
            LoginToken objLoginToken = (LoginToken)HttpContext.Current.Session["LoginToken"];
            xmlData = objLoginToken.NavigationXmlData;
            xmlDataSource1.Data = xmlData;
            xmlDataSource1.DataBind();
        }

	}
}