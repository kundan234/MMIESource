﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using System.Web.Configuration;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;
using System.Threading;

namespace MMIE.ADM
{
    public partial class DataBaseBackup : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                GetDBBackupList();
        }

        void GetDBBackupList()
        {
            UserAdminBO objUseradminBO = new UserAdminBO();
            gvBackupList.DataSource = objUseradminBO.GetBackupList();
            gvBackupList.DataBind();
        }

        protected void btnDBCreate_Click(object sender, EventArgs e)
        {
            UserAdminBO objUseradminBO = new UserAdminBO();
            DatabaseBackUp objBackup = new DatabaseBackUp();
            string path = string.Empty;
            string fileName = txtbckup.Text.Trim() + string.Format("{0:00}", DateTime.Today.Date.Day) + string.Format("{0:00}", DateTime.Today.Date.Month)
               + string.Format("{0:00}", DateTime.Today.Date.Year);

            string name = WebConfigurationManager.AppSettings["strDatabaseName"];
            path = Server.MapPath(WebConfigurationManager.AppSettings["BackUpFolder"]);

            string backupName = txtbckup.Text.Trim();
            bool status = objUseradminBO.DataBaseBackUp(path, name, fileName, backupName, LoginToken.LoginId);
            if (status)
                lblError.Text = "BackUp has been successfully created.";
            else
                lblError.Text = "There is something wrong with backUp.";
             GetDBBackupList();

        }


        bool ResponseFile(HttpRequest _Request, HttpResponse _Response, string _fileName, string _fullPath, long _speed)
        {
            try
            {
                FileStream myFile = new FileStream(_fullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                BinaryReader br = new BinaryReader(myFile);
                try
                {
                    _Response.AddHeader("Accept-Ranges", "bytes");
                    _Response.Buffer = false;
                    long fileLength = myFile.Length;
                    long startBytes = 0;

                    int pack = 10240; //10K bytes
                    int sleep = (int)Math.Floor((double)(1000 * pack / _speed)) + 1;
                    if (_Request.Headers["Range"] != null)
                    {
                        _Response.StatusCode = 206;
                        string[] range = _Request.Headers["Range"].Split(new char[] { '=', '-' });
                        startBytes = Convert.ToInt64(range[1]);
                    }
                    _Response.AddHeader("Content-Length", (fileLength - startBytes).ToString());
                    if (startBytes != 0)
                    {
                        _Response.AddHeader("Content-Range", string.Format(" bytes {0}-{1}/{2}", startBytes, fileLength - 1, fileLength));
                    }
                    _Response.AddHeader("Connection", "Keep-Alive");
                    _Response.ContentType = "application/octet-stream";
                    _Response.AddHeader("Content-Disposition", "attachment;filename=" + HttpUtility.UrlEncode(_fileName, System.Text.Encoding.UTF8));

                    br.BaseStream.Seek(startBytes, SeekOrigin.Begin);
                    int maxCount = (int)Math.Floor((double)((fileLength - startBytes) / pack)) + 1;

                    for (int i = 0; i < maxCount; i++)
                    {
                        if (_Response.IsClientConnected)
                        {
                            _Response.BinaryWrite(br.ReadBytes(pack));
                            Thread.Sleep(sleep);
                        }
                        else
                        {
                            i = maxCount;
                        }
                    }
                }
                catch
                {
                    return false;
                }
                finally
                {
                    br.Close();
                    myFile.Close();
                }
            }
            catch
            {
                return false;
            }
            return true;
        }


        protected void gvBackupList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvBackupList.PageIndex = e.NewPageIndex;
            GetDBBackupList();
        }

        protected void gvBackupList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Download")
            {
                lblError.Text = "";
                GridViewRow grArtist = ((Control)
                   (e.CommandSource)).NamingContainer as GridViewRow;
                string fileName = gvBackupList.DataKeys[grArtist.RowIndex]["BackupFileName"].ToString();
                string path = Server.MapPath(WebConfigurationManager.AppSettings["BackUpFolder"]);
                path += fileName;
                bool success = ResponseFile(Page.Request, Page.Response, fileName, path, 1024000);
                if (!success)
                {
                    lblError.Text = "Downloading Error!";
                }
                else
                {
                    lblError.Text = "";
                }
            }
        }
    }
}