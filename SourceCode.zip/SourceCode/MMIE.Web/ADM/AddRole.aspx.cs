﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.ADM
{
    public partial class AddRole : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //set client side error message
                

                if (!Page.IsPostBack)
                {
                    ViewState["IsEdit"] = false;
                    if (Request.QueryString["roleid"] != null)
                    {
                        int roleID = Convert.ToInt32(Request.QueryString["roleid"].ToString());
                        ViewState["roleid"] = roleID;
                        BindRoleDetail(roleID);
                    }
                }

                PagePermission();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSubmit.Enabled = LoginToken.IsAddOn;
            }
        }


        private void BindRoleDetail(int roleID)
        {
            UserAdminBO useradm = new UserAdminBO();
            Role objRole = new Role();
            objRole.RoleId = roleID;
            Role objRetRole = useradm.GetRoleByID(objRole);
            ViewState["IsEdit"] = true;

            txtRoleCode.Text = objRetRole.RoleCode;
            txtRoleName.Text = objRetRole.RoleName;
            if (objRetRole.IsAddOn)
                rdNew.SelectedIndex = 0;
            else
                rdNew.SelectedIndex = 1;
            if (objRetRole.IsModify)
                rdModify.SelectedIndex = 0;
            else
                rdModify.SelectedIndex = 1;

            if (objRetRole.IsCancelOn)
                rdCancel.SelectedIndex = 0;
            else
                rdCancel.SelectedIndex = 1;
            if (objRetRole.IsDeleteOn)
                rdDelete.SelectedIndex = 0;
            else
                rdDelete.SelectedIndex = 1;

            if (objRetRole.IsPrintOn)
                rdPrint.SelectedIndex = 0;
            else
                rdPrint.SelectedIndex = 1;

            if (objRetRole.IsPrintExportOn)
                rdPrintExport.SelectedIndex = 0;
            else
                rdPrintExport.SelectedIndex = 1;

            rbtAprover_Recieved.SelectedValue=Convert.ToInt32( objRetRole.IsApproverRecievedOn).ToString();
            rbtApprover_Reimboursment.SelectedValue=Convert.ToInt32(objRetRole.IsApproverReimbursementOn).ToString();
            rbtApprover_Return.SelectedValue = Convert.ToInt32(objRetRole.IsApproverReturnOn).ToString();
            rbtChangeDate.SelectedValue = Convert.ToInt32(objRetRole.IsChangeDateOn).ToString();
            rbtBranchSelect.SelectedValue = Convert.ToInt32(objRetRole.IsChangeBranchOn).ToString();
            rbtRateChange.SelectedValue = Convert.ToInt32(objRetRole.IsRateChangeOn).ToString();
            rbtPartialCancellation.SelectedValue = Convert.ToInt32(objRetRole.IsPartialCancellationOn).ToString();
            rbtCreditLimitChange.SelectedValue = Convert.ToInt32(objRetRole.IsCreditLimitChangeAllowed).ToString();
                        

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }


            try
            {
                if (Page.IsValid)
                {
                    //Set Role Detail
                    Role objRole = new Role();
                    objRole.RoleCode = txtRoleCode.Text;
                    objRole.RoleName = txtRoleName.Text;
                    objRole.AddedBy = LoginToken.LoginId;
                    objRole.LastModBy = LoginToken.LoginId;

                    // Modified on 04th Jan 2012 by Budha Singh to add Roles
                    if( rdNew.SelectedIndex==0)
                    objRole.IsAddOn = true;
                    else
                    objRole.IsAddOn=false;
                    if( rdModify.SelectedIndex==0)
                    objRole.IsModify =true;
                    else
                        objRole.IsModify = false;

                    if (rdCancel.SelectedIndex == 0)
                        objRole.IsCancelOn = true;
                    else
                        objRole.IsCancelOn = false ;

                    if(rdDelete.SelectedIndex==0)
                        objRole.IsDeleteOn = true;
                    else
                        objRole.IsDeleteOn = false;

                    if (rdPrint.SelectedIndex == 0)
                        objRole.IsPrintOn = true;
                    else
                        objRole.IsPrintOn = false;

                    if (rdPrintExport.SelectedIndex == 0)
                        objRole.IsPrintExportOn = true;
                    else
                        objRole.IsPrintExportOn = Convert.ToBoolean(Convert.ToInt16(rdPrintExport.SelectedValue));

                    objRole.IsApproverRecievedOn = Convert.ToBoolean(Convert.ToInt16(rbtAprover_Recieved.SelectedValue));
                    objRole.IsApproverReimbursementOn = Convert.ToBoolean(Convert.ToInt16(rbtApprover_Reimboursment.SelectedValue));
                    objRole.IsApproverReturnOn = Convert.ToBoolean(Convert.ToInt16(rbtApprover_Return.SelectedValue));
                    objRole.IsChangeDateOn = Convert.ToBoolean(Convert.ToInt16(rbtChangeDate.SelectedValue));
                    objRole.IsChangeBranchOn = Convert.ToBoolean(Convert.ToInt16(rbtBranchSelect.SelectedValue));
                    objRole.IsRateChangeOn = Convert.ToBoolean(Convert.ToInt16(rbtRateChange.SelectedValue));
                    objRole.IsPartialCancellationOn = Convert.ToBoolean(Convert.ToInt16(rbtPartialCancellation.SelectedValue));
                    objRole.IsCreditLimitChangeAllowed = Convert.ToBoolean(Convert.ToInt16(rbtCreditLimitChange.SelectedValue));
                        
                    // End Modified on 04th Jan 2012 by Budha Singh to add Roles

                    objRole.CompanyID = (short)LoginToken.CompanyID;
                    objRole.FinancialYearID = (short)LoginToken.FinancialYearID;
                    if (ViewState["roleid"] != null)
                    {
                        objRole.ActionType = EnumActionType.Update;
                        objRole.RoleId = Convert.ToInt32(ViewState["roleid"]);
                    }
                    else
                    {
                        objRole.ActionType = EnumActionType.Insert;
                    }

                    //Calling Save operation of IUserAdmin Service
                    UserAdminBO useradm = new UserAdminBO();
                    bool status = useradm.SaveRole(objRole);
                    if (status == true)
                    {
                        //display succuss message
                        lblError.Text = ExceptionMessage.GetMessage("1000016");
                        lblError.Visible = true;
                       
                        ViewState["IsEdit"] = false;
                    }
                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
           
            
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                //TODO: it will handled by client side function invoking

                txtRoleCode.Text = "";
                txtRoleName.Text = "";
                lblError.Text = "";
                rbtApprover_Reimboursment.SelectedIndex = 0;
                rbtApprover_Return.SelectedIndex = 0;
                rbtAprover_Recieved.SelectedIndex = 0;
                rbtBranchSelect.SelectedIndex = 0;
                rbtChangeDate.SelectedIndex = 0;
                rdCancel.SelectedIndex = 0;
                rdDelete.SelectedIndex = 0;
                rdModify.SelectedIndex = 0;
                rdNew.SelectedIndex = 0;
                rdPrint.SelectedIndex = 0;
                rdPrintExport.SelectedIndex = 0;
                rbtPartialCancellation.SelectedIndex = 0;

                ViewState["IsEdit"] = false;

            }

            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }



        #region Client Side Validation

     

        #endregion
    }
}