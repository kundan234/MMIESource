﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;

using MMIE.Data;
using MMIE.Data.Common;
////using MMIE.Data.ADM;

using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;

namespace MMIE.ADM
{
    public partial class ModifyUser : BasePage
    {
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;

        List<UserLogin> lstUserLogin = null;
        DataSet ds = null;
        int iPageCount = 0;


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                lblError.Text = "";
                lblError.Visible = false;
                errorMessage.InnerHtml = "";
                errorMessage.Visible = false;

                MasterLookupBO mstlookup = new MasterLookupBO();

                if (!Page.IsPostBack)
                {
                    BindDropDownControl(drpUserType, mstlookup.GetLookupItemListByCategoryName("User Type"));
                    GridView1.PageSize = GRID_PAGESIZE;
                    ViewState["IsEdit"] = false;
                }
                else
                {
                    string eventTarget = Request.Form["__EVENTTARGET"];
                    if (eventTarget != null)
                    {
                        if (eventTarget.IndexOf("nav") >= 0)
                        {

                            int pageIndexPos = eventTarget.LastIndexOf("_");
                            string strIndex = eventTarget.Substring(pageIndexPos + 1);
                            int iNewIndex = Convert.ToInt32(strIndex);
                            ViewState["SubmittedNewIndex"] = iNewIndex;
                            if (iNewIndex > 0)
                                BindData(iNewIndex - 1);
                            else
                                BindData(iNewIndex);
                        }

                    }
                    //Recreate Buttons for Paging
                    CreateNavigation();
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }


        }


      

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                CallSearch();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
        }

        public string MakeLoginIDLink(int userLoginID, string loginID)
        {
            string ret;
            string str;
            string pageName;
            pageName = "MaintainUser.aspx";
            str = pageName + "?userloginid=" + userLoginID.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + loginID + "</a>";
            return ret;
        }


        public void CallSearch()
        {
            GridView1.PageIndex = 0;

            UserLogin objUserLogin = new UserLogin();
            objUserLogin.LoginId = txtLoginID.Text;
            objUserLogin.UserTypeID = Convert.ToInt32(drpUserType.SelectedValue);
            objUserLogin.CurrentIndex = 0;
            objUserLogin.PageSize = GlobalConstant.PageSize;
            //List<UserLogin> lstUserLogin = UserAdminServiceAgent.SearchUserLogin(objUserLogin);

            //Save Search Options in ViewState
            ViewState[VS_SEARCH] = objUserLogin;

            BindData(0);

        }

        private DataSet SearchUserLogin(UserLogin objUserLogin)
        {
            //Call service operation to get data from database source
            UserAdminBO useradm = new UserAdminBO();
            lstUserLogin = useradm.SearchUserLogin(objUserLogin);
            DataTable dt = ORHelper<UserLogin>.GenericListToDataTable(lstUserLogin);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        private void BindData(int currentPageIndex)
        {
            GridView1.PageIndex = 0;

            PagedDataSource objPagedDataSource = new PagedDataSource();
            objPagedDataSource.AllowCustomPaging = true;
            objPagedDataSource.PageSize = GRID_PAGESIZE;
            objPagedDataSource.CurrentPageIndex = currentPageIndex;

            //Get search option from viewstate
            UserLogin objUserLogin = (UserLogin)ViewState[VS_SEARCH];
            objUserLogin.CurrentIndex = currentPageIndex;
            //Save Search Option again
            ViewState[VS_SEARCH] = objUserLogin;

            //Call service operation to get data from database source
            ds = SearchUserLogin(objUserLogin);

            if (ds.Tables[0].Rows.Count > 0)
            {

                pnlNavigation.Visible = true;
                this.GridView1.Visible = true;

                //Bind data in ViewGrid.
                objPagedDataSource.VirtualCount = Convert.ToInt32(ds.Tables[0].Rows[0]["MaximumRows"]);
                //Save Virtual Count in ViewState
                ViewState[VS_MAXROWS] = objPagedDataSource.VirtualCount;
                CreateNavigation(currentPageIndex, objPagedDataSource.PageSize, objPagedDataSource.VirtualCount);

                objPagedDataSource.DataSource = ds.Tables[0].DefaultView;
                GridView1.DataSource = objPagedDataSource;
                GridView1.DataBind();
            }
            else
            {
                ShowError("No Records Found");
                GridView1.DataSource = null;
                GridView1.DataBind();
                pnlNavigation.Visible = false;
            }
        }

        protected void ShowError(string a_sMsg)
        {
            errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            if (a_sMsg.Length > 0)
            {
                errorMessage.Visible = true;
            }
            else
            {
                errorMessage.Visible = false;
            }
        }

        #region GridView Event Handler

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.ToString())
            {
                case "Delet":
                    UserAdminBO useradm = new UserAdminBO();
                    try
                    {
                        int userLoginID = Convert.ToInt32(e.CommandArgument.ToString().Trim());
                        UserLogin objUserLogin = new UserLogin();
                        objUserLogin.UserLoginId = userLoginID;
                        objUserLogin.LastModBy = LoginToken.LoginId;
                        objUserLogin.ActionType = EnumActionType.Delete;
                        bool status = useradm.DeleteUser(objUserLogin);
                        if (status)
                        {
                            CallSearch();

                            lblError.Text = ExceptionMessage.GetMessage("1000014");
                            lblError.Visible = true;
                        }

                    }
                    catch (Exception ex) //Exception in agent layer itself
                    {
                        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                        LogManager.WriteErrorLogInDB(ex);
                    }
                    break;
            }
        }
       

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton lnkDelete = (LinkButton)e.Row.FindControl("lnkDelete");
                lnkDelete.Enabled = LoginToken.IsDeleteOn;
                if (lnkDelete.Enabled!=true)
                {
                    lnkDelete.Attributes.Add("OnClick", "return confirm('You cant delete this User?');");
                }
                else
                {
                    lnkDelete.Attributes.Add("OnClick", "return confirm('Are you sure to Delete this User?');");
                }
            }

        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BindData(GridView1.PageIndex + 1);
        }

        #endregion

        #region Create Paging Navigation and Event handler

        private void CreateNavigation()
        {
            if (ViewState[VS_CURRENTINDEX] == null || ViewState[VS_PAGESIZE] == null || ViewState[VS_MAXROWS] == null)
            {
                return;
            }
            else
            {
                CreateNavigation((int)ViewState[VS_CURRENTINDEX], (int)ViewState[VS_PAGESIZE], (int)ViewState[VS_MAXROWS]);
            }
        }

        private void CreateNavigation(int currentPageIndex, int a_iPageSize, int a_iRowCount)
        {
            //Save the arguments in ViewState
            ViewState[VS_CURRENTINDEX] = currentPageIndex;
            ViewState[VS_PAGESIZE] = a_iPageSize;
            ViewState[VS_MAXROWS] = a_iRowCount;
            pnlNavigation.Controls.Clear();
            if (a_iPageSize == 0)
            {
                return;
            }

            //Get the TotalNumber of Pages
            //int iPageCount = 0;
            iPageCount = 0;
            if (a_iRowCount % a_iPageSize == 0)
            {
                iPageCount = a_iRowCount / a_iPageSize;
            }
            else
            {
                iPageCount = (a_iRowCount / a_iPageSize) + 1;
            }

            if (iPageCount <= 1)
            {
                return;
            }

            //Check if LeftDots are to be displayed
            if ((currentPageIndex + 1) - 5 > 1)
            {
                //Start when left dots are visible then show << button also
                LinkButton linkFirst = new LinkButton();
                linkFirst.Text = "<<";
                linkFirst.CssClass = "lftmenu";
                linkFirst.ID = "linkFirst";
                linkFirst.Click += new EventHandler(linkFirst_Click);
                pnlNavigation.Controls.Add(linkFirst);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
                //End when left dots are visible then show << button also

                int iLIndex = (currentPageIndex + 1) - 5 - 1;
                //Add LeftDots
                LinkButton btnLeftDots = new LinkButton();
                btnLeftDots.Text = "...";
                btnLeftDots.CssClass = "lftmenu";
                btnLeftDots.ID = "nav_" + iLIndex.ToString();
                btnLeftDots.Attributes.Add("onclick", "__doPostBack('" + btnLeftDots.ClientID + "',' " + iLIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            int iLeftIndex = 1;

            if (currentPageIndex + 1 - 5 > 1)
            {
                iLeftIndex = currentPageIndex + 1 - 5;
            }

            //Create the Number buttons on the left side of the index
            for (int i = iLeftIndex; i <= currentPageIndex; i++)
            {
                LinkButton btnLeftNumbers = new LinkButton();
                btnLeftNumbers.Text = i.ToString();
                btnLeftNumbers.CssClass = "lftmenu";
                btnLeftNumbers.ID = "nav_" + i.ToString();
                btnLeftNumbers.Attributes.Add("onclick", "__doPostBack('" + btnLeftNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Display the Current Page Number
            Label lblCurrent = new Label();
            lblCurrent.Text = Convert.ToString(currentPageIndex + 1);
            lblCurrent.CssClass = "textNormal";
            pnlNavigation.Controls.Add(lblCurrent);
            pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

            //Create Right Number buttons
            int iRightIndex = iPageCount;

            if (currentPageIndex + 1 + 5 < iRightIndex)
            {
                iRightIndex = 5;//currentPageIndex + 1 + 5;
            }

            for (int i = currentPageIndex + 2; i <= iRightIndex; i++)
            {
                LinkButton btnRightNumbers = new LinkButton();
                btnRightNumbers.Text = i.ToString();
                btnRightNumbers.CssClass = "lftmenu";
                btnRightNumbers.ID = "nav_" + i.ToString();
                btnRightNumbers.Attributes.Add("onclick", "__doPostBack('" + btnRightNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Check if RightDots are to be displayed
            if ((currentPageIndex + 1) + 5 < iPageCount)
            {
                int iRIndex = ((currentPageIndex + 1) + 5) + 1;
                //Add RightDots
                LinkButton btnRightDots = new LinkButton();
                btnRightDots.Text = "...";
                btnRightDots.CssClass = "lftmenu";
                btnRightDots.ID = "nav_" + iRIndex.ToString();
                btnRightDots.Attributes.Add("onclick", "__doPostBack('" + btnRightDots.ClientID + "',' " + iRIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

                //Start when right dots are visible then show >> button also
                LinkButton linkLast = new LinkButton();
                linkLast.Text = ">>";
                linkLast.CssClass = "lftmenu";
                linkLast.ID = "linkLast";
                linkLast.Click += new EventHandler(linkLast_Click);
                pnlNavigation.Controls.Add(linkLast);
                //End when left dots are visible then show << button also
            }
        }

        protected void linkFirst_Click(object sender, EventArgs e)
        {
            BindData(0);
        }

        protected void linkLast_Click(object sender, EventArgs e)
        {
            BindData(iPageCount - 1);
        }

        #endregion
    }
}