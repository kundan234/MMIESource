﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.ADM
{
    public partial class UpdateLoginSchedule : BasePage
    {
        UserAdminBO objUserAdminBO = new UserAdminBO();
        protected void PagePermission()
        {
            if (LoginToken != null)
            {

                btnUpdate.Enabled = LoginToken.IsModify;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            lblSaveMessage.Text = "";

            
            if (!IsPostBack)
                BindDropDownControl(ddlEmpdetails, mstlookup.GetLookupsList(LookupNames.UserList));
            PagePermission();
        }


        public void BindDropDownControl(DropDownList ddlEmpdetails, List<LookupItem> lstLookups)
        {
            ddlEmpdetails.DataSource = lstLookups;
            ddlEmpdetails.DataValueField = "ItemId";
            ddlEmpdetails.Items.Add(new ListItem("Select Employee","0"));
            ddlEmpdetails.AppendDataBoundItems = true;
            ddlEmpdetails.DataTextField = "ItemName";
            ddlEmpdetails.DataBind();
            
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                UserLogin objUserLogin = new UserLogin();
                objUserLogin.UserLoginId = Convert.ToInt32(ddlEmpdetails.SelectedValue);

                if (chkMonInActive.Checked)
                {
                    objUserLogin.MonStartTime = null;
                    objUserLogin.MonEndTime = null;
                }
                else
                {
                    objUserLogin.MonStartTime = txtMonStartTime.Text;
                    objUserLogin.MonEndTime = txtMonEndTime.Text;
                }
                if (chkTueInActive.Checked)
                {
                    objUserLogin.TueStartTime = null;
                    objUserLogin.TueEndTime = null;
                }
                else
                {
                    objUserLogin.TueStartTime = txtTueStartTime.Text;
                    objUserLogin.TueEndTime = txtTueEndTime.Text;
                }
                if (chkWedInActive.Checked)
                {
                    objUserLogin.WedStartTime = null;
                    objUserLogin.WedEndTime = null;
                }
                else
                {
                    objUserLogin.WedStartTime = txtWedStartTime.Text;
                    objUserLogin.WedEndTime = txtWedEndTime.Text;
                }
                if (chkThurInActive.Checked)
                {
                    objUserLogin.ThurStartTime = null;
                    objUserLogin.ThurEndTime = null;
                }
                else
                {
                    objUserLogin.ThurStartTime = txtThurStartTime.Text;
                    objUserLogin.ThurEndTime = txtThurEndTime.Text;
                }
                if (chkFriInActive.Checked)
                {
                    objUserLogin.FriStartTime = null;
                    objUserLogin.FriEndTime = null;
                }
                else
                {
                    objUserLogin.FriStartTime = txtFriStartTime.Text;
                    objUserLogin.FriEndTime = txtFriEndTime.Text;
                }

                if (chkSatInActive.Checked)
                {
                    objUserLogin.SatStartTime = null;
                    objUserLogin.SatEndTime = null;
                }
                else
                {
                    objUserLogin.SatStartTime = txtSatStartTime.Text;
                    objUserLogin.SatEndTime = txtSatEndTime.Text;
                }

                if (chkSunInActive.Checked)
                {
                    objUserLogin.SunStartTime = null;
                    objUserLogin.SunEndTime = null;
                }
                else
                {
                    objUserLogin.SunStartTime = txtSunStartTime.Text;
                    objUserLogin.SunEndTime = txtSunEndTime.Text;
                }

                objUserAdminBO.UpdateLoginSchedule(objUserLogin);
                lblSaveMessage.Text = "Data Saved successfully.";
                
            }
            catch (Exception ex)
            {
                lblSaveMessage.Text = "Data not Saved successfully.";
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);

            }
        }
        
        

        protected void ddlEmpdetails_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (ddlEmpdetails.SelectedIndex == 0)
            {
                tblDays.Visible = false;
            }
            else
            {
                tblDays.Visible = true;
                UserLogin objUserLogin= objUserAdminBO.GetLoginSchedule(Convert.ToInt32(ddlEmpdetails.SelectedValue));

                if (objUserLogin.MonStartTime==null)
                {
                    chkMonInActive.Checked = true;
                    txtMonStartTime.Text = null;
                    txtMonEndTime.Text = null;
                }
                else
                {
                    chkMonInActive.Checked = false;
                    txtMonStartTime.Text = objUserLogin.MonStartTime;
                    txtMonEndTime.Text = objUserLogin.MonEndTime;
                }
                if (objUserLogin.TueStartTime==null)
                {
                    chkTueInActive.Checked = true;
                    txtTueStartTime.Text = null;
                    txtTueEndTime.Text = null;
                }
                else
                {
                    chkTueInActive.Checked = false;
                    txtTueStartTime.Text = objUserLogin.TueStartTime;
                    txtTueEndTime.Text = objUserLogin.TueEndTime;
                }
                if (objUserLogin.WedStartTime==null)
                {
                    chkWedInActive.Checked = true;
                    txtWedStartTime.Text = null;
                    txtWedEndTime.Text = null;
                }
                else
                {
                    chkWedInActive.Checked = false;
                    txtWedStartTime.Text = objUserLogin.WedStartTime;
                    txtWedEndTime.Text = objUserLogin.WedEndTime;
                }
                if (objUserLogin.ThurStartTime==null)
                {
                    chkThurInActive.Checked = true;
                    txtThurStartTime.Text = null;
                    txtThurEndTime.Text = null;
                }
                else
                {
                    chkThurInActive.Checked = false;
                    txtThurStartTime.Text=objUserLogin.ThurStartTime;
                    txtThurEndTime.Text=objUserLogin.ThurEndTime;
                }
                if (objUserLogin.FriStartTime==null)
                {
                    chkFriInActive.Checked = true;
                    txtFriStartTime.Text = null;
                    txtFriEndTime.Text = null;
                }
                else
                {
                    chkFriInActive.Checked = false;
                    txtFriStartTime.Text=objUserLogin.FriStartTime;
                    txtFriEndTime.Text=objUserLogin.FriEndTime;
                }

                if (objUserLogin.SatStartTime==null)
                {
                    chkSatInActive.Checked = true;
                    txtSatStartTime.Text = null;
                    txtSatEndTime.Text = null;
                }
                else
                {
                    chkSatInActive.Checked = false;
                    txtSatStartTime.Text=objUserLogin.SatStartTime;
                    txtSatEndTime.Text=objUserLogin.SatEndTime;
                }

                if (objUserLogin.SunStartTime==null)
                {
                    chkSunInActive.Checked = true;
                    txtSunStartTime.Text = null;
                    txtSunEndTime.Text = null;
                }
                else
                {
                    chkSunInActive.Checked = false;
                    txtSunStartTime.Text=objUserLogin.SunStartTime;
                    txtSunEndTime.Text=objUserLogin.SunEndTime;
                }
           

            }
        }

    }
}