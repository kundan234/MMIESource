﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.ADM
{
    public partial class MaintainUser : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            PagePermission();
            try
            {
                //set client side error message
                //SetErrorMessage();

                if (!Page.IsPostBack)
                {
                    ViewState["IsEdit"] = false;
                    MasterLookupBO mstlookup = new MasterLookupBO();

                    BindDropDownControl(drpRole, mstlookup.GetLookupsList(LookupNames.Role));
                    BindDropDownControl(drpUser, mstlookup.GetLookupsList(LookupNames.Employee));
                    BindDropDownControl(ddlCompany, mstlookup.GetLookupsList(LookupNames.Company));
                    BindDropDownControl(drpUserType, mstlookup.GetLookupItemListByCategoryName("User Type"));

                    if (Request.QueryString["userloginid"] != null)
                    {
                        int userLoginID = Convert.ToInt32(Request.QueryString["userloginid"].ToString());
                        ViewState["userloginid"] = userLoginID;
                        BindUserLoginDetail(userLoginID);
                    }
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
               
                btnSubmit.Enabled = LoginToken.IsAddOn;
                ddlCompany.Enabled = LoginToken.IsChangeBranchOn;
            }
        }

        private void BindUserLoginDetail(int userLoginID)
        {
            ViewState["IsEdit"]=true;
            UserLogin objUserLogin = new UserLogin();
            objUserLogin.UserLoginId = userLoginID;
            UserAdminBO useradm = new UserAdminBO();

            UserCE objUserCE = useradm.GetUserLoginByID(objUserLogin);
            objUserLogin = objUserCE.UserLogin;

            List<Role> lstRole = objUserCE.RoleList;
            UserDetail objUserDetail = objUserCE.UserDetail;

            txtLoginID.Text = objUserLogin.LoginId;
            txtPassword.Attributes.Add("value", objUserLogin.Password);
           
            txtconfirmpassword.Attributes.Add("value", objUserLogin.Password);
            ddlCompany.SelectedValue =Convert.ToString(objUserCE.UserLogin.CompanyID);
            drpUserType.SelectedIndex = drpUserType.Items.IndexOf(drpUserType.Items.FindByValue(objUserLogin.UserTypeID.ToString()));

            if (lstRole.Count > 0)
            {
                drpRole.SelectedIndex = drpRole.Items.IndexOf(drpRole.Items.FindByValue(lstRole[0].RoleId.ToString()));
            }

            if (objUserDetail != null)
            {
                drpUser.SelectedIndex = drpUser.Items.IndexOf(drpUser.Items.FindByValue(objUserDetail.UserDetailID.ToString()));
            }

            //Disable the field(s) for Modify user login infomation
            drpUser.Enabled = false;
            drpUserType.Enabled = false;
            txtLoginID.Enabled = false;

        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
        
            objDD.DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }
            try
            {
               

                
                
                
                if (Page.IsValid)
                {
                    UserCE objUserCE = new UserCE();

                    //Set Login Detail
                    objUserCE.UserLogin = new UserLogin();
                    objUserCE.UserLogin.LoginId = txtLoginID.Text;
                    objUserCE.UserLogin.Password = txtPassword.Text;
                    objUserCE.UserLogin.UserTypeID = Convert.ToInt32(drpUserType.SelectedValue);

                    objUserCE.UserLogin.AddedBy = LoginToken.LoginId;
                    objUserCE.UserLogin.LastModBy = LoginToken.LoginId;
                    objUserCE.UserLogin.CompanyID = Convert.ToInt16( ddlCompany.SelectedValue.ToString())  ; 
                    objUserCE.UserLogin.FinancialYearID = (short)LoginToken.FinancialYearID;

                    if (ViewState["userloginid"] != null)
                    {
                        objUserCE.UserLogin.ActionType = EnumActionType.Update;
                        objUserCE.UserLogin.UserLoginId = Convert.ToInt32(ViewState["userloginid"]);
                    }
                    else
                    {
                        objUserCE.UserLogin.ActionType = EnumActionType.Insert;
                    }


                    //Set Role Detail
                    Role objRole = new Role();
                    objRole.RoleId = Convert.ToInt32(drpRole.SelectedValue);
                    objRole.RoleName = drpRole.SelectedItem.Text;

                    objUserCE.RoleList = new List<Role>();
                    objUserCE.RoleList.Add(objRole);

                    //Set User Detail
                    //-----------comment by mithlesh
                    objUserCE.UserDetail = new UserDetail();
                    objUserCE.UserDetail.UserDetailID = Convert.ToInt32(drpUser.SelectedValue);
                    objUserCE.UserDetail.UserCode = drpUser.SelectedItem.Text;
                    //----------------------------
                    //Calling Save operation of IUserAdmin Service
                    UserAdminBO admuser = new UserAdminBO();
                    bool status = admuser.SaveUser(objUserCE);


                    //Calling Save operation of IUserAdmin Service
                   // bool status = UserAdminServiceAgent.SaveUser(objUserCE);


                    //bool status = UserAdminBO   U UserAdminServiceAgent.SaveUser(objUserCE);


                    if (status == true)
                    {
                        //display succuss message
                        lblError.Text = ExceptionMessage.GetMessage("1000013");
                        lblError.Visible = true;
                    }
                }

            }
           
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
                if (ex.Message.Contains("1"))
                {
                    lblError.Text = "already exist";
                }

            }

            
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                //TODO: it will handled by client side function invoking
                //reqLoginID.ErrorMessage = "";
                //cusvalLoginID.ErrorMessage = "";
                //reqPassword.ErrorMessage = "";
                reqConfirmpassword.ErrorMessage = "";
                comConfirmpassword.ErrorMessage = "";
                reqRole.ErrorMessage = "";
               // reqEmail.ErrorMessage = "";
               // regEmail.ErrorMessage = "";

                // change by ankit: for reset the controls.
                txtconfirmpassword.Text = "";
                lblError.Text = "";
                //txtEmail.Text = "";
                txtLoginID.Text = "";
                ddlCompany.SelectedIndex = 0;
                drpRole.SelectedIndex = 0;
                drpUserType.SelectedIndex = 0;
                drpUser.SelectedIndex = 0;
                //txtPassword.Text = "";
                if(ViewState["userloginid"] !=null)
                {
                    BindUserLoginDetail(Convert.ToInt32(ViewState["userloginid"].ToString()));
                }
                

                //set client side error message
                //SetErrorMessage();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void drpUserType_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblUser.Text = "Select " + drpUserType.SelectedItem.Text;
            try
            {

                // BindDropDownControl(drpUser, MasterLookupServiceAgent.GetLookupsList((LookupNames)Enum.Parse(typeof(LookupNames), drpUserType.SelectedItem.Text)));
            }
            catch (Exception) { }
        }

        #region Client Side Validation

        //protected void SetErrorMessage()
        //{
        //    //reqLoginID.ErrorMessage = ExceptionMessage.GetMessage("1000004");
        //    //cusvalLoginID.ErrorMessage = ExceptionMessage.GetMessage("1000005");
        //    //reqPassword.ErrorMessage = ExceptionMessage.GetMessage("1000006");
        //    reqConfirmpassword.ErrorMessage = ExceptionMessage.GetMessage("1000008");
        //    comConfirmpassword.ErrorMessage = ExceptionMessage.GetMessage("1000009");
        //    reqRole.ErrorMessage = ExceptionMessage.GetMessage("1000010");
        //   // reqEmail.ErrorMessage = ExceptionMessage.GetMessage("1000011");
        //    //regEmail.ErrorMessage = ExceptionMessage.GetMessage("1000012");
        //}

        #endregion
    }
}