﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.ADM
{
    public partial class ModifyRole : BasePage
    {
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;

        List<Role> lstUserLogin = null;
        DataSet ds = null;
        int iPageCount = 0;


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                lblError.Text = "";
                lblError.Visible = false;
                errorMessage.InnerHtml = "";
                errorMessage.Visible = false;


                if (!Page.IsPostBack)
                {
                    GridView1.PageSize = GRID_PAGESIZE;
                    CallSearch();
                    ViewState["IsEdit"] = false;
                }
                else
                {
                    string eventTarget = Request.Form["__EVENTTARGET"];
                    if (eventTarget != null)
                    {
                        if (eventTarget.IndexOf("nav") >= 0)
                        {

                            int pageIndexPos = eventTarget.LastIndexOf("_");
                            string strIndex = eventTarget.Substring(pageIndexPos + 1);
                            int iNewIndex = Convert.ToInt32(strIndex);
                            ViewState["SubmittedNewIndex"] = iNewIndex;
                            if (iNewIndex > 0)
                                BindData(iNewIndex - 1);
                            else
                                BindData(iNewIndex);
                        }

                    }
                    //Recreate Buttons for Paging
                    CreateNavigation();
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }


        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                CallSearch();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
        }

        public string MakeRoleIDLink(int roleID, string rolename)
        {
            string ret;
            string str;
            string pageName;
            pageName = "AddRole.aspx";
            str = pageName + "?roleid=" + roleID.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + rolename + "</a>";
            return ret;
        }


        public void CallSearch()
        {
            GridView1.PageIndex = 0;

            Role objRole = new Role();
            objRole.RoleName = txtRoleName.Text;
            objRole.RoleCode = txtRoleCode.Text;
            objRole.CurrentIndex = 0;
            objRole.PageSize = GlobalConstant.PageSize;

            //Save Search Options in ViewState
            ViewState[VS_SEARCH] = objRole;

            BindData(0);

        }

        private DataSet SearchUserLogin(Role objRole)
        {
            //Call service operation to get data from database source
            UserAdminBO useradm = new UserAdminBO();
            lstUserLogin = useradm.SearchRole(objRole);
            //lstUserLogin = UserAdminServiceAgent.SearchRole(objRole);
            DataTable dt = ORHelper<Role>.GenericListToDataTable(lstUserLogin);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        private void BindData(int currentPageIndex)
        {
            GridView1.PageIndex = 0;

            PagedDataSource objPagedDataSource = new PagedDataSource();
            objPagedDataSource.AllowCustomPaging = true;
            objPagedDataSource.PageSize = GRID_PAGESIZE;
            objPagedDataSource.CurrentPageIndex = currentPageIndex;

            //Get search option from viewstate
            Role objRole = (Role)ViewState[VS_SEARCH];
            objRole.CurrentIndex = currentPageIndex;
            //Save Search Option again
            ViewState[VS_SEARCH] = objRole;

            //Call service operation to get data from database source
            ds = SearchUserLogin(objRole);

            if (ds.Tables[0].Rows.Count > 0)
            {

                pnlNavigation.Visible = true;
                this.GridView1.Visible = true;

                //Bind data in ViewGrid.
                objPagedDataSource.VirtualCount = Convert.ToInt32(ds.Tables[0].Rows[0]["MaximumRows"]);
                //Save Virtual Count in ViewState
                ViewState[VS_MAXROWS] = objPagedDataSource.VirtualCount;
                CreateNavigation(currentPageIndex, objPagedDataSource.PageSize, objPagedDataSource.VirtualCount);

                objPagedDataSource.DataSource = ds.Tables[0].DefaultView;
                GridView1.DataSource = objPagedDataSource;
                GridView1.DataBind();
            }
            else
            {
                ShowError("No Records Found");
                GridView1.DataSource = null;
                GridView1.DataBind();
                pnlNavigation.Visible = false;
            }
        }

        protected void ShowError(string a_sMsg)
        {
            errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            if (a_sMsg.Length > 0)
            {
                errorMessage.Visible = true;
            }
            else
            {
                errorMessage.Visible = false;
            }
        }

        #region GridView Event Handler

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.ToString())
            {
                case "Delet":
                    try
                    {
                        int roleid = Convert.ToInt32(e.CommandArgument.ToString().Trim());
                        Role objRole = new Role();
                        objRole.RoleId = roleid;
                        objRole.LastModBy = LoginToken.LoginId;
                        objRole.ActionType = EnumActionType.Delete;
                        UserAdminBO useradm = new UserAdminBO();
                        bool status = useradm.DeleteRole(objRole);
                        if (status)
                        {
                            CallSearch();

                            lblError.Text = ExceptionMessage.GetMessage("1000017");
                            lblError.Visible = true;
                        }

                    }
                    catch (Exception ex) //Exception in agent layer itself
                    {
                        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                        LogManager.WriteErrorLogInDB(ex);
                    }
                    break;
            }
        }


        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton lnkDelete = (LinkButton)e.Row.FindControl("lnkDelete");
               
                lnkDelete.Enabled = LoginToken.IsDeleteOn;
                if (lnkDelete.Enabled!=true)
                {
                    lnkDelete.Attributes.Add("OnClick", "return confirm('You cant delete this Role?');");
                }
                else
                {
                    lnkDelete.Attributes.Add("OnClick", "return confirm('Are you sure to Delete this Role?');");
                }
            }
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BindData(GridView1.PageIndex + 1);
        }

        #endregion

        #region Create Paging Navigation and Event handler

        private void CreateNavigation()
        {
            if (ViewState[VS_CURRENTINDEX] == null || ViewState[VS_PAGESIZE] == null || ViewState[VS_MAXROWS] == null)
            {
                return;
            }
            else
            {
                CreateNavigation((int)ViewState[VS_CURRENTINDEX], (int)ViewState[VS_PAGESIZE], (int)ViewState[VS_MAXROWS]);
            }
        }

        private void CreateNavigation(int currentPageIndex, int a_iPageSize, int a_iRowCount)
        {
            //Save the arguments in ViewState
            ViewState[VS_CURRENTINDEX] = currentPageIndex;
            ViewState[VS_PAGESIZE] = a_iPageSize;
            ViewState[VS_MAXROWS] = a_iRowCount;
            pnlNavigation.Controls.Clear();
            if (a_iPageSize == 0)
            {
                return;
            }

            //Get the TotalNumber of Pages
            //int iPageCount = 0;
            iPageCount = 0;
            if (a_iRowCount % a_iPageSize == 0)
            {
                iPageCount = a_iRowCount / a_iPageSize;
            }
            else
            {
                iPageCount = (a_iRowCount / a_iPageSize) + 1;
            }

            if (iPageCount <= 1)
            {
                return;
            }

            //Check if LeftDots are to be displayed
            if ((currentPageIndex + 1) - 5 > 1)
            {
                //Start when left dots are visible then show << button also
                LinkButton linkFirst = new LinkButton();
                linkFirst.Text = "<<";
                linkFirst.CssClass = "lftmenu";
                linkFirst.ID = "linkFirst";
                linkFirst.Click += new EventHandler(linkFirst_Click);
                pnlNavigation.Controls.Add(linkFirst);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
                //End when left dots are visible then show << button also

                int iLIndex = (currentPageIndex + 1) - 5 - 1;
                //Add LeftDots
                LinkButton btnLeftDots = new LinkButton();
                btnLeftDots.Text = "...";
                btnLeftDots.CssClass = "lftmenu";
                btnLeftDots.ID = "nav_" + iLIndex.ToString();
                btnLeftDots.Attributes.Add("onclick", "__doPostBack('" + btnLeftDots.ClientID + "',' " + iLIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            int iLeftIndex = 1;

            if (currentPageIndex + 1 - 5 > 1)
            {
                iLeftIndex = currentPageIndex + 1 - 5;
            }

            //Create the Number buttons on the left side of the index
            for (int i = iLeftIndex; i <= currentPageIndex; i++)
            {
                LinkButton btnLeftNumbers = new LinkButton();
                btnLeftNumbers.Text = i.ToString();
                btnLeftNumbers.CssClass = "lftmenu";
                btnLeftNumbers.ID = "nav_" + i.ToString();
                btnLeftNumbers.Attributes.Add("onclick", "__doPostBack('" + btnLeftNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Display the Current Page Number
            Label lblCurrent = new Label();
            lblCurrent.Text = Convert.ToString(currentPageIndex + 1);
            lblCurrent.CssClass = "textNormal";
            pnlNavigation.Controls.Add(lblCurrent);
            pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

            //Create Right Number buttons
            int iRightIndex = iPageCount;

            if (currentPageIndex + 1 + 5 < iRightIndex)
            {
                iRightIndex = 5;//currentPageIndex + 1 + 5;
            }

            for (int i = currentPageIndex + 2; i <= iRightIndex; i++)
            {
                LinkButton btnRightNumbers = new LinkButton();
                btnRightNumbers.Text = i.ToString();
                btnRightNumbers.CssClass = "lftmenu";
                btnRightNumbers.ID = "nav_" + i.ToString();
                btnRightNumbers.Attributes.Add("onclick", "__doPostBack('" + btnRightNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Check if RightDots are to be displayed
            if ((currentPageIndex + 1) + 5 < iPageCount)
            {
                int iRIndex = ((currentPageIndex + 1) + 5) + 1;
                //Add RightDots
                LinkButton btnRightDots = new LinkButton();
                btnRightDots.Text = "...";
                btnRightDots.CssClass = "lftmenu";
                btnRightDots.ID = "nav_" + iRIndex.ToString();
                btnRightDots.Attributes.Add("onclick", "__doPostBack('" + btnRightDots.ClientID + "',' " + iRIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

                //Start when right dots are visible then show >> button also
                LinkButton linkLast = new LinkButton();
                linkLast.Text = ">>";
                linkLast.CssClass = "lftmenu";
                linkLast.ID = "linkLast";
                linkLast.Click += new EventHandler(linkLast_Click);
                pnlNavigation.Controls.Add(linkLast);
                //End when left dots are visible then show << button also
            }
        }

        protected void linkFirst_Click(object sender, EventArgs e)
        {
            BindData(0);
        }

        protected void linkLast_Click(object sender, EventArgs e)
        {
            BindData(iPageCount - 1);
        }

        #endregion
    }
}