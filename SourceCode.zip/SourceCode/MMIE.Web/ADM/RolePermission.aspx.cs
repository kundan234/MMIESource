﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using System.Text;


using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.ADM
{
    public partial class RolePermission : BasePage
    {

        DataSet dsSiteMap;
        DataTable applySitemapRoleDT;
        int roleID;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //get all site map
                MMIE.Data.Common.SiteMap objSiteMap = new MMIE.Data.Common.SiteMap();

                MasterLookupBO mstlookup = new MasterLookupBO();
                //B2RSoft.HIMS.Contracts.DataContracts.ADM.SiteMap objSiteMap = new B2RSoft.HIMS.Contracts.DataContracts.ADM.SiteMap();
                GetAllSiteMapItem(objSiteMap);

                //create all site item
                CreateSiteMapItem();              
                if (!Page.IsPostBack)
                {
                    BindDropDownControl(drpRole, mstlookup.GetLookupsList(LookupNames.Role));

                    roleID = Convert.ToInt32(drpRole.SelectedValue);
                    //get applied sitemap for selected role
                    GetAppliedSiteMapForSelectedRole();

                    ViewState["IsEdit"] = false;
                }
                else
                {
                    roleID = Convert.ToInt32(drpRole.SelectedValue);
                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }


        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSubmit.Enabled = LoginToken.IsAddOn;
            }
        }

        protected void drpRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Text = "";
            lblError.Visible = true;
            //get applied sitemap for selected role
            GetAppliedSiteMapForSelectedRole();
            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }

            try
            {
                StringBuilder objBuilder = GetCheckedSitemap();
                Role objRole = new Role();
                objRole.AddedBy = LoginToken.LoginId;
                objRole.LastModBy = LoginToken.LoginId;
                objRole.FinancialYearID = (short)LoginToken.FinancialYearID;
                objRole.CompanyID = (short)LoginToken.CompanyID;
                objRole.RoleId = roleID;
                objRole.XMLData = objBuilder.ToString();
                UserAdminBO useradm = new UserAdminBO();
                bool status = useradm.SaveSiteMapRole(objRole);
                // bool status = UserAdminServiceAgent.SaveSiteMapRole(objRole);
                if (status == true)
                {
                    //display succuss message
                    lblError.Text = ExceptionMessage.GetMessage("1000015");
                    lblError.Visible = true;
                    ViewState["IsEdit"] = false;
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            GetAppliedSiteMapForSelectedRole();
            lblError.Text = "";
            drpRole.SelectedIndex = 0;
           lblError.Visible = true;
           ViewState["IsEdit"] = false;

        }

        private bool IsSiteMapCheched(string siteMapID)
        {
            DataRow[] filterRows = applySitemapRoleDT.Select("SiteMapID=" + siteMapID, "");
            if (filterRows.Length > 0)
                return true;
            else
                return false;
        }


        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        private void GetAllSiteMapItem(MMIE.Data.Common.SiteMap objSiteMap)
        {
            //Call service operation to get data from database source
            //MMIE.Data.CommonSiteMap SiteMap = new MMIE.Data.CommonSiteMap();
            UserAdminBO useradm = new UserAdminBO();

            List<MMIE.Data.Common.SiteMap> lstSiteMap = useradm.GetAllSiteMapItem(objSiteMap);
            DataTable dt = ORHelper<MMIE.Data.Common.SiteMap>.GenericListToDataTable(lstSiteMap);
            dsSiteMap = new DataSet();
            dsSiteMap.Tables.Add(dt);
        }

        private void GetAppliedSiteMapForSelectedRole()
        {
            Role objRole = new Role();
            UserAdminBO useradm = new UserAdminBO();
            objRole.AddedBy = LoginToken.LoginId;
            objRole.LastModBy = LoginToken.LoginId;
            objRole.FinancialYearID = (short)LoginToken.FinancialYearID;
            objRole.CompanyID = (short)LoginToken.CompanyID;
            objRole.RoleId = roleID;
            List<MMIE.Data.Common.SiteMap> lstSitemap = useradm.GetSiteMapRoleByRoleID(objRole);
            applySitemapRoleDT = ORHelper<MMIE.Data.Common.SiteMap>.GenericListToDataTable(lstSitemap);

            AppliedRoleSetting();
        }

        private void CreateSiteMapItem()
        {
            tblPermission.Controls.Clear();

            TableRow r1;
            TableCell c1, c2, c3, c4, c5;
            CheckBox chk1;

            DataRow[] filterRows1 = dsSiteMap.Tables[0].Select("ParentID=0", "");
            foreach (DataRow row1 in filterRows1)
            {
                //For Level 1
                r1 = new TableRow();
                c1 = new TableCell();
                c1.ColumnSpan = 5;

                chk1 = new CheckBox();
                chk1.ID = "chk" + row1["SiteMapID"];
                chk1.Text = (string)row1["Title"];
                //chk1.Checked = IsSiteMapCheched(row1["SiteMapID"].ToString());
                c1.Controls.Add(chk1);

                r1.Cells.Add(c1);

                tblPermission.Rows.Add(r1);

                DataRow[] filterRows2 = dsSiteMap.Tables[0].Select("ParentID=" + row1["SiteMapID"], "");
                foreach (DataRow row2 in filterRows2)
                {
                    //For Level 2
                    r1 = new TableRow();
                    c1 = new TableCell();
                    c2 = new TableCell();
                    c2.ColumnSpan = 4;

                    chk1 = new CheckBox();
                    chk1.ID = "chk" + row2["SiteMapID"];
                    chk1.Text = (string)row2["Title"];
                    // chk1.Checked = IsSiteMapCheched(row2["SiteMapID"].ToString());
                    c2.Controls.Add(chk1);

                    r1.Cells.Add(c1);
                    r1.Cells.Add(c2);

                    tblPermission.Rows.Add(r1);

                    DataRow[] filterRows3 = dsSiteMap.Tables[0].Select("ParentID=" + row2["SiteMapID"], "");
                    foreach (DataRow row3 in filterRows3)
                    {
                        //For Level 3
                        r1 = new TableRow();
                        c1 = new TableCell();
                        c2 = new TableCell();
                        c3 = new TableCell();
                        c3.ColumnSpan = 3;

                        chk1 = new CheckBox();
                        chk1.ID = "chk" + row3["SiteMapID"];
                        chk1.Text = (string)row3["Title"];
                        //chk1.Checked = IsSiteMapCheched(row3["SiteMapID"].ToString());
                        c3.Controls.Add(chk1);

                        r1.Cells.Add(c1);
                        r1.Cells.Add(c2);
                        r1.Cells.Add(c3);

                        tblPermission.Rows.Add(r1);

                        DataRow[] filterRows4 = dsSiteMap.Tables[0].Select("ParentID=" + row3["SiteMapID"], "");
                        foreach (DataRow row4 in filterRows4)
                        {
                            //For Level 4
                            r1 = new TableRow();
                            c1 = new TableCell();
                            c2 = new TableCell();
                            c3 = new TableCell();
                            c4 = new TableCell();
                            c4.ColumnSpan = 2;

                            c1.Width = 20;
                            c2.Width = 20;
                            c3.Width = 20;
                            c4.Width = 20;

                            chk1 = new CheckBox();
                            chk1.ID = "chk" + row4["SiteMapID"];
                            chk1.Text = (string)row4["Title"];
                            //chk1.Checked = IsSiteMapCheched(row4["SiteMapID"].ToString());

                            c4.Controls.Add(chk1);

                            r1.Cells.Add(c1);
                            r1.Cells.Add(c2);
                            r1.Cells.Add(c3);
                            r1.Cells.Add(c4);

                            tblPermission.Rows.Add(r1);

                            DataRow[] filterRows5 = dsSiteMap.Tables[0].Select("ParentID=" + row4["SiteMapID"], "");
                            foreach (DataRow row5 in filterRows5)
                            {
                                //For Level 5
                                r1 = new TableRow();
                                c1 = new TableCell();
                                c2 = new TableCell();
                                c3 = new TableCell();
                                c4 = new TableCell();
                                c5 = new TableCell();

                                c1.Width = 20;
                                c2.Width = 20;
                                c3.Width = 20;
                                c4.Width = 20;
                                c5.Width = 20;

                                chk1 = new CheckBox();
                                chk1.ID = "chk" + row5["SiteMapID"];
                                chk1.Text = (string)row5["Title"];
                                // chk1.Checked = IsSiteMapCheched(row1["SiteMapID"].ToString());

                                c5.Controls.Add(chk1);

                                r1.Cells.Add(c1);
                                r1.Cells.Add(c2);
                                r1.Cells.Add(c3);
                                r1.Cells.Add(c4);
                                r1.Cells.Add(c5);

                                tblPermission.Rows.Add(r1);
                            }
                        }
                    }
                }
            }
        }

        private StringBuilder GetCheckedSitemap()
        {
            CheckBox chk1;

            StringBuilder objBuilder = new StringBuilder();
            objBuilder.Append("<?xml version=\"1.0\"?>");
            objBuilder.Append("<Root>");

            DataRow[] filterRows1 = dsSiteMap.Tables[0].Select("ParentID=0", "");
            foreach (DataRow row1 in filterRows1)
            {
                //For Level 1     
                chk1 = (CheckBox)tblPermission.FindControl("chk" + row1["SiteMapID"]);
                if (chk1 != null)
                {
                    if (chk1.Checked)
                    {
                        objBuilder.Append("<sitemaprole roleid=\"" + roleID + "\" sitemapid=\"" + row1["SiteMapID"] + "\"/>");
                    }
                }

                DataRow[] filterRows2 = dsSiteMap.Tables[0].Select("ParentID=" + row1["SiteMapID"], "");
                foreach (DataRow row2 in filterRows2)
                {
                    //For Level 2     
                    chk1 = (CheckBox)tblPermission.FindControl("chk" + row2["SiteMapID"]);
                    if (chk1 != null)
                    {
                        if (chk1.Checked)
                        {
                            objBuilder.Append("<sitemaprole roleid=\"" + roleID + "\" sitemapid=\"" + row2["SiteMapID"] + "\"/>");
                        }
                    }

                    DataRow[] filterRows3 = dsSiteMap.Tables[0].Select("ParentID=" + row2["SiteMapID"], "");
                    foreach (DataRow row3 in filterRows3)
                    {
                        //For Level 3
                        chk1 = (CheckBox)tblPermission.FindControl("chk" + row3["SiteMapID"]);
                        if (chk1 != null)
                        {
                            if (chk1.Checked)
                            {
                                objBuilder.Append("<sitemaprole roleid=\"" + roleID + "\" sitemapid=\"" + row3["SiteMapID"] + "\"/>");
                            }
                        }

                        DataRow[] filterRows4 = dsSiteMap.Tables[0].Select("ParentID=" + row3["SiteMapID"], "");
                        foreach (DataRow row4 in filterRows4)
                        {
                            //For Level 4
                            chk1 = (CheckBox)tblPermission.FindControl("chk" + row4["SiteMapID"]);
                            if (chk1 != null)
                            {
                                if (chk1.Checked)
                                {
                                    objBuilder.Append("<sitemaprole roleid=\"" + roleID + "\" sitemapid=\"" + row4["SiteMapID"] + "\"/>");
                                }
                            }

                            DataRow[] filterRows5 = dsSiteMap.Tables[0].Select("ParentID=" + row4["SiteMapID"], "");
                            foreach (DataRow row5 in filterRows5)
                            {
                                //For Level 5
                                chk1 = (CheckBox)tblPermission.FindControl("chk" + row5["SiteMapID"]);
                                if (chk1 != null)
                                {
                                    if (chk1.Checked)
                                    {
                                        objBuilder.Append("<sitemaprole roleid=\"" + roleID + "\" sitemapid=\"" + row5["SiteMapID"] + "\"/>");
                                    }
                                }
                            }
                        }
                    }
                }
            }

            objBuilder.Append("</Root>");

            return objBuilder;
        }

        private void AppliedRoleSetting()
        {
            CheckBox chk1;
            DataRow[] filterRows1 = dsSiteMap.Tables[0].Select("ParentID=0", "");
            foreach (DataRow row1 in filterRows1)
            {
                //For Level 1     
                chk1 = (CheckBox)tblPermission.FindControl("chk" + row1["SiteMapID"]);
                if (chk1 != null)
                {
                    chk1.Checked = IsSiteMapCheched(row1["SiteMapID"].ToString());
                }

                DataRow[] filterRows2 = dsSiteMap.Tables[0].Select("ParentID=" + row1["SiteMapID"], "");
                foreach (DataRow row2 in filterRows2)
                {
                    //For Level 2     
                    chk1 = (CheckBox)tblPermission.FindControl("chk" + row2["SiteMapID"]);
                    if (chk1 != null)
                    {
                        chk1.Checked = IsSiteMapCheched(row2["SiteMapID"].ToString());
                    }

                    DataRow[] filterRows3 = dsSiteMap.Tables[0].Select("ParentID=" + row2["SiteMapID"], "");
                    foreach (DataRow row3 in filterRows3)
                    {
                        //For Level 3
                        chk1 = (CheckBox)tblPermission.FindControl("chk" + row3["SiteMapID"]);
                        if (chk1 != null)
                        {
                            chk1.Checked = IsSiteMapCheched(row3["SiteMapID"].ToString());
                        }

                        DataRow[] filterRows4 = dsSiteMap.Tables[0].Select("ParentID=" + row3["SiteMapID"], "");
                        foreach (DataRow row4 in filterRows4)
                        {
                            //For Level 4
                            chk1 = (CheckBox)tblPermission.FindControl("chk" + row4["SiteMapID"]);
                            if (chk1 != null)
                            {
                                chk1.Checked = IsSiteMapCheched(row4["SiteMapID"].ToString());
                            }

                            DataRow[] filterRows5 = dsSiteMap.Tables[0].Select("ParentID=" + row4["SiteMapID"], "");
                            foreach (DataRow row5 in filterRows5)
                            {
                                //For Level 5
                                chk1 = (CheckBox)tblPermission.FindControl("chk" + row5["SiteMapID"]);
                                if (chk1 != null)
                                {
                                    chk1.Checked = IsSiteMapCheched(row5["SiteMapID"].ToString());
                                }
                            }
                        }
                    }
                }
            }
        }

    }
}