﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.ADM
{
    public partial class LoginScheduler :BasePage
    {
        UserAdminBO objUserAdminBO = new UserAdminBO();
        UserLogin objUserLogin = new UserLogin();
        protected void Page_Load(object sender, EventArgs e)
        {

            MasterLookupBO mstlookup = new MasterLookupBO();
            lblSaveMessage.Text = "";
            if (!IsPostBack)
                BindDropDownControl(chkEmpdetails, mstlookup.GetLookupsList(LookupNames.UserList));
            PagePermission();
            //chkEmpdetails.DataSource =  objUserAdminBO.GetUserDetails();
            // chkEmpdetails.DataBind();
        }

        protected void PagePermission()
        {
            if (LoginToken != null)
            {

                btnSave.Enabled = LoginToken.IsAddOn;
                btnSave.Enabled = LoginToken.IsModify;
            }
        }

        protected void drpLoginUsers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void CheckBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        public void BindDropDownControl(CheckBoxList objDD, List<LookupItem> lstLookups)
        {
            chkEmpdetails.DataSource = lstLookups;
            chkEmpdetails.DataValueField = "ItemId";
            chkEmpdetails.Items.Add(new ListItem("All Employee", "0"));
            chkEmpdetails.AppendDataBoundItems = true;
            chkEmpdetails.DataTextField = "ItemName";
            chkEmpdetails.DataBind();

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                UserLogin objUserLogin = new UserLogin();

                if (chkMonInActive.Checked)
                {
                    objUserLogin.MonStartTime = null;
                    objUserLogin.MonEndTime = null;
                }
                else
                {
                    objUserLogin.MonStartTime = txtMonStartTime.Text;
                    objUserLogin.MonEndTime = txtMonEndTime.Text;
                }
                if (chkTueInActive.Checked)
                {
                    objUserLogin.TueStartTime = null;
                    objUserLogin.TueEndTime = null;
                }
                else
                {
                    objUserLogin.TueStartTime = txtTueStartTime.Text;
                    objUserLogin.TueEndTime = txtTueEndTime.Text;
                }
                if (chkWedInActive.Checked)
                {
                    objUserLogin.WedStartTime = null;
                    objUserLogin.WedEndTime = null;
                }
                else
                {
                    objUserLogin.WedStartTime = txtWedStartTime.Text;
                    objUserLogin.WedEndTime = txtWedEndTime.Text;
                }
                if (chkThurInActive.Checked)
                {
                    objUserLogin.ThurStartTime = null;
                    objUserLogin.ThurEndTime = null;
                }
                else
                {
                    objUserLogin.ThurStartTime = txtThurStartTime.Text;
                    objUserLogin.ThurEndTime = txtThurEndTime.Text;
                }
                if (chkFriInActive.Checked)
                {
                    objUserLogin.FriStartTime = null;
                    objUserLogin.FriEndTime = null;
                }
                else
                {
                    objUserLogin.FriStartTime = txtFriStartTime.Text;
                    objUserLogin.FriEndTime = txtFriEndTime.Text;
                }

                if (chkSatInActive.Checked)
                {
                    objUserLogin.SatStartTime = null;
                    objUserLogin.SatEndTime = null;
                }
                else
                {
                    objUserLogin.SatStartTime = txtSatStartTime.Text;
                    objUserLogin.SatEndTime = txtSatEndTime.Text;
                }

                if (chkSunInActive.Checked)
                {
                    objUserLogin.SunStartTime = null;
                    objUserLogin.SunEndTime = null;
                }
                else
                {
                    objUserLogin.SunStartTime = txtSunStartTime.Text;
                    objUserLogin.SunEndTime = txtSunEndTime.Text;
                }



                if (chkEmpdetails.SelectedIndex == 0)
                {
                    foreach (ListItem item in chkEmpdetails.Items)
                    {
                        if (item.Value != "0" && item.Value != "1")
                        {
                            objUserLogin.UserLoginId = Convert.ToInt32(item.Value);

                            objUserAdminBO.UpdateLoginSchedule(objUserLogin);
                        }
                    }
                }
                else
                {
                    foreach (ListItem item in chkEmpdetails.Items)
                    {
                        if (item.Selected)
                        {
                            objUserLogin.UserLoginId = Convert.ToInt32(item.Value);
                            objUserAdminBO.UpdateLoginSchedule(objUserLogin);
                        }

                    }
                }
                lblSaveMessage.Text = "Data Saved successfully.";
            }
            catch (Exception ex)
            {
                lblSaveMessage.Text="Data not Saved successfully.";
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                
            }
        }

    }
}