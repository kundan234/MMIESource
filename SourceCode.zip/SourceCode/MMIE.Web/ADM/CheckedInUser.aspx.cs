﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;



namespace MMIE.ADM
{
    public partial class CheckedInUser : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                MasterLookupBO mstlookup = new MasterLookupBO();
                BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
                dllBranch.Items.Insert(0, "--Select--");
            }

        }


        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

            BindUserList();


        }

        protected void BindUserList()
        {
            UserAdminBO objUserBO = new UserAdminBO();

            List<UserLogin> lstUser = new List<UserLogin>();

            UserLogin objUser = new UserLogin();
            if(dllBranch.SelectedIndex>0)
            {
            objUser.CompanyID= Convert.ToInt16(dllBranch.SelectedValue.ToString());
            }

            objUser.UserName = txtUserName.Text;
            objUser.IsActive =  rbtStatus.SelectedIndex==0?true:false;
            objUser.IsCheckOut = rbtCheckout.SelectedIndex == 0 ? true : false;
            lstUser = objUserBO.SearchCheckedOutUser(objUser);
            grdUserList.DataSource = lstUser;
            grdUserList.DataBind();


        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            UserAdminBO objUserBO = new UserAdminBO();

            UserLogin objUser = new UserLogin();
            objUser.CompanyID = (Int16)LoginToken.CompanyID;
            objUser.FinancialYearID =(Int16) LoginToken.FinancialYearID;
            objUser.LastModBy = LoginToken.LoginId;
            objUser.XMLData=CreateGridToXML();


            if (objUserBO.CheckInUserList(objUser))
            {
                lblError.Text = "Users Checked In Successfully";

            }


        }


        protected string CreateGridToXML()
        {
            StringBuilder objBuilder = new StringBuilder();
            CheckBox chk= new CheckBox();


            foreach(GridViewRow gr in grdUserList.Rows)
            {

                chk = (CheckBox)gr.Cells[6].FindControl("chkIsCheckin");
                if (chk.Checked)
                {

                    objBuilder.Append("<CheckedIn LoginID = \"" + gr.Cells[2].Text.ToString() + "\" ");


                    objBuilder.Append(" IsCheckedIn = \"" + chk.Checked.ToString() + "\" ");
                    objBuilder.Append("/>");
                }
                

            }

            return objBuilder.ToString();
        }
    }
}