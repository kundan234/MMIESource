﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE
{
    public partial class CityMaster : BasePage
    {

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsAddOn;

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCountry();
                ViewState["IsEdit"] = false ;
            }

            PagePermission();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;
                
            }
            
            try
            {

                CityMST objCity = new CityMST();
                CityBO objCityBO = new CityBO();
                objCity.CityName = txtCityName.Text;
                objCity.CompanyID = LoginToken.CompanyID;
                objCity.FinancialYearID = LoginToken.FinancialYearID;

                objCity.Zip_Code = Convert.ToInt32(txtZipCode.Text);

                objCity.State_Code = txtStateCode.Text;
                objCity.State_Name = txtStateName.Text;

                if (rbtStatus.SelectedIndex == 0)
                {
                    objCity.IsActive = true;
                }
                else
                {
                    objCity.IsActive = false;
                }

                objCity.CountryId = Convert.ToInt32(ddlCountry.SelectedValue.ToString());

                if (ViewState["CityID"] != null)
                {
                    objCity.LastModBy = LoginToken.LoginId;
                    objCity.CityID = Convert.ToInt32(ViewState["CityID"].ToString());
                    objCity.ActionType = EnumActionType.Update;

                }
                else
                {
                    objCity.AddedBy = LoginToken.LoginId;
                    objCity.CityID = 0;
                    objCity.ActionType = EnumActionType.Insert;
                }

                if (objCityBO.SaveCity(objCity))
                {
                    if (ViewState["CityID"] != null)
                    {
                        lblError.Text = "City Updated";
                        ViewState["CityID"] = null;
                        ViewState["IsEdit"] = false;
                        ClearAll();
                    }
                    else
                    {
                        lblError.Text = "New City Added";
                        ClearAll();
                       
                    }


                }
            }          
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While save the Record of city : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }


        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ClearAll();
            lblError.Text = "";
            ViewState["IsEdit"] = false;
        }


        protected void ClearAll()
        {
            txtCityName.Text="";
            txtStateCode.Text = "";
            txtStateName.Text = "";
            txtZipCode.Text = "";
            ViewState["CityID"] = null;
        }

        private void BindCountry()
        {
            try
            {

                CountryBO objCountryBO = new CountryBO();
                List<Country> lstCountry = new List<Country>();

                lstCountry = objCountryBO.GetCountryList(false);
                ddlCountry.DataSource = lstCountry;
                ddlCountry.DataValueField = "CountryID";
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));

            }
           
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching the country Record  : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }


        }


        private void BindCityList()
        {
            try
            {
                CityBO objCityBO = new CityBO();
                List<CityMST> lstCity = new List<CityMST>();
                lstCity = objCityBO.GetCityList(true);
                grdCityList.DataSource = lstCity;
                grdCityList.DataBind();

            }
           
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching the city Record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void btnResetSearch_Click(object sender, EventArgs e)
        {
            txtSearchCityName.Text = "";
            txtSearchStateCode.Text = "";
            txtSearchStateName.Text = "";
            txtSearchZipCode.Text = "";
            lblError.Text = "";
            grdCityList.DataSource = null;
            grdCityList.DataBind();

        }

        private void SearchCity()
        {
            try
            {
                string SearchCityName, SearchStateName, SearchZipCode, SearchStateCode;


                SearchCityName = txtSearchCityName.Text.Trim();
                SearchStateName = txtSearchStateName.Text.Trim();
                SearchZipCode = txtSearchZipCode.Text.Trim();
                SearchStateCode = txtSearchStateCode.Text.Trim();



                List<CityMST> lstCity = new List<CityMST>();
                CityBO objCityBO = new CityBO();
                lstCity = objCityBO.GetCityListSearch(SearchCityName, SearchStateName, SearchZipCode, SearchStateCode);
                if (lstCity != null)
                {


                    grdCityList.DataSource = lstCity;
                    grdCityList.DataBind();
                }
                else
                {
                    lblError.Text = "No Record Found";

                }

            }
           
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While search the city record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

            this.SearchCity();

        }

        protected void grdCityList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCityList.PageIndex = e.NewPageIndex;
            this.SearchCity();
        }

        protected void grdCityList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "REdit")
                {

                    int id = Convert.ToInt32(e.CommandArgument.ToString());

                    GridViewRow gr = grdCityList.Rows[id];

                    Label lblCityName = (Label)gr.Cells[2].FindControl("lblCityName");
                    Label lblZip_Code = (Label)gr.Cells[3].FindControl("lblZip_Code");

                    Label lblStateName = (Label)gr.Cells[4].FindControl("lblStateName");
                    Label lblStateCode = (Label)gr.Cells[5].FindControl("lblStateCode");


                    Label lblCountryID = (Label)gr.Cells[6].FindControl("lblCountryID");
                    CheckBox chkIsActive = (CheckBox)gr.Cells[7].FindControl("chkIsActive");





                    LinkButton lblCityID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");
                    txtCityName.Text = lblCityName.Text;
                    txtStateName.Text = lblCountryID.Text;
                    ddlCountry.SelectedValue = lblCountryID.Text;
                    txtStateCode.Text = lblStateCode.Text;
                    txtStateName.Text = lblStateName.Text;
                    txtZipCode.Text = lblZip_Code.Text;
                    ViewState["CityID"] =  lblCityID.Text;
                    ViewState["IsEdit"] = true;
                    if (chkIsActive.Checked)
                    {
                        rbtStatus.SelectedIndex = 0;

                    }
                    else
                    {
                        rbtStatus.SelectedIndex = 1;

                    }



                }
            }
           
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching the Record of city : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }


    }
}