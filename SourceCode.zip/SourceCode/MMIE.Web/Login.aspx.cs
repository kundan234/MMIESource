﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Web;
using MMIE.Common.Util;
using System.Web.Security;
using System.Data;

namespace MMIE
{
    public partial class Login : System.Web.UI.Page
    {
        #region Variables Declaration

        #endregion

        #region Page/Control Event Handler

        protected void Page_Load(object sender, EventArgs e)
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            try
            {
                if (!Page.IsPostBack)
                {
                    BindDropDownControl(drFinancialYear, mstlookup.GetLookupsList(LookupNames.FinancialYear));
                    BindDropDownControl(drCompanyBranch, mstlookup.GetLookupsList(LookupNames.Company));
                }
            }
            catch (Exception ex) 
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);

            }
        }

        #endregion
        #region Private Members
        private void ValidateLogin()
        {
            UserLogin objUser = new UserLogin();
            objUser.LoginId = txtUserId.Text;
            objUser.Password = txtPassword.Text;
            objUser.FinancialYearID = Convert.ToInt16(drFinancialYear.SelectedValue);
            objUser.CompanyID = Convert.ToInt16(drCompanyBranch.SelectedValue);
            objUser.UserTypeID = 1; // Convert.ToInt32(drpUserType.SelectedValue);
            objUser.ActionType = EnumActionType.Select;
            UserAdminBO useradm = new UserAdminBO();
            UserCE objUSerCE = useradm.ValidateLogin(objUser);
            if (objUSerCE != null)
            {
                if (objUSerCE.RoleList.Count == 0)
                {
                    lblError.Visible = true;
                    lblError.Text = "Your Are Inactive at this time";
                }
                else
                {
                    CreateAuthenticationTicket(objUSerCE);
                    lblError.Visible = false;
                }
            }
            else
            {
                lblError.Visible = true;
                lblError.Text = "Username or Password is incorrect";
            }
        }

        /// <summary>
        /// Create form authentication ticket based on user token
        /// </summary>
        /// <param name="objLoginToken"></param>
        private void CreateAuthenticationTicket(UserCE objUSerCE)
        {
            string RolesAssigntoUser = "";
            foreach (Role objUGrp in objUSerCE.RoleList)
            {
                if (RolesAssigntoUser.Trim() != "")
                {
                    RolesAssigntoUser = RolesAssigntoUser + "," + Convert.ToString(objUGrp.RoleName);
                }
                else
                {
                    RolesAssigntoUser = Convert.ToString(objUGrp.RoleName);
                }
            }

            bool isPersistentLogin = false;
            // Create forms authentication ticket
            FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, // Ticket version

            objUSerCE.UserLogin.LoginId,// Username to be associated with this ticket
            DateTime.Now, // Date/time ticket was issued
            DateTime.Now.AddMinutes(50), // Date and time the cookie will expire
            isPersistentLogin, // if user has chcked rememebr me then create persistent cookie
            RolesAssigntoUser, // store the user data, in this case roles of the user
            FormsAuthentication.FormsCookiePath); // Cookie path specified in the web.config file in <Forms> tag if any.

            // To give more security it is suggested to hash it
            string hashCookies = FormsAuthentication.Encrypt(ticket);
            HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, hashCookies); // Hashed ticket

            // Add the cookie to the response, user browser
            Response.Cookies.Add(cookie);

            //Set login token in context session as key name/id - LoginToken
            SetLoginToken(objUSerCE);

            // Get the requested page from the url
            string returnUrl = null;
            returnUrl = "~/Home.aspx";
            Response.Redirect(returnUrl);

        }
        private void SetLoginToken(UserCE objUSerCE)
        {
            try
            {

                //Make relation in SiteMap (Parent-Child)

                DataTable dt = objUSerCE.SiteMapDT;
                DataSet ds = new DataSet();
                ds.Tables.Add(dt.Copy());

                ds.DataSetName = "SiteMaps";
                ds.Tables[0].TableName = "SiteMap";
                DataRelation relation = new DataRelation("ParentChild",
                     ds.Tables["SiteMap"].Columns["SiteMapID"],
                     ds.Tables["SiteMap"].Columns["ParentID"], true);

                relation.Nested = true;
                ds.Relations.Add(relation);

                LoginToken objLoginToken = new LoginToken();

                objLoginToken.UserLoginId = objUSerCE.UserLogin.UserLoginId;
                objLoginToken.LoginId = objUSerCE.UserLogin.LoginId;
                objLoginToken.LoginUniqueId = objUSerCE.UserLogin.LoginUniqueId;
                objLoginToken.Password = objUSerCE.UserLogin.Password;
                objLoginToken.Status = objUSerCE.UserLogin.Status;

                objLoginToken.UserTypeID = objUSerCE.UserLogin.UserTypeID;
                objLoginToken.UserTypeCode = objUSerCE.UserLogin.UserTypeCode;
                objLoginToken.UserTypeName = objUSerCE.UserLogin.UserTypeName;

                objLoginToken.FinancialYearID = objUSerCE.UserLogin.FinancialYearID;
                objLoginToken.FinancialYearCode = objUSerCE.UserLogin.FinancialYearCode;
                objLoginToken.FinancialYearName = objUSerCE.UserLogin.FinancialYearName;

                objLoginToken.CompanyID = Convert.ToInt16(drCompanyBranch.SelectedValue); //objUSerCE.UserLogin.CompanyID;
                objLoginToken.CompanyCode = objUSerCE.UserLogin.CompanyCode;
                objLoginToken.CompanyName = objUSerCE.UserLogin.CompanyName;
                objLoginToken.CompanyAddress = objUSerCE.UserLogin.CompanyAddress;
                objLoginToken.CompanyPhoneSTDCode = objUSerCE.UserLogin.CompanyPhoneSTDCode;
                objLoginToken.CompanyPhoneNo = objUSerCE.UserLogin.CompanyPhoneNo;
                objLoginToken.CompanyEmailID = objUSerCE.UserLogin.CompanyEmailID;
                objLoginToken.IsCheckOut = objUSerCE.UserLogin.IsCheckOut;

                //--------------changes by mithlesh
                objLoginToken.FirstName = "";
                objLoginToken.LastName = "";
                objLoginToken.MaritalStatusID = 0;
                objLoginToken.UserCode = "";
                objLoginToken.UserDetailID = 0;
                objLoginToken.DesignationID = 0;
                objLoginToken.DepartmentID = 0;
                //--------------------------
                objLoginToken.CompanyFaxNo = objUSerCE.UserLogin.CompanyFaxNo;
                objLoginToken.CompanyMobileNo = objUSerCE.UserLogin.CompanyMobileNo;
                objLoginToken.CompanyPhoneAltNo = objUSerCE.UserLogin.CompanyPhoneAltNo;
                objLoginToken.CompanyWebsite = objUSerCE.UserLogin.CompanyWebsite;

                string[] roleNames = new string[objUSerCE.RoleList.Count];
                int[] rolesIds = new int[objUSerCE.RoleList.Count];

                Boolean IsAddOn = false;
                Boolean IsModify = false;
                Boolean IsCancelOn = false;
                Boolean IsDeleteOn = false;
                Boolean IsPrintOn = false;
                Boolean IsPrintExportOn = false;

                Boolean IsChangeBranchOn = false;
                Boolean IsChangeDateOn = false;
                Boolean IsApproverReturnOn = false;
                Boolean IsApproverRecievedOn = false;
                Boolean IsApproverReimbursementOn = false;
                Boolean IsRateChangeOn = false;
                Boolean IsPartialOrderCancellatonOn = false;
                Boolean IsCreditLimitChangeAllowed = false;



                for (int i = 0; i <= objUSerCE.RoleList.Count - 1; i++)
                {
                    Role objRole = objUSerCE.RoleList[i];
                    roleNames[i] = objRole.RoleName;
                    rolesIds[i] = objRole.RoleId;
                    IsAddOn = objRole.IsAddOn;
                    IsModify = objRole.IsModify;
                    IsCancelOn = objRole.IsCancelOn;
                    IsDeleteOn = objRole.IsDeleteOn;
                    IsPrintOn = objRole.IsPrintOn;
                    IsPrintExportOn = objRole.IsPrintExportOn;
                    IsChangeBranchOn = objRole.IsChangeBranchOn;
                    IsChangeDateOn = objRole.IsChangeDateOn;
                    IsApproverReturnOn = objRole.IsApproverReturnOn;
                    IsApproverRecievedOn = objRole.IsApproverRecievedOn;
                    IsApproverReimbursementOn = objRole.IsApproverReimbursementOn;
                    IsRateChangeOn = objRole.IsRateChangeOn;
                    IsPartialOrderCancellatonOn = objRole.IsPartialCancellationOn;
                    IsCreditLimitChangeAllowed = objRole.IsCreditLimitChangeAllowed;
                }

                objLoginToken.RoleIds = rolesIds;
                objLoginToken.RoleNames = roleNames;
                objLoginToken.IsAddOn = IsAddOn;
                objLoginToken.IsModify = IsModify;
                objLoginToken.IsCancelOn = IsCancelOn;
                objLoginToken.IsDeleteOn = IsDeleteOn;
                objLoginToken.IsPrintOn = IsPrintOn;
                objLoginToken.IsPrintExportOn = IsPrintExportOn;

                objLoginToken.IsChangeBranchOn = IsChangeBranchOn;
                objLoginToken.IsChangeDateOn = IsChangeDateOn;
                objLoginToken.IsApproverReturnOn = IsApproverReturnOn;
                objLoginToken.IsApproverRecievedOn = IsApproverRecievedOn;
                objLoginToken.IsApproverReimbursementOn = IsApproverReimbursementOn;
                objLoginToken.IsRateChangeOn = IsRateChangeOn;

                objLoginToken.IsPartialCancellationOn = IsPartialOrderCancellatonOn;
                objLoginToken.IsCreditLimitChangeAllowed = IsCreditLimitChangeAllowed;

                objLoginToken.NavigationXmlData = ds.GetXml();


                Session["LoginToken"] = objLoginToken;
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }      
        private string IpAddress()
        {
            string strIpAddress;
            strIpAddress = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (strIpAddress == null)
                strIpAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            return strIpAddress;
        }
        
        #endregion

        #region Protected Members

        #endregion

        #region Public Members

        #endregion

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {

                ValidateLogin();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
        }
    }
}