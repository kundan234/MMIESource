﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.BusinessProcess.Common;
using MMIE.Data.Common;
using MMIE.Web;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;

namespace MMIE
{
    public partial class ManagePaymentDetails : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindBankDetails();
                BindCurrencyDropDown();
                MasterLookupBO mstlookup = new MasterLookupBO();
                BindDropDownControl(ddlEmployee, mstlookup.GetLookupsList(LookupNames.UserList));
                txtFromDate.Text = DateTime.Now.ToString("MM/dd/yyyy");
                txtToDate.Text = DateTime.Now.ToString("MM/dd/yyyy");
            }

            txtPaymentExpirationDate.Attributes.Add("ReadOnly", "True");
            txtFromDate.Attributes.Add("ReadOnly", "True");
            txtToDate.Attributes.Add("ReadOnly", "True");
            txtCurrencyRate.Attributes.Add("ReadOnly", "True");
          
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            Reset();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                PaymentDetails objPaymentDetails = new PaymentDetails();
                objPaymentDetails.PaymentMode = ddlPaymentMode.SelectedItem.Text;

                objPaymentDetails.CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue.Split('-')[0]);
                objPaymentDetails.PaymentAmount = Convert.ToDecimal(txtTotalIAmount.Text);
                objPaymentDetails.CurrencyRate = Convert.ToDecimal(txtCurrencyRate.Text);


                objPaymentDetails.IsOthers = true;
                objPaymentDetails.OtherRefNo = Convert.ToInt32(ddlEmployee.SelectedValue);

                objPaymentDetails.TransactionType = ddlTranType.SelectedValue;
                objPaymentDetails.TType = ddlTType.SelectedIndex > 0 ? ddlTType.SelectedValue.ToString() : "0";
                objPaymentDetails.Remarks = txtRemarks.Text;
                if (ddlBank.SelectedIndex != 0)
                {
                    objPaymentDetails.BankID = Convert.ToInt32(ddlBank.SelectedValue);
                    if (txtPaymentExpirationDate.Text!="")
                    objPaymentDetails.Expirationdate = Convert.ToDateTime(txtPaymentExpirationDate.Text);
                    objPaymentDetails.PaymentModeNo = txtPaymentModeNo.Text;
                }
                objPaymentDetails.CompanyID = LoginToken.CompanyID;

                objPaymentDetails.IsActive = true;
                objPaymentDetails.ActionType = EnumActionType.Insert;
                objPaymentDetails.AddedBy =ddlEmployee.SelectedIndex>0?ddlEmployee.SelectedItem.ToString().Split('-')[0]:"";

                objPaymentDetails.LastModBy = LoginToken.LoginId;
                objPaymentDetails.FinancialYearID = LoginToken.FinancialYearID;
                objPaymentDetails.PaymentSourceID = Convert.ToInt32(ddlPaymentMode.SelectedValue);

                PaymentDetailsBO objPaymentDetailsBO = new PaymentDetailsBO();
                //Insert data into PaymentDetails for purchase currency
                if (objPaymentDetailsBO.UpdatePaymentAdjustmentDetails(objPaymentDetails))
                {
                    lblError.Text = "Payment Details Saved Saved Successfully";
                }
                else
                    lblError.Text = "Transaction Incomplete";
                Reset();


            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error while updating payment transaction : "+ExceptionMessage.GetMessage(ex);     
                lblError.Visible = true;
            }
        }

        private void Reset()
        {
            ddlPaymentMode.SelectedIndex = 0;
            ddlCurrency.SelectedIndex = 0;
            txtCurrencyRate.Text = "";
            txtTotalIAmount.Text = "";
            ddlEmployee.SelectedIndex = 0;
            ddlTranType.SelectedIndex = 0;
            ddlTType.SelectedIndex = 0;
            txtRemarks.Text = "";
            ddlBank.SelectedIndex = 0;
            txtPaymentExpirationDate.Text = "";
            txtPaymentModeNo.Text = "";
            txtBalance.Text = "";
            grdPaymentDetails.DataSource = null;
            grdPaymentDetails.DataBind();
        }

        #region Binding Masters

        private void BindBankDetails()
        {
            BankBO objPaymentDetailsBO = new BankBO();
            List<Bank> lstPaymentHistory = new List<Bank>();
            lstPaymentHistory = objPaymentDetailsBO.GetBankList(false);
            if (lstPaymentHistory != null)
            {
                ddlBank.DataSource = lstPaymentHistory;
                ddlBank.DataBind();

                ddlBank.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }

        protected void BindCurrencyDropDown()
        {
            try
            {
                CurrencyBO objCurrencyBO = new CurrencyBO();

                
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlCurrency.AppendDataBoundItems = true;
                ddlCurrency.DataSource = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataTextField = "ConvertTo";
                ddlCurrency.DataValueField = "CIDRate";
                ddlCurrency.DataBind();


            }
            catch (Exception ex)
            {

                lblError.Text = "Error : " + ex.Message;
            }

        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.AppendDataBoundItems = true;
            objDD.DataBind();
        }



        #endregion

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                PaymentDetailsBO objPaymentDetailsBO = new PaymentDetailsBO();
                grdPaymentDetails.DataSource = objPaymentDetailsBO.GetOtherPaymentDetails(Convert.ToDateTime(txtFromDate.Text), Convert.ToDateTime(txtToDate.Text));
                grdPaymentDetails.DataBind();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error while search the payment detail result : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void ddlCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlCurrency.SelectedIndex != 0 && ddlPaymentMode.SelectedIndex > 0)
                {

                    txtCurrencyRate.Text = ddlCurrency.SelectedValue.Split('-')[1];
                    CompanyBalance objCompanyBalance = new CompanyBalance();
                    CompanyBalance objCompanyBalanceRET = new CompanyBalance();
                    CompanyBalanceBO objCompanyBalanceBO = new CompanyBalanceBO();
                    objCompanyBalance.BranchID = (Int16)LoginToken.CompanyID;
                    objCompanyBalance.CurrencyID = Convert.ToInt16(ddlCurrency.SelectedValue.Split('-')[0]);
                    objCompanyBalance.PaymentSourceID = Convert.ToInt16(ddlPaymentMode.SelectedValue.ToString());

                    objCompanyBalanceRET = objCompanyBalanceBO.GetCompanyBalanceStatus(objCompanyBalance);
                    if (objCompanyBalanceRET != null)
                    {
                        txtBalance.Text = Convert.ToString(objCompanyBalanceRET.CompanyBalanceAmount);

                    }



                }
                else
                {
                    txtCurrencyRate.Text = "";
                    lblError.Text = "Select A valid currency";
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error while change the currency : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }
    }
}