﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE
{
    public partial class CompanyCurrencyMST : BasePage
    {

        private CurrencyBO objCurrencyBO = new CurrencyBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MasterLookupBO mstlookup = new MasterLookupBO();
                BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
                dllBranch.Items.Insert(0, "--Select--");
                BindCurrencyDropDown();

                ViewState["IsEdit"] = false;
            }

           

        }


        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }


        protected void BindCurrencyDropDown()
        {
            try
            { 
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlCurrency.SelectedIndex = 0;

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error while show the list of currency : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                CompanyBalance Compbal = new CompanyBalance();
                CompanyBalanceBO CompbalBO = new CompanyBalanceBO();
                Compbal.BranchID = Convert.ToInt32(dllBranch.SelectedValue);
                Compbal.CompanyBalanceAmount = Convert.ToDecimal(txtCompanyBalance.Text);
                Compbal.CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue);
                Compbal.PaymentSourceID = Convert.ToInt32(ddlPaymentMode.SelectedValue);
                if (rdoStatus.SelectedIndex == 0)
                    Compbal.IsActive = true;
                else
                    Compbal.IsActive = false;


                if (ViewState["CompBalID"] != null)
                {

                    Compbal.CompanyBalanceID = Convert.ToInt32(ViewState["CompBalID"].ToString());
                    Compbal.ActionType = EnumActionType.Update;
                    Compbal.LastModBy = LoginToken.LoginId;
                    Compbal.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                    Compbal.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);

                }
                else
                {
                    Compbal.ActionType = EnumActionType.Insert;
                    Compbal.AddedBy = LoginToken.LoginId;
                    Compbal.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                    Compbal.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                }
                if (CompbalBO.SaveBillPaymentDetails(Compbal))
                {
                    if (ViewState["CompBalID"] != null)
                        lblError.Text = "Company balance Updated Successfully";
                    else
                        lblError.Text = "Company balance Added Successfully";

                    ViewState["CompBalID"] = null;
                    ViewState["IsEdit"] = false;
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {                
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "This record is already exist so please make any other record,Record should be unique : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

       

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                CompanyBalance Compbal = new CompanyBalance();
                CompanyBalanceBO CompbalBO = new CompanyBalanceBO();
                List<CompanyBalance> lstSalesType = new List<CompanyBalance>();

                if (dllBranch.SelectedValue != "--Select--")
                {
                    Compbal.BranchID = int.Parse(dllBranch.SelectedValue);
                }
                else
                {
                    Compbal.BranchID = 0;
                }
                if (ddlCurrency.SelectedItem.Text != "--Select--")
                {
                    Compbal.CurrencyID = int.Parse(ddlCurrency.SelectedValue);
                }
                else
                {
                    Compbal.CurrencyID = 0;
                }
                lstSalesType = CompbalBO.GetPaymentDetailsListByBillID(Compbal);
                grdCompBalance.DataSource = lstSalesType;
                grdCompBalance.DataBind();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error while search the records : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void grdCompBalance_RowCommand1(object sender, GridViewCommandEventArgs e)
        {

            try
            {
                if (e.CommandName == "REdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    GridViewRow gr = grdCompBalance.Rows[id];
                    Label lblBranch = (Label)gr.FindControl("lblbranchId");
                    Label lblCurrency = (Label)gr.FindControl("lblCurrencyID");
                    Label lblAmount = (Label)gr.FindControl("lblCompAmount");
                    Label lblPaymentMode = (Label)gr.FindControl("lblMode");
                    CheckBox chkIsActive = (CheckBox)gr.Cells[6].FindControl("chkIsActive");
                    LinkButton lblID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");


                    txtCompanyBalance.Text = lblAmount.Text;
                    ddlCurrency.SelectedValue = lblCurrency.Text;
                    ddlPaymentMode.SelectedValue = lblPaymentMode.Text;
                    dllBranch.SelectedValue = lblBranch.Text;
                   ViewState["CompBalID"] = lblID.Text;
                    ViewState["IsEdit"] = true;
                    if (chkIsActive.Checked)
                    {
                        rdoStatus.SelectedIndex = 0;

                    }
                    else
                    {
                        rdoStatus.SelectedIndex = 1;

                    }
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error while fetching the record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

      

        protected void Reset()
        {

            txtCompanyBalance.Text = "";
            ddlCurrency.SelectedIndex = 0;
            ddlPaymentMode.SelectedIndex = 0;
            dllBranch.SelectedIndex = 0;
            rdoStatus.SelectedIndex = 0;
            lblError.Text = "";
            grdCompBalance.DataSource = null;
            grdCompBalance.DataBind();
        }

        protected void btnReset_Click1(object sender, EventArgs e)
        {
            Reset();
        }
    }
}