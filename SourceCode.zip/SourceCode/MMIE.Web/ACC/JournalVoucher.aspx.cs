﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.Common;
//using MMIE.Data.ADM;
using MMIE.Data.ACC;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.ACC
{
    public partial class JournalVoucher : BasePage
    {
        private MasterLookupBO mstlookup = new MasterLookupBO();
        int SearchCustomerID = 0;
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsAddOn;
            }
        }


        protected void ClearAll()
        {
            ViewState["IsEdit"] = false;

            Session["JournalEntry"] = null;
            ViewState["IsEdit"] = false;
            txtAmountCR.Text = "";
            txtAmountDR.Text = "";
            txtDated.Text = DateTime.Now.ToShortDateString();
            txtLedgerDetails.Text = "";
            txtLedgerHeader.Text = "";
            ddlTType.SelectedIndex = 0;
            gvJournalEntryDetail.DataSource = null;
            gvJournalEntryDetail.DataBind();

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            txtAmountDR.Attributes.Add("ReadOnly", "True");
            txtAmountCR.Attributes.Add("ReadOnly", "True");
            if (!IsPostBack)
            {
                //BindMappedAccountGroup();
                BindTreeView();
                ViewState["AccountID"] = 0;
                ViewState["IsEdit"] = false;
                Session["JournalEntry"] = null;
                txtDated.Text = System.DateTime.Now.ToShortDateString();
            }
            System.DateTime.Now.ToShortDateString();
            PagePermission();

        }
        private void BindDropDownControl(DropDownList objDD, List<MMIE.Data.Common.LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        private void BindMappedAccountGroup()
        {
            AccountGroup obj = new AccountGroup();
            obj.FinancialYearID = (Int16)LoginToken.FinancialYearID;
            obj.CompanyID = LoginToken.CompanyID;
            JournalDetailsBO objLedgerBO = new JournalDetailsBO();
            List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
            lstAccountGroup = objLedgerBO.GetAccountGroupList(obj);

            //ddlDebitAccountGroup.DataSource = lstAccountGroup;
            //ddlDebitAccountGroup.DataTextField = "GroupName";
            //ddlDebitAccountGroup.DataValueField = "AccountGroupID";
            //ddlDebitAccountGroup.DataBind();
            //ddlDebitAccountGroup.Items.Insert(0, "--Select--");

            //ddlCreditAccountGroup.DataSource = lstAccountGroup;
            //ddlCreditAccountGroup.DataTextField = "GroupName";
            //ddlCreditAccountGroup.DataValueField = "AccountGroupID";
            //ddlCreditAccountGroup.DataBind();
            //ddlCreditAccountGroup.Items.Insert(0, "--Select--");


        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            JournalDetails objJournalDetails = new JournalDetails();
            JournalDetailsBO objJournalDetailsBO = new JournalDetailsBO();
            objJournalDetails.Details = txtLedgerDetails.Text;
            objJournalDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
            objJournalDetails.CompanyID = (Int16)LoginToken.CompanyID;
            objJournalDetails.ActionType = EnumActionType.Insert;
            objJournalDetails.EntryDate = txtDated.Text;
            objJournalDetails.IsActive = true;
            objJournalDetails.IsLocked = false;
            objJournalDetails.XMLData = XMLConverter.JournalDetailsListToXML((List<JournalDetails>)Session["JournalEntry"]).ToString();

            if (objJournalDetailsBO.SaveJournalEntry(objJournalDetails))
            {
                lblError.Text = "Record Added Successfully";
                ClearAll();
            }
        }

        protected void AddEntry_Click(object sender, EventArgs e)
        {
            List<JournalDetails> lstJournalEntry = Session["JournalEntry"] == null ? new List<JournalDetails>() : (List<JournalDetails>)Session["JournalEntry"];

            if (lstJournalEntry.Count > 0)
            {
                List<JournalDetails> lstJournalEntry1 = lstJournalEntry.FindAll(x => x.LedgerAccountID == Convert.ToInt32(ViewState["LedgerAccountID"]));

                if (lstJournalEntry1.Count > 0)
                {
                    lblError.Text = "Transaction could not be done for same Ledger account. Please try again.";
                    return;
                }
            }

            JournalDetails objJournalDetails = new JournalDetails();
            if (ddlTType.SelectedValue.ToString() == "DR")
            {
                if (txtAmountDR.Text != "")
                {
                    objJournalDetails.DebitAmount = Convert.ToDecimal(txtAmountDR.Text);
                }

            }
            if (ddlTType.SelectedValue.ToString() == "CR")
            {
                if (txtAmountCR.Text != "")
                {
                    objJournalDetails.CreditAmount = Convert.ToDecimal(txtAmountCR.Text);
                }
            }
            objJournalDetails.AccountName = txtLedgerHeader.Text;
            objJournalDetails.TType = ddlTType.SelectedValue.ToString();
            objJournalDetails.LedgerAccountID = Convert.ToInt32(ViewState["LedgerAccountID"]);


            objJournalDetails.IsLocked = false;

            objJournalDetails.IsActive = true;

            lstJournalEntry.Add(objJournalDetails);

            Session["JournalEntry"] = lstJournalEntry;
            gvJournalEntryDetail.DataSource = lstJournalEntry;
            gvJournalEntryDetail.DataBind();
            txtLedgerHeader.Text = "";
            txtAmountCR.Text = "";
            txtAmountDR.Text = "";
            ddlTType.SelectedIndex = 0;
            ViewState["LedgerAccountID"] = null;
            txtLedgerHeader.Focus();

        }

        void BindTreeView()
        {
            List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
            AccountGroup objAccountGroup = new AccountGroup();
            //objAccountGroup.IsActive = true;

            AccountGroupBO objAccountGroupBO = new AccountGroupBO();

            objAccountGroup.IsActive = true;
            lstAccountGroup = objAccountGroupBO.GetSearchVoucherGroup(objAccountGroup);
            lstBoxVoucherGroup.DataSource = lstAccountGroup;
            lstBoxVoucherGroup.DataTextField = "VoucherGroupName";
            lstBoxVoucherGroup.DataValueField = "VoucherGroupID";
            lstBoxVoucherGroup.DataBind();


            //foreach (AccountGroup obj in lstAccountGroup)
            //{
            //    //  TreeNode tr = new TreeNode(obj.VoucherGroupName.ToString(), obj.VoucherGroupID.ToString());
            //    //MenuItem Itm = new MenuItem(obj.VoucherGroupName.ToString(), obj.VoucherGroupID.ToString());
            //    //mnuVoucherGroup.Items.Add(Itm);
            //    //  tvVoucherGroup.Nodes.Add(tr);


            //    //    List<AccountGroup> lstAccountGroup1 = new List<AccountGroup>();
            //    //AccountGroup objAccountGroup1 = new AccountGroup();
            //    //objAccountGroup1.IsActive = true;
            //    //objAccountGroup1.VoucherGroupID = obj.VoucherGroupID;
            //    //AccountGroupBO objAccountGroupBO1 = new AccountGroupBO();
            //    //lstAccountGroup1 = objAccountGroupBO1.GetSearchAccountGroup(objAccountGroup1);
            //    //foreach (AccountGroup obj1 in lstAccountGroup1)
            //    //{
            //    //    TreeNode tr1 = new TreeNode(obj1.GroupName.ToString(),obj1.VoucherGroupID.ToString());
            //    //  tvVoucherGroup.Nodes[i].ChildNodes.Add(tr1);

            //    //}
            //    // i++;


            //}


        }

        protected void tvVoucherGroup_SelectedNodeChanged(object sender, EventArgs e)
        {
            LedgerHeader obj = new LedgerHeader();
            LedgerHeader objRet = new LedgerHeader();
            LedgerHeaderBO objBO = new LedgerHeaderBO();
            //obj.LedgerAccountID= Convert.ToInt32((tvVoucherGroup.SelectedValue.ToString()));
            //objRet= objBO.GetAccountGroupByID(obj);

            //txtLedgerDetails.Text = objRet.AccountName;





        }

        protected void tvVoucherGroup_TreeNodeCollapsed(object sender, TreeNodeEventArgs e)
        {

        }

        protected void tvVoucherGroup_TreeNodeExpanded(object sender, TreeNodeEventArgs e)
        {

        }

        protected void txtLedgerHeader_TextChanged(object sender, EventArgs e)
        {

            string GetCustomerId = txtLedgerHeader.Text.TrimStart();
            string[] SplitGetCustomerId = GetCustomerId.TrimStart().Split('-');
            int i = 0;
            int countidLen = 0; //Convert.ToInt16(SplitGetCustomerId.Length) + 1;

            if (SplitGetCustomerId.Count() > 1)
            {
                foreach (string word in SplitGetCustomerId)
                {
                    i = i + 1;
                    if (i == 1)
                    {
                        SearchCustomerID = Convert.ToInt32(word);
                        countidLen = word.Length + 1;
                        ViewState["LedgerAccountID"] = SearchCustomerID;
                        txtLedgerHeader.Text = txtLedgerHeader.Text.TrimStart().Remove(0, countidLen);



                    }
                    i = i + 1;
                }
            }

            ddlTType.Focus();

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            ClearAll();


        }


        protected void lstBoxVoucherGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            AutoCompleteExtender1.ContextKey = lstBoxVoucherGroup.SelectedValue;
        }

        protected void gvJournalEntryDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }



        protected void gvJournalEntryDetail_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "RDelete")
            {
                int id = Convert.ToInt32(e.CommandArgument.ToString());
                List<JournalDetails> lstJournalEntry = Session["JournalEntry"] == null ? new List<JournalDetails>() : (List<JournalDetails>)Session["JournalEntry"];
                lstJournalEntry.RemoveAt(id - 1); ;

                Session["JournalEntry"] = lstJournalEntry;
                gvJournalEntryDetail.DataSource = lstJournalEntry;
                gvJournalEntryDetail.DataBind();


            }
        }

        protected void gvJournalEntryDetail_OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //Change row colour on mouseover and mouseout
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
            }
        }

    }
}