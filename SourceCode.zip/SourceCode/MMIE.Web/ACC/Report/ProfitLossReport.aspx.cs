﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.ACC;
using MMIE.Data;
using System.IO;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Data.ACC;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.ACC.Report
{
    public partial class ProfitLossReport : BasePage
    {
        protected void PagePermission()
        {
            if (LoginToken != null)
            {

                dllBranch.SelectedValue = Convert.ToString(LoginToken.CompanyID);
                dllBranch.Enabled = LoginToken.IsChangeBranchOn;
                ddlFinancialYear.SelectedValue = Convert.ToString(LoginToken.FinancialYearID);
                ddlFinancialYear.Enabled = LoginToken.IsChangeBranchOn;
                btnPrint.Enabled = LoginToken.IsPrintOn;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            txtStartDate.Attributes.Add("ReadOnly", "True");
            txtEndDate.Attributes.Add("ReadOnly", "True");

            if (!IsPostBack)
            {
                BindBranchDetails();
                BindFinancialYear();
                //BindLegerAccount();
            }

            PagePermission();
        }


        protected void BindBranchDetails()
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
            dllBranch.Items.Insert(0, "--Select--");

        }

        protected void BindFinancialYear()
        {

            MasterLookupBO mstlookup = new MasterLookupBO();
            BindDropDownControl(ddlFinancialYear, mstlookup.GetLookupsList(LookupNames.FinancialYear));
            ddlFinancialYear.Items.Insert(0, "--Select--");
        }

      
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

     

    }
}