﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.ACC;
using MMIE.Data;
using System.IO;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Data.ACC;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.ACC.Report
{
    public partial class LedgerAccountReport : BasePage
    {
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                    
                    dllBranch.SelectedValue = Convert.ToString(LoginToken.CompanyID);
                    dllBranch.Enabled = LoginToken.IsChangeBranchOn;
                    ddlFinancialYear.SelectedValue = Convert.ToString(LoginToken.FinancialYearID);
                    ddlFinancialYear.Enabled = LoginToken.IsChangeBranchOn;
                    btnPrint.Enabled = LoginToken.IsPrintOn;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindBranchDetails();
                BindFinancialYear();
                BindLegerAccount();
            }

            PagePermission();
        }


        protected void BindBranchDetails()
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
            dllBranch.Items.Insert(0, "--Select--");

        }

        protected void BindFinancialYear()
        {

            MasterLookupBO mstlookup = new MasterLookupBO();
            BindDropDownControl( ddlFinancialYear, mstlookup.GetLookupsList(LookupNames.FinancialYear));
            ddlFinancialYear.Items.Insert(0, "--Select--");
        }

        protected void BindLegerAccount()
        {
            LedgerHeader objLedger = new LedgerHeader();
            LedgerHeaderBO objBO = new LedgerHeaderBO();
            List<LedgerHeader> lstLedger = new List<LedgerHeader>();
            if (dllBranch.SelectedIndex > 0)
                objLedger.CompanyID = Convert.ToInt16(dllBranch.SelectedValue.ToString());
            else
                objLedger.CompanyID =(Int16)LoginToken.CompanyID;
            objLedger.FinancialYearID =(Int16)LoginToken.FinancialYearID;
            objLedger.IsActive = true;
            lstLedger = objBO.GetSearchLedgerHeader(objLedger);
            ddlLedgerAccount.DataSource = lstLedger;
            ddlLedgerAccount.DataTextField = "AccountName";
            ddlLedgerAccount.DataValueField = "LedgerAccountID";
            ddlLedgerAccount.DataBind();

            ddlLedgerAccount.Items.Insert(0, new ListItem("--Select--", "0"));



        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        protected void dllBranch_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindLegerAccount();
        }

        
    }
}