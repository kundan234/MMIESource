﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.Common;
//using MMIE.Data.ADM;
using MMIE.Data.ACC;

using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.ACC
{
    
    public partial class Company : BasePage
    {
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;
        int iPageCount = 0;
        List<AccountCompany> lstCompany = null;
        DataSet ds = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            if (!IsPostBack)
            {
                CallSearch();
                grdCompany.PageSize = GRID_PAGESIZE;
                BindDropDownControl(drFinancialYear, mstlookup.GetLookupsList(LookupNames.FinancialYear));
                if (Request.QueryString["compid"] != null)
                {
                    int compid = Convert.ToInt32(Request.QueryString["compid"].ToString());
                    ViewState["compid"] = compid;
                    BindCompanyDetail(compid);
                }
            }
        }
        private void BindDropDownControl(DropDownList objDD, List<MMIE.Data.Common.LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }
        private void BindCompanyDetail(int compid)
        {
            AccountCompanyBO useradm = new AccountCompanyBO();
            AccountCompany objCompany = new AccountCompany();
            objCompany.AccountCompanyID =Convert.ToInt16(compid);
            AccountCompany objRetCompany = useradm.GetCompanyByID(objCompany);
            if (objRetCompany != null)
            {
                ddlBusinessType.SelectedItem.Text = objRetCompany.CompanyBusinessType;
                txtCompanyName.Text = objRetCompany.CompanyName;
                txtLegalName.Text = objRetCompany.CompanyLegalName;
                txtStreet.Text = objRetCompany.CompanyAddress ;
                txtLandMark.Text = objRetCompany.CompanyLandMark;
                txtZipCode.Text = objRetCompany.ZipCode;
                txtFax.Text = objRetCompany.CompanyFaxNo;
                txtEmail.Text = objRetCompany.CompanyEmailID;
                txtWebsite.Text = objRetCompany.CompanyWebsite ;
                drFinancialYear.SelectedValue = Convert.ToString(objRetCompany.CompanyFiscalYearID);
                txtPhone.Text = objRetCompany.CompanyPhone;
                txtAnnualRevenue.Text = Convert.ToString(objRetCompany.AnnualRevenue);
                txtCity.Text = objRetCompany.CityName;
                txtCountry.Text = objRetCompany.CountryName;
                ViewState["CityID"] = objRetCompany.CityID;
                ViewState["CountryID"] = objRetCompany.CountryID;
                txtState.Text = objRetCompany.StateCode;
                if (objRetCompany.IsActive )
                {
                    rdoStatus.SelectedIndex = 0;
                }
                else
                {
                    rdoStatus.SelectedIndex = 1;
                }
             
            }
            else
            {
               
            }
        }
        public void CallSearch()
        {
            grdCompany.PageIndex = 0;
            AccountCompany objCompany = new AccountCompany();
            objCompany.AccountCompanyID = 0;
            objCompany.CompanyName = "";
            objCompany.CurrentIndex = 0;
            objCompany.PageSize = GlobalConstant.PageSize;
            //Save Search Options in ViewState
            ViewState[VS_SEARCH] = objCompany;
            BindData(0);

        }

        private void BindData(int currentPageIndex)
        {
            grdCompany.PageIndex = 0;
            PagedDataSource objPagedDataSource = new PagedDataSource();
            objPagedDataSource.AllowCustomPaging = true;
            objPagedDataSource.PageSize = GRID_PAGESIZE;
            objPagedDataSource.CurrentPageIndex = currentPageIndex;
            //Get search option from viewstate
            AccountCompany objCompany = (AccountCompany)ViewState[VS_SEARCH];
            objCompany.CurrentIndex = currentPageIndex;
            //Save Search Option again
            ViewState[VS_SEARCH] = objCompany;
            //Call service operation to get data from database source
            ds = SearchCompany(objCompany);
            if (ds.Tables[0].Rows.Count > 0)
            {
                pnlNavigation.Visible = true;
                this.grdCompany.Visible = true;
                //Bind data in ViewGrid.
                objPagedDataSource.VirtualCount = Convert.ToInt32(ds.Tables[0].Rows[0]["MaximumRows"]);
                //Save Virtual Count in ViewState
                ViewState[VS_MAXROWS] = objPagedDataSource.VirtualCount;
                CreateNavigation(currentPageIndex, objPagedDataSource.PageSize, objPagedDataSource.VirtualCount);
                objPagedDataSource.DataSource = ds.Tables[0].DefaultView;
                grdCompany.DataSource = objPagedDataSource;
                grdCompany.DataBind();
            }
            else
            {
                grdCompany.DataSource = null;
                grdCompany.DataBind();
                pnlNavigation.Visible = false;
            }
        }
       

        private DataSet SearchCompany(AccountCompany objCompany)
        {
            //Call service operation to get data from database source
            AccountCompanyBO st = new AccountCompanyBO();
            lstCompany = st.SearchCompany(objCompany);
            DataTable dt = ORHelper<Company>.GenericListToDataTable(lstCompany);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    LoginToken objLoginToken = new LoginToken();
                    AccountCompany objCompany = new AccountCompany();
                    objCompany.CompanyBusinessType = ddlBusinessType.SelectedItem.Text;
                    objCompany.CompanyName = txtCompanyName.Text;
                    objCompany.CompanyLegalName = txtLegalName.Text;
                    objCompany.CompanyAddress = txtStreet.Text;
                    objCompany.CompanyLandMark = txtLandMark.Text;
                    objCompany.CompanyFiscalYearID = Convert.ToInt32(drFinancialYear.SelectedValue);
                    objCompany.ZipCode = txtZipCode.Text;
                    objCompany.CompanyPhone = txtPhone.Text;
                    objCompany.CompanyEmailID = txtEmail.Text;
                    objCompany.CompanyWebsite = txtWebsite.Text;
                    objCompany.CompanyFaxNo  = txtFax.Text;  
                    objLoginToken.LoginId = LoginToken.LoginId;
                    objCompany.LastModBy = LoginToken.LoginId;
                    objCompany.AddedBy = LoginToken.LoginId;
                    objCompany.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                    objCompany.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    objCompany.AnnualRevenue = Convert.ToDecimal(txtAnnualRevenue.Text);
                    objCompany.CityID = Convert.ToInt32(ViewState["CityID"]);
                    objCompany.CountryID = Convert.ToInt32(ViewState["CountryID"]);
                    objCompany.StateCode = txtState.Text;
                    if (rdoStatus.SelectedIndex == 0)
                    {
                        objCompany.IsActive  = true;
                    }
                    else
                    {
                        objCompany.IsActive = false;

                    }
                    if (ViewState["compid"] != null)
                    {

                        objCompany.ActionType = EnumActionType.Update;
                        objCompany.AccountCompanyID = Convert.ToInt16(ViewState["compid"]);
                    }
                    else
                    {
                        objCompany.ActionType = EnumActionType.Insert;
                    }

                    AccountCompanyBO Comp = new AccountCompanyBO();
                    bool status = Comp.SaveCompany(objCompany);
                    if (status == true)
                    {
                        CallSearch(); 
                        //display succuss message
                        lblError.Visible = true;
                        lblError.Text = ExceptionMessage.GetMessage("C00001");
                        ddlBusinessType.SelectedItem.Text = "Select";
                        txtCompanyName.Text = "";
                        txtLegalName.Text = "";
                        txtLandMark.Text = "";
                        txtZipCode.Text = "";
                        txtAnnualRevenue.Text = "";
                        txtCity.Text = "";
                        txtCountry.Text = "";
                        txtState.Text = "";
                        txtPhone.Text = "";
                        txtEmail.Text = "";
                        txtWebsite.Text = "";
                        txtFax.Text = "";
                        txtStreet.Text = "";
                        txtFax.Text = "";
                        txtStreet.Text = "";
                        ViewState["compid"] = null;
                        ViewState["CityID"] = null;
                        ViewState["CountryID"] = null;

                    }
                }
               }
                    
              

            
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void txtCity_TextChanged(object sender, EventArgs e)
        {
            BindCityDetail(txtCity.Text);
        }
        private void BindCityDetail(string cityname)
        {
            CityMST objcity = new CityMST();
            CityBO objcityBO = new CityBO();
            string[] listName = cityname.Split('#');

            if (cityname != "" && listName != null)
            {

                int id = Convert.ToInt32(listName[0]);
                objcity = objcityBO.GetCityByID(id);
                ViewState["CityID"] = objcity.CityID.ToString();
                txtCity.Text = objcity.CityName;
                ViewState["CountryID"] = objcity.CountryId.ToString();
                txtCountry.Text = objcity.CountryName;
                txtState.Text = objcity.State_Code;
            }
            else
            {
                ViewState["CityID"] = null;
                ViewState["CountryID"] = null;
                txtCity.Text = "";
                txtCountry.Text = "";
                txtState.Text = "";
            }

        }


        protected void btnReset_Click(object sender, EventArgs e)
        {
            ddlBusinessType.SelectedItem.Text="Select";
            txtCompanyName.Text="";
            txtLegalName.Text="";
            txtLandMark.Text="";
            txtZipCode.Text = "";
            txtAnnualRevenue.Text = "";
            txtCity.Text = "";
            txtCountry.Text = "";
            txtState.Text = "";
            txtPhone.Text="";
            txtEmail.Text="";
            txtWebsite.Text="";
            txtFax.Text = "";
            txtStreet.Text = "";
            txtFax.Text = "";
            txtStreet.Text = "";
            ViewState["compid"] = null;
            ViewState["CityID"] = null;
            ViewState["CountryID"] = null;
        }
        #region Create Paging Navigation and Event handler

        private void CreateNavigation()
        {
            if (ViewState[VS_CURRENTINDEX] == null || ViewState[VS_PAGESIZE] == null || ViewState[VS_MAXROWS] == null)
            {
                return;
            }
            else
            {
                CreateNavigation((int)ViewState[VS_CURRENTINDEX], (int)ViewState[VS_PAGESIZE], (int)ViewState[VS_MAXROWS]);
            }
        }

        private void CreateNavigation(int currentPageIndex, int a_iPageSize, int a_iRowCount)
        {
            //Save the arguments in ViewState
            ViewState[VS_CURRENTINDEX] = currentPageIndex;
            ViewState[VS_PAGESIZE] = a_iPageSize;
            ViewState[VS_MAXROWS] = a_iRowCount;
            pnlNavigation.Controls.Clear();
            if (a_iPageSize == 0)
            {
                return;
            }

            //Get the TotalNumber of Pages
            //int iPageCount = 0;
            iPageCount = 0;
            if (a_iRowCount % a_iPageSize == 0)
            {
                iPageCount = a_iRowCount / a_iPageSize;
            }
            else
            {
                iPageCount = (a_iRowCount / a_iPageSize) + 1;
            }

            if (iPageCount <= 1)
            {
                return;
            }

            //Check if LeftDots are to be displayed
            if ((currentPageIndex + 1) - 5 > 1)
            {
                //Start when left dots are visible then show << button also
                LinkButton linkFirst = new LinkButton();
                linkFirst.Text = "<<";
                linkFirst.CssClass = "lftmenu";
                linkFirst.ID = "linkFirst";
                linkFirst.Click += new EventHandler(linkFirst_Click);
                pnlNavigation.Controls.Add(linkFirst);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
                //End when left dots are visible then show << button also

                int iLIndex = (currentPageIndex + 1) - 5 - 1;
                //Add LeftDots
                LinkButton btnLeftDots = new LinkButton();
                btnLeftDots.Text = "...";
                btnLeftDots.CssClass = "lftmenu";
                btnLeftDots.ID = "nav_" + iLIndex.ToString();
                btnLeftDots.Attributes.Add("onclick", "__doPostBack('" + btnLeftDots.ClientID + "',' " + iLIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            int iLeftIndex = 1;

            if (currentPageIndex + 1 - 5 > 1)
            {
                iLeftIndex = currentPageIndex + 1 - 5;
            }

            //Create the Number buttons on the left side of the index
            for (int i = iLeftIndex; i <= currentPageIndex; i++)
            {
                LinkButton btnLeftNumbers = new LinkButton();
                btnLeftNumbers.Text = i.ToString();
                btnLeftNumbers.CssClass = "lftmenu";
                btnLeftNumbers.ID = "nav_" + i.ToString();
                btnLeftNumbers.Attributes.Add("onclick", "__doPostBack('" + btnLeftNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Display the Current Page Number
            Label lblCurrent = new Label();
            lblCurrent.Text = Convert.ToString(currentPageIndex + 1);
            lblCurrent.CssClass = "textNormal";
            pnlNavigation.Controls.Add(lblCurrent);
            pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

            //Create Right Number buttons
            int iRightIndex = iPageCount;

            if (currentPageIndex + 1 + 5 < iRightIndex)
            {
                iRightIndex = 5;//currentPageIndex + 1 + 5;
            }

            for (int i = currentPageIndex + 2; i <= iRightIndex; i++)
            {
                LinkButton btnRightNumbers = new LinkButton();
                btnRightNumbers.Text = i.ToString();
                btnRightNumbers.CssClass = "lftmenu";
                btnRightNumbers.ID = "nav_" + i.ToString();
                btnRightNumbers.Attributes.Add("onclick", "__doPostBack('" + btnRightNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Check if RightDots are to be displayed
            if ((currentPageIndex + 1) + 5 < iPageCount)
            {
                int iRIndex = ((currentPageIndex + 1) + 5) + 1;
                //Add RightDots
                LinkButton btnRightDots = new LinkButton();
                btnRightDots.Text = "...";
                btnRightDots.CssClass = "lftmenu";
                btnRightDots.ID = "nav_" + iRIndex.ToString();
                btnRightDots.Attributes.Add("onclick", "__doPostBack('" + btnRightDots.ClientID + "',' " + iRIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

                //Start when right dots are visible then show >> button also
                LinkButton linkLast = new LinkButton();
                linkLast.Text = ">>";
                linkLast.CssClass = "lftmenu";
                linkLast.ID = "linkLast";
                linkLast.Click += new EventHandler(linkLast_Click);
                pnlNavigation.Controls.Add(linkLast);
                //End when left dots are visible then show << button also
            }
        }

        protected void linkFirst_Click(object sender, EventArgs e)
        {
            BindData(0);
        }

        protected void linkLast_Click(object sender, EventArgs e)
        {
            BindData(iPageCount - 1);
        }
        #endregion
        public string MakeCustomerIDLink(int CompanyID, string CompanyName)
        {
            string ret;
            string str;
            string pageName;
            pageName = "Company.aspx";
            str = pageName + "?compid=" + CompanyID.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + CompanyName + "</a>";
            return ret;
        }

       
    }
}