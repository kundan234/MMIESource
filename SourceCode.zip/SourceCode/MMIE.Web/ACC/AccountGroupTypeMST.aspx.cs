﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.Common;
//using MMIE.Data.ADM;
using MMIE.Data.ACC;

using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.ACC
{
    public partial class AccountGroupTypeMST :BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                ViewState["IsEdit"] = false;
                //BindSearchVoucherGroupList();
            }
            PagePermission();
        }


        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsAddOn;
            }
        }


        protected void btnSave_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records Please contact to your System Administrator";
                return;

            }

            try
            {
                AccountGroupType objAccountGroupType = new AccountGroupType();
                AccountGroupTypeBO objAccountGroupTypeBO = new AccountGroupTypeBO();

                objAccountGroupType.AccountNumber = Convert.ToInt32(txtAccounNumber.Text);
                objAccountGroupType.AccountType = ddlAccountType.SelectedItem.Text;


                if (rbtBalanceSheetItem.SelectedIndex == 0)
                {
                    objAccountGroupType.IsBalanceSheet = true;


                }
                else
                {
                    objAccountGroupType.IsBalanceSheet = false;

                }

                if (rbtIsActive.SelectedIndex==0)
                {
                    objAccountGroupType.IsActive= true;


                }
                else
                {
                    objAccountGroupType.IsActive= false;

                }
                if (rbtPLItem.SelectedIndex == 0)
                {
                    objAccountGroupType.IsPLItem = true;


                }
                else
                {
                    objAccountGroupType.IsPLItem = false;

                }

                if (ddlAccountType.SelectedIndex > 0)
                {

                    objAccountGroupType.AccountType = (ddlAccountType.SelectedValue.ToString());
                    objAccountGroupType.GroupTypeName = txtAccountGrouptypeName.Text;
                }

                if (ViewState["GroupTypeID"] != null)
                {

                    objAccountGroupType.GroupTypeID = Convert.ToInt32(ViewState["GroupTypeID"].ToString());
                    objAccountGroupType.ActionType = EnumActionType.Update;
                    objAccountGroupType.LastModBy = LoginToken.LoginId;
                    objAccountGroupType.CompanyID = LoginToken.CompanyID;
                    objAccountGroupType.FinancialYearID = (Int16)LoginToken.FinancialYearID;

                }
                else
                {

                    objAccountGroupType.GroupTypeID = 0;
                    objAccountGroupType.ActionType = EnumActionType.Insert;
                    objAccountGroupType.AddedBy = LoginToken.LoginId;
                    objAccountGroupType.CompanyID = LoginToken.CompanyID;
                    objAccountGroupType.FinancialYearID = (Int16)LoginToken.FinancialYearID;

                }

                if (objAccountGroupTypeBO.SaveAccountGroupType(objAccountGroupType))
                {
                    if (ViewState["GroupTypeID"] != null)
                        lblError.Text = "AccountGroup Updated Successfully";
                    else
                        lblError.Text = "AccountGroup Added Successfully";

                    ViewState["GroupTypeID"] = null;
                    txtAccounNumber.Text = "";
                    txtAccountGrouptypeName.Text = "";
                    ddlAccountType.SelectedIndex = 0;
                    //ddlVoucherType.SelectedIndex = 0;



                    ViewState["IsEdit"] = false;
                }
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Saving Record : " + Ex.Message;
            }
        }


        private void BindAccountGroupTypeMasterList()
        {
            try
            {
                AccountGroupType objaccgrptype = new AccountGroupType();
                if (txtAccounNumber.Text != "")
                    objaccgrptype.AccountNumber =Convert.ToInt32(txtAccounNumber.Text);
                else
                    objaccgrptype.AccountNumber = Convert.ToInt32(null);
     
                    objaccgrptype.GroupTypeName = txtAccountGrouptypeName.Text;
     
     
                if (ddlAccountType.SelectedIndex > 0)
                    objaccgrptype.AccountType = ddlAccountType.SelectedItem.Text;
                else
                    objaccgrptype.AccountType = null;
     
                if (rbtPLItem.SelectedIndex > 0)
                    objaccgrptype.IsPLItem = false;
                else
                    objaccgrptype.IsPLItem = true;

                if (rbtBalanceSheetItem.SelectedIndex > 0)
                    objaccgrptype.IsBalanceSheet= false;
                else
                    objaccgrptype.IsBalanceSheet= true;

                if (rbtIsActive.SelectedIndex > 0)
                    objaccgrptype.IsActive=false;
                else
                    objaccgrptype.IsActive= true;

                AccountGroupTypeBO objAccGrpTypeBO = new AccountGroupTypeBO();
                List<AccountGroupType> lstgrptype = new List<AccountGroupType>();
                lstgrptype = objAccGrpTypeBO.GetAccountGroupTypeList(objaccgrptype);
                grdAccountGroupTypeMaster.DataSource = lstgrptype;
                grdAccountGroupTypeMaster.DataBind();

            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching AccountGroup List : " + Ex.Message;
            }

        }
        protected void bntSearch_Click(object sender, EventArgs e)
        {
            BindAccountGroupTypeMasterList();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            txtAccounNumber.Text = "";
            txtAccountGrouptypeName.Text = "";
            ddlAccountType.SelectedIndex = 0;
            rbtBalanceSheetItem.SelectedIndex = 0;
            rbtIsActive.SelectedIndex = 0;
            rbtPLItem.SelectedIndex = 0;
            ViewState["GroupTypeID"] = null;
            grdAccountGroupTypeMaster.DataSource = null;
            grdAccountGroupTypeMaster.DataBind();
            ViewState["IsEdit"] = false;
        }

        protected void grdAccountGroupTypeMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "REdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    GridViewRow gr = grdAccountGroupTypeMaster.Rows[id];
                    LinkButton lblGrpID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");

                    AccountGroupType objgrpMST = new AccountGroupType();
                    AccountGroupType objGroupType = new AccountGroupType();
                    AccountGroupTypeBO objBOAccTypeMST = new AccountGroupTypeBO();

                    //objgrpMST.GroupTypeID = Convert.ToInt32(lblGrpID.Text);

                    objgrpMST.GroupTypeID = Convert.ToInt32(lblGrpID.Text);
                    objGroupType = objBOAccTypeMST.GetAccountGroupTypeByID(objgrpMST);
                    if (objGroupType != null)
                    {
                        txtAccounNumber.Text = objGroupType.AccountNumber.ToString();
                        txtAccountGrouptypeName.Text = objGroupType.GroupTypeName;
                        ddlAccountType.SelectedValue = objGroupType.AccountType;
                        rbtBalanceSheetItem.SelectedValue = objGroupType.IsBalanceSheet.ToString();
                        rbtIsActive.SelectedValue = objGroupType.IsActive.ToString();
                        rbtPLItem.SelectedValue = objGroupType.IsPLItem.ToString();
                        ViewState["GroupTypeID"] = objGroupType.GroupTypeID;
                        ViewState["IsEdit"] = true;
                    }


                      if (objGroupType.IsActive)
                    {
                        rbtIsActive.SelectedIndex = 0;

                    }
                    else
                    {
                        rbtIsActive.SelectedIndex = 1;

                    }
                    if (objGroupType.IsPLItem)
                    {
                        rbtPLItem.SelectedIndex = 0;

                    }
                    else
                    {
                        rbtPLItem.SelectedIndex = 1;

                    }

                    if (objGroupType.IsBalanceSheet)
                    {
                        rbtBalanceSheetItem.SelectedIndex = 0;

                    }
                    else
                    {
                        rbtBalanceSheetItem.SelectedIndex = 1;

                    }
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void grdAccountGroupTypeMaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdAccountGroupTypeMaster.PageIndex = e.NewPageIndex;
            BindAccountGroupTypeMasterList();
        }
    }
}