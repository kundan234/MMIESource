﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.Common;
//using MMIE.Data.ADM;
using MMIE.Data.ACC;

using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;
using System.Text;
namespace MMIE.ACC
{
    public partial class AccountGroupMST :BasePage
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                ViewState["IsEdit"] = false;
                BindSearchVoucherGroupList();
                BindAccountGroupType();

            }
            PagePermission();
        }

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsAddOn; ;
                
            }
        }



        protected void btnSave_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records Please contact to your System Administrator.";
                return;

            }
            try
            {
                AccountGroup objAccountGroup = new AccountGroup();
                AccountGroupBO objAccountGroupBO = new AccountGroupBO();
                objAccountGroup.Details = txtAccountGroupDetails.Text;
                objAccountGroup.GroupName = txtAccountGroupName.Text;             
                //objAccountGroup.AccountNumber =  txtAccountNumber.Text!=""?Convert.ToInt32(txtAccountNumber.Text):0;
                if (rbtStatus.SelectedIndex == 1)
                {
                    objAccountGroup.IsActive = false;
                }
                else
                {
                    objAccountGroup.IsActive = true;
                }
                if (ddlAccountType.SelectedIndex > 0)
                {
                    objAccountGroup.AccountType =ddlAccountType.SelectedValue.ToString();
                    

                }

                if (ddlAccountGroupType.SelectedIndex > 0)
                {

                    objAccountGroup.GroupTypeID = Convert.ToInt32(ddlAccountGroupType.SelectedValue.ToString());
                    objAccountGroup.GroupTypeName = ddlAccountGroupType.SelectedItem.Text;
                }
               StringBuilder obj = new StringBuilder();

                foreach (ListItem item in chkBoxVoucherGroup.Items)
                {
                    if (item.Selected)
                    {
                        obj.Append(item.Value + ",");
                        item.Selected = false;

                    }

                }

                objAccountGroup.VoucherGroupDetails = obj.ToString();

                if (ViewState["AccountGroupID"] != null)
                {

                    objAccountGroup.AccountGroupID = Convert.ToInt32(ViewState["AccountGroupID"].ToString());
                    objAccountGroup.ActionType = EnumActionType.Update;
                    objAccountGroup.LastModBy = LoginToken.LoginId;
                    objAccountGroup.CompanyID = LoginToken.CompanyID;
                    objAccountGroup.FinancialYearID =  (Int16)LoginToken.FinancialYearID;

                }
                else
                {

                    objAccountGroup.AccountGroupID = 0;
                    objAccountGroup.ActionType = EnumActionType.Insert;
                    objAccountGroup.AddedBy = LoginToken.LoginId;
                    objAccountGroup.CompanyID = LoginToken.CompanyID;
                    objAccountGroup.FinancialYearID = (Int16)LoginToken.FinancialYearID;

                }


                if (objAccountGroupBO.SaveAccountGroup(objAccountGroup))
                {
                    if (ViewState["AccountGroupID"] != null)
                        lblError.Text = "AccountGroup Updated Successfully";
                    else
                        lblError.Text = "AccountGroup Added Successfully";

                    ViewState["AccountGroupID"] = null;
                    txtAccountGroupName.Text = "";
                    txtAccountNumber.Text = "";
                    txtAccountGroupDetails.Text = "";
                    //ddlVoucherType.SelectedIndex = 0;
                    ddlAccountGroupType.SelectedIndex = 0;
                    ddlAccountType.SelectedIndex = 0;
                    ViewState["IsEdit"] = false;
                }

            }

            catch (Exception Ex)
            {

                lblError.Text = "Error While Saving Record : " + Ex.Message;
            }


        }




        protected void BindAccountGroupType()
        {
            AccountGroupType objAccountGroup = new AccountGroupType();

            objAccountGroup.GroupTypeID = 0;
            objAccountGroup.IsActive = true;
            objAccountGroup.CompanyID = LoginToken.CompanyID;

            AccountGroupTypeBO objTaxBO = new AccountGroupTypeBO();
            List<AccountGroupType> lstTax = new List<AccountGroupType>();
            lstTax = objTaxBO.GetAccountGroupTypeList(objAccountGroup);
            if (lstTax.Count > 0)
            {
                ddlAccountGroupType.DataSource = lstTax;
                ddlAccountGroupType.DataTextField = "GroupTypeName";
                ddlAccountGroupType.DataValueField = "GroupTypeID";
                ddlAccountGroupType.DataBind();

                ddlAccountGroupType.Items.Insert(0, "--Select--");
            }
            else
            {
                lblError.Text = "No Group Type Found";
            }
        }



        protected void btnReset_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            txtAccountGroupDetails.Text = "";
            //ddlVoucherType.SelectedIndex = 0;
            ddlAccountGroupType.SelectedIndex = 0;
            ddlAccountType.SelectedIndex = 0;
            rbtStatus.SelectedIndex = 0;
            ViewState["AccountGroupID"] = null;
            grdAccountGroupList.DataSource = null;
            grdAccountGroupList.DataBind();
            txtAccountGroupName.Text = "";
            txtAccountNumber.Text = "";
            ViewState["IsEdit"] = false;
            foreach (ListItem objItems in chkBoxVoucherGroup.Items)
            {
                objItems.Selected = false;


            }
        }


        private void BindAccountGroupList()
        {
            try
            {

                AccountGroupBO objTaxBO = new AccountGroupBO();
                List<AccountGroup> lstTax = new List<AccountGroup>();
                lstTax = objTaxBO.GetAccountGroupList(true);

                grdAccountGroupList.DataSource = lstTax;
                grdAccountGroupList.DataBind();
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching AccountGroup List : " + Ex.Message;
            }

        }

        
 


        protected void bntSearch_Click(object sender, EventArgs e)
        {
            BindSearchAccountGroupList();

        }


        private void BindSearchAccountGroupList()
        {
            try
            {
                AccountGroup objAccountGroup = new AccountGroup();

  

                if (ddlAccountGroupType.SelectedIndex > 0)
                {

                    objAccountGroup.GroupTypeID = Convert.ToInt32(ddlAccountGroupType.SelectedValue.ToString());

                }
                else
                    objAccountGroup.GroupTypeID = 0;
                //if (ddlAccountType.SelectedIndex > 0)
                //    objAccountGroup.AccountType = ddlAccountType.SelectedValue.ToString();
                //else
                //    objAccountGroup.AccountType = "";

                if (txtAccountGroupDetails.Text != "")
                    objAccountGroup.Details = txtAccountGroupDetails.Text;
                else
                    objAccountGroup.Details = null;
               
                //objAccountGroup.AccountType = ddlAccountType.SelectedIndex>0?ddlAccountType.SelectedValue:"0";

                objAccountGroup.GroupName = txtAccountGroupName.Text !=""?txtAccountGroupName.Text:null;
                objAccountGroup.IsActive = rbtStatus.SelectedIndex == 0 ? true : false;
                AccountGroupBO objTaxBO = new AccountGroupBO();
                List<AccountGroup> lstTax = new List<AccountGroup>();
                lstTax = objTaxBO.GetSearchAccountGroup(objAccountGroup);

                grdAccountGroupList.DataSource = lstTax;
                grdAccountGroupList.DataBind();
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching AccountGroup List : " + Ex.Message;
            }

        }


        private void BindSearchVoucherGroupList()
        {
            try
            {
                AccountGroup objAccountGroup = new AccountGroup();

                objAccountGroup.VoucherGroupID = 0;
                objAccountGroup.IsActive = true;
                objAccountGroup.CompanyID = LoginToken.CompanyID;

                AccountGroupBO objTaxBO = new AccountGroupBO();
                List<AccountGroup> lstTax = new List<AccountGroup>();
                lstTax = objTaxBO.GetSearchVoucherGroup(objAccountGroup);
                chkBoxVoucherGroup.DataSource = lstTax;
                chkBoxVoucherGroup.DataBind();
               

                //lstBoxVourcherGroup.DataSource = lstTax;
                //      lstBoxVourcherGroup.DataBind();

            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching  Voucher Group List : " + Ex.Message;
            }

        }
   

        protected void grdAccountGroupList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "REdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    lblError.Text = "";
                    GridViewRow gr = grdAccountGroupList.Rows[id];
                    AccountGroup objACGroup = new AccountGroup();
                    AccountGroup objRetACGroup = new AccountGroup();
                    AccountGroupBO objAcGroupBO = new AccountGroupBO();

                  

                    //TextBox lblTaxName = (TextBox)gr.Cells[4].FindControl("lblRemarkDetails");
                    Label lblAccountGroupType = (Label)gr.Cells[5].FindControl("lblGroupTypeID");
                    //Label lblTType = (Label)gr.Cells[3].FindControl("lblTType");
                    
                    LinkButton lblTaxID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");
                   CheckBox chkIsActive = (CheckBox)gr.Cells[4].FindControl("chkIsActive");

                   objACGroup.AccountGroupID = Convert.ToInt32(lblTaxID.Text);
                   objACGroup.IsActive = chkIsActive.Checked;
                   objRetACGroup = objAcGroupBO.GetAccountGroupByID(objACGroup);
                   if (objRetACGroup != null)
                   {
                       txtAccountGroupDetails.Text = objRetACGroup.Details;
                       //ddlVoucherType.SelectedValue = objRetACGroup.VoucherGroupID.ToString();
                      // ddlAccountType.SelectedValue = objRetACGroup.AccountType;
                       ddlAccountGroupType.SelectedValue = objRetACGroup.GroupTypeID.ToString();
                       txtAccountGroupName.Text = objRetACGroup.GroupName;
                     //  txtAccountNumber.Text = objRetACGroup.AccountNumber.ToString();
                       ViewState["AccountGroupID"] = objRetACGroup.AccountGroupID;
                       ViewState["IsEdit"] = true;
                       if (objRetACGroup.VoucherGroupDetails != null)
                       {
                           //if (objRetACGroup.VoucherGroupDetails != null || objRetACGroup.VoucherGroupDetails != "")
                           //{
                               string[] GroupMAP = objRetACGroup.VoucherGroupDetails.Split(',');

                           //}//lstBoxVourcherGroup.SelectionMode = ListSelectionMode.Multiple;
                           //for(int i=0; i < GroupMAP.Length-1 ; i++)
                           //{
                           //    lstBoxVourcherGroup.Items[0]. = GroupMAP[i];

                           //}

                           foreach (ListItem objItems in chkBoxVoucherGroup.Items)
                           {
                               objItems.Selected = false;

                               if (GroupMAP.Contains<string>(objItems.Value))
                               {
                                   objItems.Selected = true;
                               }

                           }

                       }
                       if (chkIsActive.Checked)
                       {
                           rbtStatus.SelectedIndex = 0;

                       }
                       else
                       {
                           rbtStatus.SelectedIndex = 1;

                       }





                       //Label lblID = (Label)grdUnit.Rows[e.RowIndex].FindControl("lblUnitID");
                       //TextBox txtBoxUnit = (TextBox)grdUnit.Rows[e.RowIndex].FindControl("txtUnitName");


                   }
                }
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching AccountGroup Record : " + Ex.Message;
            }



        }

        protected void grdAccountGroupList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdAccountGroupList.PageIndex = e.NewPageIndex;
            BindSearchAccountGroupList();

        }

        protected void grdAccountGroupList_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            grdAccountGroupList.PageIndex = e.NewSelectedIndex;
            BindSearchAccountGroupList();
        }

     
    }
}