﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;
using MMIE.Data.ACC;

namespace MMIE.ACC
{
    public partial class LedgerAccounts : BasePage
    {
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;
        int iPageCount = 0;
        List<AccountCompany> lstCompany = null;
        DataSet ds = null;

        private MasterLookupBO mstlookup = new MasterLookupBO();
        protected void PagePermission()
        {
            if (LoginToken != null)
            {

                //BindDropDownControl(ddlLedgerGroup, mstlookup.GetLookupsList(LookupNames.AccountGroup));
                //BindDropDownControl(ddlVoucherGroup, mstlookup.GetLookupsList(LookupNames.V));
             
                btnSave.Enabled = LoginToken.IsAddOn;
             
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                PagePermission();
                if (!IsPostBack)
                {
                    BindAccountGroup();
                    //BindVoucherGroup();
                    ViewState["IsEdit"] = false;
                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

           
            
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
                {
                    lblError.Text = "You can not modify the records contact to your System Administrator";
                    return;

                }

                LedgerHeader objLedger = new LedgerHeader();
                LedgerHeaderBO objLedgerHeaderBO = new LedgerHeaderBO();

                objLedger.AccountName = txtAccountName.Text;
                objLedger.AccountNumber = txtAccountNumber.Text;
                objLedger.Details = txtDetails.Text;
                objLedger.CompanyID = (Int16)LoginToken.CompanyID;
                objLedger.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                if (ddlLedgerGroup.SelectedIndex > 0)
                {
                    objLedger.AccountGroupID = Convert.ToInt32(ddlLedgerGroup.SelectedValue.ToString());

                }

                //if (ddlVoucherGroup.SelectedIndex > 0)
                //{
                //    objLedger.VoucherGroupID = Convert.ToInt32(ddlVoucherGroup.SelectedValue.ToString());

                //}

                objLedger.IsActive = (rbtStatus.SelectedIndex) == 0 ? true : false;




                if (ViewState["LedgerAccountID"] != null)
                {
                    objLedger.LedgerAccountID = (Int32)ViewState["LedgerAccountID"];
                    objLedger.LastModBy = LoginToken.LoginId;
                    objLedger.ActionType = EnumActionType.Update;

                }
                else
                {

                    objLedger.AddedBy = LoginToken.LoginId;
                    objLedger.ActionType = EnumActionType.Insert;
                }



                if (objLedgerHeaderBO.SaveLedgerHeader(objLedger))
                {
                    if (ViewState["LedgerAccountID"] != null)
                    {
                        ViewState["LedgerAccountID"] = null;

                        lblError.Text = "Ledger Account Updated Successfully";
                    }
                    else
                    {
                        lblError.Text = "Ledger Account Added Successfully";
                    }

                    ClearAll();

                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        private void ClearAll()
        {

            txtAccountName.Text = "";
            txtAccountNumber.Text = "";
            txtDetails.Text = "";
            ViewState["LedgerAccountID"] = null;
            ViewState["IsEdit"] = false;
            ddlLedgerGroup.SelectedIndex = 0;
            //ddlVoucherGroup.SelectedIndex = 0;
            rbtStatus.SelectedIndex = 0;
            grdLedgerAccount.DataSource = null;
            grdLedgerAccount.DataBind();

        }

        private void BindAccountGroup()
        {
            AccountGroup objAccountGroup = new AccountGroup();
            AccountGroupBO objBO = new AccountGroupBO();
            List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
            objAccountGroup.IsActive = true;

            lstAccountGroup = objBO.GetSearchAccountGroup(objAccountGroup);
            ddlLedgerGroup.DataSource = lstAccountGroup;
            ddlLedgerGroup.DataTextField = "GroupName";
            ddlLedgerGroup.DataValueField = "AccountGroupID";
            ddlLedgerGroup.DataBind();
            ddlLedgerGroup.Items.Insert(0, "--Select--");




        }

        //private void BindVoucherGroup()
        //{
        //    AccountGroup objAccountGroup = new AccountGroup();
        //    AccountGroupBO objBO = new AccountGroupBO();
        //    List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
        //    objAccountGroup.IsActive =true;

        //    lstAccountGroup = objBO.GetSearchVoucherGroup(objAccountGroup);
        //    ddlVoucherGroup.DataSource = lstAccountGroup;
        //    ddlVoucherGroup.DataTextField = "VoucherGroupName";
        //    ddlVoucherGroup.DataValueField = "VoucherGroupID";
        //    ddlVoucherGroup.DataBind();
        //    ddlVoucherGroup.Items.Insert(0, "--Select--");

          


        //}
        private void BindDropDownControl(DropDownList objDD, List<MMIE.Data.Common.LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        #region Create Paging Navigation and Event handler

        private void CreateNavigation()
        {
            if (ViewState[VS_CURRENTINDEX] == null || ViewState[VS_PAGESIZE] == null || ViewState[VS_MAXROWS] == null)
            {
                return;
            }
            else
            {
                CreateNavigation((int)ViewState[VS_CURRENTINDEX], (int)ViewState[VS_PAGESIZE], (int)ViewState[VS_MAXROWS]);
            }
        }

        private void CreateNavigation(int currentPageIndex, int a_iPageSize, int a_iRowCount)
        {
            //Save the arguments in ViewState
            ViewState[VS_CURRENTINDEX] = currentPageIndex;
            ViewState[VS_PAGESIZE] = a_iPageSize;
            ViewState[VS_MAXROWS] = a_iRowCount;
            pnlNavigation.Controls.Clear();
            if (a_iPageSize == 0)
            {
                return;
            }

            //Get the TotalNumber of Pages
            //int iPageCount = 0;
            iPageCount = 0;
            if (a_iRowCount % a_iPageSize == 0)
            {
                iPageCount = a_iRowCount / a_iPageSize;
            }
            else
            {
                iPageCount = (a_iRowCount / a_iPageSize) + 1;
            }

            if (iPageCount <= 1)
            {
                return;
            }

            //Check if LeftDots are to be displayed
            if ((currentPageIndex + 1) - 5 > 1)
            {
                //Start when left dots are visible then show << button also
                LinkButton linkFirst = new LinkButton();
                linkFirst.Text = "<<";
                linkFirst.CssClass = "lftmenu";
                linkFirst.ID = "linkFirst";
                linkFirst.Click += new EventHandler(linkFirst_Click);
                pnlNavigation.Controls.Add(linkFirst);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
                //End when left dots are visible then show << button also

                int iLIndex = (currentPageIndex + 1) - 5 - 1;
                //Add LeftDots
                LinkButton btnLeftDots = new LinkButton();
                btnLeftDots.Text = "...";
                btnLeftDots.CssClass = "lftmenu";
                btnLeftDots.ID = "nav_" + iLIndex.ToString();
                btnLeftDots.Attributes.Add("onclick", "__doPostBack('" + btnLeftDots.ClientID + "',' " + iLIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            int iLeftIndex = 1;

            if (currentPageIndex + 1 - 5 > 1)
            {
                iLeftIndex = currentPageIndex + 1 - 5;
            }

            //Create the Number buttons on the left side of the index
            for (int i = iLeftIndex; i <= currentPageIndex; i++)
            {
                LinkButton btnLeftNumbers = new LinkButton();
                btnLeftNumbers.Text = i.ToString();
                btnLeftNumbers.CssClass = "lftmenu";
                btnLeftNumbers.ID = "nav_" + i.ToString();
                btnLeftNumbers.Attributes.Add("onclick", "__doPostBack('" + btnLeftNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Display the Current Page Number
            Label lblCurrent = new Label();
            lblCurrent.Text = Convert.ToString(currentPageIndex + 1);
            lblCurrent.CssClass = "textNormal";
            pnlNavigation.Controls.Add(lblCurrent);
            pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

            //Create Right Number buttons
            int iRightIndex = iPageCount;

            if (currentPageIndex + 1 + 5 < iRightIndex)
            {
                iRightIndex = 5;//currentPageIndex + 1 + 5;
            }

            for (int i = currentPageIndex + 2; i <= iRightIndex; i++)
            {
                LinkButton btnRightNumbers = new LinkButton();
                btnRightNumbers.Text = i.ToString();
                btnRightNumbers.CssClass = "lftmenu";
                btnRightNumbers.ID = "nav_" + i.ToString();
                btnRightNumbers.Attributes.Add("onclick", "__doPostBack('" + btnRightNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Check if RightDots are to be displayed
            if ((currentPageIndex + 1) + 5 < iPageCount)
            {
                int iRIndex = ((currentPageIndex + 1) + 5) + 1;
                //Add RightDots
                LinkButton btnRightDots = new LinkButton();
                btnRightDots.Text = "...";
                btnRightDots.CssClass = "lftmenu";
                btnRightDots.ID = "nav_" + iRIndex.ToString();
                btnRightDots.Attributes.Add("onclick", "__doPostBack('" + btnRightDots.ClientID + "',' " + iRIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

                //Start when right dots are visible then show >> button also
                LinkButton linkLast = new LinkButton();
                linkLast.Text = ">>";
                linkLast.CssClass = "lftmenu";
                linkLast.ID = "linkLast";
                linkLast.Click += new EventHandler(linkLast_Click);
                pnlNavigation.Controls.Add(linkLast);
                //End when left dots are visible then show << button also
            }
        }

        protected void linkFirst_Click(object sender, EventArgs e)
        {
            BindData(0);
        }

        protected void linkLast_Click(object sender, EventArgs e)
        {
            BindData(iPageCount - 1);
        }

       private void BindData(int PageNO)
        {
        }
        #endregion

       private void SearchHeaderAccount()
       {
           try
           {
               LedgerHeader objLedger = new LedgerHeader();
               List<LedgerHeader> lstLedgerHeader = new List<LedgerHeader>();
               LedgerHeaderBO objBO = new LedgerHeaderBO();
               objLedger.AccountName = txtAccountName.Text;
               objLedger.AccountNumber = txtAccountNumber.Text;
               objLedger.Details = txtDetails.Text;
               objLedger.CompanyID = (Int16)LoginToken.CompanyID;
               objLedger.FinancialYearID = (Int16)LoginToken.FinancialYearID;
               if (ddlLedgerGroup.SelectedIndex > 0)
               {
                   objLedger.AccountGroupID = Convert.ToInt32(ddlLedgerGroup.SelectedValue.ToString());

               }

               //if (ddlVoucherGroup.SelectedIndex > 0)
               //{
               //    objLedger.VoucherGroupID = Convert.ToInt32(ddlVoucherGroup.SelectedValue.ToString());

               //}
               objLedger.IsActive = (rbtStatus.SelectedIndex == 0) ? true : false;

               lstLedgerHeader = objBO.GetSearchLedgerHeader(objLedger);

               grdLedgerAccount.DataSource = lstLedgerHeader;
               grdLedgerAccount.DataBind();

           }
           catch (Exception ex) //Exception in agent layer itself
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
               LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
               lblError.Text = ExceptionMessage.GetMessage(ex);
               lblError.Visible = true;
           }
       }

       protected void btnSearch_Click(object sender, EventArgs e)
       {
           SearchHeaderAccount();
       }

       protected void grdLedgerAccount_RowCommand(object sender, GridViewCommandEventArgs e)
       {

           try
           {
               if (e.CommandName == "REdit")
               {
                   int id = Convert.ToInt32(e.CommandArgument.ToString());

                   GridViewRow gr = grdLedgerAccount.Rows[id];
                   LedgerHeader objACGroup = new LedgerHeader();
                   LedgerHeader objRetACGroup = new LedgerHeader();
                   LedgerHeaderBO objAcGroupBO = new LedgerHeaderBO();



                   //TextBox lblTaxName = (TextBox)gr.Cells[4].FindControl("lblRemarkDetails");
                   Label lblAccountGroupType = (Label)gr.Cells[5].FindControl("lblGroupTypeID");
                   //Label lblTType = (Label)gr.Cells[3].FindControl("lblTType");

                   LinkButton lblTaxID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");
                   

                   objACGroup.LedgerAccountID = Convert.ToInt32(lblTaxID.Text);
                   objRetACGroup = objAcGroupBO.GetAccountGroupByID(objACGroup);

                   txtDetails.Text = objRetACGroup.Details;
                   //ddlVoucherType.SelectedValue = objRetACGroup.VoucherGroupID.ToString();
                   ddlLedgerGroup.SelectedValue = objRetACGroup.AccountGroupID.ToString();
                   //ddlVoucherGroup.SelectedValue = objRetACGroup.VoucherGroupID.ToString();
                   txtAccountName.Text = objRetACGroup.AccountName;
                   txtAccountNumber.Text = objRetACGroup.AccountNumber;

                   ViewState["LedgerAccountID"] = objRetACGroup.LedgerAccountID;
                   ViewState["IsEdit"] = true;
                   if (objRetACGroup.IsActive)
                   {
                       rbtStatus.SelectedIndex = 0;

                   }
                   else
                   {
                       rbtStatus.SelectedIndex = 1;

                   }
               }

           }

           catch (Exception ex) //Exception in agent layer itself
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
               LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
               lblError.Text = ExceptionMessage.GetMessage(ex);
               lblError.Visible = true;
           }


       }

       protected void btnReset_Click(object sender, EventArgs e)
       {

           lblError.Text = "";
           ClearAll();
       }
    }
}