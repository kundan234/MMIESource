﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.Common;
//using MMIE.Data.ADM;
using MMIE.Data.ACC;

using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.ACC
{
    public partial class VoucherGroupMST : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                ViewState["IsEdit"] = false;
                //BindSearchVoucherGroupList();
            }
            PagePermission();
        }

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsAddOn; ;
            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records Please contact to your System Administrator";
                return;

            }

            try
            {
                AccountGroup objAccountGroup = new AccountGroup();
                VoucherGroupBO objVoucherGroup = new VoucherGroupBO();
                objAccountGroup.Remarks = txtVoucherGroupRemarks.Text;
                objAccountGroup.GroupName = txtVoucherGroupName.Text;
                if (rbtStatus.SelectedIndex == 1)
                {
                    objAccountGroup.IsActive = false;


                }
                else
                {
                    objAccountGroup.IsActive = true;

                }

                if (ViewState["VoucherGroupID"] != null)
                {

                    objAccountGroup.VoucherGroupID = Convert.ToInt32(ViewState["VoucherGroupID"].ToString());
                    objAccountGroup.ActionType = EnumActionType.Update;
                    objAccountGroup.LastModBy = LoginToken.LoginId;
                    objAccountGroup.CompanyID = LoginToken.CompanyID;
                    objAccountGroup.FinancialYearID = (Int16)LoginToken.FinancialYearID;

                }
                else
                {

                    objAccountGroup.VoucherGroupID = 0;
                    objAccountGroup.ActionType = EnumActionType.Insert;
                    objAccountGroup.AddedBy = LoginToken.LoginId;
                    objAccountGroup.CompanyID = LoginToken.CompanyID;
                    objAccountGroup.FinancialYearID = (Int16)LoginToken.FinancialYearID;

                }

                if (objVoucherGroup.SaveAccountGroup(objAccountGroup))
                {
                    if (ViewState["VoucherGroupID"] != null)
                    {
                        ViewState["VoucherGroupID"] = null;
                        lblError.Text = "AccountGroup Updated Successfully";
                    }
                    else
                        lblError.Text = "AccountGroup Added Successfully";

                    ViewState["AccountGroupID"] = null;
                    txtVoucherGroupRemarks.Text = "";

                    //ddlVoucherType.SelectedIndex = 0;
                    txtVoucherGroupName.Text = "";

                    ViewState["IsEdit"] = false;
                }
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Saving Record : " + Ex.Message;
            }
        }


        private void BindSearchVoucherGroupList()
        {
                AccountGroup objAccountGroup = new AccountGroup();
                if (txtVoucherGroupName.Text != "")
                    objAccountGroup.VoucherGroupName = txtVoucherGroupName.Text;
                else
                    objAccountGroup.VoucherGroupName = null;
                if (txtVoucherGroupRemarks.Text != "")
                    objAccountGroup.Remarks = txtVoucherGroupRemarks.Text;
                else
                    objAccountGroup.Remarks = null;
                


                AccountGroupBO objTaxBO = new AccountGroupBO();
                List<AccountGroup> lstTax = new List<AccountGroup>();
                lstTax = objTaxBO.GetSearchVoucherGroup(objAccountGroup);
                grdAccountVoucherGroupList.DataSource = lstTax;
                grdAccountVoucherGroupList.DataBind();

        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindSearchVoucherGroupList();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            lblError.Text = "";

            txtVoucherGroupName.Text = "";
            txtVoucherGroupRemarks.Text = "";
            rbtStatus.SelectedIndex = 0;
            grdAccountVoucherGroupList.DataSource = null;
            grdAccountVoucherGroupList.DataBind();
            ViewState["AccountGroupID"] = null;
            ViewState["IsEdit"] = false;
        }

        protected void grdAccountVoucherGroupList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "REdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    lblError.Text = "";
                    GridViewRow gr = grdAccountVoucherGroupList.Rows[id];
                    AccountGroup objACGroup = new AccountGroup();
                    AccountGroup objRetACGroup = new AccountGroup();
                    VoucherGroupBO objAcGroupBO = new VoucherGroupBO();
                    
                    LinkButton lblTaxID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");
                   // CheckBox chkIsActive = (CheckBox)gr.Cells[5].FindControl("chkIsActive");
                    
                    objACGroup.VoucherGroupID= Convert.ToInt32(lblTaxID.Text);
                    objRetACGroup = objAcGroupBO.GetVoucherGroupByID(objACGroup);
                    if (objRetACGroup != null)
                    {
                        txtVoucherGroupName.Text = objRetACGroup.VoucherGroupName;
                        txtVoucherGroupRemarks.Text = objRetACGroup.Remarks;
                        ViewState["VoucherGroupID"] = objRetACGroup.VoucherGroupID;
                        ViewState["IsEdit"] = true;

                        if (objRetACGroup.IsActive)
                        {
                            rbtStatus.SelectedIndex = 0;

                        }
                        else
                        {
                            rbtStatus.SelectedIndex = 1;

                        }
                    }

                }
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching VoucherGroup Record : " + Ex.Message;
            }
        }

        protected void grdAccountVoucherGroupList_PageIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void grdAccountVoucherGroupList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdAccountVoucherGroupList.PageIndex = e.NewPageIndex;
           BindSearchVoucherGroupList();
        }
    }
}