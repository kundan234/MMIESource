﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.PRL;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Data.PRL;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.PRL
{
    public partial class EmployeeLoanMST : BasePage
    {
        protected void PagePermission()
        {
            if (LoginToken != null)
            {


                btnSubmit.Enabled = LoginToken.IsAddOn;
                btnLoanPay.Enabled = LoginToken.IsApproverRecievedOn;


            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            PagePermission();

            if (!IsPostBack)
            {

                MasterLookupBO mstlookup = new MasterLookupBO();
                BindDropDownControl(ddlDepartment, mstlookup.GetLookupsList(LookupNames.Department));
                BindDropDownControl(ddlDesignation, mstlookup.GetLookupsList(LookupNames.Designation));
                ddlDesignation.Items.Insert(0, "--Select--");
                ddlDepartment.Items.Insert(0, "--Select--");
                txtLoanDate.Text = DateTime.Now.ToShortDateString();
                txtLoanDueDate.Text = DateTime.Now.AddDays(1).ToShortDateString();
                BindCurrencyDropDown();
                BindBankDetails();
               
            }
        }


        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        private void BindBankDetails()
        {
            BankBO objPaymentDetailsBO = new BankBO();
            List<Bank> lstPaymentHistory = new List<Bank>();
            lstPaymentHistory = objPaymentDetailsBO.GetBankList(false);
            if (lstPaymentHistory != null)
            {
                ddlBank.DataSource = lstPaymentHistory;
                ddlBank.DataBind();

                ddlBank.Items.Insert(0, new ListItem("--Select--", "0"));
                
            }
        }

        protected void BindCurrencyDropDown()
        {
            CurrencyBO objCurrencyBO = new CurrencyBO();
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            catch (Exception ex)
            {

                lblError.Text = "Error while Loading Currency : " + ex.Message;
            }

        }
        protected void btnSearchEmployee_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            ClearAll();
            BindSeachEmployeeList();
        }

        protected void BindSeachEmployeeList()
        {
            try
            {
                Employee objEmp = new Employee();
                EmployeeBO objEmployeeBO = new EmployeeBO();
                List<Employee> lstEmployee = new List<Employee>();
                objEmp.EmployeeID = Convert.ToInt32(txtEmployeeID.Text != "" ? txtEmployeeID.Text : "0");

                objEmp.FirstName = txtEmployeeName.Text;
                objEmp.CurrentIndex = 0;
                objEmp.PageSize = 30;
                objEmp.IsActive = true;
                lstEmployee = objEmployeeBO.GetSearchEmployeeList(objEmp);

                grdEmployeeList.DataSource = lstEmployee;

                grdEmployeeList.DataBind();

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Employee List :" + ex.Message;
            }


        }

        private void BindEmployeeDetail(int empid)
        {
            EmployeeBO useradm = new EmployeeBO();
            Employee objEmployee = new Employee();
            objEmployee.EmployeeID = empid;
            Employee objRetEmployee = useradm.GetEmployeeByID(objEmployee);
            if (objRetEmployee != null)
            {
                ViewState["IsEdit"] = true;
                txtFirstName.Text = objRetEmployee.FirstName;
                txtLastName.Text = objRetEmployee.LastName;

                txtDob.Text = objRetEmployee.DOB;
                txtEmail.Text = objRetEmployee.Email;
                txtAddress.Text = objRetEmployee.Address + " " + objRetEmployee.CityName + " \n" + objRetEmployee.CountryName + " - " + objRetEmployee.PostalCode;
                txtPhoneNo.Text = objRetEmployee.PhoneNo;
                //txtStreet.Text = objRetEmployee.Street;
                //txtCountry.Text = objRetEmployee.CountryName;
                //txtCity.Text = objRetEmployee.CityName;
                //txtHireDate.Text = objRetEmployee.HireDate;
                //txtReleaseDate.Text = objRetEmployee.ReleaseDate;
                //txtRate.Text = objRetEmployee.EarningRate.ToString();
                //txtPostalCode.Text = objRetEmployee.PostalCode;
                txtAccountNo.Text = objRetEmployee.AccountNo;
                txtSalary.Text = objRetEmployee.EarningRate.ToString();
                ddlFrequency.SelectedItem.Text = objRetEmployee.PayFreequency;
                ddlDepartment.SelectedValue = Convert.ToString(objRetEmployee.DepartmentID);
                ddlDepartment.SelectedItem.Text = Convert.ToString(objRetEmployee.DepartmentName);
                ddlDesignation.SelectedValue = Convert.ToString(objRetEmployee.DesignationID);
                ddlDesignation.SelectedItem.Text = Convert.ToString(objRetEmployee.DesignationName);
                ddlCurrency.SelectedValue = Convert.ToString(objRetEmployee.CurrencyID);
                txtCurrencyRate.Text = Convert.ToString(objRetEmployee.CurrencyRate);
                txtCellNo.Text = objRetEmployee.CellNo;
                txtTotalLoanAmount.Text = objRetEmployee.TotalLoanAmount.ToString();
                txtTotalLoanDeduction.Text = objRetEmployee.TotalDeduction.ToString();

                if (objRetEmployee.Gender == true)
                {
                    rdoGender.SelectedIndex = 0;
                }
                else
                {
                    rdoGender.SelectedIndex = 1;
                }

                if (objRetEmployee.IsActive)
                {
                    rdoEmployeeStatus.SelectedIndex = 0;
                }
                else
                {
                    rdoEmployeeStatus.SelectedIndex = 1;
                }
                if (objRetEmployee.IdScanIDDetail != null)
                {
                    hyScanID.NavigateUrl = "~\\EmployeeScanID\\" + objRetEmployee.IdScanIDDetail;
                    hyScanID.Text = objRetEmployee.SacnIdType;
                    hyScanID.Visible = true;
                    hyScanID.Target = "_blank";
                    ViewState["ScanName"] = objRetEmployee.IdScanIDDetail;
                }
                

                ViewState["EmployeeID"] = objRetEmployee.EmployeeID;
                BindEmployeeLoanList(objRetEmployee.EmployeeID);

            }
            else
            {
                lblError.Text = "Employee Id  Not Found";
            }//---------
        }


        private void BindEmployeeLoanList(int empid)
        {
            Loan objLoan = new Loan();
            LoanBO objLoanBO = new LoanBO();

            List<Loan> lstLoan = new List<Loan>();
            objLoan.EmployeeID = empid;   
        
            objLoan.CurrentIndex = 0;
            objLoan.PageSize = 30;
            objLoan.IsActive = true;
            lstLoan = objLoanBO.SearchEmployee(objLoan);
            grdEmployeeLoanList.DataSource = lstLoan;
            grdEmployeeLoanList.DataBind();

        }
        protected void grdEmployeeList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ShowDetails")
            {
                GridViewRow grArtist = ((Control)
                   (e.CommandSource)).NamingContainer as GridViewRow;
                int num = 0;
                int.TryParse(grdEmployeeList.DataKeys[grArtist.RowIndex]["EmployeeID"].ToString(), out num);
                BindEmployeeDetail(num);

                num = 0;
                ClearAllLoan();

            }
        }

        protected void grdEmployeeList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdEmployeeLoanList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                ClearAllLoan();
                if (e.CommandName == "ShowDetailsLoan")
                {
                    GridViewRow grArtist = ((Control)
                          (e.CommandSource)).NamingContainer as GridViewRow;
                    GridViewRow grRows = grdEmployeeLoanList.Rows[grArtist.RowIndex];
                    ViewState["LoanID"] = null;
                    MakeDisable();
                    int num = 0;
                    int typeID = 0;
                    int.TryParse(grdEmployeeLoanList.DataKeys[grArtist.RowIndex]["LoanID"].ToString(), out num);
                    txtLoanDetail.Text = grRows.Cells[2].Text;
                    int.TryParse(grdEmployeeLoanList.DataKeys[grArtist.RowIndex]["LoanTypeID"].ToString(),out typeID);
                    ddlLoanType.SelectedValue = typeID.ToString();
                    
                    txtLoanAmount.Text = grRows.Cells[5].Text;
                    txtDeductionAmount.Text = grRows.Cells[6].Text;
                    txtPaidLoanAmount.Text = grRows.Cells[7].Text;
                    txtLoanDate.Text = grRows.Cells[8].Text;
                    txtLoanDueDate.Text = grRows.Cells[9].Text;
                    txtInstalment.Text = grRows.Cells[10].Text;

                    CheckBox chk = (CheckBox)grRows.Cells[11].FindControl("chkIsActive");
                    if (chk.Checked) rbtStatus.SelectedIndex = 0;
                    else rbtStatus.SelectedIndex = 1;
                    CheckBox chk1 = (CheckBox)grRows.Cells[11].FindControl("chkIsPaid");
                    if (chk1.Checked)
                    {
                        btnLoanPay.Enabled = false;
                        btnLoanPay.Visible = false;
                        Pmt.Visible = false;
                        rbtPaymentStatus.SelectedIndex = 0;
                        rbtPaymentStatus.Enabled = false;
                    }
                    else
                    {
                        btnLoanPay.Enabled = true;
                        btnLoanPay.Visible = true;
                        Pmt.Visible = true;
                        rbtPaymentStatus.SelectedIndex = 1;
                        rbtPaymentStatus.Enabled =true;
                    }
                    

                    ViewState["LoanID"] = num;
                    ViewState["LoanDeduction"] = grRows.Cells[5].Text;
                    num = 0;
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Loading Loan Details : " + ex.Message;

            }
        }

        protected void grdEmployeeLoanList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

     
       


        protected void ClearAll()
        {
           
            txtFirstName.Text = "";
            txtLastName.Text = "";



            txtAddress.Text = "";

            txtPhoneNo.Text = "";
            txtCellNo.Text = "";
            txtEmail.Text = "";

            txtDob.Text = "";

            ddlDesignation.SelectedIndex = 0;
            ddlDesignation.SelectedIndex = 0;
            ddlDepartment.SelectedIndex = 0;
            txtAccountNo.Text = "";
            ViewState["LoanDeduction"] = null;
            ViewState["LoanID"] = null;
           // ViewState["SalaryID"] = null;
     
            grdEmployeeList.DataBind();
            grdEmployeeLoanList.DataSource = null;
            grdEmployeeLoanList.DataBind();
            txtLoanAmount.Text = "";
            txtLoanDetail.Text = "";
            txtLoanDueDate.Text = "";
            txtDeductionAmount.Text = "";
            txtPaidLoanAmount.Text = "";
            txtCurrencyRate.Text = "";
            txtSalary.Text = "";
            ClearAllLoan();
           
        }


        protected void ClearAllLoan()
        {
            txtInstalment.Text = "";
            txtLoanDate.Text = "";
            txtTotalLoanAmount.Text = "";
            txtTotalLoanDeduction.Text = "";
            ddlLoanType.SelectedIndex = 0;
            ViewState["LoanID"] = null;
            txtLoanDetail.Enabled = true;
            txtLoanAmount.Enabled = true;
            txtLoanDate.Enabled = true;
            txtDeductionAmount.Enabled = true;
            txtPaidLoanAmount.Enabled = true;
            txtInstalment.Enabled = true;
            txtLoanAmount.Enabled = true;
            txtLoanDueDate.Enabled = true;
            ddlLoanType.Enabled = true;
        }
       
        protected void MakeDisable()
        {
            txtLoanDetail.Enabled = false;           
            txtLoanDate.Enabled = false;
            txtDeductionAmount.Enabled = false;
            txtPaidLoanAmount.Enabled = false;
            txtLoanAmount.Enabled = false;

            
            
            txtInstalment.Enabled = false;
            txtLoanAmount.Enabled = false;
            txtLoanDueDate.Enabled = false;
            ddlLoanType.Enabled = false;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                
                //DateTime Fromdate = Convert.ToDateTime(txtLoanDate.Text);
                //DateTime Todate = Convert.ToDateTime(txtLoanDueDate.Text);
                //TimeSpan span = Todate.Subtract(Fromdate);
                //int days = span.Days;
                Loan objloan = new Loan();
                LoanBO objLoanBo = new LoanBO();
                int LoanId = ViewState["LoanID"] != null ? Convert.ToInt32(ViewState["LoanID"]) : 0;
                objloan.LoanDetails = txtLoanDetail.Text;
                objloan.LoanTypeID = Convert.ToInt32(ddlLoanType.SelectedValue);
                objloan.LoanAmount = Convert.ToDecimal(txtLoanAmount.Text);
                if (txtPaidLoanAmount.Text != "")
                    objloan.PaidLoanAmount = Convert.ToDecimal(txtPaidLoanAmount.Text);
                else
                    objloan.PaidLoanAmount = 0;
                objloan.LoanDate = Convert.ToDateTime(txtLoanDate.Text);
                objloan.LoanDueDate = Convert.ToDateTime(txtLoanDueDate.Text);
                objloan.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                objloan.CompanyID = Convert.ToInt16(LoginToken.CompanyID);

                objloan.IsActive = true;
                objloan.IsApproved = false;
                objloan.EmployeeID = Convert.ToInt32(ViewState["EmployeeID"]);
                objloan.LastModDTM = Convert.ToDateTime(DateTime.Now.ToShortDateString());
                objloan.AddedDTM = Convert.ToDateTime(DateTime.Now.ToShortDateString());
                if (ViewState["LoanID"] != null)
                {
                    objloan.LoanID = Convert.ToInt32(ViewState["LoanID"]);
                    objloan.ActionType = EnumActionType.Update;
                    objloan.LastModBy = LoginToken.LoginId;
                   
                }
                else
                {
                    objloan.ActionType = EnumActionType.Insert;
                    objloan.AddedBy = LoginToken.LoginId;
                  
                }

                if (txtInstalment.Text != "")
                    objloan.TotalInstallments = Convert.ToInt32(txtInstalment.Text);
                else
                    objloan.TotalInstallments = 0;
                objloan.PaidInstallments = 0;
                objloan.DeductionAmount = Convert.ToDecimal(txtDeductionAmount.Text);
                if (objloan.DeductionAmount > Convert.ToDecimal(txtSalary.Text))
                {
                    lblError.Text = "Deduction Amount should be less then employee Earning rate.";
                    lblError.Visible = true;
                    return;
                }
                if (objLoanBo.UpdateLoanDetails(objloan))
                {
                    if (ViewState["LoanID"] != null)
                        lblError.Text = "Loan Detail Updated successfully.";
                    else
                        lblError.Text = "Loan Detail added successfully.";
                    lblError.Visible = true;
                    ViewState["LoanID"] = null;
                    ClearAll();
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Saving Loan Details : " + ex.Message;
            }
        }

        protected void btnReset_Click1(object sender, EventArgs e)
        {
            lblError.Text = "";
            ClearAll();
            ViewState["EmployeeID"] = null;
            grdEmployeeList.DataSource = null;
        }

        protected void txtLoanAmount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                CalculateAmounts();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Calculate Loan Amounts Details : " + ex.Message;
            }
        }

        protected void CalculateAmounts()
        {
            int TotalInstalment = 0;
            decimal DeductionAmount = 0;
            string[] str1 = txtLoanDate.Text.Split('/');
            string[] str2 = txtLoanDueDate.Text.Split('/');
            DateTime date1 = new DateTime(Convert.ToInt32(str1[2]), Convert.ToInt32(str1[0]), Convert.ToInt32(str1[1]));
            DateTime date2 = new DateTime(Convert.ToInt32(str2[2]), Convert.ToInt32(str2[0]), Convert.ToInt32(str2[1]));

            TimeSpan span = date2 - date1;
            int days = span.Days;

         
            if (ddlFrequency.SelectedValue == "Weekly")
            {
                TotalInstalment = days / 7;
            }
            else if (ddlFrequency.SelectedValue == "Biweekly")
            {
                TotalInstalment = days / 15;
            }
            else if (ddlFrequency.SelectedValue == "Monthly")
            {
                TotalInstalment = days / 30;
            }
            decimal LoanAmount = Convert.ToDecimal(txtLoanAmount.Text);
            if (TotalInstalment != 0)
            {
                DeductionAmount =Convert.ToDecimal((LoanAmount / (decimal)TotalInstalment));
            }
            else
                DeductionAmount = 0;

            if(ViewState["LoanID"]!=null)
            {
                DeductionAmount =( (txtTotalLoanDeduction.Text != "" ? Convert.ToDecimal(txtTotalLoanDeduction.Text) : 0) - (ViewState["LoanDeduction"] != null ? Convert.ToDecimal(ViewState["LoanDeduction"]) : 0) + DeductionAmount);

            }

            txtDeductionAmount.Text = DeductionAmount.ToString(".00");

            if (Convert.ToDecimal(txtDeductionAmount.Text) > Convert.ToDecimal(txtSalary.Text))
            {
                lblError.Text = "Deduction Amount should be less then employee Earning rate.";
                lblError.Visible = true;
                return;
            }
          //  txtDeductionAmount.Text = DeductionAmount.ToString();
            txtInstalment.Text = TotalInstalment.ToString();
        }

        protected void btnLoanPay_Click(object sender, EventArgs e)
        {
            try
            {
                int LoanID = ViewState["LoanID"] != null ? Convert.ToInt32(ViewState["LoanID"]) : 0;

    PaymentDetails objPaymentDetails= new PaymentDetails() ;
    PaymentDetailsBO objPaymentDetailsBO = new PaymentDetailsBO();

    objPaymentDetails.PaymentAmount = Convert.ToDecimal(txtLoanAmount.Text);


   
    objPaymentDetails.PaymentSourceID = Convert.ToInt32(ddlPaymentMode.SelectedValue.ToString());
    objPaymentDetails.PaymentMode = ddlPaymentMode.SelectedItem.ToString();
    objPaymentDetails.PaymentModeNo = txtPaymentModeNo.Text;
    objPaymentDetails.BankID = ddlBank.SelectedIndex > 0 ? Convert.ToInt32(ddlBank.SelectedValue.ToString()) : 0;
    if (ddlPaymentMode.SelectedValue == "2" || ddlPaymentMode.SelectedValue == "3") { objPaymentDetails.Expirationdate = Convert.ToDateTime(txtPaymentExpirationDate.Text); }
    objPaymentDetails.AuthorizationNo = 0;
    objPaymentDetails.CurrencyID = ddlCurrency.SelectedIndex > 0 ? Convert.ToInt32(ddlCurrency.SelectedValue.ToString()) : 0;
    objPaymentDetails.CurrencyRate = Convert.ToDecimal(txtCurrencyRate.Text != "" ? txtCurrencyRate.Text : "0");


  //  objPaymentDetails.EmployeeID = ViewState["EmployeeID"] != null ? (int)ViewState["SupplierID"] : 0;
    objPaymentDetails.FinancialYearID = LoginToken.FinancialYearID;
    objPaymentDetails.CompanyID = LoginToken.CompanyID;
    objPaymentDetails.AddedBy = LoginToken.LoginId;

    


    objPaymentDetails.TType = "DR";
    objPaymentDetails.TransactionType = "LoanPayment";
    objPaymentDetails.Remarks = txtRemarks.Text;
    if (ViewState["EmployeeID"] != null)
        objPaymentDetails.EmployeeID = ViewState["EmployeeID"] != null ? (int)ViewState["EmployeeID"] : 0;
    else
    {
        lblError.Text = "Invalid Employee Selected ";
        return;
    }
    if (ViewState["LoanID"] != null)
    {
        objPaymentDetails.LoanID = ViewState["LoanID"] != null ? Convert.ToInt32(ViewState["LoanID"]) : 0;
    }
    else
                {
                    lblError.Text = "Invalid Loan Selected ";
                    return;
                }
    objPaymentDetails.IsActive = true;

    objPaymentDetails.IsLoan = true;

    if (objPaymentDetailsBO.SaveEmployeeLoanPaymentDetails(objPaymentDetails))
    {
        //ViewState["LoanID"] = null;
        lblError.Text = "Loan Payment Transaction Saved Successfully";
        ClearAllLoan();
    }
                



            }
                        
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Loan Loan Payment: " + ex.Message;
            }


        }

        protected void grdEmployeeLoanList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       
    }
}