﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.BusinessProcess.PRL;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using MMIE.Data.Common;
using MMIE.Data.PRL;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
namespace MMIE.PRL
{
    public partial class SalaryCalculation :BasePage
    {
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
     

                dllBranch.Enabled = LoginToken.IsChangeBranchOn;
                btnSearch.Enabled = LoginToken.IsAddOn;
               
            }
        }
       
        protected void Page_Load(object sender, EventArgs e)
        {
            PagePermission();
            if (!IsPostBack)
            {
                MasterLookupBO mstlookup = new MasterLookupBO();
                BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
                dllBranch.Items.Insert(0, "--Select--");
            }
        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {

                string[] str1 = txtdatefrom.Text.Split('-');
                string[] str2 = txtdateto.Text.Split('-');
 
                DateTime date1 = new DateTime(Convert.ToInt32(str1[2]),Convert.ToInt32(str1[0]),Convert.ToInt32(str1[1]));


                DateTime date2 = new DateTime(Convert.ToInt32(str2[2]), Convert.ToInt32(str2[0]), Convert.ToInt32(str2[1]));
            //   int n= DateTime.Compare( date2,date1);
            //   lblError.Text = n.ToString();
               System.TimeSpan myt = date2 - date1;
               int n = myt.Days;

                if (ddlPayFreequncy.SelectedItem.ToString() == "Weekly" && n !=7)
                {
                    
                    lblError.Text="Invalid Date Selected for the "+ddlPayFreequncy.SelectedItem.ToString()+" pay frequency";
                    return;
                }
                else if (ddlPayFreequncy.SelectedItem.ToString() == "Biweekly" &&  !(n == 15 || n == 14 || n == 13))
                { 
                lblError.Text="Invalid Date Selected for the "+ddlPayFreequncy.SelectedItem.ToString()+" pay frequency";
                    return;
                }
                else if (ddlPayFreequncy.SelectedItem.ToString() == "Monthly"  && !( n ==30 ||  n ==31 ||  n ==28 ||  n ==29))
                { 
                lblError.Text="Invalid Date Selected for the "+ddlPayFreequncy.SelectedItem.ToString()+" pay frequency";
                    return;

                }


                Employee objEmployee = new Employee();
                objEmployee.CompanyID = Convert.ToInt16(dllBranch.SelectedValue);
                objEmployee.PayFreequency = ddlPayFreequncy.SelectedValue;
                objEmployee.FromDate = txtdatefrom.Text.Trim();
                objEmployee.ToDate = txtdateto.Text.Trim();
                objEmployee.AddedBy =LoginToken.LoginId;
                objEmployee.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                EmployeeBO Emp = new EmployeeBO();
                bool status = Emp.CalculateEmployeeSalary(objEmployee);
                if (status == true)
                {
                   // Page.ClientScript.RegisterStartupScript(this.GetType(), "Script", "alert('Employee Salary generated Successfully.')", true);
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "Script", "alert('Employee Salary generated Successfully.')", true);
                    BindSalaryList();
                }
                else
                {
                   ScriptManager.RegisterStartupScript(Page,this.GetType(), "msg", "alert('No Employee Record Found.')", true);
                }
            }

            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                
            }
        }

        private void BindSalaryList()
        {
            try
            {
                Employee objEmp = new Employee();
                EmployeeBO objEmployeeBO = new EmployeeBO();
                List<Employee> lstEmployee = new List<Employee>();
                objEmp.CompanyID =  Convert.ToInt16(dllBranch.SelectedValue.ToString()) ;

                objEmp.FromDate = txtdatefrom.Text;
                objEmp.ToDate = txtdateto.Text;
                
                objEmp.IsActive = true;
                lstEmployee = objEmployeeBO.GetSearchSalaryList(objEmp);

                grdEmployeeSalaryList.DataSource = lstEmployee;

                grdEmployeeSalaryList.DataBind();

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching  Salary List :" + ex.Message;
            }


        }

        protected void btnSearchSalary_Click(object sender, EventArgs e)
        {
            BindSalaryList();

        }
        protected void grdEmployeeSalaryList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

       
    }
}