﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE
{
    public partial class PayTaxRange : BasePage
    {
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;
        int iPageCount = 0;
        List<Tax> lstTax = null;
        DataSet ds = null;

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSubmit.Enabled = LoginToken.IsAddOn;
                btnOtherSubmit.Enabled = LoginToken.IsAddOn;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            PagePermission();
            if (!IsPostBack)
            {
              //  CallSearch();
                grdTaxList.PageSize = GRID_PAGESIZE;
                this.BindTaxList();
                this.BindOtherTaxList();
                ViewState["IsEdit"] = false;
            }
        }
        
        public string MakeCustomerIDLink(int TaxID, string FromRange)
        {
            string ret;
            string str;
            string pageName;
            pageName = "PayTaxRange.aspx";
            str = pageName + "?taxid=" + TaxID.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + FromRange + "</a>";
            return ret;
        }
        protected void ShowError(string a_sMsg)
        {
            //errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            //if (a_sMsg.Length > 0)
            //{
            //    errorMessage.Visible = true;
            //}
            //else
            //{
            //    errorMessage.Visible = false;
            //}
        }

       

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }

            if (Page.IsValid)
            {
                try
                {

                    Tax objTax = new Tax();
                    TaxBO objTaxBO = new TaxBO();

                    objTax.FromRange = Convert.ToInt64(txtFromRange.Text) ;
                    objTax.ToRange = Convert.ToInt64(txtToRange.Text);
                    objTax.TaxAmount = Convert.ToDecimal(txtAmount.Text);   


                    if (rdoStatus.SelectedIndex == 1)
                    {
                        objTax.IsActive = false;


                    }
                    else
                    {
                        objTax.IsActive = true;

                    }

                    if (ViewState["TaxID"] != null)
                    {

                        objTax.TaxID = Convert.ToInt32(ViewState["TaxID"].ToString());
                        objTax.ActionType = 2;
                        objTax.LastModBy = LoginToken.LoginId;
                        objTax.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                        objTax.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    }
                    else
                    {

                        objTax.TaxID = 0;
                        objTax.ActionType = 1;
                        objTax.AddedBy = LoginToken.LoginId;
                        objTax.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                        objTax.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    }


                    if (objTaxBO.SaveRangeTax(objTax))
                    {
                        if (ViewState["TaxID"] != null)
                            lblError.Text = "Tax Range Updated Successfully";
                        else
                            lblError.Text = "Tax Range Added Successfully";
                        lblError.Visible = true;
                        txtFromRange.Text = "";
                        txtToRange.Text = "";
                        txtAmount.Text = "";  
                        ViewState["TaxID"] = null;
                        BindTaxList();
                        ViewState["IsEdit"] = false;
                    }

                }

                catch (Exception ex)
                {
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                    lblError.Text = "Error While Fetching saving Record : " + ExceptionMessage.GetMessage(ex);
                    lblError.Visible = true;
                } 
               

            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtFromRange.Text = "";
            txtToRange.Text = "";
            txtAmount.Text = "";
            lblError.Text = "";

            ViewState["TaxID"] = null;
        }

        protected void grdTaxList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "REdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());

                    GridViewRow gr = grdTaxList.Rows[id];

                    Label lblFromRange = (Label)gr.Cells[2].FindControl("lblFromRange");
                    Label lblTorange = (Label)gr.Cells[3].FindControl("lblTorange");
                    Label lblTaxRate = (Label)gr.Cells[4].FindControl("lblTaxRate");
                    CheckBox chkIsActive = (CheckBox)gr.Cells[5].FindControl("chkIsActive");
                    LinkButton lblTaxID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");
                    txtFromRange.Text = lblFromRange.Text;
                    txtToRange.Text = lblTorange.Text;
                    txtAmount.Text = lblTaxRate.Text;  
                    ViewState["TaxID"] = lblTaxID.Text;
                    ViewState["IsEdit"] = true;

                    if (chkIsActive.Checked)
                    {
                        rdoStatus.SelectedIndex = 0;

                    }
                    else
                    {
                        rdoStatus.SelectedIndex = 1;

                    }

                    //Label lblID = (Label)grdUnit.Rows[e.RowIndex].FindControl("lblUnitID");
                    //TextBox txtBoxUnit = (TextBox)grdUnit.Rows[e.RowIndex].FindControl("txtUnitName");



                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching tax Record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 
               


        }

        protected void btnOtherSubmit_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }
            
            if (Page.IsValid)
            {
                try
                {

                    Tax objTax = new Tax();
                    TaxBO objTaxBO = new TaxBO();

                    objTax.TaxName = txtName.Text;
                    objTax.TaxRate = Convert.ToDecimal(txtTaxAmount.Text);


                    if (rdoOtherStatus.SelectedIndex == 1)
                    {
                        objTax.IsActive = false;


                    }
                    else
                    {
                        objTax.IsActive = true;

                    }

                    if (ViewState["OtherTax"] != null)
                    {

                        objTax.TaxID = Convert.ToInt32(ViewState["OtherTax"].ToString());
                        objTax.ActionType = 2;
                        objTax.LastModBy = LoginToken.LoginId;
                        objTax.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                        objTax.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    }
                    else
                    {

                        objTax.TaxID = 0;
                        objTax.ActionType = 1;
                        objTax.AddedBy = LoginToken.LoginId;
                        objTax.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                        objTax.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    }


                    if (objTaxBO.SaveOtherTax(objTax))
                    {
                        if (ViewState["OtherTax"] != null)
                            lblErrorOther.Text = "Tax Updated Successfully";
                        else
                            lblErrorOther.Text = "Tax Added Successfully";
                        lblErrorOther.Visible = true;
                        txtFromRange.Text = "";
                        txtToRange.Text = "";
                        txtAmount.Text = "";
                        txtName.Text = "";
                        txtTaxAmount.Text = "";
                        ViewState["OtherTax"] = null;
                        ViewState["IsEdit"] = false;
                        BindOtherTaxList(); 
                    }

                }

                catch (Exception ex)
                {
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                    lblError.Text = "Error While saving tax Record : " + ExceptionMessage.GetMessage(ex);
                    lblError.Visible = true;
                } 
               
            }

        }

        protected void btnOtherReset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtTaxAmount.Text = "";
            rdoStatus.SelectedIndex = 0;
            rdoOtherStatus.SelectedIndex = 0;
            ViewState["OtherTax"] = null;
            lblErrorOther.Text = "";
            ViewState["IsEdit"] = false;
        }
        private void BindTaxList()
        {
            try
            {

                TaxBO objTaxBO = new TaxBO();
                List<Tax> lstTax = new List<Tax>();
                lstTax = objTaxBO.SearchTax(true);
                grdTaxList.DataSource = lstTax;
                grdTaxList.DataBind();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching the list of taxes : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 
               
        }

        private void BindOtherTaxList()
        {
            try
            {

                TaxBO objTaxBO = new TaxBO();
                List<Tax> lstTax = new List<Tax>();
                lstTax = objTaxBO.SearchOtherTax(true);
                grdOtherTaxList.DataSource = lstTax;
                grdOtherTaxList.DataBind();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching the other tax list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 
               

        }

        protected void grdOtherTaxList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "OtherEdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());

                    GridViewRow gr = grdOtherTaxList.Rows[id];
                    Label lblOtherTaxName = (Label)gr.Cells[2].FindControl("lblOtherTaxName");
                    Label lblOtherTaxRate = (Label)gr.Cells[3].FindControl("lblOtherTaxRate");
                    CheckBox chkOtherIsActive = (CheckBox)gr.Cells[4].FindControl("chkOtherIsActive");
                    LinkButton lblOtherTaxID = (LinkButton)gr.Cells[1].FindControl("lnkOtherEdit");
                    txtName.Text = lblOtherTaxName.Text;
                    txtTaxAmount.Text = lblOtherTaxRate.Text;

                    ViewState["OtherTax"] = lblOtherTaxID.Text;
                    ViewState["IsEdit"] = true;

                    if (chkOtherIsActive.Checked)
                    {
                        rdoOtherStatus.SelectedIndex = 0;

                    }
                    else
                    {
                        rdoOtherStatus.SelectedIndex = 1;

                    }

                    //Label lblID = (Label)grdUnit.Rows[e.RowIndex].FindControl("lblUnitID");
                    //TextBox txtBoxUnit = (TextBox)grdUnit.Rows[e.RowIndex].FindControl("txtUnitName");



                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Tax Record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 
               

        }

        protected void grdOtherTaxList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdOtherTaxList.PageIndex = e.NewPageIndex;
                BindOtherTaxList();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While goes to next page : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 
               
        }

        protected void grdTaxList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdTaxList.PageIndex = e.NewPageIndex;
                BindTaxList();
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While goes to next page : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            } 
               
        }
    }
}