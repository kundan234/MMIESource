﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.PRL;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Data.PRL;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.PRL
{
    public partial class EmployeeDetail : BasePage
    {
        string fName;
        //string MyString;
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;
        List<Employee> lstEmployee = null;
        DataSet ds = null;
        int iPageCount = 0;


        protected void PagePermission()
        {
            if (LoginToken != null)
            {
            
                 btnSubmit.Enabled = LoginToken.IsAddOn;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (!IsPostBack)
            {
                MasterLookupBO mstlookup = new MasterLookupBO();
                TabEmployeeRegistration.ActiveTabIndex = 1;
                TabEmployeeDetail.Enabled = true;
                grdEmployee.PageSize = GRID_PAGESIZE;

                BindDropDownControl(ddlDepartment, mstlookup.GetLookupsList(LookupNames.Department));
                BindDropDownControl(ddlDesignation, mstlookup.GetLookupsList(LookupNames.Designation));
                BindDropDownControl(ddlClassTrack, mstlookup.GetLookupsList(LookupNames.ClassTrack));
                BindDropDownControl(ddlEmployementType, mstlookup.GetLookupsList(LookupNames.EmployeerType));
                BindCurrencyDropDown();


                ddlDesignation.Items.Insert(0, "Select Designation");
                ddlDepartment.Items.Insert(0, "Select Department");
                ddlClassTrack.Items.Insert(0, "Select ClassTrack");
                ddlEmployementType.Items.Insert(0, "Select Employment Type");

                hyScanID.Visible = false;
                //TabEmployeeContactDetail.a = false ;
                //TabPayrollCompansationInfo.Enabled = false;
                //TabPanelEmployeement.Enabled = false;
                if (Request.QueryString["empid"] != null)
                {
                    int empid = Convert.ToInt32(Request.QueryString["empid"].ToString());
                    ViewState["empid"] = empid;
                    BindEmployeeDetail(empid);
                }

                ViewState["IsEdit"] = false;
                
            }

            else
            {
                string eventTarget = Request.Form["__EVENTTARGET"];
                if (eventTarget != null)
                {
                    if (eventTarget.IndexOf("nav") >= 0)
                    {

                        int pageIndexPos = eventTarget.LastIndexOf("_");
                        string strIndex = eventTarget.Substring(pageIndexPos + 1);
                        int iNewIndex = Convert.ToInt32(strIndex);
                        ViewState["SubmittedNewIndex"] = iNewIndex;
                        if (iNewIndex > 0)
                            BindData(iNewIndex - 1);
                        else
                            BindData(iNewIndex);
                    }

                }
                PagePermission();
                //Recreate Buttons for Paging
                CreateNavigation();
            }
        }
        protected void BindCurrencyDropDown()
        {
            CurrencyBO objCurrencyBO = new CurrencyBO();
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            catch (Exception ex)
            {

                lblError.Text = "Error while Loading Currency : " + ex.Message;
            }

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }


            try
            {
                Employee objEmployee = new Employee();
                objEmployee.EmployeeID = 0;
                objEmployee.FirstName = txtFirstName.Text;
                objEmployee.LastName = txtLastName.Text;
                objEmployee.CountryID = Convert.ToInt32(ViewState["CountryID"]);
                objEmployee.CityID = Convert.ToInt32(ViewState["CityID"]);
                objEmployee.SacnIdType = ddlIdType.SelectedValue;
                objEmployee.ScanIDNo = txtIDvalue.Text;
                objEmployee.Address = txtAddress.Text;
                objEmployee.Street = txtStreet.Text;
                objEmployee.PhoneNo = txtPhoneNo.Text;
                objEmployee.CellNo = txtCellNo.Text;
                objEmployee.Email = txtEmail.Text;
                objEmployee.AlternativePhoneNo = txtAlternativePhone.Text;
                objEmployee.PostalCode = txtPostalCode.Text;
                objEmployee.DOB = (txtDob.Text.Trim() == "" ? "0" : txtDob.Text.Trim());
                objEmployee.HireDate = (txtHireDate.Text.Trim() == "" ? "0" : txtHireDate.Text.Trim());
                objEmployee.ReleaseDate = (txtReleaseDate.Text.Trim() == "" ? "0" : txtReleaseDate.Text.Trim());
                objEmployee.EanringType = ddlEanringType.SelectedValue.ToString();
                objEmployee.EarningRate = Convert.ToInt32(txtRate.Text.Trim() == "" ? "0" : txtRate.Text.Trim());
                objEmployee.DesignationID = Convert.ToInt32(ddlDesignation.SelectedIndex);
                objEmployee.DepartmentID = Convert.ToInt32(ddlDepartment.SelectedIndex);
                objEmployee.AccountNo = txtAccountNo.Text;
                objEmployee.AddedBy = LoginToken.LoginId;
                
             
               
                objEmployee.PayFreequency = Convert.ToString(ddlPayFreequncy.SelectedValue);

                if (rdoEmployeeTaxes.SelectedIndex == 0)
                {
                    objEmployee.EmployeeTaxes = true;
                }
                else
                {
                    objEmployee.EmployeeTaxes = false;
                }
                if (rdoRetirementPlan.SelectedIndex == 0)
                {
                    objEmployee.RetirementPlan = true;
                }
                else
                {
                    objEmployee.RetirementPlan = false;
                }
                if (rdoCompanyPaid.SelectedIndex == 0)
                {
                    objEmployee.CompanyPaid = true;
                }
                else
                {
                    objEmployee.CompanyPaid = false;
                }
                if (rdoCompanyPaid.SelectedIndex == 0)
                {
                    objEmployee.CompanyPaid = true;
                }
                else
                {
                    objEmployee.CompanyPaid = false;
                }
                objEmployee.SickAllownces = Convert.ToDecimal(txtSick.Text.Trim() == "" ? "0" : txtSick.Text.Trim());
                objEmployee.VacationAllownces = Convert.ToDecimal(txtVacation.Text.Trim() == "" ? "0" : txtVacation.Text.Trim());
                objEmployee.Bonous = Convert.ToDecimal(txtBonous.Text.Trim() == "" ? "0" : txtBonous.Text.Trim());
                objEmployee.Allownces = Convert.ToDecimal(txtAllownces.Text.Trim() == "" ? "0" : txtAllownces.Text.Trim());
                if (rdoInsure.SelectedIndex == 0)
                {
                    objEmployee.Insurance = true;
                }
                else
                {
                    objEmployee.Insurance = false;
                }
                objEmployee.EmployeeTypeID = Convert.ToInt32(ddlEmployementType.SelectedValue);
                objEmployee.ClassTrackID = Convert.ToInt32(ddlClassTrack.SelectedValue);
                objEmployee.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                objEmployee.CurrencyID =Convert.ToInt32(ddlCurrency.SelectedValue.ToString());


                if (flUploadScanId.HasFile )
                {
                    //if (flUploadScanId.PostedFile.ContentLength > 0)  
                    //{
                    fName = flUploadScanId.PostedFile.FileName;
                    int ExtractPos = fName.LastIndexOf("\\") + 1;
                    String UploadedFileName = fName.Substring(ExtractPos, fName.Length - ExtractPos);
                    string appPath = HttpContext.Current.Request.ApplicationPath;
                    string physicalPath = HttpContext.Current.Request.MapPath(appPath);
                    flUploadScanId.PostedFile.SaveAs(physicalPath + "\\" + "EmployeeScanID" + "\\" + UploadedFileName);
                    objEmployee.IdScanIDDetail = fName;
                }
                if (ViewState["empid"] != null)
                {

                    if (flUploadScanId.HasFile ==false)
                    {
                        objEmployee.IdScanIDDetail = ViewState["ScanName"] != null ? (string)ViewState["ScanName"] : "";
                    }
                    objEmployee.ActionType = EnumActionType.Update;
                    objEmployee.EmployeeID = Convert.ToInt32(ViewState["empid"]);
                    objEmployee.LastModBy = LoginToken.LoginId;
                }
                else
                {
                    objEmployee.ActionType = EnumActionType.Insert;
                }
                if (rdoEmployeeStatus.SelectedIndex == 0)
                {
                    objEmployee.IsActive = true;
                }
                else
                {
                    objEmployee.IsActive = false;

                }
                if (rdoGender.SelectedIndex == 0)
                {
                    objEmployee.Gender = true;
                }
                else
                {
                    objEmployee.Gender = false;

                }

                objEmployee.EmployeeStatus = true;
                objEmployee.CityID = Convert.ToInt32(ViewState["CityID"]);
                objEmployee.CountryID = Convert.ToInt32(ViewState["CountryID"]);
                objEmployee.FinancialYearID =Convert.ToInt16(LoginToken.FinancialYearID);
                objEmployee.EmployementType = ddlEmployementType.SelectedValue;
                EmployeeBO Emp = new EmployeeBO();
                bool status = Emp.UpdateEmployeeDetail(objEmployee);
                if (status == true)
                {
                    ViewState["ScanName"] = null;
                    ViewState["IsEdit"] = false;
                    txtFirstName.Text = "";
                    txtLastName.Text = "";
                    ddlIdType.SelectedValue = "Select";
                    ddlIdType.SelectedItem.Text = "Select";
                    txtIDvalue.Text = "";
                    txtAddress.Text = "";
                    txtStreet.Text = "";
                    txtPhoneNo.Text = "";
                    txtCellNo.Text = "";
                    txtEmail.Text = "";
                    txtAlternativePhone.Text = "";
                    txtPostalCode.Text = "";
                    txtDob.Text = "";
                    txtHireDate.Text = "";
                    txtReleaseDate.Text = "";
                    txtRate.Text = "";
                    ddlDesignation.SelectedIndex = 0;
                    ddlDesignation.SelectedIndex = 0;
                    ddlDepartment.SelectedIndex = 0;
                    txtAccountNo.Text = "";
                    txtSick.Text = "";
                    txtVacation.Text = "";
                    txtBonous.Text = "";
                    txtAllownces.Text = "";
                    ddlEmployementType.SelectedIndex = 0;
                    ddlClassTrack.SelectedIndex = 0;

                    //display succuss message
                    lblError.Text = ExceptionMessage.GetMessage("PAR00001");
                    lblError.Visible = true;

                }
            }


            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void txtCity_TextChanged(object sender, EventArgs e)
        {
            BindCityDetail(txtCity.Text);
        }

        private void BindCityDetail(string cityname)
        {
            CustomerBO useradm = new CustomerBO();
            Customer objEmployee = new Customer();
            objEmployee.CityName = cityname.ToString();
            Customer objRetCustomer = useradm.GetCountryByName(objEmployee);
            if (objRetCustomer != null)
            {
                txtCountry.Text = Convert.ToString(objRetCustomer.CountryName);
                ViewState["CityID"] = objRetCustomer.CityID;
                ViewState["CountryID"] = objRetCustomer.CountryID;
                //CityBO objBo = new CityBO();
                //CityMST obj = new CityMST();
                //obj = objBo.GetCityByID(objRetCustomer.CityID);
                txtCity.Text = objRetCustomer.CityName; ;
                //txtCountry.Text = obj.CountryName;
                txtPostalCode.Text = Convert.ToString(objRetCustomer.Zip_Code);
                //  btnSubmit.Enabled = true; 
            }
            else
            {
                txtCity.Text = "";
                txtCountry.Text = "";
                //    btnSubmit.Enabled = true;
            }

        }

        private void BindEmployeeDetail(int empid)
        {
            EmployeeBO useradm = new EmployeeBO();
            Employee objEmployee = new Employee();
            objEmployee.EmployeeID = empid;
            Employee objRetEmployee = useradm.GetEmployeeByID(objEmployee);
            if (objRetEmployee != null)
            {
                ViewState["IsEdit"] = true;
                txtFirstName.Text = objRetEmployee.FirstName;
                txtLastName.Text = objRetEmployee.LastName;
                txtIDvalue.Text = objRetEmployee.ScanIDNo;
                txtDob.Text = objRetEmployee.DOB;
                txtEmail.Text = objRetEmployee.Email;
                txtAddress.Text = objRetEmployee.Address;
                txtPhoneNo.Text = objRetEmployee.PhoneNo;
                txtStreet.Text = objRetEmployee.Street;
                txtCountry.Text = objRetEmployee.CountryName;
                txtCity.Text = objRetEmployee.CityName;
                txtHireDate.Text = objRetEmployee.HireDate;
                txtReleaseDate.Text = objRetEmployee.ReleaseDate;
                txtRate.Text = objRetEmployee.EarningRate.ToString();
                txtAccountNo.Text = objRetEmployee.AccountNo;
                txtPostalCode.Text = objRetEmployee.PostalCode;
                ddlDepartment.SelectedValue = Convert.ToString(objRetEmployee.DepartmentID);
                
                ddlDesignation.SelectedValue = Convert.ToString(objRetEmployee.DesignationID);
                
                ddlEanringType.SelectedValue = Convert.ToString(objRetEmployee.EanringType);
                
                txtSick.Text = Convert.ToString(objRetEmployee.SickAllownces);
                txtVacation.Text = Convert.ToString(objRetEmployee.VacationAllownces);
                txtBonous.Text = Convert.ToString(objRetEmployee.Bonous);
                txtAllownces.Text = Convert.ToString(objRetEmployee.Allownces);
                ddlEmployementType.SelectedValue = Convert.ToString(objRetEmployee.EmployeeTypeID);
                //ddlEmployementType.SelectedItem  = Convert.ToString(objRetEmployee.EmployementType);
                ddlClassTrack.SelectedValue = Convert.ToString(objRetEmployee.ClassTrackID);
                
                txtCellNo.Text = objRetEmployee.CellNo;
                txtAlternativePhone.Text = objRetEmployee.AlternativePhoneNo;
                ddlPayFreequncy.SelectedValue = objRetEmployee.PayFreequency;
                ddlPayFreequncy.SelectedValue = objRetEmployee.PayFreequency;
                ddlCurrency.SelectedValue =Convert.ToString ( objRetEmployee.CurrencyID); 

                if (objRetEmployee.SacnIdType != null)
                {
                    ddlIdType.SelectedValue = objRetEmployee.SacnIdType;
                    ddlIdType.SelectedItem.Text = objRetEmployee.SacnIdType;
                }
                if (objRetEmployee.Gender == true)
                {
                    rdoGender.SelectedIndex = 0;
                }
                else
                {
                    rdoGender.SelectedIndex = 1;
                }

                if (objRetEmployee.IsActive)
                {
                    rdoEmployeeStatus.SelectedIndex = 0;
                }
                else
                {
                    rdoEmployeeStatus.SelectedIndex = 1;
                }

                if (objRetEmployee.EmployeeTaxes == true)
                {
                    rdoEmployeeTaxes.SelectedIndex = 0;
                }
                else
                {
                    rdoEmployeeTaxes.SelectedIndex = 1;
                }
                if (objRetEmployee.RetirementPlan == true)
                {
                    rdoRetirementPlan.SelectedIndex = 0;
                }
                else
                {
                    rdoRetirementPlan.SelectedIndex = 1;
                }
                if (objRetEmployee.CompanyPaid == true)
                {
                    rdoCompanyPaid.SelectedIndex = 0;
                }
                else
                {
                    rdoCompanyPaid.SelectedIndex = 1;
                }
                if (objRetEmployee.Insurance == true)
                {
                    rdoInsure.SelectedIndex = 0;
                }
                else
                {
                    rdoInsure.SelectedIndex = 1;
                }
                if (objRetEmployee.IdScanIDDetail != null)
                {
                    hyScanID.NavigateUrl = "~\\EmployeeScanID\\"+ objRetEmployee.IdScanIDDetail;
                    hyScanID.Text = objRetEmployee.SacnIdType; 
                    hyScanID.Visible = true;
                    hyScanID.Target = "_blank";
                    ViewState["ScanName"] = objRetEmployee.IdScanIDDetail;
                }
                ViewState["CountryID"]=objRetEmployee.CountryID;
                ViewState["CityID"] = objRetEmployee.CityID;
            }
            else
            {
                ShowError("Employee Id  Not Found");
            }//---------
        }

        #region GridView Event Handler


        private void CreateNavigation()
        {
            if (ViewState[VS_CURRENTINDEX] == null || ViewState[VS_PAGESIZE] == null || ViewState[VS_MAXROWS] == null)
            {
                return;
            }
            else
            {
                CreateNavigation((int)ViewState[VS_CURRENTINDEX], (int)ViewState[VS_PAGESIZE], (int)ViewState[VS_MAXROWS]);
            }
        }

        private void CreateNavigation(int currentPageIndex, int a_iPageSize, int a_iRowCount)
        {
            //Save the arguments in ViewState
            ViewState[VS_CURRENTINDEX] = currentPageIndex;
            ViewState[VS_PAGESIZE] = a_iPageSize;
            ViewState[VS_MAXROWS] = a_iRowCount;
            pnlNavigation.Controls.Clear();
            if (a_iPageSize == 0)
            {
                return;
            }

            //Get the TotalNumber of Pages
            //int iPageCount = 0;
            iPageCount = 0;
            if (a_iRowCount % a_iPageSize == 0)
            {
                iPageCount = a_iRowCount / a_iPageSize;
            }
            else
            {
                iPageCount = (a_iRowCount / a_iPageSize) + 1;
            }

            if (iPageCount <= 1)
            {
                return;
            }

            //Check if LeftDots are to be displayed
            if ((currentPageIndex + 1) - 5 > 1)
            {
                //Start when left dots are visible then show << button also
                LinkButton linkFirst = new LinkButton();
                linkFirst.Text = "<<";
                linkFirst.CssClass = "lftmenu";
                linkFirst.ID = "linkFirst";
                linkFirst.Click += new EventHandler(linkFirst_Click);
                pnlNavigation.Controls.Add(linkFirst);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
                //End when left dots are visible then show << button also

                int iLIndex = (currentPageIndex + 1) - 5 - 1;
                //Add LeftDots
                LinkButton btnLeftDots = new LinkButton();
                btnLeftDots.Text = "...";
                btnLeftDots.CssClass = "lftmenu";
                btnLeftDots.ID = "nav_" + iLIndex.ToString();
                btnLeftDots.Attributes.Add("onclick", "__doPostBack('" + btnLeftDots.ClientID + "',' " + iLIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            int iLeftIndex = 1;

            if (currentPageIndex + 1 - 5 > 1)
            {
                iLeftIndex = currentPageIndex + 1 - 5;
            }

            //Create the Number buttons on the left side of the index
            for (int i = iLeftIndex; i <= currentPageIndex; i++)
            {
                LinkButton btnLeftNumbers = new LinkButton();
                btnLeftNumbers.Text = i.ToString();
                btnLeftNumbers.CssClass = "lftmenu";
                btnLeftNumbers.ID = "nav_" + i.ToString();
                btnLeftNumbers.Attributes.Add("onclick", "__doPostBack('" + btnLeftNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Display the Current Page Number
            Label lblCurrent = new Label();
            lblCurrent.Text = Convert.ToString(currentPageIndex + 1);
            lblCurrent.CssClass = "textNormal";
            pnlNavigation.Controls.Add(lblCurrent);
            pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

            //Create Right Number buttons
            int iRightIndex = iPageCount;

            if (currentPageIndex + 1 + 5 < iRightIndex)
            {
                iRightIndex = 5;//currentPageIndex + 1 + 5;
            }

            for (int i = currentPageIndex + 2; i <= iRightIndex; i++)
            {
                LinkButton btnRightNumbers = new LinkButton();
                btnRightNumbers.Text = i.ToString();
                btnRightNumbers.CssClass = "lftmenu";
                btnRightNumbers.ID = "nav_" + i.ToString();
                btnRightNumbers.Attributes.Add("onclick", "__doPostBack('" + btnRightNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Check if RightDots are to be displayed
            if ((currentPageIndex + 1) + 5 < iPageCount)
            {
                int iRIndex = ((currentPageIndex + 1) + 5) + 1;
                //Add RightDots
                LinkButton btnRightDots = new LinkButton();
                btnRightDots.Text = "...";
                btnRightDots.CssClass = "lftmenu";
                btnRightDots.ID = "nav_" + iRIndex.ToString();
                btnRightDots.Attributes.Add("onclick", "__doPostBack('" + btnRightDots.ClientID + "',' " + iRIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

                //Start when right dots are visible then show >> button also
                LinkButton linkLast = new LinkButton();
                linkLast.Text = ">>";
                linkLast.CssClass = "lftmenu";
                linkLast.ID = "linkLast";
                linkLast.Click += new EventHandler(linkLast_Click);
                pnlNavigation.Controls.Add(linkLast);
                //End when left dots are visible then show << button also
            }
        }

        protected void linkFirst_Click(object sender, EventArgs e)
        {
            BindData(0);
        }

        protected void linkLast_Click(object sender, EventArgs e)
        {
            BindData(iPageCount - 1);
        }
        #endregion
        private void BindData(int currentPageIndex)
        {
            grdEmployee.PageIndex = 0;

            PagedDataSource objPagedDataSource = new PagedDataSource();
            objPagedDataSource.AllowCustomPaging = true;
            objPagedDataSource.PageSize = GRID_PAGESIZE;
            objPagedDataSource.CurrentPageIndex = currentPageIndex;

            //Get search option from viewstate
            Employee objEmployee = (Employee)ViewState[VS_SEARCH];
            objEmployee.CurrentIndex = currentPageIndex;
            //Save Search Option again
            ViewState[VS_SEARCH] = objEmployee;

            //Call service operation to get data from database source
            ds = SearchEmployee(objEmployee);

            if (ds.Tables[0].Rows.Count > 0)
            {
                this.grdEmployee.Visible = true;
                //Bind data in ViewGrid.
                objPagedDataSource.VirtualCount = Convert.ToInt32(ds.Tables[0].Rows[0]["MaximumRows"]);
                //Save Virtual Count in ViewState
                ViewState[VS_MAXROWS] = objPagedDataSource.VirtualCount;
                CreateNavigation(currentPageIndex, objPagedDataSource.PageSize, objPagedDataSource.VirtualCount);

                objPagedDataSource.DataSource = ds.Tables[0].DefaultView;
                grdEmployee.DataSource = objPagedDataSource;
                grdEmployee.DataBind();
            }
            else
            {
                ShowError("No Records Found");
                grdEmployee.DataSource = null;
                grdEmployee.DataBind();
                pnlNavigation.Visible = false;
            }
        }

        private DataSet SearchEmployee(Employee objEmployee)
        {
            //Call service operation to get data from database source
            EmployeeBO useradm = new EmployeeBO();
            lstEmployee = useradm.SearchEmployee(objEmployee);
            //    lstCustomer  = UserAdminServiceAgent.SearchCustomer(objCustomer);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstEmployee);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        protected void ShowError(string a_sMsg)
        {
            errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            if (a_sMsg.Length > 0)
            {
                errorMessage.Visible = true;
            }
            else
            {
                errorMessage.Visible = false;
            }
        }

        protected void btnCustpmerSearch_Click(object sender, EventArgs e)
        {
            try
            {
                CallSearch();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
        }
        public void CallSearch()
        {
            grdEmployee.PageIndex = 0;
            Employee objEmployee = new Employee();
            objEmployee.FirstName = txtFname.Text;
            objEmployee.LastName = txtLname.Text;
            objEmployee.PhoneNo = txtPhone.Text;
            objEmployee.CellNo = txtCustcellno.Text;
            objEmployee.Address = txtCustAddress.Text;
            objEmployee.Street = txtCustStreet.Text;
            objEmployee.CurrentIndex = 0;
            objEmployee.PageSize = GlobalConstant.PageSize;
            //Save Search Options in ViewState
            ViewState[VS_SEARCH] = objEmployee;

            BindData(0);

        }

        protected void btnCustReset_Click(object sender, EventArgs e)
        {
            txtFname.Text = "";
            txtLname.Text = "";
            txtPhone.Text = "";
            txtCustcellno.Text = "";
            txtCustAddress.Text = "";
            txtCustStreet.Text = "";
            grdEmployee.DataSource = null;
            grdEmployee.DataBind();
            ViewState["IsEdit"] = false;
            pnlNavigation.Visible = false;
        }
        public string MakeCustomerIDLink(int EmployeeID, string FirstName)
        {
            string ret;
            string str;
            string pageName;
            pageName = "EmployeeDetail.aspx";
            str = pageName + "?empid=" + EmployeeID.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + FirstName + "</a>";
            return ret;
        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ddlDesignation_SelectedIndexChanged(object sender, EventArgs e)
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            BindDropDownControl(ddlDepartment, mstlookup.GetLookupsList(LookupNames.Department));
            ddlDepartment.Items.Insert(0, "Select Department");
        }

        protected void flUploadScanId_Unload(object sender, EventArgs e)
        {
            //if(flUploadScanId!="")

            //Response.Write("test");
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            ddlIdType.SelectedValue = "Select";
            ddlIdType.SelectedItem.Text = "Select";
            txtIDvalue.Text = "";
            txtAddress.Text = "";
            txtStreet.Text = "";
            txtPhoneNo.Text = "";
            txtCellNo.Text = "";
            txtEmail.Text = "";
            txtAlternativePhone.Text = "";
            txtPostalCode.Text = "";
            txtDob.Text = "";
            txtHireDate.Text = "";
            txtReleaseDate.Text = "";
            txtRate.Text = "";
            ddlDesignation.SelectedIndex = 0;
            ddlDesignation.SelectedIndex = 0;
            ddlDepartment.SelectedIndex = 0;
            txtAccountNo.Text = "";
            txtSick.Text = "";
            txtVacation.Text = "";
            txtBonous.Text = "";
            txtAllownces.Text = "";
            ddlEmployementType.SelectedIndex = 0;
            ddlClassTrack.SelectedIndex = 0;

        }
    }
}