﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.PRL;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Data.PRL;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.PRL.Report
{
    public partial class EmployeeSalarySlip :BasePage
    {
        int SearchCustomerID = 0;

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
               
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnSearchEmployee_Click(object sender, EventArgs e)
        {
            this.BindEmployeeSalaryList(int.Parse(txtEmployeeID.Text));
        }

        private void BindEmployeeSalaryList(int empid)
        {
            try
            {
                Employee objEmp = new Employee();
                EmployeeBO objEmployeeBO = new EmployeeBO();
                List<Employee> lstEmployee = new List<Employee>();
                objEmp.EmployeeID = empid;

              
                objEmp.CurrentIndex = 0;
                objEmp.PageSize = 30;
                objEmp.IsActive = true;
                lstEmployee = objEmployeeBO.GetSearchEmployeeSalaryList(objEmp);

                grdEmployeeSalaryList.DataSource = lstEmployee;

                grdEmployeeSalaryList.DataBind();

            }
            catch (Exception ex)
            {
                lblError.Text = "Error While Fetching Employee List :" + ex.Message;
            }


        }  
      
    }
}