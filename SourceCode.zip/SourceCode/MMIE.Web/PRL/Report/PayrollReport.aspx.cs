﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data.SqlClient;
using System.Configuration;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;
using System.Collections;
using MMIE.PRL.Report;
using MMIE.Web.Reports;

namespace MMIE.PRL.Report
{
    public partial class PayrollReport : BasePage
    {
     
        
        ReportDocument rptDoc;
        protected void Page_Load(object sender, EventArgs e)
        {
            ReportUtil RU = new ReportUtil();
          
            // This command is using to hide show the export button
          if(LoginToken !=null)
            crSaleReport.HasExportButton = this.LoginToken.IsPrintExportOn;

            if (Request.QueryString["ReportType"] == "SalaryRpt")
            {
                try
                {

                    rptDoc = new rptEmployeeSalaryReport();
                    Hashtable htable = new Hashtable();
                    
                    htable.Add("@FromDate", Request.QueryString["Fromdate"].Trim());
                    htable.Add("@ToDate", Request.QueryString["Todate"].Trim());
                    htable.Add("@PayFreequency", Request.QueryString["PayFreq"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }



            }
            else if (Request.QueryString["ReportType"] == "EmployeeSalarySlip")
            {
                try
                {

                    rptDoc = new rptEmployeeSalarySlipNew();
                    Hashtable htable = new Hashtable();
                    htable.Add("@ID", Request.QueryString["Id"].Trim());
                   
                    //htable.Add("@GroupType", Request.QueryString["GroupType"].Trim());
                    //htable.Add("@BranchID", LoginToken.CompanyID.ToString());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }
            }
            else if (Request.QueryString["ReportType"] == "PrintSalarySlips")
            {
                try
                {

                    rptDoc = new rptEmplopyeeSalarySlipReport();
                    Hashtable htable = new Hashtable();
                    htable.Add("@PayFrequency", Request.QueryString["PayFrequency"].Trim());
                    htable.Add("@FromDate", Request.QueryString["DateFrom"].Trim());
                    htable.Add("@ToDate", Request.QueryString["DateTo"].Trim());
                    htable.Add("@CompanyID", Request.QueryString["Branch"].Trim());
                    //htable.Add("@GroupType", Request.QueryString["GroupType"].Trim());
                    //htable.Add("@BranchID", LoginToken.CompanyID.ToString());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }
            }

            else if (Request.QueryString["ReportType"] == "EmployeePaymentHistory")
            {
                try
                {

                    rptDoc = new rptSalaryPaymentHistory();
                    Hashtable htable = new Hashtable();
                    htable.Add("@EmployeeID", Request.QueryString["Emp"].Trim());                  
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }
            }

             else if (Request.QueryString["ReportType"] == "EmployeeLoanAndDebtHistory")
            {
                try
                {

                    rptDoc = new rptEmployeeLoanAndDebtHistory();
                    Hashtable htable = new Hashtable();
                    htable.Add("@EmployeeID", Request.QueryString["Emp"].Trim());                  
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }
            }

            else if (Request.QueryString["ReportType"] == "EmployeeDebtReport")
            {
                try
                {

                    rptDoc = new rptEmployeeDebt();
                    Hashtable htable = new Hashtable();
                    htable.Add("@EmployeeID", Request.QueryString["Emp"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }
            }

            else if (Request.QueryString["ReportType"] == "EmployeeSalaryPaymentHistory")
            {
                try
                {

                    rptDoc = new rptEmployeePayementHistory();
                    Hashtable htable = new Hashtable();
                    htable.Add("@EmployeeID", Request.QueryString["Emp"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }
            }


            else if (Request.QueryString["ReportType"] == "SalaryPaymentDetails")
            {
                try
                {

                    rptDoc = new rptSalaryPaymentReport();
                    Hashtable htable = new Hashtable();
                    htable.Add("@CompanyID", Request.QueryString["Branch"].Trim());
                    htable.Add("@FromDate", Request.QueryString["DateFrom"].Trim());
                    htable.Add("@ToDate", Request.QueryString["DateTo"].Trim());
                    htable.Add("@PaymentMode", Request.QueryString["Mode"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }
            }
        }
        protected void Page_UnLoad(object sender, EventArgs e)
        {

            rptDoc.Close();
            rptDoc.Dispose();

        }
    }
}