﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.PRL;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Data.PRL;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.PRL
{
    public partial class EmployeesalaryHistory : BasePage
    {

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                
              
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MasterLookupBO mstlookup = new MasterLookupBO();
                TabContainerCustomer_ActiveTabChanged(TabCustomerDetail, null);
             
              

                BindDropDownControl(ddlDepartment, mstlookup.GetLookupsList(LookupNames.Department));
                BindDropDownControl(ddlDesignation, mstlookup.GetLookupsList(LookupNames.Designation));
                BindDropDownControl(ddlClassTrack, mstlookup.GetLookupsList(LookupNames.ClassTrack));
                BindDropDownControl(ddlEmployementType, mstlookup.GetLookupsList(LookupNames.EmployeerType));


                ddlDesignation.Items.Insert(0, "Select Designation");
                ddlDepartment.Items.Insert(0, "Select Department");
                ddlClassTrack.Items.Insert(0, "Select ClassTrack");
                ddlEmployementType.Items.Insert(0, "Select Employment Type");
            }
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        protected void TabContainerCustomer_ActiveTabChanged(object sender, EventArgs e)
        {


            try
            {
                lblError.Text = "";

            }
            catch
            {
                throw;
            }
            finally
            {

            }
        }


        public string MakeCustomerIDLink(int EmployeeID, string FirstName)
        {
            string ret;
            string str;
            string pageName;
            pageName = "EmployeeDetail.aspx";
            str = pageName + "?empid=" + EmployeeID.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + FirstName + "</a>";
            return ret;
        }
    }
}