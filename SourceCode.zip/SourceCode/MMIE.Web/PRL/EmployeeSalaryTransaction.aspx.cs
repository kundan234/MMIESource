﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.PRL;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
////using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Data.PRL;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.PRL
{
    public partial class EmployeeSalaryTransaction : BasePage
    {
        protected void PagePermission()
        {
            if (LoginToken != null)
            {


                btnSubmit.Enabled = LoginToken.IsAddOn;
                

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            PagePermission();
            
            if (!IsPostBack)
            {

                MasterLookupBO mstlookup = new MasterLookupBO();
                BindDropDownControl(ddlDepartment, mstlookup.GetLookupsList(LookupNames.Department));
                BindDropDownControl(ddlDesignation, mstlookup.GetLookupsList(LookupNames.Designation));
                ddlDesignation.Items.Insert(0, "--Select--");
                ddlDepartment.Items.Insert(0, "--Select--");
                BindCurrencyDropDown();
                BindBankDetails();

            }
            PagePermission();
        }

        protected void btnSearchEmployee_Click(object sender, EventArgs e)
        {
            BindSeachEmployeeList();
        }
        private void BindBankDetails()
        {
            BankBO objPaymentDetailsBO = new BankBO();
            List<Bank> lstPaymentHistory = new List<Bank>();
            lstPaymentHistory = objPaymentDetailsBO.GetBankList(false);
            if (lstPaymentHistory != null)
            {
                ddlBank.DataSource = lstPaymentHistory;
                ddlBank.DataBind();

                ddlBank.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }


        #region Bind Data
        protected void BindSeachEmployeeList()
        {
            try
            {
                Employee objEmp = new Employee();
                EmployeeBO objEmployeeBO = new EmployeeBO();
                List<Employee> lstEmployee = new List<Employee>();
                objEmp.EmployeeID = Convert.ToInt32(txtEmployeeID.Text != "" ? txtEmployeeID.Text : "0");

                objEmp.FirstName = txtEmployeeName.Text;
                objEmp.CurrentIndex = 0;
                objEmp.PageSize = 30;
                objEmp.IsActive = true;
                lstEmployee = objEmployeeBO.GetSearchEmployeeList(objEmp);

                grdEmployeeList.DataSource = lstEmployee;

                grdEmployeeList.DataBind();

            }
            catch(Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Employee List :" + ex.Message; 
            }


        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        protected void ClearAll()
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            
            
            
            txtAddress.Text = "";
            
            txtPhoneNo.Text = "";
            txtCellNo.Text = "";
            txtEmail.Text = "";
            
                      txtDob.Text = "";
                        
            ddlDesignation.SelectedIndex = 0;
            ddlDesignation.SelectedIndex = 0;
            ddlDepartment.SelectedIndex = 0;
            txtAccountNo.Text = "";

            ViewState["SalaryID"] = null;
            ViewState["EmployeeID"] = null;
            grdEmployeeList.DataSource = null;
            grdEmployeeSalaryList.DataBind();

            grdEmployeeSalaryList.DataSource = null;
            grdEmployeeSalaryList.DataBind();
            txtSalaryFrom.Text = "";
            txtSalaryPaying.Text = "";
            txtSalaryTo.Text = "";
            txtRemarks.Text = "";
            ddlPaymentMode.SelectedIndex = 0;
            ddlBank.SelectedIndex = 0;
            txtNetSalary.Text = "";
            txtPaidSalary.Text = "";
            txtPaymentExpirationDate.Text = "";
            txtPaymentModeNo.Text = "";

        }

        private void BindEmployeeDetail(int empid)
        {
            EmployeeBO useradm = new EmployeeBO();
            Employee objEmployee = new Employee();
            objEmployee.EmployeeID = empid;
            Employee objRetEmployee = useradm.GetEmployeeByID(objEmployee);
            if (objRetEmployee != null)
            {
                ViewState["IsEdit"] = true;
                txtFirstName.Text = objRetEmployee.FirstName;
                txtLastName.Text = objRetEmployee.LastName;
              
                txtDob.Text = objRetEmployee.DOB;
                txtEmail.Text = objRetEmployee.Email;
                txtAddress.Text = objRetEmployee.Address +" " + objRetEmployee.CityName + " \n" + objRetEmployee.CountryName +" - " +objRetEmployee.PostalCode;
                txtPhoneNo.Text = objRetEmployee.PhoneNo;
                //txtStreet.Text = objRetEmployee.Street;
                //txtCountry.Text = objRetEmployee.CountryName;
                //txtCity.Text = objRetEmployee.CityName;
                //txtHireDate.Text = objRetEmployee.HireDate;
                //txtReleaseDate.Text = objRetEmployee.ReleaseDate;
                //txtRate.Text = objRetEmployee.EarningRate.ToString();
                //txtPostalCode.Text = objRetEmployee.PostalCode;
                txtAccountNo.Text = objRetEmployee.AccountNo;
              
                ddlDepartment.SelectedValue = Convert.ToString(objRetEmployee.DepartmentID);
                ddlDepartment.SelectedItem.Text = Convert.ToString(objRetEmployee.DepartmentName);
                ddlDesignation.SelectedValue = Convert.ToString(objRetEmployee.DesignationID);
                ddlDesignation.SelectedItem.Text = Convert.ToString(objRetEmployee.DesignationName);
                ddlCurrency.SelectedValue = Convert.ToString(objRetEmployee.CurrencyID);
                txtCurrencyRate.Text = Convert.ToString(objRetEmployee.CurrencyRate);
                txtCellNo.Text = objRetEmployee.CellNo;

                if (objRetEmployee.Gender == true)
                {
                    rdoGender.SelectedIndex = 0;
                }
                else
                {
                    rdoGender.SelectedIndex = 1;
                }

                if (objRetEmployee.IsActive)
                {
                    rdoEmployeeStatus.SelectedIndex = 0;
                }
                else
                {
                    rdoEmployeeStatus.SelectedIndex = 1;
                }
                if (objRetEmployee.IdScanIDDetail != null)
                {
                    hyScanID.NavigateUrl = "~\\EmployeeScanID\\" + objRetEmployee.IdScanIDDetail;
                    hyScanID.Text = objRetEmployee.SacnIdType;
                    hyScanID.Visible = true;
                    hyScanID.Target = "_blank";
                    ViewState["ScanName"] = objRetEmployee.IdScanIDDetail;
                }


                ViewState["EmployeeID"] = objRetEmployee.EmployeeID;
                BindEmployeeSalaryList(objRetEmployee.EmployeeID);  

            }
            else
            {
                lblError.Text=  "Employee Id  Not Found";
            }//---------
        }


        private void BindEmployeeSalaryList(int empid)
        {
            try
            {
                Employee objEmp = new Employee();
                EmployeeBO objEmployeeBO = new EmployeeBO();
                List<Employee> lstEmployee = new List<Employee>();
                objEmp.EmployeeID = empid;

                objEmp.FirstName = txtEmployeeName.Text;
                objEmp.CurrentIndex = 0;
                objEmp.PageSize = 30;
                objEmp.IsActive = true;
                lstEmployee = objEmployeeBO.GetSearchEmployeeSalaryList(objEmp);

                grdEmployeeSalaryList.DataSource = lstEmployee;

                grdEmployeeSalaryList.DataBind();

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Employee List :" + ex.Message;
            }


        }



        private void BindEmployeeSalaryDetails(int id)
        {
            try
            {
                Employee objEmp = new Employee();
                EmployeeBO objEmployeeBO = new EmployeeBO();
                Employee retEmployee = new Employee();
                objEmp.ID  = id ;

                
                retEmployee = objEmployeeBO.GetEmployeeSalaryDetailsByID(objEmp);

                if (retEmployee != null)
                {

                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Employee List :" + ex.Message;
            }


        }


        #endregion
        #region Grid View Events



        protected void grdEmployeeList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if(e.CommandName=="ShowDetails")
            {
                GridViewRow grArtist = ((Control)
                   (e.CommandSource)).NamingContainer as GridViewRow;
                int num = 0;
                int.TryParse(grdEmployeeList.DataKeys[grArtist.RowIndex]["EmployeeID"].ToString(), out num);
                BindEmployeeDetail(num);

                num = 0;

            }
        }

        protected void grdEmployeeList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

    

        protected void grdEmployeeSalaryList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "ShowDetailsSalary")
                {


                    GridViewRow grArtist = ((Control)
                   (e.CommandSource)).NamingContainer as GridViewRow;
                    GridViewRow grRows = grdEmployeeSalaryList.Rows[grArtist.RowIndex];
                    ViewState["SalaryID"] = null;
                    int num = 0;
                    int.TryParse(grdEmployeeSalaryList.DataKeys[grArtist.RowIndex]["ID"].ToString(), out num);

                    //      int.TryParse(grdEmployeeList.DataKeys[grArtist.RowIndex]["ID"].ToString(), out num);
                    //    BindEmployeeSalaryDetails(num);
                    txtSalaryFrom.Text = grRows.Cells[2].Text;
                    txtSalaryTo.Text = grRows.Cells[3].Text;

                    txtGrossSalary.Text = grRows.Cells[5].Text;
                    txtNetSalary.Text = grRows.Cells[6].Text;

                    txtPaidSalary.Text = grRows.Cells[8].Text;
                    decimal NetSal = 0;
                    decimal PaidSal = 0;
                    NetSal = Convert.ToDecimal(grRows.Cells[6].Text);
                    PaidSal = Convert.ToDecimal(grRows.Cells[8].Text);

                    txtSalaryPaying.Text = (NetSal - PaidSal).ToString();

                    //  grdEmployeeSalaryList.Rows[grArtist.RowIndex].Cells[8].ToString(); 
                    ViewState["SalaryID"] = num;
                    num = 0;

                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Loading Salary Details : " + ex.Message;

            }

        }

        protected void BindCurrencyDropDown()
        {
            CurrencyBO objCurrencyBO = new CurrencyBO();
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            catch (Exception ex)
            {

                lblError.Text = "Error while Loading Currency : " + ex.Message;
            }

        }


        protected void grdEmployeeSalaryList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }


        #endregion

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                int SalaryID = ViewState["SalaryID"]!=null?Convert.ToInt32(ViewState["SalaryID"]):0;

    PaymentDetails objPaymentDetails= new PaymentDetails() ;
    PaymentDetailsBO objPaymentDetailsBO = new PaymentDetailsBO();

    objPaymentDetails.PaymentAmount = Convert.ToDecimal(txtSalaryPaying.Text);


   
    objPaymentDetails.PaymentSourceID = Convert.ToInt32(ddlPaymentMode.SelectedValue.ToString());
    objPaymentDetails.PaymentMode = ddlPaymentMode.SelectedItem.ToString();
    objPaymentDetails.PaymentModeNo = txtPaymentModeNo.Text;
    objPaymentDetails.BankID = ddlBank.SelectedIndex > 0 ? Convert.ToInt32(ddlBank.SelectedValue.ToString()) : 0;
    if (ddlPaymentMode.SelectedValue == "2" || ddlPaymentMode.SelectedValue == "3") { objPaymentDetails.Expirationdate = Convert.ToDateTime(txtPaymentExpirationDate.Text); }
    objPaymentDetails.AuthorizationNo = 0;
    objPaymentDetails.CurrencyID = ddlCurrency.SelectedIndex > 0 ? Convert.ToInt32(ddlCurrency.SelectedValue.ToString()) : 0;
    objPaymentDetails.CurrencyRate = Convert.ToDecimal(txtCurrencyRate.Text != "" ? txtCurrencyRate.Text : "0");


  //  objPaymentDetails.EmployeeID = ViewState["EmployeeID"] != null ? (int)ViewState["SupplierID"] : 0;
    objPaymentDetails.FinancialYearID = LoginToken.FinancialYearID;
    objPaymentDetails.CompanyID = LoginToken.CompanyID;
    objPaymentDetails.AddedBy = LoginToken.LoginId;

    


    objPaymentDetails.TType = "DR";
    objPaymentDetails.TransactionType = "SalaryPayment";
    objPaymentDetails.Remarks = txtRemarks.Text;
    if (ViewState["EmployeeID"] != null)
        objPaymentDetails.EmployeeID = ViewState["EmployeeID"] != null ? (int)ViewState["EmployeeID"] : 0;
    else
    {
        lblError.Text = "Invalid Employee Selected ";
        return;
    }
    if( ViewState["SalaryID"] != null )
    {
    objPaymentDetails.SalaryID = ViewState["SalaryID"] != null ? Convert.ToInt32(ViewState["SalaryID"]) : 0;
    }
    else
                {
                    lblError.Text = "Invalid Salary Selected ";
                    return;
                }
    objPaymentDetails.IsActive = true;
    


    if (objPaymentDetailsBO.SaveEmployeePaymentDetails(objPaymentDetails))
    {
        ViewState["SalaryID"] = null;
        lblError.Text = "Payment Transaction Saved Successfully";
        ClearAll();
    }
                



            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Saving Salary Payment Details : " + ex.Message;
            }


        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ClearAll(); 
        }
    }
}