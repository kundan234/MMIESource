﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.INV;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;

namespace MMIE.INV
{
    public partial class StockAdjustQty : BasePage
    {
        DataSet ds = null;
        List<Customer> lstStore = null;
        const string VS_SEARCH = "VS_SEARCH";
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    MasterLookupBO mstlookup = new MasterLookupBO();
                    //BindDropDownControl(drCompanyBranch, mstlookup.GetLookupsList(LookupNames.Company));
                    BindDropDownControl(ddlStoreType, mstlookup.GetLookupsList(LookupNames.StoreName));
                    ddlStoreType.Items.Insert(0, "Select Store/Depot");
                    BindDropDownControl(ddlProductGroupType, mstlookup.GetLookupsList(LookupNames.Group));
                    ddlProductGroupType.Items.Insert(0, "Select Product Type");

                    
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemid";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
        }

        protected void BindProductStock()
        { 
         Order objOrd= new Order();
         objOrd.ProductName = txtProductName.Text;
            int n=0;
            int.TryParse(txtProductCode.Text,out  n);
            objOrd.ProductID = n;
            objOrd.GroupType= Convert.ToInt32( ddlProductGroupType.SelectedIndex>0?ddlProductGroupType.SelectedValue.ToString():"0");
            objOrd.StoreID = Convert.ToInt32(ddlStoreType.SelectedIndex > 0 ? ddlStoreType.SelectedValue.ToString() : "0");

                INVBO objINBO = new INVBO();
                List<Order> lstOrder = new List<Order>();
                lstOrder = objINBO.SearchProductStockList(objOrd);
                gvStockInfo.DataSource = lstOrder;
                gvStockInfo.DataBind();

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                BindProductStock();
              
                // objCustomer = new Customer();
                //objCustomer.CompanyID = Convert.ToInt16(drCompanyBranch.SelectedValue);
                //objCustomer.StoreID = Convert.ToInt32(ddlStoreType.SelectedValue);
                //objCustomer.GroupType = Convert.ToInt32(ddlProductGroupType.SelectedValue);
                //Session[VS_SEARCH] = objCustomer;
                //ds = SearchStore(objCustomer);
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                //    gvStockInfo.DataSource = ds.Tables[0].DefaultView;
                //    gvStockInfo.DataBind();
                //    gvStockInfo.Visible = true;

                //}
                //else
                //{
                //    gvStockInfo.Visible = true;
                //    gvStockInfo.DataSource = ds.Tables[0].DefaultView;
                //    gvStockInfo.DataBind();

                //}
                //lblError.Visible = false;
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        //private DataSet SearchStore(Customer objStore)
        //{
        //    //Call service operation to get data from database source
        //    INVBO st = new INVBO();
        //    lstStore = st.SearchStore(objStore);
        //    DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
        //    ds = new DataSet();
        //    ds.Tables.Add(dt);
        //    return ds;
        //}

        protected void gvStockInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvStockInfo.PageIndex = e.NewPageIndex;
            BindProductStock();
            //Customer objCustDetails = (Customer)Session[VS_SEARCH];
            //ds = SearchStore(objCustDetails);
            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    gvStockInfo.DataSource = ds.Tables[0].DefaultView;
            //    gvStockInfo.DataBind();
            //    gvStockInfo.Visible = true;

            //}
        }

        protected void gvStockInfo_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                double  Num;
                int ProductID = Convert.ToInt32(gvStockInfo.Rows[e.RowIndex].Cells[1].Text);
                Label lblGrpId = (Label)gvStockInfo.Rows[e.RowIndex].FindControl("lblGrpId");

                TextBox txtRemarks = (TextBox)gvStockInfo.Rows[e.RowIndex].FindControl("txtRemarks");
                TextBox txtAdjustQty = (TextBox)gvStockInfo.Rows[e.RowIndex].FindControl("txtAdjustQty");
                Label lblStoreID = (Label)gvStockInfo.Rows[e.RowIndex].FindControl("lblStoreID");
                Label lblID = (Label)gvStockInfo.Rows[e.RowIndex].FindControl("lblID");
                INVBO ObjStockUpdate = new INVBO();
                Order objCustmer = new Order();
                objCustmer.ProductID = ProductID;
                objCustmer.ID = Convert.ToInt32(lblID.Text);
                objCustmer.StoreID = Convert.ToInt32(lblStoreID.Text);
                objCustmer.CompanyID = (Int16)LoginToken.CompanyID;
                objCustmer.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                objCustmer.AddedBy = LoginToken.LoginId;


                bool isNum = double.TryParse(txtAdjustQty.Text.Trim(), out Num);

                if (isNum)
                {
                    objCustmer.AvailableQty = Convert.ToDouble(gvStockInfo.Rows[e.RowIndex].Cells[5].Text);
                    objCustmer.AdjustQty = Num;
                    objCustmer.GroupType = Convert.ToInt32(lblGrpId.Text.Trim());
                    bool status = ObjStockUpdate.UpdateStockQuantityNew(objCustmer);
                    if (status == true)
                    {
                        BindProductStock();
                        //Customer objCustDetails = (Customer)Session[VS_SEARCH];
                        //ds = SearchStore(objCustDetails);
                        //if (ds.Tables[0].Rows.Count > 0)
                        //{
                        //    gvStockInfo.DataSource = ds.Tables[0].DefaultView;
                        //    gvStockInfo.DataBind();
                        //    gvStockInfo.Visible = true;

                        //}
                        lblError.Text = ExceptionMessage.GetMessage("STR7000003");
                        lblError.Visible = true;
                    }
                }
                else
                {
                    lblError.Text = ExceptionMessage.GetMessage("INV00001");
                    lblError.Visible = true;
                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void gvStockInfo_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

    }
}