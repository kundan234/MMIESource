﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.BusinessProcess.INV;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.PUR;


namespace MMIE.INV
{
    public partial class TransferStockQty : BasePage
    {
        DataSet ds = null;
        List<Customer> lstStore = null;
        const string VS_SEARCH = "VS_SEARCH";
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnUpdate.Enabled = LoginToken.IsAddOn;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            
            try
            {
                if (!IsPostBack)
                {
                    PagePermission();
                    MasterLookupBO mstlookup = new MasterLookupBO();
                    //BindDropDownControl(drCompanyBranchfrom, mstlookup.GetLookupsList(LookupNames.Company));
                    BindDropDownControl(ddlStoreTypefrom, mstlookup.GetLookupsList(LookupNames.StoreName));
                    ddlStoreTypefrom.Items.Insert(0, "Select Store/Depot");
                    BindDropDownControl(ddlProductGroupTypefrom, mstlookup.GetLookupsList(LookupNames.Group));
                    ddlProductGroupTypefrom.Items.Insert(0, "Select Product Type");

                    //BindDropDownControl(drCompanyBranchTo, mstlookup.GetLookupsList(LookupNames.Company));
                    BindDropDownControl(ddlStoreTypeTo, mstlookup.GetLookupsList(LookupNames.StoreName));
                    ddlStoreTypeTo.Items.Insert(0, "Select Store/Depot");
                    //BindDropDownControl(ddlProductGroupTypeTo, mstlookup.GetLookupsList(LookupNames.Group));
                    //ddlProductGroupTypeTo.Items.Insert(0, "Select Product Type");

                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemid";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
        }

        protected void BindProductStock()
        {
            Order objOrd = new Order();
            lblError.Text = "";
            objOrd.ProductName = txtProductName.Text;
            int n = 0;
            int.TryParse(txtProductCode.Text, out  n);
            objOrd.ProductID = n;
            objOrd.GroupType = Convert.ToInt32(ddlProductGroupTypefrom.SelectedIndex > 0 ? ddlProductGroupTypefrom.SelectedValue.ToString() : "0");
            objOrd.StoreID = Convert.ToInt32(ddlStoreTypefrom.SelectedIndex > 0 ? ddlStoreTypefrom.SelectedValue.ToString() : "0");

            INVBO objINBO = new INVBO();
            List<Order> lstOrder = new List<Order>();
            lstOrder = objINBO.SearchProductStockList(objOrd);
            if (lstOrder.Count > 0)
            {
                if (Convert.ToInt32(ddlProductGroupTypefrom.SelectedValue.ToString()) == 1)
                {
                    dvVehical.Visible = true;
                    gvVehicalStockInfo.DataSource = lstOrder;
                    gvVehicalStockInfo.DataBind();
                    gvVehicalStockInfo.Visible = true;

                    //Hide Part Details 
                    dvPart.Visible = false;
                    gvPartDetails.DataSource = null;
                    gvPartDetails.DataBind();
                    gvPartDetails.Visible = false;

                }
                else
                {
                    dvPart.Visible = true;
                    gvPartDetails.DataSource = lstOrder;
                    gvPartDetails.DataBind();
                    gvPartDetails.Visible = true;
                  
                    //Hide Vehical Details 
                    dvVehical.Visible = false;
                    gvVehicalStockInfo.DataSource = null;
                    gvVehicalStockInfo.DataBind();
                    gvVehicalStockInfo.Visible = false;

                }
                ddlProductGroupTypefrom.Enabled = false;
                ddlStoreTypefrom.Enabled = false;
            }
            else
            {
                lblError.Text = "No Product Found Please Try Again....!";

            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {

                gvVehicalStockInfo.DataSource = null;
                gvVehicalStockInfo.DataBind();

                gvPartDetails.DataSource = null;
                gvPartDetails.DataBind();
                grdVehicalDetails.DataSource = null;
                grdVehicalDetails.DataBind();

                BindProductStock();
                //Session[VS_SEARCH] = null;
                //Customer objCustomer = new Customer();
                //objCustomer.CompanyID = Convert.ToInt16(drCompanyBranchfrom.SelectedValue);
                //objCustomer.StoreID = Convert.ToInt32(ddlStoreTypefrom.SelectedValue);
                //objCustomer.GroupType = Convert.ToInt32(ddlProductGroupTypefrom.SelectedValue);
                //Session[VS_SEARCH] = objCustomer;
                //ds = SearchStore(objCustomer);
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                //    gvStockInfo.DataSource = ds.Tables[0].DefaultView;
                //    gvStockInfo.DataBind();
                //    gvStockInfo.Visible = true;

                //}
                //else
                //{
                //    gvStockInfo.Visible = true;
                //    gvStockInfo.DataSource = ds.Tables[0].DefaultView;
                //    gvStockInfo.DataBind();

                //}
                //lblError.Visible = false;
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        private DataSet SearchStore(Customer objStore)
        {
            //Call service operation to get data from database source
            INVBO st = new INVBO();
            lstStore = st.SearchStore(objStore);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        //protected void gvStockInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
        //{
        //    gvStockInfo.PageIndex = e.NewPageIndex;
        //    Customer objCustDetails = (Customer)Session[VS_SEARCH];
        //    ds = SearchStore(objCustDetails);
        //    if (ds.Tables[0].Rows.Count > 0)
        //    {
        //        gvStockInfo.DataSource = ds.Tables[0].DefaultView;
        //        gvStockInfo.DataBind();
        //        gvStockInfo.Visible = true;

        //    }
        //}

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    #region Old Code


                    //    int i;
                    //    int Num;

                    //    for (i = 0; i < gvStockInfo.Rows.Count; i++)
                    //    {
                    //        GridViewRow rows = gvStockInfo.Rows[i];
                    //        TextBox txTransferQty = (TextBox)gvStockInfo.Rows[rows.RowIndex].Cells[6].FindControl("txtTransferQty");

                    //        if (txTransferQty.Text != "")
                    //        {

                    //            int availableQty = Convert.ToInt32(gvStockInfo.Rows[rows.RowIndex].Cells[5].Text);
                    //            bool isNum = int.TryParse(txTransferQty.Text.Trim(), out Num);

                    //            if (isNum)
                    //            {
                    //                if (availableQty < Convert.ToInt32(txTransferQty.Text.ToString()))
                    //                {
                    //                    lblError.Text = "Please check Available Qty and try again!";
                    //                    lblError.Visible = true;
                    //                    return;
                    //                }

                    //            }
                    //            else
                    //            {
                    //                lblError.Text = ExceptionMessage.GetMessage("INV00001");
                    //                lblError.Visible = true;
                    //                return;
                    //            }
                    //        }
                    //    }

                    //    for (i = 0; i < gvStockInfo.Rows.Count; i++)
                    //    {
                    //        GridViewRow row = gvStockInfo.Rows[i];
                    //        int ProductID = Convert.ToInt32(gvStockInfo.Rows[row.RowIndex].Cells[1].Text);
                    //        Label lblGrpId = (Label)gvStockInfo.Rows[row.RowIndex].Cells[2].FindControl("lblGrpId");
                    //        TextBox txtTransferQty = (TextBox)gvStockInfo.Rows[row.RowIndex].Cells[6].FindControl("txtTransferQty");
                    //        INVBO ObjStockUpdate = new INVBO();
                    //        Customer objCustmer = new Customer();
                    //        objCustmer.ProductID = ProductID;



                    //            objCustmer.Quantity = Convert.ToInt32(txtTransferQty.Text.Trim() == "" ? "0" : txtTransferQty.Text.Trim());
                    //            objCustmer.GroupType = Convert.ToInt32(lblGrpId.Text.Trim());
                    //            objCustmer.StoreID = Convert.ToInt32(ddlStoreTypeTo.SelectedValue);
                    //            objCustmer.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                    //            if (objCustmer.Quantity != 0)
                    //            {
                    //                bool status = ObjStockUpdate.UpdateTransferStockQuantity(objCustmer);

                    //                if (status == true)
                    //                {
                    //                    lblError.Text = ExceptionMessage.GetMessage("STR7000003");
                    //                    lblError.Visible = true;
                    //                }
                    //            }


                    //    }
                    //            Customer objCustDetails = (Customer)Session[VS_SEARCH];
                    //            ds = SearchStore(objCustDetails);
                    //            if (ds.Tables[0].Rows.Count > 0)
                    //            {
                    //                gvStockInfo.DataSource = ds.Tables[0].DefaultView;
                    //                gvStockInfo.DataBind();
                    //                gvStockInfo.Visible = true;

                    //            }
                    //}

                    #endregion

                    INVBO objINVBO = new INVBO();

                    Order objOrder = new Order();

                    objOrder.AddedBy = LoginToken.LoginId;
                    objOrder.CompanyID =(Int16) LoginToken.CompanyID;
                    objOrder.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                    objOrder.ToStore = Convert.ToInt32(ddlStoreTypeTo.SelectedValue.ToString());
                    objOrder.GroupType = Convert.ToInt32(ddlProductGroupTypefrom.SelectedValue.ToString());
                    if (dvVehical.Visible)
                    {

                        objOrder.XMLData = VehicalGridTOXML();
                        if (objINVBO.UpdateTransferStockQuantityVehical(objOrder))
                        {
                            lblError.Text = "Vehicals Transfered Successfully";
                            grdVehicalDetails.DataSource = null;
                            grdVehicalDetails.DataBind();
                        }
                        
                    
                    }

                    if (dvPart.Visible)
                    {
                        objOrder.XMLData = PartGridTOXML();
                        if (objINVBO.UpdateTransferStockQuantityParts(objOrder))
                        {
                            lblError.Text = "Part Transfered Successfully";
                            gvPartDetails.DataSource = null;
                            gvPartDetails.DataBind();
                        }
                        
                    
                    }

                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void ClearAll()
        {


            dvPart.Visible = false;
            gvPartDetails.DataSource = null;
            gvPartDetails.DataBind();
            gvPartDetails.Visible = false;
            txtProductCode.Text="";
            txtProductName.Text = "";
            ddlProductGroupTypefrom.Enabled = true;
            ddlStoreTypefrom.Enabled = true;
            //Hide Vehical Details 
            dvVehical.Visible = false;
            gvVehicalStockInfo.DataSource = null;
            gvVehicalStockInfo.DataBind();
            gvVehicalStockInfo.Visible = false;

            ddlProductGroupTypefrom.SelectedIndex = 0;
            ddlStoreTypefrom.SelectedIndex = 0;
            ddlStoreTypeTo.SelectedIndex = 0;
       
            
        }

        protected string PartGridTOXML()
        {
            StringBuilder objBuilder = new StringBuilder();

            if (dvPart.Visible)
            {


                foreach (GridViewRow gr in gvPartDetails.Rows)
                {
                    TextBox txtAdjustqty = new TextBox();
                    CheckBox chk = new CheckBox();
                    Label lblStoreID = new Label();
                    Label lblID = new Label();
                    lblID = (Label)gr.FindControl("lblID");
                    lblStoreID = (Label)gr.FindControl("lblStoreID");
                    txtAdjustqty = (TextBox)gr.FindControl("txtAdjustQty");
                    chk = (CheckBox)gr.FindControl("chkIsCheckin");

                    if (chk.Checked)
                    {


                       objBuilder.Append("<StockTransferXML ProductID  = \"" + gr.Cells[2].Text.ToString() + "\" ");
                       objBuilder.Append(" Qty  = \"" + txtAdjustqty.Text + "\" ");
                       objBuilder.Append(" StoreID= \"" + lblStoreID.Text + "\" ");
                       objBuilder.Append(" ID= \"" + lblID.Text + "\" ");
                       objBuilder.Append(" AvailableQty= \"" + gr.Cells[5].Text.ToString() + "\" ");
                       objBuilder.Append("/>");
                                                                  
                                            
                    }
                    

                }
            
            
            
            
            }
            return objBuilder.ToString();
        
        }

        protected string VehicalGridTOXML()
           {

               StringBuilder objBuilder = new StringBuilder();
               //Create XML for Vehical List
               if (dvVehical.Visible)
               {


                   foreach (GridViewRow gr in grdVehicalDetails.Rows)
                   {
                       TextBox txtRemarks = new TextBox();
                       CheckBox chk = new CheckBox();
                       Label lblStoreID = new Label();
                       Label lblPOID = new Label();
                       lblPOID = (Label)gr.FindControl("lblPOID");
                       lblStoreID = (Label)gr.FindControl("lblStoreID");
                       txtRemarks = (TextBox)gr.FindControl("txtRemarksCheck");
                       chk = (CheckBox)gr.FindControl("chkIsCheckin");

                       if (chk.Checked)
                       {


                           objBuilder.Append("<StockTransferXML ProductID  = \"" + gr.Cells[2].Text.ToString() + "\" ");
                           objBuilder.Append(" StoreID= \"" + lblStoreID.Text + "\" ");
                           objBuilder.Append(" VehicalPOID= \"" + lblPOID.Text + "\" ");
                           objBuilder.Append(" VINNO= \"" + gr.Cells[6].Text.ToString() + "\" ");
                           objBuilder.Append(" EngineNo= \"" + gr.Cells[7].Text.ToString() + "\" ");
                           objBuilder.Append(" Remarks= \"" + txtRemarks.Text + "\" ");
                           objBuilder.Append("/>");


                       }


                   }




               }

               return objBuilder.ToString();

        }

        protected void grdVehicalDetails_OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ClearAll();
            lblError.Text = "";
           
        }

        protected void gvPartDetails_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void gvVehicalStockInfo_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void gvVehicalStockInfo_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "ShowDetails")
            {

                int id = Convert.ToInt32(e.CommandArgument.ToString());
              
                GridViewRow gr = gvVehicalStockInfo.Rows[id];
                LinkButton lnk = (LinkButton)gr.Cells[1].FindControl("lnkOrderNo");
                BindVehicleGrid(Convert.ToInt32(lnk.Text));
            }
        }


        private void BindVehicleGrid(int ProductID)
        {
            Product objproduct = new Product();
            objproduct.PONumber = 0;
            objproduct.GroupType = Convert.ToInt32( ddlProductGroupTypefrom.SelectedValue.ToString());
            objproduct.ProductID = ProductID;
            objproduct.StoreID = Convert.ToInt32( ddlStoreTypefrom.SelectedValue.ToString());

            PartBO objPartBO = new PartBO();
            lblError.Text = "";
            List<Product> lstProduct = new List<Product>();

            lstProduct = objPartBO.SearchPurchaseOderDetails(objproduct);
            grdVehicalDetails.DataSource = lstProduct;
            grdVehicalDetails.DataBind();

            //if (lstProduct.Count > 0)
            //{
            //    btnUpdate.Enabled = true;

            //}
            //else
            //{
            //    lblError.Text = "No Vehical found in this store please try again later...!";
            //}
           

            grdVehicalDetails.Visible = true;
        }
    }
}