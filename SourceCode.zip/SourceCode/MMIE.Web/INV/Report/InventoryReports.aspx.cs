﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data.SqlClient;
using System.Configuration;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;
using System.Collections;
using MMIE.SAL.Report;
using MMIE.Web.Reports;

namespace MMIE.INV.Report
{
    public partial class InventoryReports : BasePage
    {
        ReportDocument rptDoc;
        // System.Configuration.ConnectionStringSettings conStr = System.Configuration.ConfigurationManager.ConnectionStrings["SqlConnectionString"];
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                crSaleReport.HasExportButton = this.LoginToken.IsPrintExportOn;

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            ReportUtil RU = new ReportUtil();

            // Hide show Report Export Button

            PagePermission();

            if (Request.QueryString["ReportType"] == "DateWiseStockReport")
            {
                try
                {

                    rptDoc = new rptDateWiseStock();
                    Hashtable htable = new Hashtable();
                    htable.Add("@StockDate", Request.QueryString["StockDate"].Trim());
                    htable.Add("@StoreID", Request.QueryString["StoreID"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "Stock")
            {
                try
                {

                    rptDoc = new rptStockReportNew();
                    Hashtable htable = new Hashtable();
                    htable.Add("@GroupType", Request.QueryString["GroupID"].Trim());
                    htable.Add("@Model", Request.QueryString["model"].Trim());
                    htable.Add("@CompanyID", Request.QueryString["BranchID"].Trim());
                    htable.Add("@ProductName", Request.QueryString["Productname"].Trim());

                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }


            else if (Request.QueryString["ReportType"] == "Transfer" && Request.QueryString["GroupID"] == "1")
            {
                try
                {

                    rptDoc = new rptTransferReportVehical();
                    Hashtable htable = new Hashtable();
                    htable.Add("@GroupType", Request.QueryString["GroupID"].Trim());
                    //htable.Add("@BranchID", Request.QueryString["BranchID"].Trim());
                    htable.Add("@StoreID", Request.QueryString["StoreID"].Trim());
                    htable.Add("@Fromdate", Request.QueryString["Fromdate"].Trim());
                    htable.Add("@Todate", Request.QueryString["Todate"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }



            }
            else if (Request.QueryString["ReportType"] == "Transfer" && Request.QueryString["GroupID"] == "2")
            {
                try
                {

                    rptDoc = new rptTransferReportPart();
                    Hashtable htable = new Hashtable();
                    htable.Add("@GroupType", Request.QueryString["GroupID"].Trim());
                    //htable.Add("@BranchID", Request.QueryString["BranchID"].Trim());
                    htable.Add("@StoreID", Request.QueryString["StoreID"].Trim());
                    htable.Add("@Fromdate", Request.QueryString["Fromdate"].Trim());
                    htable.Add("@Todate", Request.QueryString["Todate"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }



            }
            else if (Request.QueryString["ReportType"] == "StockAdjust")
            {
                try
                {

                    rptDoc = new rptStockAdjustment();
                    Hashtable htable = new Hashtable();
                    htable.Add("@GroupType", Request.QueryString["GroupID"].Trim());
                    htable.Add("@BranchID", Request.QueryString["BranchID"].Trim());
                    htable.Add("@StoreID", Request.QueryString["StoreID"].Trim());
                    htable.Add("@Fromdate", Request.QueryString["Fromdate"].Trim());
                    htable.Add("@Todate", Request.QueryString["Todate"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }



            }

            else if (Request.QueryString["ReportType"] == "StoreWiseStockReport")
            {
                try
                {

                    rptDoc = new rptStoreWiseStock();
                    Hashtable htable = new Hashtable();
                    htable.Add("@GroupType", Request.QueryString["GroupID"].Trim());
                    htable.Add("@StoreID", Request.QueryString["StoreID"].Trim());
                    htable.Add("@ProductID", Request.QueryString["ProductID"].Trim());
                    htable.Add("@ProductName", Request.QueryString["ProductName"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }



            }

        }
        protected void Page_UnLoad(object sender, EventArgs e)
        {

            rptDoc.Close();
            rptDoc.Dispose();

        }
    }
}