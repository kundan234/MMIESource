﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.INV.Report
{
    public partial class TransferReport : BasePage
    {
        MasterLookupBO mstlookup = new MasterLookupBO();
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSubmit.Enabled = LoginToken.IsAddOn;
                //dllBranch.SelectedValue = Convert.ToString(LoginToken.CompanyID);
                //dllBranch.Enabled = LoginToken.IsChangeBranchOn;
                txtdatefrom.Enabled = LoginToken.IsChangeDateOn;
                txtdateto.Enabled = LoginToken.IsChangeDateOn;
           
            }
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
           
            BindDropDownControl(ddlProductGroupType, mstlookup.GetLookupsList(LookupNames.Group));
            ddlProductGroupType.Items.Insert(0, "Select Product Type");

            BindDropDownControl(ddlStore, mstlookup.GetLookupsList(LookupNames.StoreName));
            ddlStore.Items.Insert(0, new ListItem("Select Store/Depot", "0"));
           // BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
           // dllBranch.Items.Insert(0,new ListItem("Select A Branch","0"));
            txtdatefrom.Text = System.DateTime.Now.ToShortDateString();
            txtdateto.Text = System.DateTime.Now.ToShortDateString();

            PagePermission();
            
        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }
    }
}