﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;


namespace MMIE.SAL
{
    public partial class CreditCheckOut : BasePage
    {
        DataSet ds = null;
        List<Order> lstOrder = null;
        DataSet dsOrderdetails = null;
        List<Customer> lstStore = null;
        const string VS_SEARCH = "VS_SEARCH";
        private Currency objCurrency = new Currency();
        private CurrencyBO objCurrencyBO = new CurrencyBO();
        private int Count = 1;
        private Table t;
        TextBox tb;
    //    CheckBox chk;

        private void BindBankDetails()
        {
            BankBO objPaymentDetailsBO = new BankBO();
            List<Bank> lstPaymentHistory = new List<Bank>();
            lstPaymentHistory = objPaymentDetailsBO.GetBankList(false);
            if (lstPaymentHistory != null)
            {
                ddlBank.DataSource = lstPaymentHistory;
                ddlBank.DataBind();

                ddlBank.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }

        private void BindPaymentDetails(string order)
        {
              PaymentDetailsBO objPaymentDetailsBO = new PaymentDetailsBO();
                    List<PaymentDetails> lstPaymentHistory = new List<PaymentDetails>();
                    lstPaymentHistory = objPaymentDetailsBO.GetPaymentDetailsListByOrderCR(order);
                    if (lstPaymentHistory != null)
                    {
                        grdTransaction.DataSource = lstPaymentHistory;
                        grdTransaction.DataBind();
                    }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                  //  btnPrintReceipt.Enabled = false;
                    t = new Table();
                    Session["Files"] = t;
                    Session["Count"] = Count;
                    BindCurrencyDropDown();
                    BindBankDetails();
                    if (Request.QueryString["OrderNo"] != null && Request.QueryString["GroupType"] != null)
                    {
                        string OrderNo = Request.QueryString["OrderNo"].ToString();
                        int GroupType = Convert.ToInt32(Request.QueryString["GroupType"].ToString());
                        ViewState["OrderNo"] = OrderNo;

                        txtSearchOrder.Text = OrderNo;
                        Customer objCustomer = new Customer();
                        objCustomer.OrderNo = OrderNo;
                        objCustomer.GroupType = GroupType;
                        dsOrderdetails = BindOrderDetail(objCustomer);


                        //-----------------get customer id------------------
                        Order objOrder = new Order();
                        objOrder.OrderNumber = OrderNo;
                        objOrder.GroupType = Convert.ToInt32(Request.QueryString["GroupType"]);
                        ds = SearchOrder(objOrder);
                        if (Request.QueryString["cust"] != null)
                        {
                            ViewState["custid"] = Convert.ToInt32(Request.QueryString["cust"]);
                            BindCustomerDocumentDetail(Convert.ToInt32(ViewState["custid"]));
                        }
                            
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            ViewState["custid"] = ds.Tables[0].Rows[0]["CustomerID"].ToString();
                            BindPaymentDetails(OrderNo);

                        }
                        //----------------------------
                        if (dsOrderdetails.Tables[0].Rows.Count > 0)
                        {
                            ddlCurrency.SelectedValue = ds.Tables[0].Rows[0]["CurrencyID"].ToString();
                            ViewState["BillHeaderID"] = ds.Tables[0].Rows[0]["BillHeaderID"].ToString();
                          //  btnPrintReceipt.Enabled = true;

                            if (GroupType == 1)
                            {

                                gvOrderVehicleDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                                gvOrderVehicleDetail.DataBind();

                                lblDepositInGourdes.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalance"].ToString();
                                lblDepositInUSD.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalanceUSD"].ToString();
                                txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGrandTotalUSD"].ToString();
                                txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGrandTotalGourdes"].ToString();
                                //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                                //txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                                txtTotalDueAmountUSD.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                                txtTotalDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                                //  ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString();
                                Remarks.Text = dsOrderdetails.Tables[0].Rows[0]["RemarksCheckout"].ToString();
                                Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                                ds = SearchStore(objcustOrdr);
                                gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                                gvOrderSearch.DataBind();
                                btnsave.Enabled = true;
                                ShowLabelControls(true);
                                if (dsOrderdetails.Tables[0].Rows[0]["CurrencyID"].ToString() == "1")
                                {
                                    ddlCurrency.SelectedIndex = 0;
                                }
                                else
                                    ddlCurrency.SelectedIndex = 1;
                            }
                            else if (GroupType == 2)
                            {
                                gvOrderPartDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                                gvOrderPartDetail.DataBind();

                                lblDepositInGourdes.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalance"].ToString();
                                lblDepositInUSD.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalanceUSD"].ToString();
                                txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGrandTotalUSD"].ToString();
                                txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGrandTotalGourdes"].ToString();
                                //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                                //txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                                txtTotalDueAmountUSD.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                                txtTotalDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                                //   ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString();
                                Remarks.Text = dsOrderdetails.Tables[0].Rows[0]["RemarksCheckout"].ToString();
                                if (dsOrderdetails.Tables[0].Rows[0]["CurrencyID"].ToString() == "1")
                                {
                                    ddlCurrency.SelectedIndex = 0;
                                }
                                else
                                    ddlCurrency.SelectedIndex = 1;

                                Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                                ds = SearchStore(objcustOrdr);
                                gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                                gvOrderSearch.DataBind();
                                btnsave.Enabled = true;
                                ShowLabelControls(true);
                            }

                            ddlCurrency.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["CurrencyID"].ToString();
                            txtGourdesConverter.Text = dsOrderdetails.Tables[0].Rows[0]["CurrencyRate"].ToString();


                            //  ViewState["custid"] = dsOrderdetails.Tables[0].Rows[0]["CustomerID"].ToString();

                            //  int a =Convert.ToInt32(ViewState["custid"]);
                        }
                        else
                        {
                            t = (Table)Session["Files"];
                            Count = (int)Session["Count"];
                            phControls.Controls.Add(t);
                            Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                            ds = SearchStore(objcustOrdr);
                            gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                            gvOrderSearch.DataBind();
                            ShowError("No Records Found");


                        }
                    }
                }
            }
            catch(Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Loading Credit Checkout Order Details : " + ex.Message;  

      
            
            }
        }
      
        private DataSet SearchOrder(Order objOrder)
        {
            //Call service operation to get data from database source
            OrderBO odr = new OrderBO();
            lstOrder = odr.SearchOrder(objOrder);
            //    lstCustomer  = UserAdminServiceAgent.SearchCustomer(objCustomer);
            DataTable dt = ORHelper<Order>.GenericListToDataTable(lstOrder);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        protected void BindCurrencyDropDown()
        {
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
                //ddlCurrency.SelectedIndex = 1;
                txtGourdesConverter.Text = ddlCurrency.SelectedValue.ToString();

            }
            catch (Exception ex)
            {

                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Binding Currency Details : " + ex.Message;  

      
            }

        }
       

        protected void ShowError(string a_sMsg)
        {
            errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            if (a_sMsg.Length > 0)
            {
                errorMessage.Visible = true;
            }
            else
            {
                errorMessage.Visible = false;
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Session[VS_SEARCH] = null;
                dsOrderdetails = null;
                Customer objCustomer = new Customer();
                objCustomer.OrderNo = txtSearchOrder.Text.Trim();
                objCustomer.CustomerName = txtSearchCustomerName.Text.Trim();
                objCustomer.CustomerPhone = txtSearchPhone.Text.Trim();
                Session[VS_SEARCH] = objCustomer;
                ds = SearchStore(objCustomer);


                if (ds.Tables[0].Rows.Count > 0)
                {
                    gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                    gvOrderSearch.DataBind();
                    // gvOrderPartDetail.Visible = true;
                    //  gvOrderVehicleDetail.Visible = true;
                    gvOrderSearch.Visible = true;
                    if (ds.Tables[0].Rows.Count == 1)
                    {
                        string OrderNo = ds.Tables[0].Rows[0]["OrderNo"].ToString();
                        int GroupType = Convert.ToInt32(ds.Tables[0].Rows[0]["GroupType"].ToString());


                        ViewState["custid"] = Convert.ToInt32(ds.Tables[0].Rows[0]["CustomerID"].ToString());
                        string path = "CreditCheckOut.aspx?OrderNo=" + OrderNo.ToString().Trim() + "&GroupType=" + GroupType + "&cust=" + Convert.ToInt32(ds.Tables[0].Rows[0]["CustomerID"].ToString());

                        Response.Redirect(path);



                    }
                    //    ShowLabelControls(true);
                }
                else
                {
                    ShowError("No Records Found");
                    gvOrderPartDetail.Visible = false;
                    gvOrderVehicleDetail.Visible = false;
                    gvOrderSearch.Visible = false;
                    ShowLabelControls(false);
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Searching Order Details : " + ex.Message;  

      
            
            }
        }

        private DataSet SearchStore(Customer objStore)
        {
            //Call service operation to get data from database source
            PartBO st = new PartBO();
            lstStore = st.CheckOutSearchStore(objStore);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        private DataSet BindOrderDetail(Customer objStore)
        {
            //Call service operation to get data from database source
            PartBO st = new PartBO();
            lstStore = st.BindOrderDetail(objStore);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        public string MakeCustomerIDLink(string OrderNo, int GroupType, int CustID)
        {
            string ret;
            string str;
            string pageName;
            pageName = "CreditCheckOut.aspx";
            str = pageName + "?OrderNo=" + OrderNo.ToString().Trim() + "&GroupType=" + GroupType + "&cust=" + CustID;
            ret = "<a href=\"" + str + "\">" + OrderNo + "</a>";
           
            return ret;
        }

        private void ShowLabelControls(bool flag)
        {
            lblNetAmount0.Visible = flag;
            txtTotAmount.Visible = flag;
            lblGourdesAmount.Visible = flag;
            txtGourdesAmount.Visible = flag;
            //lblUSDDueAmount.Visible = flag;
            //txtUSDDueAmount.Visible = flag;
            //lblGourdesDueAmount.Visible = flag;
            //txtGourdesDueAmount.Visible = flag;
            //lblUSDPaidAmount.Visible = flag;
            //txtUSDPaidAmount.Visible = flag;
            //lblGourdesPaidAmount.Visible = flag;
            //txtGourdesPaidAmount.Visible = flag;
            lblpaymentMode.Visible = flag;
            ddlPaymentMode.Visible = flag;
            lblCurrency.Visible = flag;
            ddlCurrency.Visible = flag;
            txtGourdesConverter.Visible = flag;
            ShowDetails.Visible = flag;
            ddlBank.Visible = flag;

            txtPaymentExpirationDate.Visible = flag;
            txtPaymentModeNo.Visible = flag;
            txtCodeNo.Visible = flag;
            txtTotalDueAmount.Visible = flag;
            txtTotalDueAmountUSD.Visible = flag;
            lblTotalDueAmount.Visible = flag;
            lblTotalDueAmountUSD.Visible = flag;
            PaymentHistory.Visible = flag;
           

        }
        protected void btnsave_Click(object sender, EventArgs e)
        {
          //  PartBO st = new PartBO();
          //  Customer objCust = new Customer();
          //// List<Customer> listObj = new List<Customer>();
          //listObj = st.GETMAXBillHeaderID();
            //if (listObj.Count > 0)
            //{
            //    Int64 ShipID = listObj[0].MaxBillHeaderID;
            
             bool status= false;   
            int BillHeaderID=0;
          

                   #region Save Payment Details
            try
            {


                PaymentDetails objPaymentDetails = new PaymentDetails();

                PaymentDetailsBO objPaymentBO = new PaymentDetailsBO();
                if (ViewState["BillHeaderID"] != null)
                {
                    BillHeaderID = Convert.ToInt32(ViewState["BillHeaderID"].ToString());
                    objPaymentDetails.ShipID = "SH" + BillHeaderID;
                }

                //        if (ddlPaymentMode.SelectedValue.ToString() == "Deposit")
                //{

                objPaymentDetails.SalesStatus = Convert.ToInt16(ddlStatus.SelectedValue);
                objPaymentDetails.OrderNumber = Request.QueryString["OrderNo"].ToString();
                if (txtAdjustAmountUSD.Text != "")
                    objPaymentDetails.PaidUSDAmt = Convert.ToDecimal(txtAdjustAmountUSD.Text.Trim()); // Convert.ToDecimal(txtUSDPaidAmount.Text.Trim());
                if (txtTotalDueAmountUSD.Text != "")
                    objPaymentDetails.DueUSDAmt = Convert.ToDecimal(txtTotalDueAmountUSD.Text.Trim()) - objPaymentDetails.PaidUSDAmt; //Convert.ToDecimal(txtUSDDueAmount.Text.Trim());
                if (txtAdjustAmount.Text != "")
                    objPaymentDetails.PaidGourdesAmt = Convert.ToDecimal(txtAdjustAmount.Text.Trim()); //Convert.ToDecimal(txtGourdesPaidAmount.Text.Trim());
                if (txtTotalDueAmount.Text != "")
                    objPaymentDetails.DueGourdesAmt = Convert.ToDecimal(txtTotalDueAmount.Text.Trim()) - objPaymentDetails.PaidGourdesAmt; // Convert.ToDecimal(txtGourdesDueAmount.Text.Trim());
                //            // status = st.SaveBulkShipNumber(objCust);
                //}
                //else
                //{
                //    objPaymentDetails.SalesStatus = Convert.ToInt16(ddlStatus.SelectedValue);
                //    objPaymentDetails.OrderNumber = Request.QueryString["OrderNo"].ToString();

                //    if (txtTotalDueAmountUSD.Text != "")
                //    {
                //        objPaymentDetails.DueUSDAmt = Convert.ToDecimal(txtTotalDueAmountUSD.Text.Trim());
                //        objPaymentDetails.PaidUSDAmt = Convert.ToDecimal(txtTotalDueAmountUSD.Text.Trim()); // Convert.ToDecimal(txtUSDPaidAmount.Text.Trim());
                //    }
                //    if (txtTotalDueAmount.Text != "")
                //    {
                //        objPaymentDetails.DueGourdesAmt = Convert.ToDecimal(txtTotalDueAmount.Text.Trim());
                //        objPaymentDetails.PaidGourdesAmt = Convert.ToDecimal(txtTotalDueAmount.Text.Trim()); //Convert.ToDecimal(txtGourdesPaidAmount.Text.Trim());
                //    }       
                //            objPaymentDetails.DueUSDAmt = 0; //Convert.ToDecimal(txtUSDDueAmount.Text.Trim());

                //    objPaymentDetails.DueGourdesAmt = 0; // Convert.ToDecimal(txtGourdesDueAmount.Text.Trim());
                //   // status = st.SaveBulkShipNumber(objCust);
                //}



                objPaymentDetails.BillHeaderID = BillHeaderID;
                objPaymentDetails.PaymentModeNo = txtPaymentModeNo.Text;
                objPaymentDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                objPaymentDetails.CompanyID = (Int16)LoginToken.CompanyID;
                objPaymentDetails.AddedBy = LoginToken.LoginId;

                objPaymentDetails.CustomerID = Convert.ToInt32(ViewState["custid"].ToString());
                //objPaymentDetails.BillHeaderID = BillHeaderID;
                objPaymentDetails.IsChecked = false;
                objPaymentDetails.IsSafeBox = false;
                objPaymentDetails.ParentID = 0;
                if (ddlBank.SelectedIndex > 0)
                {
                    objPaymentDetails.BankID = Convert.ToUInt16(ddlBank.SelectedValue.ToString());
                }

                if (txtPaymentExpirationDate.Text != "")
                {
                    objPaymentDetails.Expirationdate = Convert.ToDateTime(txtPaymentExpirationDate.Text);
                }

                objPaymentDetails.OrderNumber = Request.QueryString["OrderNo"].ToString();
                objPaymentDetails.PaymentMode = ddlPaymentMode.SelectedItem.ToString();
                objPaymentDetails.PaymentSourceID = int.Parse(ddlPaymentMode.SelectedValue); // Added by ankit for source id detail
                objPaymentDetails.IsActive = true;
                objPaymentDetails.ActionType = EnumActionType.Insert;
                if (txtCodeNo.Text != "")
                {
                    objPaymentDetails.AuthorizationNo = Convert.ToInt32(txtCodeNo.Text);
                }
                if (ddlPaymentMode.SelectedItem.Text != "Check" && ddlPaymentMode.SelectedItem.Text != "Card")
                {
                    objPaymentDetails.Expirationdate = System.DateTime.Now;

                }


                if (ViewState["BillHeaderID"] != null)
                    objPaymentDetails.BillHeaderID = Convert.ToInt32(ViewState["BillHeaderID"]);
                objPaymentDetails.TType = "CR";



                //objPaymentDetails.PaymentAmount = objCust.PaidGourdesAmt;
                //objPaymentDetails.PaymentAmountUSD = objCust.PaidUSDAmt;




                if (ddlPaymentMode.SelectedItem.Text == "Deposit")
                {
                    //  objPaymentDetails.PaymentAmount = Convert.ToDecimal(txtAdjustAmount.Text);
                    //  objPaymentDetails.PaymentAmountUSD = Convert.ToDecimal(txtAdjustAmountUSD.Text);
                    objPaymentDetails.Remarks = "Payment Adjusted for : " + Request.QueryString["OrderNo"].ToString();
                }
                //    status = objPaymentBO.AdjustPaymentDetails(objPaymentDetails);

                //    if (status)
                //    {
                //        objPaymentDetails.PaymentAmount = objCust.PaidGourdesAmt - Convert.ToDecimal(txtAdjustAmount.Text);
                //        objPaymentDetails.PaymentAmountUSD = objCust.PaidUSDAmt - Convert.ToDecimal(txtAdjustAmountUSD.Text);
                //        objPaymentDetails.Remarks = "Payment Recieved for : " + Request.QueryString["OrderNo"].ToString();
                //        status = objPaymentBO.SavePaymentDetails(objPaymentDetails);
                //    }
                //}
                else
                {

                    objPaymentDetails.Remarks = "Payment Received for : " + Request.QueryString["OrderNo"].ToString();

                }

                // objPaymentDetails.Remarks = "Payment Recieved for : " + Request.QueryString["OrderNo"].ToString();

                objPaymentDetails.TransactionType = "CreditCheckout";
                objPaymentDetails.CurrencyID = ddlCurrency.SelectedIndex > 0 ? Convert.ToInt32(ddlCurrency.SelectedValue.ToString()) : 0;
                objPaymentDetails.IsSales = true;
                objPaymentDetails.CurrencyRate = Convert.ToDecimal(txtGourdesConverter.Text);
                objPaymentDetails.PurchaseOrderID = 0;
                objPaymentDetails.RemarksCheck = Remarks.Text;

                status = objPaymentBO.SaveBillPaymentDetails(objPaymentDetails);

                if (status)
                {
                    lblError.Text = ExceptionMessage.GetMessage("STR7000001");
                    lblError.Visible = true;
                 //   btnPrintReceipt.Enabled = true;
                    btnsave.Enabled = false;
                    ShowDetails.Visible = false;
                    ViewState["BillHeaderID"] = null;
                    BindPaymentDetails(objPaymentDetails.OrderNumber);
                    PaymentHistory.Visible = true;

                }
                else
                {
                    lblError.Text = "Error While Saving Payment Details";
                }





                //else
                //{
                //    lblError.Text = "No Payment Applicable";
                //}

            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Saving Payment Details : " + ex.Message;  

      
            
            }
                #endregion
                



                

                if (status == true)
                {
                    lblError.Text = ExceptionMessage.GetMessage("STR7000001");
                    lblError.Visible = true;
                  //  btnPrintReceipt.Enabled = true;
                    btnsave.Enabled = false;
                    ShowDetails.Visible = false;
                }
            }
        

        protected void btnPrintReceipt_Click(object sender, EventArgs e)
        {
            Response.Redirect("Report/SaleReport.aspx?ReportType=Receipt&id=" + txtSearchOrder.Text.Trim() + "");
        }

        protected void grdTransaction_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (Request.QueryString["OrderNo"] != null && Request.QueryString["GroupType"] != null)
            {
                string OrderNo = Request.QueryString["OrderNo"].ToString();


                grdTransaction.PageIndex = e.NewPageIndex;
                BindPaymentDetails(OrderNo);
            }

        }

        #region Get Customer Document By Customer Id
        private void addfiletable()
        {
            t = new Table();
            t.Rows.Clear();
            t.BorderStyle = BorderStyle.Solid;

            TableHeaderRow th = new TableHeaderRow();
            th.BorderStyle = BorderStyle.Solid;
            TableCell c1 = new TableCell();
            c1.Text = "S.No.";
            c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

            TableCell c2 = new TableCell();
            c2.Text = "Uploaded Files";
            c2.Style.Add(HtmlTextWriterStyle.Width, "25%");

            //TableCell c3 = new TableCell();
            //c3.Text = "Document Type";
            //c3.Style.Add(HtmlTextWriterStyle.Width, "8%");
            //c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c4 = new TableCell();
            c4.Text = "Document ID";
            c4.Style.Add(HtmlTextWriterStyle.Width, "20%");
            c4.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c5 = new TableCell();
            c5.Text = "Remarks";
            c5.Style.Add(HtmlTextWriterStyle.Width, "10%");
            c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");

            


            th.Cells.Add(c1);
            th.Cells.Add(c2);
          
            th.Cells.Add(c4);
            th.Cells.Add(c5);
    



            Style myStyle = new Style();
            myStyle.ForeColor = System.Drawing.Color.Black;
            myStyle.BackColor = System.Drawing.Color.LightGray;
            myStyle.Font.Bold = true;
            myStyle.BorderStyle = BorderStyle.Solid;

            th.ApplyStyle(myStyle);
            // th.Font.Size =Unit.Percentage(12);
            th.BorderStyle = BorderStyle.Solid;
            th.BorderWidth = Unit.Pixel(1);

            t.Rows.Add(th);

        }
        private void BindCustomerDocumentDetail(int id)
        {
            //CheckBox chk;
            CustomerBO objCust = new CustomerBO();
            List<CustomerDocument> lst = new List<CustomerDocument>();
            lst = objCust.SearchCustomerDocument(id);
            t.Rows.Clear();
            addfiletable();

            Count = 1;
            foreach (CustomerDocument obj in lst)
            {

                HyperLink lnk = new HyperLink();
                lnk.EnableViewState = true;
                lnk.ID = "lnk" + Count.ToString();
                lnk.Text = obj.FriendlyName;
                lnk.NavigateUrl = "~/CustomerScanID/" + obj.CustomerID.ToString() + "/" + obj.CustomerScanID;
                lnk.Visible = true;
                lnk.Target = "_blank";

                tb = new TextBox();
                tb.EnableViewState = true;
                tb.ID = "txt" + Count.ToString();
                tb.MaxLength = 150;
                tb.Text = obj.CustomerDescription;
                tb.Enabled = false;


                //chk = new CheckBox();
                //chk.Checked = true;
                //chk.ID = "chk" + Count.ToString();
                //chk.Enabled = false;

                //Label Uid = new Label();
                //Uid.EnableViewState = true;
                //Uid.ID = "label2" + Count.ToString();
                //Uid.Text = Convert.ToString(obj.ScanID);
                //Uid.Visible = false;


                Label uName = new Label();
                uName.EnableViewState = true;
                uName.ID = "label3" + Count.ToString();
                uName.Text = obj.CustomerScanID;
                uName.Visible = false;



                TableRow dr = new TableRow();
                TableCell c1 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();
                //TableCell c5 = new TableCell();
                TableCell C6 = new TableCell();
                TableCell c7 = new TableCell();
                //TableCell c8 = new TableCell();
                TableCell c9 = new TableCell();

                //Label DocType = new Label();
                //DocType.EnableViewState = true;
                //DocType.ID = "lblDocType" + Count.ToString();
                //DocType.Text = obj.DocumentType;
                //DocType.Visible = true;


                Label DocID = new Label();
                DocID.EnableViewState = true;
                DocID.ID = "lblDocID" + Count.ToString();
                DocID.Text = obj.DocumentID;
                DocID.Visible = true;

                //c8.Controls.Add(DocType);
                c9.Controls.Add(DocID);


                c7.Controls.Add(uName);
                //c8.Controls.Add(filePath);

                c3.Text = "File" + Count.ToString(); ;
                c3.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //  c1.Style.Add(HtmlTextWriterStyle.Width, "30%");
                TableCell c2 = new TableCell();
                //   c2.Style.Add(HtmlTextWriterStyle.Width, "30%");
                //   c4.Style.Add(HtmlTextWriterStyle.Width, "4%");
                //   c5.Style.Add(HtmlTextWriterStyle.Width, "2%");
                c2.Controls.Add(tb);
                c1.Controls.Add(lnk);
                //c5.Controls.Add(chk);
                //C6.Controls.Add(Uid);

                c1.Style.Add(HtmlTextWriterStyle.Width, "25%");
                c2.Style.Add(HtmlTextWriterStyle.Width, "5%");

                //  c3.Style.Add(HtmlTextWriterStyle.Width, "3%");
                c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                //c8.Style.Add(HtmlTextWriterStyle.Width, "8%");
                //c8.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c9.Style.Add(HtmlTextWriterStyle.Width, "20%");
                c9.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                //c5.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");


                dr.Cells.Add(c3);
                dr.Cells.Add(c1);
                //dr.Cells.Add(c8);
                dr.Cells.Add(c9);
                // dr.Cells.Add(c4);
                dr.Cells.Add(c2);
                //dr.Cells.Add(c5);
                dr.Cells.Add(C6);
                dr.Cells.Add(c7);

                Style myStyle = new Style();
                myStyle.ForeColor = System.Drawing.Color.Black;
                myStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                myStyle.Font.Bold = false;


                c1.ApplyStyle(myStyle);
                //c8.ApplyStyle(myStyle);
                c3.ApplyStyle(myStyle);
                c9.ApplyStyle(myStyle);
                //c5.ApplyStyle(myStyle);
                c2.ApplyStyle(myStyle);

                t.Rows.Add(dr);
                phControls.Controls.Add(t);
                Count++;

            }
            phControls.Controls.Add(t);
            Session["Files"] = t;
            Session["Count"] = Count;

        }

        #endregion 

        protected void gvOrderSearch_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdTransaction_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ViewState["BillHeaderID"] = null;
            Session[VS_SEARCH] = null;
            ViewState["OrderNo"]=null;
            ViewState["custid"] = null;
            Session["Files"] = null;
            Session["Count"] = null;

            Response.Redirect("~/SAL/CreditCheckOut.aspx");
        }
 
    }
}