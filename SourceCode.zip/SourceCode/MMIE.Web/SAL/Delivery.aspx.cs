﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Data.ACC;
using MMIE.BusinessProcess.ACC;
using MMIE.Common;


namespace MMIE.SAL
{
    public partial class Delivery : BasePage
    {

        // List<Order> lstOrder = null;
        DataSet ds = null;
        DataSet dsOrderdetails = null;
        List<Customer> lstStore = null;
        const string VS_SEARCH = "VS_SEARCH";
        private Currency objCurrency = new Currency();
        private CurrencyBO objCurrencyBO = new CurrencyBO();
        private int Count = 1;
        private Table t;
        TextBox tb;
        public static bool isPriceshow = false;

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnsave.Enabled = LoginToken.IsAddOn; ;
                btnBonDeReport.Enabled = LoginToken.IsPrintOn;
                btnPrintFacture.Enabled = LoginToken.IsPrintOn;
                btnAddPartsDelDetails.Enabled = LoginToken.IsAddOn;
                //if (LoginToken.IsCheckOut)
                //{
                //    lblError.Text = "Sorry You Are Checked Out Please Contact to your System Administrator for Checked In";
                //    btnsave.Enabled = false;
                //    btnSearch.Enabled = false;
                //    lblError.Visible = true;
                //    return;
                //}

            }
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {


                MasterLookupBO mstlookup = new MasterLookupBO();



                if (!Page.IsPostBack)
                {
                    Session["IssuedProductList"] = null;
                    Session["IssuedProductList"] = null;
                    ViewState["VehicalSalesList"] = null;
                    btnPrintFacture.Enabled = false;
                    btnBonDeReport.Enabled = false;
                    // btnBonDePriceReport.Enabled = false;
                    t = new Table();
                    Session["Files"] = t;
                    Session["Count"] = Count;
                    BindCurrencyDropDown();
                    BindDropDownControl(ddlStore, mstlookup.GetLookupsList(LookupNames.StoreName));
                    ddlStore.Items.Insert(0, "Select Store/Depot");
                    //BindLedgerGroup();

                    //if (Request.QueryString["OrderNo"] != null && Request.QueryString["GroupType"] != null)
                    //{
                    //    if (Session[VS_SEARCH] != null)
                    //    {
                    //        Customer objCust = (Customer)Session[VS_SEARCH];
                    //        txtSearchOrder.Text = objCust.OrderNo;
                    //        txtSearchPhone.Text = objCust.CustomerPhone;
                    //        txtSearchCustomerName.Text = objCust.CustomerName;

                    //    }
                    //    string OrderNo = Request.QueryString["OrderNo"].ToString();

                    //    int GroupType = Convert.ToInt32(ViewState["GroupType"].ToString());
                    //    ViewState["OrderNo"] = OrderNo;
                    //    Customer objCustomer = new Customer();
                    //    objCustomer.OrderNo = OrderNo;
                    //    txtSearchOrder.Text = OrderNo;
                    //    objCustomer.GroupType = GroupType;
                    //    Order objOrder = new Order();
                    //    objOrder.OrderNumber = OrderNo;
                    //    objOrder.BillHeaderID = Convert.ToInt32(ViewState["BillID"].ToString());

                    //    dsOrderdetails = BindOrderDetail(objOrder);
                    //    if (Request.QueryString["cust"] != null)
                    //    {
                    //        ViewState["custid"] = Convert.ToString(Request.QueryString["cust"].ToString());
                    //        BindCustomerDocumentDetail(Convert.ToInt32(ViewState["custid"]));
                    //    }
                    //    //-----------------get customer id------------------

                    //    objOrder.GroupType = Convert.ToInt32(Request.QueryString["GroupType"]);

                    //    ds = SearchStore(objCustomer);
                    //    if (ds.Tables[0].Rows.Count > 0)
                    //    {
                    //        ViewState["custid"] = ds.Tables[0].Rows[0]["CustomerID"].ToString();
                    //        BindCustomerDocumentDetail(Convert.ToInt32(ViewState["custid"]));
                    //        ddlCurrency.SelectedValue = ds.Tables[0].Rows[0]["CurrencyID"].ToString();
                    //        txtGourdesConverter.Text = ds.Tables[0].Rows[0]["CurrencyRate"].ToString();
                    //        //New column currencyID is fetched and bind to the dropdown currency

                    //    }



                    //    if (dsOrderdetails.Tables[0].Rows.Count > 0)
                    //    {
                    //        btnPrintFacture.Enabled = true;
                    //        btnBonDeReport.Enabled = true;
                    //        if ((dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString() == "Cash" && (Convert.ToDecimal(dsOrderdetails.Tables[0].Rows[0]["DueGrourdesAmount"].ToString()) <= 0)) || (dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString() == "Credit"))
                    //        {
                    //            TabContainerproductRegistration.ActiveTabIndex = 1;

                    //            // btnBonDePriceReport.Enabled = true;
                    //            if (GroupType == 1)
                    //            {
                    //                gvOrderVehicleDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                    //                gvOrderVehicleDetail.DataBind();
                    //                //txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalUSDAmt"].ToString();
                    //                //txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGourdesAmt"].ToString();
                    //                //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                    //                //txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                    //                //txtUSDDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                    //                //txtGourdesDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();

                    //                ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString();
                    //                ddlGroupType.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["GroupType"].ToString();

                    //                Remarks.Text = dsOrderdetails.Tables[0].Rows[0]["RemarksDelivery"].ToString();
                    //                txtDeliveryStreet.Text = dsOrderdetails.Tables[0].Rows[0]["StreetName"].ToString();

                    //                lblInvoiceNo.Text = dsOrderdetails.Tables[0].Rows[0]["InvoiceNo"].ToString();
                    //                lblShipmentNo.Text = dsOrderdetails.Tables[0].Rows[0]["ShipmentNumber"].ToString();

                    //                hdnIsPriceVisible.Value = Convert.ToBoolean(dsOrderdetails.Tables[0].Rows[0]["IsPriceVisible"].ToString()).ToString();

                    //                Customer objcustOrdr = (Customer)Session[VS_SEARCH];

                    //                if (objcustOrdr != null)
                    //                {
                    //                    ds = SearchStore(objcustOrdr);
                    //                    gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                    //                    gvOrderSearch.DataBind();
                    //                    btnsave.Enabled = false;
                    //                    // ShowLabelControls(true);
                    //                    ShowLabelControls(false);
                    //                    //  trPreOrderDetails.Visible = true;
                    //                  //  tdScanHeader.Visible = true;

                    //                    DeliverData.Visible = true;
                    //                    tdSelectCurDDL.Visible = true;
                    //                    tdSelectCur.Visible = true;
                    //                  //  OrderDetails.Visible = true;
                    //                    dvVehical.Visible = true;
                    //                    dvParts.Visible = false;
                    //                    PagePermission();
                    //                    ddlCurrency.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["CurrencyID"] != null ? dsOrderdetails.Tables[0].Rows[0]["CurrencyID"].ToString() : "0";
                    //                    ddlStore.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["StoreID"] != null ? dsOrderdetails.Tables[0].Rows[0]["StoreID"].ToString() : "0";
                    //                    ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"] != null ? dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString() : "0";
                    //                    ddlPaymentMode.Visible = true;
                    //                }
                    //            }
                    //            else if (GroupType == 2)
                    //            {
                    //                dvVehical.Visible = false;
                    //                dvParts.Visible = true;
                    //                gvOrderPartDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                    //                gvOrderPartDetail.DataBind();
                    //             //   OrderDetails.Visible = true;
                    //                //txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalUSDAmt"].ToString();
                    //                //txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGourdesAmt"].ToString();
                    //                //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                    //                //txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                    //                //txtUSDDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                    //                //txtGourdesDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                    //                ddlStore.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["StoreID"] != null ? dsOrderdetails.Tables[0].Rows[0]["StoreID"].ToString() : "0";
                    //                ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString();
                    //                ddlGroupType.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["GroupType"].ToString();
                    //                lblInvoiceNo.Text = dsOrderdetails.Tables[0].Rows[0]["InvoiceNo"].ToString();
                    //                lblShipmentNo.Text = dsOrderdetails.Tables[0].Rows[0]["ShipmentNumber"].ToString();

                    //                hdnIsPriceVisible.Value = Convert.ToBoolean(dsOrderdetails.Tables[0].Rows[0]["IsPriceVisible"].ToString()).ToString();

                    //                Remarks.Text = dsOrderdetails.Tables[0].Rows[0]["RemarksDelivery"].ToString();
                    //                Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                    //                if (objcustOrdr != null)
                    //                {
                    //                    ds = SearchStore(objcustOrdr);
                    //                    gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                    //                    gvOrderSearch.DataBind();
                    //                    btnsave.Enabled = false;
                    //                    //ShowLabelControls(true);
                    //                    ShowLabelControls(false);
                    //                    //trPreOrderDetails.Visible = true;
                    //                    //   tdScanHeader.Visible = true;

                    //                    tdSelectCurDDL.Visible = true;
                    //                    tdSelectCur.Visible = true;
                    //                    PagePermission();
                    //                    //   OrderDetails.Visible = true;
                    //                    ddlPaymentMode.Visible = true;
                    //                    ddlCurrency.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["CurrencyID"] != null ? dsOrderdetails.Tables[0].Rows[0]["CurrencyID"].ToString() : "0";
                    //                    ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"] != null ? dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString() : "0";
                    //                }
                    //            }
                    //        }
                    //        else
                    //        {
                    //            lblError.Text = "Please Check This Order Has the Pending Payment..!";


                    //        }

                    //    }
                    //    else
                    //    {
                    //        t = (Table)Session["Files"];
                    //        Count = (int)Session["Count"];
                    //        phControls.Controls.Add(t);
                    //        Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                    //        ds = SearchStore(objcustOrdr);
                    //        gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                    //        gvOrderSearch.DataBind();
                    //        if (GroupType == 1)
                    //        {
                    //            gvOrderVehicleDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                    //            gvOrderVehicleDetail.DataBind();
                    //            gvOrderVehicleDetail.Visible = true;
                    //        }
                    //        else if (GroupType == 2)
                    //        {
                    //            gvOrderPartDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                    //            gvOrderPartDetail.DataBind();
                    //            gvOrderPartDetail.Visible = true;
                    //        }
                    //        //trPreOrderDetails.Visible = true;
                    //        //ShowError("No Records Found");


                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Loading Delivery Product Order Details : " + ex.Message;



            }

        }

        //private DataSet SearchOrder(Order objOrder)
        //{
        //    //Call service operation to get data from database source
        //    OrderBO odr = new OrderBO();
        //    lstOrder = odr.SearchOrder(objOrder);
        //    //    lstCustomer  = UserAdminServiceAgent.SearchCustomer(objCustomer);
        //    DataTable dt = ORHelper<Order>.GenericListToDataTable(lstOrder);
        //    ds = new DataSet();
        //    ds.Tables.Add(dt);
        //    return ds;
        //}
        protected void BindCurrencyDropDown()
        {
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlCurrency.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Binding Currency : " + ex.Message;


            }

        }
        protected void ddlCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //if (ddlCurrency.SelectedIndex > 0 && txtTotAmount.Text.Length > 0)
                //{
                //    int i = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());
                //    if (i > 0)
                //    {
                //        objCurrency = objCurrencyBO.GetCurrencyByID(i);
                //    }
                //    txtGourdesConverter.Text = objCurrency.Rate.ToString(".00");
                //   // decimal amount = Convert.ToDecimal(txtDeliveredTotalUSDAmount.Text);
                //   // txtDeliveredTotalGourdesAmount.Text = ((amount / objCurrency.Rate).ToString(".00"));
                //}
                //else
                //{
                //    txtGourdesConverter.Text = "";
                //    //txtDeliveredTotalGourdesAmount.Text = "";
                //}
                //////trCurrency.Style.Add("DISPLAY","block");

                ////if (ViewState["GroupType"].ToString() == "1")
                ////{
                ////    trVehicleDelivery.Style.Add("DISPLAY", "block");
                ////}
                //if (ViewState["GroupType"].ToString() == "2")
                //{
                //    trPartsDelivery.Style.Add("DISPLAY", "block");
                //}

                //trtotaldeleveredAmt.Style.Add("DISPLAY", "block");

            }
            catch (FormatException)
            {
                lblError.Text = "Enter a valid amount";

            }
            catch (Exception ex)
            {
                lblError.Text = "Error : " + ex.Message;

            }


        }
        //protected void ShowError(string a_sMsg)
        //{
        //    errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
        //    if (a_sMsg.Length > 0)
        //    {
        //        errorMessage.Visible = true;
        //    }
        //    else
        //    {
        //        errorMessage.Visible = false;
        //    }
        //}
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {

                Session[VS_SEARCH] = null;
                ClearData();

                dsOrderdetails = null;
                Customer objCustomer = new Customer();
                objCustomer.OrderNo = txtSearchOrder.Text.Trim();
                objCustomer.CustomerName = txtSearchCustomerName.Text.Trim();
                objCustomer.CustomerPhone = txtSearchPhone.Text.Trim();

                Session[VS_SEARCH] = objCustomer;
                ds = SearchStore(objCustomer);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                    gvOrderSearch.DataBind();
                    gvOrderSearch.Visible = true;
                    //   isPriceshow = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsPriceVisible"]);

                    // ShowLabelControls(true);
                }
                else
                {
                    //ShowError("No Records Found");
                    gvOrderPartDetail.Visible = false;
                    gvOrderVehicleDetail.Visible = false;

                    gvOrderSearch.Visible = true;
                    gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                    gvOrderSearch.DataBind();
                    ShowLabelControls(false);

                    btnsave.Enabled = false;

                    dvParts.Visible = false;
                    dvVehical.Visible = false;
                    btnsave.Enabled = false;
                }







            }
            catch (Exception ex)
            {
                lblError.Text = "Error While Searching Orders :" + ex.Message;

            }
        }

        private DataSet SearchStore(Customer objStore)
        {
            //Call service operation to get data from database source
            PartBO st = new PartBO();
            lstStore = st.SearchOrderDetails(objStore);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        private DataSet BindOrderDetail(Order objStore)
        {
            //Call service operation to get data from database source
            BillHeaderDetailsBO st = new BillHeaderDetailsBO();
            List<Order> lstOrder = new List<Order>();
            objStore.IsActive = true;
            lstOrder = st.GetSearchOrderDetails(objStore);
            DataTable dt = ORHelper<Order>.GenericListToDataTable(lstOrder);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        public string MakeCustomerIDLink(string OrderNo, int GroupType, int id, int billId)
        {
            string ret;
            string str;
            string pageName;
            pageName = "Delivery.aspx";
            str = pageName + "?OrderNo=" + OrderNo.ToString().Trim() + "&GroupType=" + GroupType + "&cust=" + id.ToString() + "&BillID=" + billId.ToString();
            ret = "<a href=\"" + str + "\">" + OrderNo + "</a>";

            return ret;
        }

        private void ShowLabelControls(bool flag)
        {
            //lblNetAmount0.Visible = flag;
            //txtTotAmount.Visible = flag;
            //lblGourdesAmount.Visible = flag;
            //txtGourdesAmount.Visible = flag;
            //lblUSDDueAmount.Visible = flag;
            //txtUSDDueAmount.Visible = flag;
            //lblGourdesDueAmount.Visible = flag;
            //txtGourdesDueAmount.Visible = flag;
            //lblUSDPaidAmount.Visible = flag;
            //txtUSDPaidAmount.Visible = flag;
            //lblGourdesPaidAmount.Visible = flag;
            //txtGourdesPaidAmount.Visible = flag;
            //lblpaymentMode.Visible = flag;
            ddlPaymentMode.Visible = flag;
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {

                PartBO st = new PartBO();
                Order objOrder = new Order();
                decimal amount = 0;
                if (Session["IssuedProductList"] == null)
                {
                    lblError.Text = "Error : Please Select Valid Products to Delivery and try again..!";

                }
                //if (!(CustomerLedgerID > 0))
                //{
                //    lblError.Text = "Please slect a valid customer Ledger..!";
                //    return;
                //}
                //List<Customer> listObj = new List<Customer>();
                //listObj = 
                Int64 ShipID = st.GETMAXBillHeaderID();
                lblError.Text = "";
                decimal TotalBillAmount = 0;
                decimal TotalBillAmountUSD = 0;
                objOrder.ShipmentNumber = "SH" + ShipID;
                objOrder.InvoiceNo = "IN" + ShipID;
                objOrder.SalesStatus = Convert.ToInt16(ddlStatus.SelectedValue);
                objOrder.OrderNumber = ViewState["OrderNo"].ToString();
                objOrder.CustomerID = Convert.ToInt32(ViewState["CustomerID"]);
                objOrder.BillHeaderID = Convert.ToInt32(ViewState["BillID"].ToString());
                objOrder.StoreID = Convert.ToInt32(ddlStore.SelectedValue.ToString());
                objOrder.LastModBy = LoginToken.LoginId;
                bool status = false;
                int GroupType = Convert.ToInt32(ViewState["GroupType"].ToString());
                //StringBuilder objBuilder = ViewState["VehicalSalesList"] == null ? new StringBuilder() : (StringBuilder)ViewState["VehicalSalesList"];
                //if (objBuilder == null)
                //{
                //    lblError.Text = "No Product Selected to deliver";
                //}

                if (GroupType == 1)
                {
                    List<Product> lstProduct = (List<Product>)Session["IssuedProductList"];
                    if (lstProduct == null || lstProduct.Count < 1)
                    {

                        lblError.Text = "Please Select valid product to delivery list...!";
                        return;
                    }




                    if (lstProduct != null && lstProduct.Count > 0)
                    {
                        foreach (Product pd in lstProduct)
                        {

                            TotalBillAmount += pd.IssuedQty * pd.UnitPriceGourdes + pd.SaleTaxGourdes;
                            TotalBillAmountUSD += pd.IssuedQty * pd.UnitPriceGourdes + pd.SaleTaxGourdes;

                        }
                    }

                    amount = TotalBillAmount;
                    //objCust.VehicalSalesDetailsXML = objBuilder.ToString();
                    if (ddlCurrency.SelectedValue.ToString() == "1")
                    {
                        if (ddlPaymentMode.SelectedValue.ToString() == "Credit")
                        {

                            objOrder.DueGrourdesAmount = TotalBillAmount;
                            objOrder.DueUSDAmount = 0;
                        }


                    }
                    else
                    {
                        if (ddlPaymentMode.SelectedValue.ToString() == "Credit")
                        {

                            objOrder.DueGrourdesAmount = 0;
                            objOrder.DueUSDAmount = TotalBillAmountUSD;
                        }

                    }

                    objOrder.GroupType = 1;
                    objOrder.PaymentMode = ddlPaymentMode.SelectedValue.ToString();
                    //objCust.TotalGourdesAmt = TotalBillAmount;
                    //objCust.TotalUSDAmt = TotalBillAmountUSD;
                    objOrder.XMLData = XMLConverter.DeliveryVehicleListToXML((List<Product>)Session["IssuedProductList"]).ToString();
                    objOrder.Amount = TotalBillAmount;
                    objOrder.RemarksDelivery = Remarks.Text;
                    status = st.SaveBulkShipNumber(objOrder);
                }
                else if (GroupType == 2)
                {
                    List<Product> lstProduct = (List<Product>)Session["IssuedProductList"];
                    if (lstProduct == null || lstProduct.Count < 1)
                    {

                        lblError.Text = "Please Select valid product to delivery list...!";
                        return;
                    }

                    if (lstProduct != null && lstProduct.Count > 0)
                    {
                        foreach (Product pd in lstProduct)
                        {

                            TotalBillAmount += pd.IssuedQty * pd.UnitPriceGourdes + pd.SaleTaxGourdes;
                            TotalBillAmountUSD += pd.IssuedQty * pd.UnitPriceGourdes + pd.SaleTaxGourdes;

                        }
                    }

                    amount = TotalBillAmount;
                    //objCust.VehicalSalesDetailsXML = objBuilder.ToString();
                    if (ddlCurrency.SelectedValue.ToString() == "1")
                    {
                        if (ddlPaymentMode.SelectedValue.ToString() == "Credit")
                        {

                            objOrder.DueGrourdesAmount = TotalBillAmount;
                            objOrder.DueUSDAmount = 0;
                        }


                    }
                    else
                    {
                        if (ddlPaymentMode.SelectedValue.ToString() == "Credit")
                        {

                            objOrder.DueGrourdesAmount = 0;
                            objOrder.DueUSDAmount = TotalBillAmountUSD;
                        }

                    }

                    objOrder.XMLData = XMLConverter.DeliveryVehicleListToXML((List<Product>)Session["IssuedProductList"]).ToString();
                    objOrder.PaymentMode = ddlPaymentMode.SelectedValue.ToString();
                    objOrder.GroupType = 2;
                    objOrder.RemarksDelivery = Remarks.Text;
                    //objCust.VehicalSalesDetailsXML = objBuilder.ToString();
                    objOrder.Amount = TotalBillAmount;
                    status = st.SaveBulkShipNumber(objOrder);


                }


                if (status == true)
                {

                    lblError.Text = ExceptionMessage.GetMessage("STR7000001");
                    lblError.Visible = true;
                    txtInvoiceNo.Text = objOrder.InvoiceNo;
                    txtDeliveryShipMentNo.Text = objOrder.ShipmentNumber;
                    string OdrNo = ViewState["OrderNo"].ToString();
                    int GrpType = Convert.ToInt32(ViewState["GroupType"].ToString());
                    //Order objOrder = new Order();
                    //objOrder.OrderNumber = OdrNo;
                    //objOrder.GroupType = GrpType;
                    //SaveLedgerEntry(OdrNo, amount);

                    //CustomerLedgerID = 0;
                    ClearData();
                    BindOrderDetails(OdrNo, GrpType);

                    //   dsOrderdetails = BindOrderDetail(objOrder);

                    //if (dsOrderdetails.Tables[0].Rows.Count > 0)
                    //{
                    //    if (GrpType == 1)
                    //    {
                    //        gvOrderVehicleDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                    //        gvOrderVehicleDetail.DataBind();
                    //        gvOrderVehicleDetail.Visible = true;
                    //    }
                    //    else if (GrpType == 2)
                    //    {
                    //        gvOrderPartDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                    //        gvOrderPartDetail.DataBind();
                    //        gvOrderPartDetail.Visible = true;
                    //    }
                    //}
                    Session["IssuedProductList"] = null;
                    Session["IssuedProductList"] = null;
                    //gvProductDetail.DataSource = Session["IssuedProductList"];
                    //gvProductDetail.DataBind();
                    //gvProductDetail.Visible = true;
                    grdpartsDeleverDetails.DataSource = null;

                    grdpartsDeleverDetails.DataBind();
                    grdpartsDeleverDetails.Visible = true;
                    gvOrderPartDetail.DataSource = null;
                    gvOrderPartDetail.DataBind();
                    gvOrderVehicleDetail.DataSource = null;
                    gvOrderVehicleDetail.DataBind();
                    //txtDeliveredTotalUSDAmount.Text = "";
                    //txtDeliveredTotalGourdesAmount.Text = "";
                    btnsave.Enabled = false;
                    btnPrintFacture.Enabled = true;
                    btnBonDeReport.Enabled = true;
                    ViewState["VehicalSalesList"] = null;
                    //OrderDetails.Visible = false;
                    grdVehicalDeliveryDetails.DataSource = null;
                    grdVehicalDeliveryDetails.DataBind();
                    //btnBonDePriceReport.Enabled = true;
                }
            }


            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Updating Product Delivery Details : " + ex.Message;


            }
        }

        protected void gvOrderVehicleDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{

            //    for (int count = 0; count < e.Row.Cells.Count; count++)
            //        e.Row.Cells[count].ToolTip = e.Row.Cells[count].Text;
            //     HyperLink hy = (e.Row.Cells[0].Controls[0]) as HyperLink;
            //    if (hy != null)
            //    {
            //        hy.NavigateUrl = "javascript:" + hy.NavigateUrl;
            //        hy.ToolTip = hy.Text;
            //    }
            //}
        }

        protected void gvOrderPartDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                for (int count = 0; count < e.Row.Cells.Count; count++)
                    e.Row.Cells[count].ToolTip = e.Row.Cells[count].Text;
                HyperLink hy = (e.Row.Cells[0].Controls[0]) as HyperLink;
                if (hy != null)
                {
                    hy.NavigateUrl = "javascript:" + hy.NavigateUrl;
                    hy.ToolTip = hy.Text;
                }
            }
        }



        protected void gvProductDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            // get the values for delete operation

            GridView gvTemp = (GridView)sender;
            int index = e.RowIndex;
            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];

            if (listProduct != null && index >= 0)
            {
                // get IssuedQty
                int IssuedQty = listProduct[index].IssuedQty;
                decimal TotalAmount = listProduct[index].TotalAmount;
                // get product Sale ID
                long TransID = listProduct[index].ProductSaleID;
                // remove row for the index
                listProduct.RemoveAt(index);
                Session["IssuedProductList"] = listProduct;
                //gvProductDetail.DataSource = listProduct;
                //gvProductDetail.DataBind();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertUser", "UpdateFooter(" + IssuedQty + ", " + TotalAmount + ");", true);
            }
        }





        protected void btnAddPartsDelDetails_Click(object sender, EventArgs e)
        {
            try
            {
                lblProductError.Text = "";
                IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
                List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
                Product objProduct = new Product();
                foreach (Product obP in listProduct)
                {
                    if (obP.ProductID == Convert.ToInt32(txtPartsProdID.Text.Trim() == "" ? "0" : txtPartsProdID.Text.Trim()))
                    {
                        lblProductError.Text = " Product Already Exist In delivery list";
                        return;

                    }
                }
                objProduct.UnitId = Convert.ToInt32(txtUnitID.Text.Trim() == "" ? "0" : txtUnitID.Text.Trim());
                objProduct.ProductID = Convert.ToInt32(txtPartsProdID.Text.Trim() == "" ? "0" : txtPartsProdID.Text.Trim());
                objProduct.Model = txtPartsModalNo.Text;
                objProduct.ProductName = txtPartsProdName.Text;
                objProduct.SaleOrderNumber = txtPartsOrderNo.Text;
                objProduct.ProductSaleID = Convert.ToInt32(txtPartsProdSaleID.Text.Trim() == "" ? "0" : txtPartsProdSaleID.Text.Trim());
                objProduct.EquivalentUnit = Convert.ToDecimal(txtPartsDelQty.Text.Trim() == "" ? "0" : txtPartsDelQty.Text.Trim()) * Convert.ToDecimal(txtEquivalentUnit.Text.Trim() == "" ? "0" : txtEquivalentUnit.Text.Trim());
                objProduct.IssuedQty = Convert.ToInt32(txtPartsDelQty.Text.Trim() == "" ? "0" : txtPartsDelQty.Text.Trim());
                objProduct.UnitPriceGourdes = Convert.ToDecimal(txtUnitprice.Text == "" ? "0" : txtUnitprice.Text);
                if (Convert.ToDecimal(txtTaxAmount.Text == "" ? "0" : txtTaxAmount.Text) != 0)
                {
                    objProduct.SaleTaxGourdes = (objProduct.UnitPriceGourdes * Convert.ToDecimal(txtTaxAmount.Text == "" ? "0" : txtTaxAmount.Text) / 100) * Convert.ToDecimal(txtPartsDelQty.Text.Trim() == "" ? "0" : txtPartsDelQty.Text.Trim());
                }
                else
                {
                    objProduct.SaleTaxGourdes = 0;
                }
                // objProduct.UnitPriceGourdes = Convert.ToDecimal(txtPartsDelRate.Text.Trim() == "" ? "0" : txtPartsDelRate.Text.Trim());
                // objProduct.UnitPriceUSD = objProduct.UnitPriceGourdes / Convert.ToDecimal(txtGourdesConverter.Text);

                //objProduct.TotalAmount = Convert.ToDecimal(txtPartsDelAmt.Text.Trim() == "" ? "0" : txtPartsDelAmt.Text.Trim());
                objProduct.DeliveryGourdesAmount = ((objProduct.UnitPriceGourdes * objProduct.IssuedQty) + objProduct.SaleTaxGourdes);
                //objProduct.DeliveryAmount = objProduct.DeliveryGourdesAmount / Convert.ToDecimal(txtGourdesConverter.Text);//Convert.ToDecimal(txtDeliveredTotalGourdesAmount.Text.Trim() == "" ? "0" : txtDeliveredTotalGourdesAmount.Text.Trim());

                objProduct.ModifiedBy = LoginToken.LoginId;
                objProduct.AddedBy = LoginToken.LoginId;
                objProduct.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                objProduct.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                objProduct.UnitName = txtUnit.Text;

                listProduct.Add(objProduct);
                if (listProduct.Count > 0)
                {
                    grdpartsDeleverDetails.DataSource = listProduct;

                    Session["IssuedProductList"] = listProduct;
                }
                else
                {
                    grdpartsDeleverDetails.DataSource = null;
                    Session["IssuedProductList"] = null;
                }
                grdpartsDeleverDetails.DataBind();
                //trPartsDelivery.Style.Add("DISPLAY", "block");
                //trtotaldeleveredAmt.Style.Add("DISPLAY", "block");
                // trtotaldeleveredAmt.Style.Add("DISPLAY", "none");
                //trCurrency.Style.Add("DISPLAY", "block");
                // save the list to the

                // update total amount
                //txtDeliveredTotalUSDAmount.Text = (Convert.ToDecimal(txtPartsDelAmt.Text.Trim() == "" ? "0" : txtPartsDelAmt.Text.Trim()) + Convert.ToDecimal(txtDeliveredTotalUSDAmount.Text.Trim() == "" ? "0" : txtDeliveredTotalUSDAmount.Text.Trim())).ToString();
                //txtDeliveredTotalGourdesAmount.Text = Convert.ToDecimal(objProduct.DeliveryAmount * Convert.ToDecimal(txtGourdesConverter.Text) + Convert.ToDecimal(txtDeliveredTotalGourdesAmount.Text.Trim() == "" ? "0" : txtDeliveredTotalGourdesAmount.Text.Trim())).ToString(".00");

                btnsave.Enabled = true;
                //StringBuilder objBuilder = ViewState["VehicalSalesList"] == null ? new StringBuilder() : (StringBuilder)ViewState["VehicalSalesList"];


                //objBuilder.Append("<VehicalSalesList ProductSaleID = \"" + txtPartsProdSaleID.Text + "\" ");
                //objBuilder.Append(" IssuedQty = \"" + txtPartsDelQty.Text + "\" ");
                //objBuilder.Append(" EquivalentUnit = \"" + objProduct.EquivalentUnit.ToString() + "\" ");

                //objBuilder.Append(" LastModBy = \"" + LoginToken.LoginId + "\" ");
                //objBuilder.Append(" />");

                //ViewState["VehicalSalesList"] = objBuilder;

                txtPartsProdID.Text = "";
                txtPartsDelQty.Text = "";
                txtPartsOrderNo.Text = "";
                txtPartsModalNo.Text = "";
                txtPartsProdName.Text = "";
                txtPending.Text = "";
                txtPartsProdSaleID.Text = "";
                txtPartsOrderQty.Text = "";
                txtUnit.Text = "";
                txtUnitID.Text = "";
                txtEquivalentUnit.Text = "";
                txtTaxAmount.Text = "";
                txtAvailableQty.Text = "";
                btnAddPartsDelDetails.Enabled = false;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Adding Part Details : " + ex.Message;

            }
        }

        protected void grdpartsDeleverDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            // get the values for delete operation

            GridView gvTemp = (GridView)sender;
            int index = e.RowIndex;
            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];

            if (listProduct != null && index >= 0)
            {
                // get IssuedQty
                int IssuedQty = listProduct[index].IssuedQty;
                decimal TotalAmount = listProduct[index].TotalAmount;
                // get product Sale ID
                long TransID = listProduct[index].ProductSaleID;
                // remove row for the index
                listProduct.RemoveAt(index);
                Session["IssuedProductList"] = listProduct;
                grdpartsDeleverDetails.DataSource = listProduct;
                grdpartsDeleverDetails.DataBind();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertUser", "UpdateFooter(" + IssuedQty + ", " + TotalAmount + ");", true);
            }
        }

        #region Get Customer Document By Customer Id
        private void addfiletable()
        {
            t = new Table();
            t.Rows.Clear();
            t.BorderStyle = BorderStyle.Solid;

            TableHeaderRow th = new TableHeaderRow();
            th.BorderStyle = BorderStyle.Solid;
            TableCell c1 = new TableCell();
            c1.Text = "S.No.";
            c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

            TableCell c2 = new TableCell();
            c2.Text = "Uploaded Files";
            c2.Style.Add(HtmlTextWriterStyle.Width, "25%");

            //TableCell c3 = new TableCell();
            //c3.Text = "Document Type";
            //c3.Style.Add(HtmlTextWriterStyle.Width, "8%");
            //c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c4 = new TableCell();
            c4.Text = "Document ID";
            c4.Style.Add(HtmlTextWriterStyle.Width, "20%");
            c4.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c5 = new TableCell();
            c5.Text = "Remarks";
            c5.Style.Add(HtmlTextWriterStyle.Width, "10%");
            c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");




            th.Cells.Add(c1);
            th.Cells.Add(c2);

            th.Cells.Add(c4);
            th.Cells.Add(c5);




            Style myStyle = new Style();
            myStyle.ForeColor = System.Drawing.Color.Black;
            myStyle.BackColor = System.Drawing.Color.LightGray;
            myStyle.Font.Bold = true;
            myStyle.BorderStyle = BorderStyle.Solid;

            th.ApplyStyle(myStyle);
            // th.Font.Size =Unit.Percentage(12);
            th.BorderStyle = BorderStyle.Solid;
            th.BorderWidth = Unit.Pixel(1);

            t.Rows.Add(th);

        }
        private void BindCustomerDocumentDetail(int id)
        {
            //CheckBox chk;
            CustomerBO objCust = new CustomerBO();
            List<CustomerDocument> lst = new List<CustomerDocument>();
            lst = objCust.SearchCustomerDocument(id);
            t.Rows.Clear();
            addfiletable();

            Count = 1;
            foreach (CustomerDocument obj in lst)
            {

                HyperLink lnk = new HyperLink();
                lnk.EnableViewState = true;
                lnk.ID = "lnk" + Count.ToString();
                lnk.Text = obj.FriendlyName;
                lnk.NavigateUrl = "~/CustomerScanID/" + obj.CustomerID.ToString() + "/" + obj.CustomerScanID;
                lnk.Visible = true;
                lnk.Target = "_blank";

                tb = new TextBox();
                tb.EnableViewState = true;
                tb.ID = "txt" + Count.ToString();
                tb.MaxLength = 150;
                tb.Text = obj.CustomerDescription;
                tb.Enabled = false;


                //chk = new CheckBox();
                //chk.Checked = true;
                //chk.ID = "chk" + Count.ToString();
                //chk.Enabled = false;

                //Label Uid = new Label();
                //Uid.EnableViewState = true;
                //Uid.ID = "label2" + Count.ToString();
                //Uid.Text = Convert.ToString(obj.ScanID);
                //Uid.Visible = false;


                Label uName = new Label();
                uName.EnableViewState = true;
                uName.ID = "label3" + Count.ToString();
                uName.Text = obj.CustomerScanID;
                uName.Visible = false;



                TableRow dr = new TableRow();
                TableCell c1 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();
                //TableCell c5 = new TableCell();
                TableCell C6 = new TableCell();
                TableCell c7 = new TableCell();
                //TableCell c8 = new TableCell();
                TableCell c9 = new TableCell();

                //Label DocType = new Label();
                //DocType.EnableViewState = true;
                //DocType.ID = "lblDocType" + Count.ToString();
                //DocType.Text = obj.DocumentType;
                //DocType.Visible = true;


                Label DocID = new Label();
                DocID.EnableViewState = true;
                DocID.ID = "lblDocID" + Count.ToString();
                DocID.Text = obj.DocumentID;
                DocID.Visible = true;

                //c8.Controls.Add(DocType);
                c9.Controls.Add(DocID);


                c7.Controls.Add(uName);
                //c8.Controls.Add(filePath);

                c3.Text = "File" + Count.ToString(); ;
                c3.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //  c1.Style.Add(HtmlTextWriterStyle.Width, "30%");
                TableCell c2 = new TableCell();
                //   c2.Style.Add(HtmlTextWriterStyle.Width, "30%");
                //   c4.Style.Add(HtmlTextWriterStyle.Width, "4%");
                //   c5.Style.Add(HtmlTextWriterStyle.Width, "2%");
                c2.Controls.Add(tb);
                c1.Controls.Add(lnk);
                //c5.Controls.Add(chk);
                //C6.Controls.Add(Uid);

                c1.Style.Add(HtmlTextWriterStyle.Width, "25%");
                c2.Style.Add(HtmlTextWriterStyle.Width, "5%");

                //  c3.Style.Add(HtmlTextWriterStyle.Width, "3%");
                c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                //c8.Style.Add(HtmlTextWriterStyle.Width, "8%");
                //c8.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c9.Style.Add(HtmlTextWriterStyle.Width, "20%");
                c9.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                //c5.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");


                dr.Cells.Add(c3);
                dr.Cells.Add(c1);
                //dr.Cells.Add(c8);
                dr.Cells.Add(c9);
                // dr.Cells.Add(c4);
                dr.Cells.Add(c2);
                //dr.Cells.Add(c5);
                dr.Cells.Add(C6);
                dr.Cells.Add(c7);

                Style myStyle = new Style();
                myStyle.ForeColor = System.Drawing.Color.Black;
                myStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                myStyle.Font.Bold = false;


                c1.ApplyStyle(myStyle);
                //c8.ApplyStyle(myStyle);
                c3.ApplyStyle(myStyle);
                c9.ApplyStyle(myStyle);
                //c5.ApplyStyle(myStyle);
                c2.ApplyStyle(myStyle);

                t.Rows.Add(dr);
                phControls.Controls.Add(t);
                Count++;

            }
            phControls.Controls.Add(t);
            Session["Files"] = t;
            Session["Count"] = Count;

        }

        #endregion



        protected void BindVehicalList(Product objProduct)
        {
            try
            {
                lblProductSearchError.Text = "";
                grdVehicalList.DataSource = null;
                grdVehicalList.DataBind();

                VehicleBO objVehical = new VehicleBO();

                List<Product> lstProduct = new List<Product>();

                lstProduct = objVehical.SearchVehicalList(objProduct);
                grdVehicalList.DataSource = lstProduct;

                grdVehicalList.DataBind();
                if (lstProduct == null)
                {
                    lblProductSearchError.Text = "Vehicals not available in this store..!";
                    return;
                }

                if (lstProduct != null)
                {
                    if (lstProduct.Count < 1)
                        lblProductSearchError.Text = "Vehicals not available in this store..!";
                    return;
                }

            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Binding Vehical List : " + ex.Message;


            }

        }

        protected void btnSearchVehical_Click(object sender, EventArgs e)
        {
            Product objProduct = new Product();
            //  objProduct.Model = txtSearchModelNo.Text;
            objProduct.ContainerNo = txtContainerNo.Text;
            objProduct.SaleOrderNumber = ViewState["OrderNo"].ToString();
            BindVehicalList(objProduct);

        }

        protected void gvOrderVehicleDetail_RowCommand(object sender, GridViewCommandEventArgs e)
        {


            try
            {
                lblError.Text = "";
                lblGridError.Text = "";
                lblProductError.Text = "";
                lblProductSearchError.Text = "";
                int id = Convert.ToInt32(e.CommandArgument.ToString());
                ViewState["ProductFlag"] = id;

                if (e.CommandName == "ProductID")
                {

                    Product objProduct = new Product();




                    GridViewRow gr = gvOrderVehicleDetail.Rows[id];



                    LinkButton lblID = (LinkButton)gr.Cells[1].FindControl("lnkProdID");
                    LinkButton lblModelID = (LinkButton)gr.Cells[3].FindControl("lnkModelNo");


                    objProduct.ProductID = Convert.ToInt32(lblID.Text);
                    objProduct.PageSize = Convert.ToInt32(gr.Cells[7].Text.ToString());
                    objProduct.ProductSaleID = Convert.ToInt32(gr.Cells[10].Text.ToString());
                    lblGridError.Text = objProduct.PageSize == 0 ? "No More Pending Items..!" : "";
                    //objProduct.Model = lblModelID.Text;
                    objProduct.SaleOrderNumber = ViewState["OrderNo"].ToString();

                    //Added later to refine the search
                    objProduct.VINNO = txtVinNo.Text;
                    objProduct.EngineNo = txtEngineNo.Text;
                    objProduct.ContainerNo = txtContainerNo.Text;
                    //Added later to refine the search

                    BindVehicalList(objProduct);



                }

                if (e.CommandName == "ModelNo")
                {

                    Product objProduct = new Product();
                    //Added later to refine the search
                    objProduct.VINNO = txtVinNo.Text;
                    objProduct.EngineNo = txtEngineNo.Text;
                    objProduct.ContainerNo = txtContainerNo.Text;
                    //Added later to refine the search

                    lblError.Text = "";
                    GridViewRow gr = gvOrderVehicleDetail.Rows[id];
                    LinkButton lblID = (LinkButton)gr.Cells[1].FindControl("lnkProdID");

                    LinkButton lblModelID = (LinkButton)gr.Cells[3].FindControl("lnkModelNo");

                    //  objProduct.ProductID = Convert.ToInt32(lblID.Text);
                    objProduct.ProductSaleID = Convert.ToInt32(gr.Cells[10].Text.ToString());
                    objProduct.PageSize = Convert.ToInt32(gr.Cells[7].Text.ToString());
                    lblGridError.Text = objProduct.PageSize == 0 ? "No More Pending Items" : "";

                    objProduct.Model = lblModelID.Text;
                    objProduct.SaleOrderNumber = ViewState["OrderNo"].ToString();
                    BindVehicalList(objProduct);

                }

                tabContainerVehicalList.ActiveTabIndex = 0;

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);



                lblError.Text = "Error While Loading Vehical/Product List Record : " + ex.Message;
            }



        }



        protected void btnAddVhical_Click(object sender, EventArgs e)
        {
            try
            {

                lblError.Text = "";
                List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
                StringBuilder objBuilder = ViewState["VehicalSalesList"] == null ? new StringBuilder() : (StringBuilder)ViewState["VehicalSalesList"];



                Product objProduct = new Product();

                int CountVehical = 0;
                //int SaleID = 0;
                lblGridError.Text = "";
                int gridIndex = Convert.ToInt32(ViewState["ProductFlag"]);
                if (ViewState["ProductFlag"] == null)
                {

                    lblGridError.Text = "Please Select A Valid Product First";
                }
                else
                {


                    GridViewRow productOrder = gvOrderVehicleDetail.Rows[gridIndex];
                    foreach (GridViewRow grow in grdVehicalList.Rows)
                    {
                        objProduct = new Product();

                        CheckBox chkBox = (CheckBox)grow.Cells[1].FindControl("chkIsCheckin");

                        if (chkBox.Checked)
                        {



                            //LinkButton lblModelID = (LinkButton)grow.Cells[4].FindControl("lnkModelNo");

                            //Label lblRate = (Label)grow.Cells[9].FindControl("lblRate");
                            objProduct.ProductID = Convert.ToInt32(grow.Cells[2].Text.ToString());
                            objProduct.Model = grow.Cells[4].Text.ToString();

                            int PCount = 0;

                            foreach (Product objtest in listProduct)
                            {

                                if ((objProduct.ProductID == objtest.ProductID || objtest.Model == objProduct.Model) && objtest.ProductSaleID == Convert.ToInt64(productOrder.Cells[10].Text.ToString()))
                                {
                                    PCount++;

                                }

                                if (objtest.VehiclePOID == Convert.ToInt64(grow.Cells[8].Text.ToString()))
                                {
                                    lblGridError.Text = "Delivery List Containing this vehical...!";
                                    return;
                                }

                            }


                            if ((PCount == Convert.ToInt32(productOrder.Cells[7].Text)) || PCount > Convert.ToInt32(productOrder.Cells[7].Text))
                            {

                                lblGridError.Text = " You can not add more than " + Convert.ToInt32(productOrder.Cells[7].Text) + " vehical for the Product  ID " + objProduct.ProductID.ToString();
                                return;
                            }

                            objProduct.VehiclePOID = Convert.ToInt64(grow.Cells[8].Text.ToString());
                            objProduct.ProductName = grow.Cells[3].Text.ToString();

                            objProduct.Color = grow.Cells[5].Text.ToString();
                            // objProduct.UnitName = grow.Cells[6].Text.ToString();
                            objProduct.SaleOrderNumber = ViewState["OrderNo"].ToString();
                            objProduct.IssuedQty = 1;
                            objProduct.VINNO = grow.Cells[6].Text.ToString();
                            objProduct.EngineNo = grow.Cells[7].Text.ToString();
                            objProduct.UnitName = grow.Cells[9].Text.ToString();

                            //if (lblRate.Text != "")
                            //    objProduct.UnitPriceGourdes = Convert.ToDecimal(lblRate.Text);
                            //if (ddlCurrency.SelectedIndex == 1)
                            //    objProduct.DeliveryGourdesAmount = Convert.ToDecimal(lblRate.Text);
                            //else
                            //    objProduct.DeliveryAmount = Convert.ToDecimal(lblRate.Text);

                            objProduct.LastModBy = LoginToken.LoginId;
                            objProduct.AddedBy = LoginToken.LoginId;
                            objProduct.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                            objProduct.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                            objProduct.ProductSaleID = Convert.ToInt32(productOrder.Cells[10].Text);
                            objProduct.UnitPriceGourdes = Convert.ToDecimal(productOrder.Cells[13].Text);
                            objProduct.EquivalentUnit = 1;
                            if (Convert.ToDecimal(productOrder.Cells[14].Text) != 0)
                            {
                                objProduct.SaleTaxGourdes = (Convert.ToDecimal(productOrder.Cells[13].Text) * Convert.ToDecimal(productOrder.Cells[14].Text)) / 100;
                            }
                            else
                            {
                                objProduct.SaleTaxGourdes = 0;
                            }
                            objProduct.DeliveryGourdesAmount = (Convert.ToDecimal(productOrder.Cells[13].Text)) + objProduct.SaleTaxGourdes;



                            CountVehical++;

                            listProduct.Add(objProduct);
                        }




                        //if (listProduct.Count > 0) .DataSource = listProduct;
                        //else gvProductDetail.DataSource = null;
                        //gvProductDetail.DataBind();
                        //trVehicleDelivery.Style.Add("DISPLAY", "block");
                        //trtotaldeleveredAmt.Style.Add("DISPLAY", "block");
                        //trtotaldeleveredAmt.Style.Add("DISPLAY", "none");
                        //trDeliverheader.Style.Add("DISPLAY", "block");

                    }

                    //LinkButton lblID = (LinkButton)productOrder.Cells[1].FindControl("lnkProdID");

                    //objBuilder.Append("<VehicalSalesList ProductSaleID = \"" + productOrder.Cells[10].Text + "\" ");
                    //objBuilder.Append(" IssuedQty = \"" + CountVehical.ToString() + "\" ");
                    //objBuilder.Append(" LastModBy = \"" + LoginToken.LoginId + "\" ");
                    //objBuilder.Append(" ProductID = \"" + Convert.ToString(lblID.Text) + "\" ");

                    //objBuilder.Append(" />");

                    //ViewState["VehicalSalesList"] = objBuilder;


                    if (listProduct.Count > 0) grdVehicalDeliveryDetails.DataSource = listProduct;
                    else grdVehicalDeliveryDetails.DataSource = null;

                    if (listProduct.Count > 0)
                    {
                        Session["IssuedProductList"] = listProduct;
                        tabContainerVehicalList.ActiveTabIndex = 1;

                    }

                    grdVehicalDeliveryDetails.DataBind();

                    grdVehicalList.DataSource = null;
                    grdVehicalList.DataBind();
                    ViewState["ProductFlag"] = null;
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Searching Product : " + ex.Message;


            }

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {


            gvOrderVehicleDetail.DataSource = null;
            grdVehicalList.DataBind();
            gvOrderVehicleDetail.DataBind();
            grdVehicalList.DataBind();


        }

        private void ClearData()
        {
            txtVinNo.Text = "";
            txtEngineNo.Text = "";
            txtContainerNo.Text = "";
            //txtSearchModelNo.Text = "";
            gvOrderPartDetail.DataSource = null;
            gvOrderVehicleDetail.DataSource = null;
            gvOrderPartDetail.DataBind();
            gvOrderVehicleDetail.DataBind();
            grdVehicalList.DataSource = null;
            grdVehicalList.DataBind();

            grdInvoiceDetails.DataSource = null;
            grdInvoiceDetails.DataBind();

            grdVehicalDeliveryDetails.DataSource = null;
            grdVehicalDeliveryDetails.DataBind();

            Session["IssuedProductList"] = null;
            ViewState["VehicalSalesList"] = null;
            Session["IssuedProductList"] = null;
            ViewState["OrderNo"] = null;

            ViewState["BillID"] = null;
            ViewState["GroupType"] = null;
            ViewState["CustomerID"] = null;

            // btnBonDePriceReport.Enabled = false;
            dvParts.Visible = false;
            dvVehical.Visible = false;
            //CustomerLedgerID = 0;
            Session["Files"] = null;
            Session["Count"] = null;


        }

        protected void gvOrderSearch_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void gvOrderVehicleDetail_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void gvOrderPartDetail_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdVehicalList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdVehicalDeliveryDetails_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdpartsDeleverDetails_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void btnResetAll_Click(object sender, EventArgs e)
        {

            ClearData();

            Response.Redirect("~/SAL/Delivery.aspx");
        }



        //#region  Account Entry

        //private int CustomerLedgerID
        //{
        //    get
        //    {
        //        int x;
        //        Int32.TryParse(hdnCustomerLedgerID.Value, out x);
        //        return x;
        //    }

        //    set { hdnCustomerLedgerID.Value = Convert.ToString(value); }

        //}


        //private void BindLedgerAccountList()
        //{
        //    try
        //    {
        //        LedgerHeader objLedgerHeader = new LedgerHeader();
        //        LedgerHeaderBO objLedgerHeaderBO = new LedgerHeaderBO();
        //        List<LedgerHeader> lstLedgerHeader = new List<LedgerHeader>();
        //        objLedgerHeader.IsActive = true;
        //        objLedgerHeader.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
        //        objLedgerHeader.AccountGroupID = Convert.ToInt32(ddlLedgerGroup.SelectedValue.ToString());
        //        lstLedgerHeader = objLedgerHeaderBO.GetSearchLedgerHeader(objLedgerHeader);
        //        objLedgerHeader.IsActive = true;
        //        ddlLedgerName.DataSource = lstLedgerHeader;
        //        ddlLedgerName.DataValueField = "LedgerAccountID";
        //        ddlLedgerName.DataTextField = "AccountName";
        //        ddlLedgerName.DataBind();
        //        ddlLedgerName.Items.Insert(0, new ListItem("--Select--", "--Select--"));
        //    }
        //    catch (Exception Ex)
        //    {
        //        lblError.Text = "Error While Fetching Bank Account List : " + Ex.Message;
        //    }
        //}
        //private void BindLedgerGroup()
        //{
        //    AccountGroup objAccountGroup = new AccountGroup();
        //    AccountGroupBO objAccountGroupBO = new AccountGroupBO();
        //    List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
        //    objAccountGroup.CompanyID = LoginToken.CompanyID;
        //    //objAccountGroup.GroupName = ddlPaymentMode.SelectedValue.ToString();

        //    objAccountGroup.IsActive = true;
        //    lstAccountGroup = objAccountGroupBO.GetSearchAccountGroup(objAccountGroup);
        //    ddlLedgerGroup.DataSource = lstAccountGroup;
        //    ddlLedgerGroup.DataValueField = "AccountGroupID";
        //    ddlLedgerGroup.DataTextField = "GroupName";
        //    ddlLedgerGroup.DataBind();
        //    ddlLedgerGroup.Items.Insert(0, new ListItem("--Select--", "--Select--"));


        //}

        //protected void ddlLedgerGroup_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    BindLedgerAccountList();

        //}


        //protected bool SaveLedgerEntry(string Order, decimal Amount)
        //{
        //    bool result = false;
        //     //ddlCurrency.SelectedValue == "1" ? Convert.ToDecimal(txtTotalDueAmount.Text) : (Convert.ToDecimal(txtTotalDueAmountUSD.Text) * Convert.ToDecimal(txtGourdesConverter.Text));

        //    JournalDetails objJournalDetails = new JournalDetails();
        //   JournalDetailsBO objJournalDetailsBO = new JournalDetailsBO();

        //    objJournalDetails.Details = "Product Deliver for " + Order + ":" + Remarks.Text;
        //    objJournalDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
        //    objJournalDetails.CompanyID = (Int16)LoginToken.CompanyID;
        //    objJournalDetails.ActionType = EnumActionType.Insert;
        //    objJournalDetails.EntryDate = System.DateTime.Now.ToShortDateString();
        //    objJournalDetails.AddedBy = LoginToken.LoginId;
        //    objJournalDetails.IsActive = true;
        //    objJournalDetails.IsLocked = false;


        //    List<JournalDetails> lstJournalDetails = new List<JournalDetails>();
        //    JournalDetails objJournalDetailsNew;

        //    //To prepare Debit entry collection 
        //    //Read values one by one from Grid


        //    #region To prepare debit entry details

        //    objJournalDetailsNew = new JournalDetails();
        //    objJournalDetailsNew.JournalDetailsID = 0;
        //    //Get LedgerAccountID for pay order to From dataKeyValues
        //    objJournalDetailsNew.LedgerAccountID = CustomerLedgerID;
        //    objJournalDetailsNew.TType = "DR";
        //    objJournalDetailsNew.LF = "";
        //    objJournalDetailsNew.DebitAmount = Amount;
        //    objJournalDetailsNew.CreditAmount = 0;
        //    //Adding the object to the JournalDetails collection
        //    lstJournalDetails.Add(objJournalDetailsNew);

        //    #endregion


        //    #region To prepare creadit entry details

        //    objJournalDetailsNew = new JournalDetails();
        //    objJournalDetailsNew.JournalDetailsID = 0;
        //    //Get LedgerAccountID for pay order to From dataKeyValues
        //    objJournalDetailsNew.LedgerAccountID = Convert.ToInt32(ddlLedgerName.SelectedValue.ToString());
        //    objJournalDetailsNew.TType = "CR"; 
        //    objJournalDetailsNew.LF = "";
        //    objJournalDetailsNew.DebitAmount = 0;

        //    objJournalDetailsNew.CreditAmount = Amount;
        //    //Adding the object to the JournalDetails collection
        //    lstJournalDetails.Add(objJournalDetailsNew);
        //    #endregion




        //    //Creating XML for Credit/Debit transactions
        //    objJournalDetails.XMLData = XMLConverter.JournalDetailsListToXML(lstJournalDetails).ToString();

        //    //Inserting transaction to JournalDetails table
        //    if (objJournalDetailsBO.SaveJournalEntry(objJournalDetails))
        //    {
        //        lblError.Text = "Ledger Transaction for sales added successfully.";
        //        result = true;

        //    }
        //    return result;

        //}

        //#endregion



        protected void gvOrderSearch_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "ShowDetails")
            {
                int Index = Convert.ToInt32(e.CommandArgument.ToString());

                LinkButton lnk = (LinkButton)gvOrderSearch.Rows[Index].FindControl("lnkOrderNo");
                Label lbl = (Label)gvOrderSearch.Rows[Index].FindControl("lblGroupType");

                BindOrderDetails(lnk.Text, Convert.ToInt32(lbl.Text));


                // BindVehicalList(Index);


            }


        }
        #region Order Binding

        protected void BindOrderDetails(string OrderNumber, int GroupType)
        {
            Order objOrder = new Order();
            BillHeaderDetailsBO st = new BillHeaderDetailsBO();

            List<Order> lstOrderDetails = new List<Order>();
            objOrder.OrderNumber = OrderNumber;
            objOrder.GroupType = GroupType;
            lstOrderDetails = st.GetSearchOrderDetails(objOrder);
            trPartsDelivery.Style.Add("DISPLAY", "block");
            lblError.Text = "";
            lblGridError.Text = "";
            lblProductSearchError.Text = "";
            if (lstOrderDetails != null && lstOrderDetails.Count > 0)
            {

                if ((lstOrderDetails[0].PaymentMode == "Cash" && (lstOrderDetails[0].DueGrourdesAmount <= 0)) || (lstOrderDetails[0].PaymentMode == "Credit"))
                {
                    //CustomerLedgerID = lstOrderDetails[0].LedgerAccountID;

                    ViewState["OrderNo"] = lstOrderDetails[0].OrderNumber;
                    ViewState["BillID"] = lstOrderDetails[0].BillHeaderID;
                    ViewState["GroupType"] = lstOrderDetails[0].GroupType;
                    ViewState["CustomerID"] = lstOrderDetails[0].CustomerID;
                    txtGourdesConverter.Text = lstOrderDetails[0].CurrencyRate.ToString("0.00");
                    ddlCurrency.SelectedValue = lstOrderDetails[0].CurrencyID.ToString();
                    ddlStore.SelectedValue = lstOrderDetails[0].StoreID.ToString();
                    ddlPaymentMode.SelectedValue = lstOrderDetails[0].PaymentMode;
                    ddlPaymentMode.Visible = true;
                    btnPrintFacture.Enabled = true;
                    btnBonDeReport.Enabled = true;


                    TabContainerproductRegistration.ActiveTabIndex = 1;

                    // btnBonDePriceReport.Enabled = true;
                    if (GroupType == 1)
                    {

                        dvParts.Visible = false;
                        gvOrderVehicleDetail.DataSource = lstOrderDetails;
                        gvOrderVehicleDetail.DataBind();

                        //txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalUSDAmt"].ToString();
                        //txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGourdesAmt"].ToString();
                        //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                        //txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                        //txtUSDDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                        //txtGourdesDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();

                        ddlPaymentMode.SelectedValue = lstOrderDetails[0].PaymentMode;
                        ddlGroupType.SelectedValue = lstOrderDetails[0].GroupType.ToString();

                        Remarks.Text = lstOrderDetails[0].RemarksDelivery;
                        txtDeliveryStreet.Text = lstOrderDetails[0].StreetName;

                        lblInvoiceNo.Text = lstOrderDetails[0].InvoiceNo;
                        lblShipmentNo.Text = lstOrderDetails[0].ShipmentNumber;
                        hdnIsPriceVisible.Value = lstOrderDetails[0].IsPriceVisible.ToString();
                        Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                        btnsave.Enabled = false;
                        // ShowLabelControls(true);
                        ShowLabelControls(false);
                        //  trPreOrderDetails.Visible = true;
                        //  tdScanHeader.Visible = true;
                        tdSelectCurDDL.Visible = true;
                        tdSelectCur.Visible = true;
                        //  OrderDetails.Visible = true;
                        dvVehical.Visible = true;
                        dvParts.Visible = false;
                        PagePermission();



                    }
                    else if (GroupType == 2)
                    {
                        dvVehical.Visible = false;
                        dvParts.Visible = true;

                        gvOrderPartDetail.DataSource = lstOrderDetails;
                        gvOrderPartDetail.DataBind();

                        //txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalUSDAmt"].ToString();
                        //txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGourdesAmt"].ToString();
                        //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                        //txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                        //txtUSDDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                        //txtGourdesDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();

                        ddlPaymentMode.SelectedValue = lstOrderDetails[0].PaymentMode;
                        ddlGroupType.SelectedValue = lstOrderDetails[0].GroupType.ToString();

                        Remarks.Text = lstOrderDetails[0].RemarksDelivery;
                        txtDeliveryStreet.Text = lstOrderDetails[0].StreetName;

                        lblInvoiceNo.Text = lstOrderDetails[0].InvoiceNo;
                        lblShipmentNo.Text = lstOrderDetails[0].ShipmentNumber;

                        hdnIsPriceVisible.Value = lstOrderDetails[0].IsPriceVisible.ToString();

                        Customer objcustOrdr = (Customer)Session[VS_SEARCH];


                        btnsave.Enabled = false;
                        // ShowLabelControls(true);
                        ShowLabelControls(false);
                        //  trPreOrderDetails.Visible = true;
                        //  tdScanHeader.Visible = true;


                        tdSelectCurDDL.Visible = true;
                        tdSelectCur.Visible = true;
                        //  OrderDetails.Visible = true;
                        dvVehical.Visible = false;
                        dvParts.Visible = true;
                        PagePermission();


                    }
                    int bilid = Convert.ToInt32(lstOrderDetails[0].BillHeaderID);
                    BindInvoiceDetails(bilid);

                }
                else
                {
                    lblError.Text = "Please Check This Order Has the Pending Payment..!";


                }

            }
            else
            {
                t = (Table)Session["Files"];
                Count = (int)Session["Count"];
                phControls.Controls.Add(t);

                lblError.Text = "No Records Found";


            }
        }

        protected void BindInvoiceDetails(int BillHeaderID)
        {
            BillInvoiceDetails objInvoice = new BillInvoiceDetails();
            List<BillInvoiceDetails> lstInvoice = new List<BillInvoiceDetails>();
            OrderBO objBillBO = new OrderBO();
            objInvoice.BillHeaderID = BillHeaderID;
            lstInvoice = objBillBO.SearchOrderInvoiceList(objInvoice);

            grdInvoiceDetails.DataSource = lstInvoice;
            grdInvoiceDetails.DataBind();



        }


        #endregion

        protected void ddlLedgerGroup_SelectedIndexChanged1(object sender, EventArgs e)
        {
            //BindLedgerAccountList();
        }

        protected void txtDeliveryStreet_TextChanged(object sender, EventArgs e)
        {

        }

        protected void grdInvoiceDetails_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }




    }
}