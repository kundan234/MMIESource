﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;


namespace MMIE.SAL
{
    public partial class BulkDelivery : BasePage
    {
      
        List<Order> lstOrder = null;
        DataSet ds = null;
        DataSet dsOrderdetails = null;
        List<Customer> lstStore = null;
        const string VS_SEARCH = "VS_SEARCH";
        private Currency objCurrency = new Currency();
        private CurrencyBO objCurrencyBO = new CurrencyBO();
        private int Count = 1;
        private Table t;
        TextBox tb;
        public static bool isPriceshow =false;

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnsave.Enabled = LoginToken.IsAddOn; ;
                btnBonDeReport.Enabled = LoginToken.IsPrintOn;
                btnPrintFacture.Enabled = LoginToken.IsPrintOn;
                btnAddPartsDelDetails.Enabled = LoginToken.IsAddOn;
                //if (LoginToken.IsCheckOut)
                //{
                //    lblError.Text = "Sorry You Are Checked Out Please Contact to your System Administrator for Checked In";
                //    btnsave.Enabled = false;
                //    btnSearch.Enabled = false;
                //    lblError.Visible = true;
                //    return;
                //}

            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {


            PagePermission();

        

            
            if (!Page.IsPostBack)
            {
                Session["IssuedProductList"] = null;
                Session["IssuedPartsProductList"] = null;
                ViewState["VehicalSalesList"] = null;
                btnPrintFacture.Enabled = false ;
                btnBonDeReport.Enabled = false;
               // btnBonDePriceReport.Enabled = false;
                t = new Table();
                Session["Files"] = t;
                Session["Count"] = Count;
                BindCurrencyDropDown();
               
                //Customer objSearchParam = new Customer();
                //objSearchParam.OrderNo = txtSearchOrder.Text.Trim();
                //objSearchParam.CustomerName = txtSearchCustomerName.Text.Trim();
                //objSearchParam.CustomerPhone = txtSearchPhone.Text.Trim();
                //ds = SearchStore(objSearchParam);
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                //    gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                //    gvOrderSearch.DataBind();
                //    gvOrderSearch.Visible = true;
                //    isPriceshow = Convert.ToBoolean( ds.Tables[0].Rows[0]["IsPriceVisible"]);
                  

                //}
                //else
                //{
                //    gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                //    gvOrderSearch.DataBind();
                //    gvOrderSearch.Visible = true;
                //}
                                    
                if (Request.QueryString["OrderNo"] != null && Request.QueryString["GroupType"] != null)
                {
                    if (Session[VS_SEARCH] != null)
                    {
                        Customer objCust = (Customer)Session[VS_SEARCH];
                        txtSearchOrder.Text = objCust.OrderNo;
                        txtSearchPhone.Text = objCust.CustomerPhone;
                        txtSearchCustomerName.Text = objCust.CustomerName;
                        txtEngineNoSearch.Text = objCust.EngineNo;
                        txtVinNoSearch.Text = objCust.VinNo;
                    }
                    string OrderNo = Request.QueryString["OrderNo"].ToString();
                    int GroupType = Convert.ToInt32(Request.QueryString["GroupType"].ToString());
                    ViewState["OrderNo"] = OrderNo;
                    Customer objCustomer = new Customer();
                    objCustomer.OrderNo = OrderNo;
                    txtSearchOrder.Text = OrderNo;  
                    objCustomer.GroupType = GroupType;
                    dsOrderdetails = BindOrderDetail(objCustomer);
                    if (Request.QueryString["cust"] != null)
                    {
                        ViewState["custid"] =Convert.ToString(Request.QueryString["cust"].ToString());
                        BindCustomerDocumentDetail(Convert.ToInt32(ViewState["custid"]));
                    }
                    //-----------------get customer id------------------
                    Order objOrder = new Order();
                    objOrder.OrderNumber = OrderNo;
                    objOrder.GroupType = Convert.ToInt32(Request.QueryString["GroupType"]);
                    ds = SearchOrder(objOrder);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        ViewState["custid"] = ds.Tables[0].Rows[0]["CustomerID"].ToString();
                        BindCustomerDocumentDetail(Convert.ToInt32(ViewState["custid"]));
                        ddlCurrency.SelectedValue = ds.Tables[0].Rows[0]["CurrencyID"].ToString();

                        //New column currencyID is fetched and bind to the dropdown currency
                          
                    }

            

                    if (dsOrderdetails.Tables[0].Rows.Count > 0)
                    {
                        btnPrintFacture.Enabled = true;
                        btnBonDeReport.Enabled = true;
                       // btnBonDePriceReport.Enabled = true;
                        if (GroupType == 1)
                        {
                            gvOrderVehicleDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                            gvOrderVehicleDetail.DataBind();
                            txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalUSDAmt"].ToString();
                            txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGourdesAmt"].ToString();
                            txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                            txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                            txtUSDDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                            txtGourdesDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                            ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString();
                            Remarks.Text = dsOrderdetails.Tables[0].Rows[0]["RemarksDelivery"].ToString();
                            txtDeliveryStreet.Text = dsOrderdetails.Tables[0].Rows[0]["StreetName"].ToString();
                            Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                            ds = SearchStore(objcustOrdr);
                            gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                            gvOrderSearch.DataBind();
                            btnsave.Enabled = false;
                           // ShowLabelControls(true);
                            ShowLabelControls(false);
                            trPreOrderDetails.Visible = true;
                            tdScanHeader.Visible = true;
                            tdRemarktext.Visible = true;
                            tdRemarktexcontrol.Visible = true;
                            td122.Visible = true;
                            td121.Visible = true;
                            DeliverData.Visible = true;
                            if (dsOrderdetails.Tables[0].Rows[0]["RemarksDelivery"].ToString() == "1")
                            {
                                ddlCurrency.SelectedIndex = 0;
                            }
                            else
                                ddlCurrency.SelectedIndex = 1;
                        }
                        else if (GroupType == 2)
                        {
                            gvOrderPartDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                            gvOrderPartDetail.DataBind();
                            txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalUSDAmt"].ToString();
                            txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGourdesAmt"].ToString();
                            txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                            txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                            txtUSDDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                            txtGourdesDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                            ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString();
                            Remarks.Text = dsOrderdetails.Tables[0].Rows[0]["RemarksDelivery"].ToString();
                            Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                            ds = SearchStore(objcustOrdr);
                            gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                            gvOrderSearch.DataBind();
                            btnsave.Enabled = false;
                            //ShowLabelControls(true);
                            ShowLabelControls(false);
                            trPreOrderDetails.Visible = true;
                            tdScanHeader.Visible = true;
                            tdRemarktext.Visible = true;
                            tdRemarktexcontrol.Visible = true;
                            td122.Visible = true;
                            td121.Visible = true;

                            if (dsOrderdetails.Tables[0].Rows[0]["RemarksDelivery"].ToString() == "1")
                            {
                                ddlCurrency.SelectedIndex = 0;
                            }
                            else
                                ddlCurrency.SelectedIndex = 1;
                            
                        }
                    }
                    else
                    {
                        t = (Table)Session["Files"];
                        Count = (int)Session["Count"];
                        phControls.Controls.Add(t);
                        Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                        ds = SearchStore(objcustOrdr);
                        gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                        gvOrderSearch.DataBind();
                        if (GroupType == 1)
                        {
                            gvOrderVehicleDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                            gvOrderVehicleDetail.DataBind();
                            gvOrderVehicleDetail.Visible = true;
                        }
                        else if (GroupType == 2)
                        {
                            gvOrderPartDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                            gvOrderPartDetail.DataBind();
                            gvOrderPartDetail.Visible = true;
                        }
                        trPreOrderDetails.Visible = true;
                        //ShowError("No Records Found");


                    }
                }
            }

        }

        private DataSet SearchOrder(Order objOrder)
        {
            //Call service operation to get data from database source
            OrderBO odr = new OrderBO();
            lstOrder = odr.SearchOrder(objOrder);
            //    lstCustomer  = UserAdminServiceAgent.SearchCustomer(objCustomer);
            DataTable dt = ORHelper<Order>.GenericListToDataTable(lstOrder);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        protected void BindCurrencyDropDown()
        {
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("----Select Currency----", "0"));
                ddlCurrency.SelectedIndex = 1;
                 objCurrency = objCurrencyBO.GetCurrencyByID(1);
                    
                    txtGourdesConverter.Text = objCurrency.Rate.ToString(".00");
            }
            catch (Exception ex)
            {

                lblError.Text = "Error : " + ex.Message;
            }

        }
        protected void ddlCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlCurrency.SelectedIndex > 0 && txtTotAmount.Text.Length > 0)
                {
                    int i = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());
                    if (i > 0)
                    {
                        objCurrency = objCurrencyBO.GetCurrencyByID(i);
                    }
                    txtGourdesConverter.Text = objCurrency.Rate.ToString(".00");
                   // decimal amount = Convert.ToDecimal(txtDeliveredTotalUSDAmount.Text);
                   // txtDeliveredTotalGourdesAmount.Text = ((amount / objCurrency.Rate).ToString(".00"));
                }
                else
                {
                    txtGourdesConverter.Text = "";
                    txtDeliveredTotalGourdesAmount.Text = "";
                }
                trCurrency.Style.Add("DISPLAY","block");
                trDeliverheader.Style.Add("DISPLAY", "block");
                //if (Request.QueryString["GroupType"].ToString() == "1")
                //{
                //    trVehicleDelivery.Style.Add("DISPLAY", "block");
                //}
                if (Request.QueryString["GroupType"].ToString() == "2")
                {
                    trPartsDelivery.Style.Add("DISPLAY", "block");
                }
               
                //trtotaldeleveredAmt.Style.Add("DISPLAY", "block");
                trtotaldeleveredAmt.Style.Add("DISPLAY", "none");
            }
            catch (FormatException)
            {
                lblError.Text = "Enter a valid amount";

            }
            catch (Exception ex)
            {
                lblError.Text = "Error : " + ex.Message;

            }


        }
        //protected void ShowError(string a_sMsg)
        //{
        //    errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
        //    if (a_sMsg.Length > 0)
        //    {
        //        errorMessage.Visible = true;
        //    }
        //    else
        //    {
        //        errorMessage.Visible = false;
        //    }
        //}
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Session[VS_SEARCH] = null;
            ClearData();

            dsOrderdetails = null;
            Customer objCustomer = new Customer();
            objCustomer.OrderNo = txtSearchOrder.Text.Trim();
            objCustomer.CustomerName = txtSearchCustomerName.Text.Trim();
            objCustomer.CustomerPhone = txtSearchPhone.Text.Trim();
            objCustomer.EngineNo = txtEngineNoSearch.Text.Trim();
            objCustomer.VinNo = txtVinNoSearch.Text;
            Session[VS_SEARCH] = objCustomer;
            ds = SearchStore(objCustomer);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                gvOrderSearch.DataBind();
                gvOrderSearch.Visible = true;
                isPriceshow = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsPriceVisible"]);
              
                // ShowLabelControls(true);
            }
            else
            {
                //ShowError("No Records Found");
                gvOrderPartDetail.Visible = false;
                gvOrderVehicleDetail.Visible = false;
                gvOrderSearch.Visible = true;
                gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                gvOrderSearch.DataBind();
                ShowLabelControls(false);
                trPreOrderDetails.Visible = false;
                //trVehicleDelivery.Visible = false;
                trPartsDelivery.Visible = false;
                btnsave.Enabled = false;
                tdScanHeader.Visible = false;
                tdRemarktext.Visible = false;
                tdRemarktexcontrol.Visible = false;
            }
        }

        private DataSet SearchStore(Customer objStore)
        {
            //Call service operation to get data from database source
            PartBO st = new PartBO();
            lstStore = st.SearchOrderDetails(objStore);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        private DataSet BindOrderDetail(Customer objStore)
        {
            //Call service operation to get data from database source
            PartBO st = new PartBO();
            lstStore = st.BindOrderDetail(objStore);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        public string MakeCustomerIDLink(string OrderNo, int GroupType,int id)
        {
            string ret;
            string str;
            string pageName;
            pageName = "BulkDelivery.aspx";
            str = pageName + "?OrderNo=" + OrderNo.ToString().Trim() + "&GroupType=" + GroupType +"&cust="+id.ToString();
            ret = "<a href=\"" + str + "\">" + OrderNo + "</a>";
           
            return ret;
        }

        private void ShowLabelControls(bool flag)
        {
            lblNetAmount0.Visible = flag;
            txtTotAmount.Visible = flag;
            lblGourdesAmount.Visible = flag;
            txtGourdesAmount.Visible = flag;
            lblUSDDueAmount.Visible = flag;
            txtUSDDueAmount.Visible = flag;
            lblGourdesDueAmount.Visible = flag;
            txtGourdesDueAmount.Visible = flag;
            lblUSDPaidAmount.Visible = flag;
            txtUSDPaidAmount.Visible = flag;
            lblGourdesPaidAmount.Visible = flag;
            txtGourdesPaidAmount.Visible = flag;
            lblpaymentMode.Visible = flag;
            ddlPaymentMode.Visible = flag;
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            PartBO st = new PartBO();
            Customer objCust = new Customer();

          
          
            Int64 ShipID    = st.GETMAXBillHeaderID();
                ShipID = ShipID + 1;
                objCust.ShipmentNumber = "SH" + ShipID;
                objCust.SalesStatus = Convert.ToInt16(ddlStatus.SelectedValue);
                objCust.OrderNo = Request.QueryString["OrderNo"].ToString();
                  bool status=false;
                int GroupType = Convert.ToInt32(Request.QueryString["GroupType"].ToString());
                if (GroupType == 1)
                {
                    decimal TotalBillAmount = 0;
                    decimal TotalBillAmountUSD = 0;
                    List<Product> lstProduct = (List<Product>)Session["IssuedProductList"];
                    
                    if(lstProduct!=null)
                    {
                        foreach (Product pd in lstProduct)
                        {
                            objCust.TotalGourdesAmt = pd.UnitPriceGourdes;
                            TotalBillAmount += objCust.TotalGourdesAmt;
                            objCust.TotalUSDAmt = pd.UnitPriceUSD;
                            TotalBillAmountUSD += objCust.TotalUSDAmt;

                        }
                    }

                    StringBuilder objBuilder = ViewState["VehicalSalesList"] == null ? new StringBuilder() : (StringBuilder)ViewState["VehicalSalesList"];
                    objCust.VehicalSalesDetailsXML = objBuilder.ToString();

                    objCust.TotalGourdesAmt = TotalBillAmount;
                    objCust.TotalUSDAmt = TotalBillAmountUSD;
                    objCust.XMLData = XMLConverter.DeliveryVehicleListToXML((List<Product>)Session["IssuedProductList"]).ToString();
                   // status = st.SaveBulkShipNumber(objCust);
                }
                else if (GroupType == 2)
                {
                    objCust.XMLData = XMLConverter.DeliveryVehicleListToXML((List<Product>)Session["IssuedPartsProductList"]).ToString();
                    
                    status  = st.SaveShipNumber(objCust);

                }

             
                if (status == true)
                {
                    DeliverData.Visible = false;
                    lblError.Text = ExceptionMessage.GetMessage("STR7000001");
                    lblError.Visible = true;
                    string OdrNo = Request.QueryString["OrderNo"].ToString();
                    int GrpType = Convert.ToInt32(Request.QueryString["GroupType"].ToString());
                    Customer objCustomer = new Customer();
                    objCustomer.OrderNo = OdrNo;
                    objCustomer.GroupType = GrpType;
                    dsOrderdetails = BindOrderDetail(objCustomer);
                    if (dsOrderdetails.Tables[0].Rows.Count > 0)
                    {
                        if (GrpType == 1)
                        {
                            gvOrderVehicleDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                            gvOrderVehicleDetail.DataBind();
                            gvOrderVehicleDetail.Visible = true;
                        }
                        else if (GrpType == 2)
                        {
                            gvOrderPartDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                            gvOrderPartDetail.DataBind();
                            gvOrderPartDetail.Visible = true;
                        }
                    }
                    Session["IssuedProductList"] = null;
                    Session["IssuedPartsProductList"] = null;
                    //gvProductDetail.DataSource = Session["IssuedPartsProductList"];
                    //gvProductDetail.DataBind();
                    //gvProductDetail.Visible = true;
                    grdpartsDeleverDetails.DataSource = Session["IssuedPartsProductList"];
                    grdpartsDeleverDetails.DataBind();
                    grdpartsDeleverDetails.Visible = true;
                    txtDeliveredTotalUSDAmount.Text = "";
                    txtDeliveredTotalGourdesAmount.Text = "";
                    btnPrintFacture.Enabled = true;
                    btnBonDeReport.Enabled = true;
                    ViewState["VehicalSalesList"] = null;

                    grdVehicalDeliveryDetails.DataSource = null;
                    grdVehicalDeliveryDetails.DataBind();
                    //btnBonDePriceReport.Enabled = true;
                }
            }
        

        protected void gvOrderVehicleDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                for (int count = 0; count < e.Row.Cells.Count; count++)
                    e.Row.Cells[count].ToolTip = e.Row.Cells[count].Text;
                 HyperLink hy = (e.Row.Cells[0].Controls[0]) as HyperLink;
                if (hy != null)
                {
                    hy.NavigateUrl = "javascript:" + hy.NavigateUrl;
                    hy.ToolTip = hy.Text;
                }
            }
        }

        protected void gvOrderPartDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                for (int count = 0; count < e.Row.Cells.Count; count++)
                    e.Row.Cells[count].ToolTip = e.Row.Cells[count].Text;
                HyperLink hy = (e.Row.Cells[0].Controls[0]) as HyperLink;
                if (hy != null)
                {
                    hy.NavigateUrl = "javascript:" + hy.NavigateUrl;
                    hy.ToolTip = hy.Text;
                }
            }
        }

    

        protected void gvProductDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            // get the values for delete operation

            GridView gvTemp = (GridView)sender;
            int index = e.RowIndex;
            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];

            if (listProduct != null && index >= 0)
            {
                // get IssuedQty
                int IssuedQty = listProduct[index].IssuedQty;
                decimal TotalAmount = listProduct[index].TotalAmount;
                // get product Sale ID
                long TransID = listProduct[index].ProductSaleID;
                // remove row for the index
                listProduct.RemoveAt(index);
                Session["IssuedProductList"] = listProduct;
                //gvProductDetail.DataSource = listProduct;
                //gvProductDetail.DataBind();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertUser", "UpdateFooter(" + IssuedQty + ", " + TotalAmount + ");", true);
            }
        }





        protected void btnAddPartsDelDetails_Click(object sender, EventArgs e)
        {
            IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
            List<Product> listProduct = Session["IssuedPartsProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedPartsProductList"];
            Product objProduct = new Product();
            objProduct.ProductID = Convert.ToInt32(txtPartsProdID.Text.Trim() == "" ? "0" : txtPartsProdID.Text.Trim());
            objProduct.Model = txtPartsModalNo.Text;
            objProduct.ProductName = txtPartsProdName.Text;
            objProduct.SaleOrderNumber = txtPartsOrderNo.Text;
            objProduct.ProductSaleID = Convert.ToInt32(txtPartsProdSaleID.Text.Trim() == "" ? "0" : txtPartsProdSaleID.Text.Trim());
            objProduct.IssuedQty = Convert.ToInt32(txtPartsDelQty.Text.Trim() == "" ? "0" : txtPartsDelQty.Text.Trim());

            objProduct.UnitPriceGourdes = Convert.ToDecimal(txtPartsDelRate.Text.Trim() == "" ? "0" : txtPartsDelRate.Text.Trim());
            objProduct.UnitPriceUSD = objProduct.UnitPriceGourdes / Convert.ToDecimal(txtGourdesConverter.Text);

            objProduct.TotalAmount = Convert.ToDecimal(txtPartsDelAmt.Text.Trim() == "" ? "0" : txtPartsDelAmt.Text.Trim());
            objProduct.DeliveryGourdesAmount = Convert.ToDecimal(txtPartsDelAmt.Text.Trim() == "" ? "0" : txtPartsDelAmt.Text.Trim());

            objProduct.DeliveryAmount = objProduct.DeliveryGourdesAmount / Convert.ToDecimal(txtGourdesConverter.Text);//Convert.ToDecimal(txtDeliveredTotalGourdesAmount.Text.Trim() == "" ? "0" : txtDeliveredTotalGourdesAmount.Text.Trim());
            
            
            
            objProduct.ModifiedBy = LoginToken.LoginId;
            objProduct.AddedBy = LoginToken.LoginId;
            objProduct.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
            objProduct.CompanyID = Convert.ToInt16(LoginToken.CompanyID);


            listProduct.Add(objProduct);
            if (listProduct.Count > 0) grdpartsDeleverDetails.DataSource = listProduct;
            else grdpartsDeleverDetails.DataSource = null;
            grdpartsDeleverDetails.DataBind();
            trPartsDelivery.Style.Add("DISPLAY", "block");
            //trtotaldeleveredAmt.Style.Add("DISPLAY", "block");
            trtotaldeleveredAmt.Style.Add("DISPLAY", "none");
            trDeliverheader.Style.Add("DISPLAY", "block");
            trCurrency.Style.Add("DISPLAY", "block");
            // save the list to the
            if (listProduct.Count > 0) Session["IssuedPartsProductList"] = listProduct;
            listProduct = null;
            // update total amount
            txtDeliveredTotalUSDAmount.Text = (Convert.ToDecimal(txtPartsDelAmt.Text.Trim() == "" ? "0" : txtPartsDelAmt.Text.Trim()) + Convert.ToDecimal(txtDeliveredTotalUSDAmount.Text.Trim() == "" ? "0" : txtDeliveredTotalUSDAmount.Text.Trim())).ToString();
            txtDeliveredTotalGourdesAmount.Text = Convert.ToDecimal(objProduct.DeliveryAmount * Convert.ToDecimal(txtGourdesConverter.Text) + Convert.ToDecimal(txtDeliveredTotalGourdesAmount.Text.Trim() == "" ? "0" : txtDeliveredTotalGourdesAmount.Text.Trim())).ToString(".00");
            // reset all textboxes
            //txtProductID.Text = "";
            //txtModeNumber.Text = "";
            //txtProductName.Text = "";
            //txtOrderedQty.Text = "";
            //txtTotalAmount.Text = "";
            //txtDeliveredQuantity.Text = "";
            //txtDeliveredRate.Text = "";
            //txtOrderNo.Text = "";
            //txtOrderedRate.Text = "";
            //txtVINNo.Text = "";
            //txtProdSaleID.Text = "";
            //txtEngineNo.Text = "";
            //btnAddMaterial.Enabled = false;
            btnsave.Enabled = true;
        }

        protected void grdpartsDeleverDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            // get the values for delete operation

            GridView gvTemp = (GridView)sender;
            int index = e.RowIndex;
            List<Product> listProduct = Session["IssuedPartsProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedPartsProductList"];

            if (listProduct != null && index >= 0)
            {
                // get IssuedQty
                int IssuedQty = listProduct[index].IssuedQty;
                decimal TotalAmount = listProduct[index].TotalAmount;
                // get product Sale ID
                long TransID = listProduct[index].ProductSaleID;
                // remove row for the index
                listProduct.RemoveAt(index);
                Session["IssuedPartsProductList"] = listProduct;
                grdpartsDeleverDetails.DataSource = listProduct;
                grdpartsDeleverDetails.DataBind();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertUser", "UpdateFooter(" + IssuedQty + ", " + TotalAmount + ");", true);
            }
        }

        #region Get Customer Document By Customer Id
        private void addfiletable()
        {
            t = new Table();
            t.Rows.Clear();
            t.BorderStyle = BorderStyle.Solid;

            TableHeaderRow th = new TableHeaderRow();
            th.BorderStyle = BorderStyle.Solid;
            TableCell c1 = new TableCell();
            c1.Text = "S.No.";
            c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

            TableCell c2 = new TableCell();
            c2.Text = "Uploaded Files";
            c2.Style.Add(HtmlTextWriterStyle.Width, "25%");

            //TableCell c3 = new TableCell();
            //c3.Text = "Document Type";
            //c3.Style.Add(HtmlTextWriterStyle.Width, "8%");
            //c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c4 = new TableCell();
            c4.Text = "Document ID";
            c4.Style.Add(HtmlTextWriterStyle.Width, "20%");
            c4.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c5 = new TableCell();
            c5.Text = "Remarks";
            c5.Style.Add(HtmlTextWriterStyle.Width, "10%");
            c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");




            th.Cells.Add(c1);
            th.Cells.Add(c2);

            th.Cells.Add(c4);
            th.Cells.Add(c5);




            Style myStyle = new Style();
            myStyle.ForeColor = System.Drawing.Color.Black;
            myStyle.BackColor = System.Drawing.Color.LightGray;
            myStyle.Font.Bold = true;
            myStyle.BorderStyle = BorderStyle.Solid;

            th.ApplyStyle(myStyle);
            // th.Font.Size =Unit.Percentage(12);
            th.BorderStyle = BorderStyle.Solid;
            th.BorderWidth = Unit.Pixel(1);

            t.Rows.Add(th);

        }
        private void BindCustomerDocumentDetail(int id)
        {
            //CheckBox chk;
            CustomerBO objCust = new CustomerBO();
            List<CustomerDocument> lst = new List<CustomerDocument>();
            lst = objCust.SearchCustomerDocument(id);
            t.Rows.Clear();
            addfiletable();

            Count = 1;
            foreach (CustomerDocument obj in lst)
            {

                HyperLink lnk = new HyperLink();
                lnk.EnableViewState = true;
                lnk.ID = "lnk" + Count.ToString();
                lnk.Text = obj.FriendlyName;
                lnk.NavigateUrl = "~/CustomerScanID/" + obj.CustomerID.ToString() + "/" + obj.CustomerScanID;
                lnk.Visible = true;
                lnk.Target = "_blank";

                tb = new TextBox();
                tb.EnableViewState = true;
                tb.ID = "txt" + Count.ToString();
                tb.MaxLength = 150;
                tb.Text = obj.CustomerDescription;
                tb.Enabled = false;


                //chk = new CheckBox();
                //chk.Checked = true;
                //chk.ID = "chk" + Count.ToString();
                //chk.Enabled = false;

                //Label Uid = new Label();
                //Uid.EnableViewState = true;
                //Uid.ID = "label2" + Count.ToString();
                //Uid.Text = Convert.ToString(obj.ScanID);
                //Uid.Visible = false;


                Label uName = new Label();
                uName.EnableViewState = true;
                uName.ID = "label3" + Count.ToString();
                uName.Text = obj.CustomerScanID;
                uName.Visible = false;



                TableRow dr = new TableRow();
                TableCell c1 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();
                //TableCell c5 = new TableCell();
                TableCell C6 = new TableCell();
                TableCell c7 = new TableCell();
                //TableCell c8 = new TableCell();
                TableCell c9 = new TableCell();

                //Label DocType = new Label();
                //DocType.EnableViewState = true;
                //DocType.ID = "lblDocType" + Count.ToString();
                //DocType.Text = obj.DocumentType;
                //DocType.Visible = true;


                Label DocID = new Label();
                DocID.EnableViewState = true;
                DocID.ID = "lblDocID" + Count.ToString();
                DocID.Text = obj.DocumentID;
                DocID.Visible = true;

                //c8.Controls.Add(DocType);
                c9.Controls.Add(DocID);


                c7.Controls.Add(uName);
                //c8.Controls.Add(filePath);

                c3.Text = "File" + Count.ToString(); ;
                c3.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //  c1.Style.Add(HtmlTextWriterStyle.Width, "30%");
                TableCell c2 = new TableCell();
                //   c2.Style.Add(HtmlTextWriterStyle.Width, "30%");
                //   c4.Style.Add(HtmlTextWriterStyle.Width, "4%");
                //   c5.Style.Add(HtmlTextWriterStyle.Width, "2%");
                c2.Controls.Add(tb);
                c1.Controls.Add(lnk);
                //c5.Controls.Add(chk);
                //C6.Controls.Add(Uid);

                c1.Style.Add(HtmlTextWriterStyle.Width, "25%");
                c2.Style.Add(HtmlTextWriterStyle.Width, "5%");

                //  c3.Style.Add(HtmlTextWriterStyle.Width, "3%");
                c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                //c8.Style.Add(HtmlTextWriterStyle.Width, "8%");
                //c8.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c9.Style.Add(HtmlTextWriterStyle.Width, "20%");
                c9.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                //c5.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");


                dr.Cells.Add(c3);
                dr.Cells.Add(c1);
                //dr.Cells.Add(c8);
                dr.Cells.Add(c9);
                // dr.Cells.Add(c4);
                dr.Cells.Add(c2);
                //dr.Cells.Add(c5);
                dr.Cells.Add(C6);
                dr.Cells.Add(c7);

                Style myStyle = new Style();
                myStyle.ForeColor = System.Drawing.Color.Black;
                myStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                myStyle.Font.Bold = false;


                c1.ApplyStyle(myStyle);
                //c8.ApplyStyle(myStyle);
                c3.ApplyStyle(myStyle);
                c9.ApplyStyle(myStyle);
                //c5.ApplyStyle(myStyle);
                c2.ApplyStyle(myStyle);

                t.Rows.Add(dr);
                phControls.Controls.Add(t);
                Count++;

            }
            phControls.Controls.Add(t);
            Session["Files"] = t;
            Session["Count"] = Count;

        }

        #endregion 



        protected void BindVehicalList( Product objProduct)
        {
            try
            {

                VehicleBO objVehical = new VehicleBO();

                List<Product> lstProduct = new List<Product>();

                lstProduct = objVehical.SearchVehicalList(objProduct);

                grdVehicalList.DataSource = lstProduct;

                grdVehicalList.DataBind();

            }

            catch(Exception ex)
            {

                lblError.Text = ex.Message;
            }

        }

        protected void btnSearchVehical_Click(object sender, EventArgs e)
        {
            Product objProduct = new Product();
            objProduct.Model = txtSearchModelNo.Text;
            objProduct.ContainerNo = txtContainerNo.Text;
            objProduct.SaleOrderNumber = Request.QueryString["OrderNo"].ToString();
            BindVehicalList(objProduct);

        }

        protected void gvOrderVehicleDetail_RowCommand(object sender, GridViewCommandEventArgs e)
        {


            try
            {
                lblError.Text = "";



                if (e.CommandName == "ProductID")
                {

                    Product objProduct = new Product();


                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    lblError.Text = "";
                    GridViewRow gr = gvOrderVehicleDetail.Rows[id];

                    

                    LinkButton lblID = (LinkButton)gr.Cells[1].FindControl("lnkProdID");
                    LinkButton lblModelID = (LinkButton)gr.Cells[4].FindControl("lnkModelNo");

                    objProduct.ProductID = Convert.ToInt32(lblID.Text);
                    objProduct.PageSize = Convert.ToInt32(gr.Cells[9].Text.ToString());
                    objProduct.ProductSaleID = Convert.ToInt32(gr.Cells[10].Text.ToString());
                    lblError.Text = objProduct.PageSize == 0 ? "No More Pending Items" : "";
                    objProduct.Model = lblModelID.Text;
                    objProduct.SaleOrderNumber = Request.QueryString["OrderNo"].ToString();

                    BindVehicalList(objProduct);

                }

                if (e.CommandName == "ModelNo")
                {

                    Product objProduct = new Product();


                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    lblError.Text = "";
                    GridViewRow gr = gvOrderVehicleDetail.Rows[id];
                    LinkButton lblID = (LinkButton)gr.Cells[1].FindControl("lnkProdID");
                    LinkButton lblModelID = (LinkButton)gr.Cells[4].FindControl("lnkModelNo");
                  //  objProduct.ProductID = Convert.ToInt32(lblID.Text);
                    objProduct.ProductSaleID = Convert.ToInt32(gr.Cells[10].Text.ToString());
                    objProduct.PageSize = Convert.ToInt32(gr.Cells[9].Text.ToString());
                   lblError.Text= objProduct.PageSize == 0 ? "No More Pending Items" : "";

                    objProduct.Model = lblModelID.Text;
                    objProduct.SaleOrderNumber = Request.QueryString["OrderNo"].ToString();
                    BindVehicalList(objProduct);

                }
               
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching Vehical/Product List Record : " + Ex.Message;
            }



        }



        protected void btnAddVhical_Click(object sender, EventArgs e)
        {

            lblError.Text = "";
            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
            StringBuilder objBuilder = ViewState["VehicalSalesList"] == null ? new StringBuilder() : (StringBuilder)ViewState["VehicalSalesList"];






            Product objProduct;
           
            int CountVehical = 0;
            int SaleID = 0;
            foreach (GridViewRow grow in grdVehicalList.Rows)
            {
                
                objProduct = new Product();
                CheckBox chkBox = (CheckBox)grow.Cells[4].FindControl("chkIsCheckin");
           
                if (chkBox.Checked)
                {



                    //LinkButton lblID = (LinkButton)grow.Cells[1].FindControl("lnkProdID");
                    //LinkButton lblModelID = (LinkButton)grow.Cells[4].FindControl("lnkModelNo");

                    Label lblRate = (Label)grow.Cells[9].FindControl("lblRate");


                    objProduct.ProductID = Convert.ToInt32(grow.Cells[1].Text.ToString());
                    
                    objProduct.Model = grow.Cells[3].Text.ToString();
                    objProduct.ProductName = grow.Cells[2].Text.ToString();
                    objProduct.Color = grow.Cells[4].Text.ToString();
                    objProduct.UnitName = grow.Cells[5].Text.ToString();
                    objProduct.SaleOrderNumber = Request.QueryString["OrderNo"].ToString();
          
                    objProduct.IssuedQty = 1;
                    objProduct.EngineNo = grow.Cells[7].Text.ToString();
                    objProduct.VINNO = grow.Cells[6].Text.ToString();
                    if (lblRate.Text != "")
                        objProduct.UnitPriceGourdes = Convert.ToDecimal(lblRate.Text);
                    if(ddlCurrency.SelectedIndex==1)
                        objProduct.DeliveryGourdesAmount = Convert.ToDecimal(lblRate.Text);   
                    else
                     objProduct.DeliveryAmount = Convert.ToDecimal(lblRate.Text);   
                    
                    objProduct.ModifiedBy = LoginToken.LoginId;
                    objProduct.AddedBy = LoginToken.LoginId;
                    objProduct.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    objProduct.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                    objProduct.ProductSaleID = Convert.ToInt32(grow.Cells[10].Text.ToString());
                    if (grow.Cells[10].Text != "")
                    
                    CountVehical++;
                    SaleID = Convert.ToInt32(grow.Cells[10].Text.ToString());
                    listProduct.Add(objProduct);
                }

             
              

                //if (listProduct.Count > 0) .DataSource = listProduct;
                //else gvProductDetail.DataSource = null;
                //gvProductDetail.DataBind();
                //trVehicleDelivery.Style.Add("DISPLAY", "block");
                //trtotaldeleveredAmt.Style.Add("DISPLAY", "block");
                //trtotaldeleveredAmt.Style.Add("DISPLAY", "none");
                //trDeliverheader.Style.Add("DISPLAY", "block");

            }
            objBuilder.Append("<VehicalSalesList ProductSaleID = \"" + SaleID.ToString() + "\" ");
            objBuilder.Append(" IssuedQty = \"" + CountVehical.ToString() + "\" ");
            objBuilder.Append(" />");

            ViewState["VehicalSalesList"] = objBuilder;


            if (listProduct.Count > 0) grdVehicalDeliveryDetails.DataSource = listProduct;
            else grdVehicalDeliveryDetails.DataSource = null;

            if (listProduct.Count > 0) Session["IssuedProductList"] = listProduct;

            grdVehicalDeliveryDetails.DataBind();

            grdVehicalList.DataSource = null;
            grdVehicalList.DataBind();
                   
          

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ClearData();


        }

        private void ClearData()
        {

            txtContainerNo.Text = "";
            txtSearchModelNo.Text = "";
            gvOrderPartDetail.DataSource = null;
            gvOrderVehicleDetail.DataSource = null;
            gvOrderPartDetail.DataSource = null;
            gvOrderVehicleDetail.DataBind();
            grdVehicalList.DataBind();
            grdVehicalList.DataBind();

            grdVehicalDeliveryDetails.DataSource = null;
            grdVehicalDeliveryDetails.DataBind();
        }
      
    }
}