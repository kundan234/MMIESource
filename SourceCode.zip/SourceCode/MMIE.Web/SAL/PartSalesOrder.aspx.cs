﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;

public partial class PartSalesOrder :BasePage
{

    protected void PagePermission()
    {
        if (LoginToken != null)
        {
            btnOtherCharge.Enabled = LoginToken.IsAddOn;
            btnAdd.Enabled = LoginToken.IsAddOn;
            //if (LoginToken.IsCheckOut)
            //{
            //    lblError.Text = "Sorry You Are Checked Out Please Contact to your System Administrator for Checked In";
            //    btnAdd.Enabled = false;
            //    btnSearch.Enabled = false;
            //    btnSubmit0.Enabled = false;
            //    //btnPrintProforma.Enabled = false;
            //    //btnPrintInvoice.Enabled = false;
            //    lblError.Visible = true;

            //    return;
            //}
            
        
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        PagePermission();
        if (!IsPostBack)
        {
            //TabContainerVechileSalesOrder_ActiveTabChanged(TabContainerVechileSalesOrder, null);
        }
    }
    protected void TabContainerVechileSalesOrder_ActiveTabChanged(object sender, EventArgs e)
    {

    }
}