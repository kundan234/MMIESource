﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Data.ACC;
using MMIE.BusinessProcess.ACC;
using MMIE.Common;


namespace MMIE.SAL
{
    public partial class PartSales : BasePage
    {
        DataSet ds = null;
        DataSet dsOrderdetails = null;
        List<Customer> lstStore = null;
        List<Order> lstOrder = null;
        const string VS_SEARCH = "VS_SEARCH";
        private int SearchCustomerID;
        private int StreetID;
        private int Count = 1;
        private Table t;
        TextBox tb;
        private Currency objCurrency = new Currency();
        private CurrencyBO objCurrencyBO = new CurrencyBO();
        // CheckBox chk;
        protected void Page_UnLoad(object sender, EventArgs e)
        {
            if (Session["ProductDetail"] == null) Session["ProductDetail"] = null;
        }

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                //btnOtherCharge.Enabled = LoginToken.IsAddOn;
                btnsave.Enabled = LoginToken.IsAddOn;
                btnPrint.Enabled = LoginToken.IsPrintOn;
                txtDate.Enabled = LoginToken.IsChangeDateOn;
                txtRate.Enabled = LoginToken.IsRateChangeOn;
                //if (LoginToken.IsCheckOut)
                //{
                //    lblError.Text = "Sorry You Are Checked Out Please Contact to your System Administrator for Checked In";
                //    btnsave.Enabled = false;
                //    btnSearch.Enabled = false;
                //    //btnPrint.Enabled = false;
                //    lblError.Visible = true;
                //    return;
                //}

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            


            txtDate.Attributes.Add("ReadOnly", "True");
            btnsave.Attributes.Add("onclick", "return validate()");
            PagePermission();
            try
            {

                MasterLookupBO mstlookup = new MasterLookupBO();
                if (!IsPostBack)
                {
                    Session["ProductDetail"] = null;
                    Session["IssuedProductList"] = null;
                    Session["Files"] = null;
                    Session["Count"] = null;
                    Session["dsMaterialDetail"] = null;
                    ViewState["CustomerID"] = null;

                    t = new Table();
                    Session["Files"] = t;
                    Session["Count"] = Count;
                    BindDropDownControl(ddlStore, mstlookup.GetLookupsList(LookupNames.StoreName));
                    ddlStore.Items.Insert(0, "Select Store/Depot");
                    BindCurrencyDropDown();
                    Session["IssuedProductList"] = null;
                    Session["dsPartMaterialDetail"] = null;

                  //  BindLedgerGroup();
                  //  string str = lblChargeID.Text;
                }

                else
                {
                    //for (var i = 0; i < ExpenseBoxCount; i++)
                    //    AddExpenseBox(i);
                    //for (var i = 0; i < DescBoxCount; i++)
                    //    AddDescriptionBox(i);
                    t = (Table)Session["Files"];
                    Count = (int)Session["Count"];
                    phControls.Controls.Add(t);
                }

                txtDate.Text = System.DateTime.Now.ToString("MM/dd/yyyy");
                txtTime.Text = System.DateTime.Now.ToString("hh:mm:ss");
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
            }
        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

    


        protected void BindCurrencyDropDown()
        {
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("----Select Currency----", "0"));
                ddlCurrency.SelectedIndex = 0;
                txtGourdesConverter.Text = "";
                txtTotGourAmount.Text = "";

                //if (ddlCurrency.SelectedIndex > 0 && txtTotGourAmount.Text.Length > 0)
                //{
                //    int i = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());
                //    if (i > 0)
                //    {
                //        objCurrency = objCurrencyBO.GetCurrencyByID(i);
                //    }
                //    txtGourdesConverter.Text = objCurrency.Rate.ToString(".00");
                //    decimal amount = Convert.ToDecimal(txtTotGourAmount.Text);
                //    // Strart Code changed by Budha Singh on 20-Jan-2012
                //    // Standard currency USD has changed to Gourdes  
                //    // txtTotGourAmount.Text = ((amount / objCurrency.Rate).ToString(".00"));
                //    txtTotAmount.Text = ((amount / objCurrency.Rate).ToString(".0"));
                //    // End Code changed by Budha Singh on 20-Jan-2012

                //}
                //else
                //{
                //    txtGourdesConverter.Text = "";
                //    txtTotGourAmount.Text = "";
                //}

            }
            catch (Exception ex)
            {

                lblError.Text = "Error : " + ex.Message;
            }

        }
        protected void ddlCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                lblError.Text = "";
                if (ddlCurrency.SelectedIndex > 0 )
                {
                    
                    int i = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());
                   
                        objCurrency = objCurrencyBO.GetCurrencyByID(i);
                        if (objCurrency != null)
                        {
                            ClearProductSales();

                            txtGourdesConverter.Text = objCurrency.Rate.ToString(".00");
                            //decimal rate = Convert.ToDecimal(txtRate.Text!=""?txtRate.Text:"0");
                            //decimal qty = Convert.ToDecimal(txtQuantity.Text !=""?txtQuantity.Text:"0");
                            //txtTotalAmount.Text = ((rate * qty) / objCurrency.Rate).ToString(".00");
                                                 
                            //decimal amount = Convert.ToDecimal(txtTotGourAmount.Text);
                            //txtTotAmount.Text = ((amount / objCurrency.Rate)).ToString(".00");
                            txtTotalAmount.Text = "";
                            txtQuantity.Text = "";
                            CalculateAmount();
                    
                            //SearchProduct();
                            
                            //gvProductSearch.DataSource = null;
                            //gvProductSearch.DataBind();
                            // End Code changed by Budha Singh on 20-Jan-2012
                        }
                }
                else
                {
                    txtGourdesConverter.Text = "";
                    txtTotAmount.Text = "";
                    txtTotGourAmount.Text = "";
                }
            }
            catch (FormatException)
            {
                lblError.Text = "Enter a valid amount";

            }
            catch (Exception ex)
            {
                lblError.Text = "Error : " + ex.Message;

            }


        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {

                    string strAmountValue = string.Empty;
                    string strDescValue = string.Empty;

                    string strExpID = string.Empty;
          //foreach (var control in phControls1.Controls)
                    //{
                    //    var textBox = control as TextBox;
                    //    if (textBox == null) continue;
                    //    strAmountValue += textBox.Text + ",";
                    //}
                    //foreach (var control in panel1.Controls)
                    //{
                    //    var textBox1 = control as TextBox;
                    //    if (textBox1 == null) continue;
                    //    strDescValue += textBox1.Text + ",";
                    //}

                    //foreach (var control in panelExpID.Controls)
                    //{
                    //    var textBox1 = control as TextBox;
                    //    if (textBox1 == null) continue;
                    //    strExpID  += textBox1.Text + ",";
                    //}

                   
                    if (txtCustomer.Text.Trim() == "")
                    {
                        lblError.Text = "Select Customer";
                    }

                    if (txtCustomer.Text.Trim() != "")
                    {
                        Product ProductSales = GetProductIssuesDetail();
                       // ProductSales.OtherChargeID = lblChargeID.Text;
                        ProductSales.Othercharges = strAmountValue; //txtAddGourdes.Text.Trim();
                        ProductSales.OtherDesc = strDescValue; //txtDesc.Text.Trim();
                        //if (ProductSales.DiscountAmount + ProductSales.PaidAmount == ProductSales.TotalAmount)
                        //{
                        ProductSales.CurrencyRate = Convert.ToDecimal(txtGourdesConverter.Text);
                        ProductSales.CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue);
                        ProductSales.TotalDeliveryChargesGrourdes = Convert.ToDecimal(txtTotalDeliveryChargeGourdes.Text.Trim() == "" ? "0" : txtTotalDeliveryChargeGourdes.Text.Trim());
                        ProductSales.TotalSalesTaxGrourdes = Convert.ToDecimal(txtTotalSalesTaxGourdes.Text.Trim() == "" ? "0" : txtTotalSalesTaxGourdes.Text.Trim());
                        ProductSales.TotalGrandTotalGourdes = Convert.ToDecimal(txtGrandTotalGourdes.Text.Trim() == "" ? "0" : txtGrandTotalGourdes.Text.Trim());
                        if (ddlPaymentMode.SelectedItem.Text == "Credit")
                        {
                            ProductSales.DueGrourdesAmount=0;
                            ProductSales.DueUSDAmount = 0;
                        }
                        else  {
                            ProductSales.DueGrourdesAmount = Convert.ToDecimal(txtGrandTotalGourdes.Text.Trim() == "" ? "0" : txtGrandTotalGourdes.Text.Trim());
                            ProductSales.DueUSDAmount = Convert.ToDecimal(txtGrandTotalUSD.Text.Trim() == "" ? "0" : txtGrandTotalUSD.Text.Trim());
                        }

                        ProductSales.TotalDeliveryChargesUSD = Convert.ToDecimal(txtTotalDeliveryChargeUSD.Text.Trim() == "" ? "0" : txtTotalDeliveryChargeUSD.Text.Trim());
                        ProductSales.TotalSalesTaxUSD = Convert.ToDecimal(txtTotalSalesTaxUSD.Text.Trim() == "" ? "0" : txtTotalSalesTaxUSD.Text.Trim());
                        ProductSales.TotalGrandTotalUSD = Convert.ToDecimal(txtGrandTotalUSD.Text.Trim() == "" ? "0" : txtGrandTotalUSD.Text.Trim());
                        ProductSales.BillDueDate = Convert.ToDateTime(txtDuedate.Text.Trim() == "" ? "0" : txtDuedate.Text.Trim());
                        ProductSales.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                        ProductSales.CompanyID = (Int16)LoginToken.CompanyID;
                        ProductBO objProduct = new ProductBO();

                        ProductSales.Remarks = txtRemark.Text;
                        
                        PartBO partBO = new PartBO();
                        //#region Get Remarks Details
                        //Remarks objRemark = new Remarks();

                        //RemarksBO objRemarksBO = new RemarksBO();
                        //List<Remarks> lstRemarks = new List<Remarks>();
                        //objRemark.RemarksType = "PREORDER";
                        //objRemark.CustomerType = ddlPaymentMode.SelectedItem.ToString();
                        //lstRemarks = objRemarksBO.GetSearchRemarksList(objRemark);
                        //if (lstRemarks.Count > 0)
                        //    objRemark = lstRemarks[0];
                        //ProductSales.Remarks = objRemark.RemarksDetails;
                        //lstRemarks = null;
                        //objRemark.RemarksType = "DELIVERY";
                        //objRemark.CustomerType = ddlPaymentMode.SelectedItem.ToString();
                        //objRemark.RemarksDetails = "";
                        //lstRemarks = objRemarksBO.GetSearchRemarksList(objRemark);
                        //if (lstRemarks.Count > 0)
                        //    objRemark = lstRemarks[0];

                        //ProductSales.RemarksDelivery = objRemark.RemarksDetails;
                        //lstRemarks = null;
                        //objRemark.RemarksType = "CHECKOUT";
                        //objRemark.CustomerType = ddlPaymentMode.SelectedItem.ToString();
                        //objRemark.RemarksDetails = "";
                        //lstRemarks = objRemarksBO.GetSearchRemarksList(objRemark);
                        //if (lstRemarks.Count > 0)
                        //    objRemark = lstRemarks[0];
                        //ProductSales.RemarksCheckout = objRemark.RemarksDetails;
                        //#endregion

                        if (ViewState["CustomerID"] == null)
                        {
                            lblError.Text = "Invalid Customer Selected";
                            return;
                        }

                        string result = partBO.UpdateSalesProductDetail(ProductSales);

                        if (result != "")
                        {
                            txtSalesOrderNumber.Text = result;
                           // SaveLedgerEntry(result);
                            ClearAll();
                        }
                        else
                        {
                            lblError.Text = ExceptionMessage.GetMessage("OP700000");
                        }
                        //}
                        //else
                        //{
                        //    lblError.Text = "Paid amount should be equal to (Total - Discount).";
                        //}
                    }
                }
                lblError.Visible = true;
            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "@message");
                LogManager.WriteErrorLogInDB(ex);
                lblError.Visible = true;
                lblError.Text = ExceptionMessage.GetMessage("OP700000");
            }
            btnPrint.Focus();
        }

       protected void ClearProductSales()
        {

            txtTotAmount.Text = "0";
            txtStreetName.Text = "";
            txtStreetCharges.Text = "0";
            txtTotGourAmount.Text = "0";
            txtGrandTotalGourdes.Text = "";
            txtGrandTotalUSD.Text = "";
            txtEquivalentUnit.Text = "";
            txtProductID.Text = "";
            txtModeNumber.Text = "";
            txtProductName.Text = "";
            txtTotalAmount.Text = "";
            txtQuantity.Text = "";
            txtRate.Text = "";
            txtAvailiable.Text = "";
            txtSCharge.Text = "";
            txtTax.Text = "";
            btnAddMaterial.Enabled = false;
            ddlUnit.Items.Clear();

        }


        protected void ClearAll()
        {

            Session["ProductDetail"] = null;
            Session["IssuedProductList"] = null;
            gvProductDetail.DataSource = null;
            gvProductDetail.DataBind();

            gvProductSearch.DataSource = null;
            gvProductSearch.DataBind();
            phControls.Controls.Clear();
            txtGourdesConverter.Text = "";
            txtMemoNote.Text = "";
            txtTotalSalesTaxGourdes.Text = "";
            txtTotalSalesTaxUSD.Text = "";
            lblCreditLimit.Text = "";
            lblCreditLimitUSD.Text = "";
            lblMaxCreditLimit.Text = "";
            lblMaxCreditLimitUSD.Text = "";
            hdncreditlimit.Value = "";
            hdnCreditLimitUSD.Value = "";
            hdnRate.Value = "";
            hdnSalesTypeID.Value = "";
           // CustomerLedgerID = 0;


            btnPrint.Enabled = true;
          //  lblChargeID.Text = "";
            lblError.Text = ExceptionMessage.GetMessage("OP7000001");
            txtCustomer.Text = "";
            txtAddress.Text = "";
            txtStreet.Text = "";
            txtPhone.Text = "";
           txtFax.Text = "";
            txtEmail.Text = "";
            txtDate.Text = System.DateTime.Now.ToString("MM/dd/yyyy");
            txtTime.Text = System.DateTime.Now.ToShortTimeString();
            txtRemark.Text = "";
            txtProductName.Text = "";
            txtSearchName.Text = "";
            ViewState["CustomerID"] = null;
            txtCellPhone.Text = "";
            txtCity.Text = "";
            ddlCurrency.SelectedIndex = 0;
            ddlCurrency.Enabled = true;
            
            btnsave.Enabled = false;
            //Clear Accounting
            //ddlLedgerGroup.SelectedIndex = 0;
            //ddlLedgerName.Items.Clear();
            txtMemoNote.Text = "";
            hdncreditlimit.Value = "0";
            hdncreditlimit.Value = "0";
            lblCreditLimit.Text = "0";
            lblCreditLimitUSD.Text = "0";
            lblMaxCreditLimit.Text = "0";
            lblMaxCreditLimitUSD.Text = "0";
            //Clear Accounting


            ClearProductSales();
           
        }
        private Product GetProductIssuesDetail()
        {
            Product objProductCommon = new Product();

            try
            {
                if (Session["IssuedProductList"] != null) //Issue Product List
                {
                    IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);

                    // Product List Info
                    if (txtCustomer.Text.Trim() != "")
                    {
                        objProductCommon.CustomerID = Convert.ToInt32(ViewState["CustomerID"]);
                    }
                    objProductCommon.StoreID = ddlStore.SelectedValue == "" ? 0 : int.Parse(ddlStore.SelectedValue);
                    objProductCommon.SalesStatus = Convert.ToInt16(ddlStatus.SelectedValue);
                    objProductCommon.SaleOrderNumber = txtSalesOrderNumber.Text.Trim() == "" ? "0" : txtSalesOrderNumber.Text.Trim();
                    objProductCommon.BillDate = DateTime.Now;
                    objProductCommon.TotalAmount = Convert.ToDecimal(txtTotAmount.Text.Trim() == "" ? "0" : txtTotAmount.Text.Trim());
                    //Code changed on 23rd Jan 2012 by Budha to removing Paid amount and /Due Amount  
                    //objProductCommon.PaidAmount = Convert.ToDecimal(txtPaidAmount.Text.Trim() == "" ? "0" : txtPaidAmount.Text.Trim());
                    objProductCommon.PaidAmount = 0; // Convert.ToDecimal(txtPaidAmount.Text.Trim() == "" ? "0" : txtPaidAmount.Text.Trim());
                    objProductCommon.CreditAmount = Convert.ToDecimal(txtTotAmount.Text.Trim() == "" ? "0" : txtTotAmount.Text.Trim()); //Convert.ToDecimal(txtCreditAmount.Text.Trim() == "" ? "0" : txtCreditAmount.Text.Trim());
                    objProductCommon.TotalGourdesAmount = Convert.ToDecimal(txtTotGourAmount.Text.Trim() == "" ? "0" : txtTotGourAmount.Text.Trim());
                    objProductCommon.PaidGourdesAmount = 0; // Convert.ToDecimal(txtGourPaidAmount.Text.Trim() == "" ? "0" : txtGourPaidAmount.Text.Trim());
                    objProductCommon.CreditGourdesAmount = Convert.ToDecimal(txtTotGourAmount.Text.Trim() == "" ? "0" : txtTotGourAmount.Text.Trim());   // Convert.ToDecimal(txtGourCreditAmount.Text.Trim() == "" ? "0" : txtGourCreditAmount.Text.Trim());

                    //End Code changed on 23rd Jan 2012 by Budha to hide Paid amount and Due Amount 
                    objProductCommon.DeliveryAmount = Convert.ToDecimal(txtStreetCharges.Text.Trim() == "" ? "0" : txtStreetCharges.Text.Trim());
                    objProductCommon.StreetID = Convert.ToInt32(ViewState["StreetID"]);
                    objProductCommon.Remark = txtRemark.Text;
                    objProductCommon.AddedBy = LoginToken.LoginId;
                    objProductCommon.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    objProductCommon.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                    objProductCommon.BillGroupCode = 2;
                    objProductCommon.ActionType = EnumActionType.Insert;

                    objProductCommon.PaymentMode = ddlPaymentMode.SelectedValue;
                    objProductCommon.xmlSalesTransactionDetail = XMLConverter.SalesVehicleListToXML((List<Product>)Session["IssuedProductList"]).ToString();
                    objProductCommon.DueGrourdesAmount = objProductCommon.TotalGourdesAmount - objProductCommon.PaidGourdesAmount;
                    objProductCommon.DueUSDAmount = objProductCommon.TotalAmount - objProductCommon.PaidAmount;

                }
                else
                {
                    lblError.Text = "Select";
                }
            }
            catch (Exception ex)
            {
                objProductCommon = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objProductCommon;
        }



        protected void btnAddMaterial_Click(object sender, EventArgs e)
        {
            IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
            lblProductError.Text = "";

            foreach (Product prd in listProduct)
            {
                if (prd.ProductID == (Convert.ToInt32(txtProductID.Text.Trim() == "" ? "0" : txtProductID.Text.Trim())) && (Convert.ToInt32(ddlUnit.SelectedValue.ToString()) == prd.UnitId))
                {

                    lblProductError.Text = "Product Aready Exist in the list..!";
                    return;

                }
            }
                
                


            Product objProduct = new Product();
            decimal currencyRate = Convert.ToDecimal(txtGourdesConverter.Text);
            objProduct.ProductID = Convert.ToInt32(txtProductID.Text.Trim() == "" ? "0" : txtProductID.Text.Trim());
            objProduct.Model = txtModeNumber.Text;
            objProduct.ProductName = txtProductName.Text;
            objProduct.TotalAmount = Convert.ToDecimal(txtTotalAmount.Text.Trim() == "" ? "0" : txtTotalAmount.Text.Trim());
            objProduct.IssuedQty = Convert.ToInt32(txtQuantity.Text.Trim() == "" ? "0" : txtQuantity.Text.Trim());
            //chnaged by budha singh on 23rd Jan 2012 for removing Paid amount, Due amount
            // objProduct.UnitPriceGourdes = objProduct.UnitPriceUSD * Convert.ToDecimal(txtGourdesConverter.Text.Trim());
            
           

           // objProduct.StockMaterialReceivedTransID = Convert.ToInt32(txtTransID.Text.Trim() == "" ? "0" : txtTransID.Text.Trim());
            objProduct.TaxRate = Convert.ToDecimal(txtTax.Text.Trim());
            if (ddlCurrency.SelectedValue == "1")
            {
                objProduct.UnitPriceGourdes = Convert.ToDecimal(txtRate.Text.Trim() == "" ? "0" : txtRate.Text.Trim());
                objProduct.SaleTaxGourdes = (Convert.ToDecimal(txtTotalAmount.Text.Trim()) * (Convert.ToDecimal(txtTax.Text.Trim()) / 100));
                if (Convert.ToDecimal(txtSCharge.Text) > 0) //1 is using as Gourdes value
                {
                objProduct.DeliveryChargeGourdes = (Convert.ToDecimal(txtSCharge.Text.Trim()) * Convert.ToDecimal(txtQuantity.Text.Trim()));
                }
            
            }

            else if (Convert.ToInt32 (ddlCurrency.SelectedValue.ToString())>1)
            {
                objProduct.UnitPriceGourdes = Convert.ToDecimal(txtRate.Text.Trim() == "" ? "0" : txtRate.Text.Trim());
                objProduct.SaleTaxGourdes = (Convert.ToDecimal(txtTotalAmount.Text.Trim()) * (Convert.ToDecimal(txtTax.Text.Trim()) / 100)) ;
                if (Convert.ToDecimal(txtSCharge.Text) > 0) // 2 is using as USD value
                {
                    objProduct.DeliveryChargeGourdes = Convert.ToDecimal(txtSCharge.Text.Trim()) * Convert.ToDecimal(txtQuantity.Text.Trim()) / currencyRate;
                }
            }
          
            objProduct.UnitName= ddlUnit.SelectedItem.ToString();
            objProduct.EngineNo = "";
            objProduct.VINNO = "";
            //Changed on 23rd jan 2012 by budha singh for conversion of Standard Gourdes conversion
            objProduct.UnitId = Convert.ToInt32(ddlUnit.SelectedValue.ToString());

            objProduct.CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());
            objProduct.CurrencyRate = currencyRate;

            listProduct.Add(objProduct);



            if (listProduct.Count > 0) { 
                gvProductDetail.DataSource = listProduct; gvProductDetail.DataBind();
                ddlCurrency.Enabled = false;
            }
            else
            {
                gvProductDetail.DataSource = null;
                gvProductDetail.DataBind();
                ddlCurrency.Enabled = true;

            }
            txtEquivalentUnit.Text = "0";
            ddlUnit.SelectedIndex = 0;

            // save the list to the
            Session["IssuedProductList"] = listProduct;


            this.CalculateAmount();
            
   
    
            txtProductID.Text = "";
            txtModeNumber.Text = "";
            txtProductName.Text = "";
            txtTotalAmount.Text = "";
            txtQuantity.Text = "";
            txtRate.Text = "";
            txtAvailiable.Text = "";
            txtSCharge.Text = "";
            txtTax.Text = "";
            btnAddMaterial.Enabled = false;
            ddlUnit.Items.Clear();
            // ddlUnit.DataBind();
            
        }


        private void CalculateAmount()
        {
            decimal TotalAmount = 0;
            decimal TotalDeliveryCharge = 0;
            decimal TotalSalesTax = 0;
            decimal GrandTotal = 0;
            List<Product> lstproduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
            if (lstproduct.Count > 0)
            {
                foreach (Product lst in lstproduct)
                {
                    TotalAmount = TotalAmount + Convert.ToDecimal(lst.TotalAmount == 0 ? 0 : lst.TotalAmount);
                    
                    TotalDeliveryCharge = TotalDeliveryCharge +lst.DeliveryChargeGourdes;
                    TotalSalesTax = TotalSalesTax + lst.SaleTaxGourdes ;
                    GrandTotal = (TotalAmount + TotalDeliveryCharge + TotalSalesTax);
                    //if (ddlCurrency.SelectedValue == "1")
                    //{
                    //    txtTotGourAmount.Text = TotalAmount.ToString();
                    //    txtTotalDeliveryChargeGourdes.Text = TotalDeliveryCharge.ToString();
                    //    txtTotalSalesTaxGourdes.Text = TotalSalesTax.ToString();
                    //    txtGrandTotalGourdes.Text = GrandTotal.ToString();
                    //}

                    //else if( Convert.ToInt32(ddlCurrency.SelectedValue.ToString())>1)
                    //{
                    //    TotalAmount = TotalAmount + Convert.ToDecimal(gr.Cells[5].Text.ToString() == "" ? "0" : gr.Cells[5].Text.ToString());
                    //    TotalDeliveryCharge = TotalDeliveryCharge + Convert.ToDecimal(gr.Cells[6].Text.ToString() == "" ? "0" : gr.Cells[6].Text.ToString());
                    //    TotalSalesTax = TotalSalesTax + Convert.ToDecimal(gr.Cells[8].Text.ToString() == "" ? "0" : gr.Cells[8].Text.ToString());
                    //    GrandTotal = (TotalAmount + TotalDeliveryCharge + TotalSalesTax);
                    //    txtTotAmount.Text = TotalAmount.ToString();
                    //    txtTotalDeliveryChargeUSD.Text = TotalDeliveryCharge.ToString();
                    //    txtTotalSalesTaxUSD.Text = TotalSalesTax.ToString();
                    //    txtGrandTotalUSD.Text = GrandTotal.ToString();

                    //}

                }
            }
            if (ddlCurrency.SelectedValue == "1")
            {
                txtTotGourAmount.Text = TotalAmount.ToString("0.00");
                txtTotalDeliveryChargeGourdes.Text = TotalDeliveryCharge.ToString("0.00");
                txtTotalSalesTaxGourdes.Text = TotalSalesTax.ToString("0.00");
                txtGrandTotalGourdes.Text = GrandTotal.ToString("0.00");
            }
            else
            {
                txtTotAmount.Text = TotalAmount.ToString("0.00");
                txtTotalDeliveryChargeUSD.Text = TotalDeliveryCharge.ToString("0.00");
                txtTotalSalesTaxUSD.Text = TotalSalesTax.ToString("0.00");
                txtGrandTotalUSD.Text = GrandTotal.ToString("0.00");
            }

        }

     
          

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SearchProduct();
        }
        protected void gvProductSearch_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    for (int count = 0; count < e.Row.Cells.Count; count++)
            //        e.Row.Cells[count].ToolTip = e.Row.Cells[count].Text;
            //    HyperLink hy = (e.Row.Cells[0].Controls[0]) as HyperLink;
            //    if (hy != null)
            //    {
            //        hy.NavigateUrl = "javascript:" + hy.NavigateUrl;
            //        hy.ToolTip = hy.Text;
            //    }
            //}
        }
        protected void gvProductDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {


            // add javascript, delete confirmation
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // add javascript, delete confirmation
                foreach (DataControlFieldCell cell in e.Row.Cells)
                {
                    // check all cells in one row
                    foreach (Control control in cell.Controls)
                    {
                        // Must use LinkButton here instead of ImageButton
                        // if you are having Links (not images) as the command button.
                        ImageButton button = control as ImageButton;
                        if (button != null && button.CommandName == "Delete")
                            // Add delete confirmation
                            button.OnClientClick = "if (!confirm('Are you sure " +
                                   "you want to delete this record?')) return;";
                    }
                }
            }
        }



        protected void gvProductDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            // get the values for delete operation

            GridView gvTemp = (GridView)sender;
            int index = e.RowIndex;
            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];

            if (listProduct != null && index >= 0)
            {
                // get IssuedQty
                int IssuedQty = listProduct[index].IssuedQty;
                decimal TotalAmount = listProduct[index].TotalAmount;

                // get MaterialTransID
                long TransID = listProduct[index].StockMaterialReceivedTransID;

                // restore the quantity in the datatable
                DataTable dtProductDetail = InitMaterialList();

                // Finds the row specified in txtUnit
                DataRow dr = dtProductDetail.Rows.Find(TransID);
                int intRowIndex = dtProductDetail.Rows.IndexOf(dr);
                // decimal BalcQty = Convert.ToDecimal(dtProductDetail.Rows[intRowIndex]["BalancedQty"].ToString() == "" ? "0" : dtProductDetail.Rows[intRowIndex]["BalancedQty"].ToString());

                // modify certain values into the DataTable
                // dtProductDetail.Rows[intRowIndex]["BalancedQty"] = BalcQty + Convert.ToDecimal(IssuedQty);
                dtProductDetail.AcceptChanges();

                // remove row for the index
                listProduct.RemoveAt(index);
                Session["IssuedProductList"] = listProduct;
                gvProductDetail.DataSource = listProduct;
                gvProductDetail.DataBind();

                //ClientScript.RegisterClientScriptBlock(GetType(), "Javascript","<script>alert('Record Added Successfully')</script>");
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertUser", "UpdateFooter(" + IssuedQty + ", " + TotalAmount + ");", true);
                this.CalculateAmount();
            }
            if ( index == 0)
            {
                if (gvProductDetail.Rows.Count <= 0) //Once You selected currency and start transaction then 
                //user should not allow to change currency, until the selected currency is not clear
                {
                    ddlCurrency.Enabled = true;
                }
                else
                {
                    ddlCurrency.Enabled = false;
                }

                txtStreetName.Enabled = true;
            }
        }
        public DataTable InitMaterialList()
        {
            DataTable dtProductDetail = (DataTable)Session["dsPartMaterialDetail"];
            //Set Primary key
            DataColumn[] dcPK = new DataColumn[1];
            dcPK[0] = dtProductDetail.Columns["ProductID"];
            dtProductDetail.PrimaryKey = dcPK;
            return dtProductDetail;
        }
        public void SearchProduct()
        {
            
                // set session for the material details
                Session["dsPartMaterialDetail"] = null;
                gvProductSearch.DataSource = null;
                gvProductSearch.DataBind();
                Session["dsPartMaterialDetail"] = PartBO.GetMaterialVehicalDetail(
                (ViewState["StreetID"] != null ? Convert.ToInt32(ViewState["StreetID"]) : 0), 
                Convert.ToInt32(ViewState["StreetChargeID"]), 
                Convert.ToInt32(ViewState["CustomerID"]), 
                txtSearchName.Text,
                txtSearchModel.Text,
                2,
                ddlStore.SelectedIndex>0?Convert.ToInt32(ddlStore.SelectedValue.ToString()):0
                );


                if (Session["dsPartMaterialDetail"] != null)
                {
                    DataTable dtProductDetail = (DataTable)Session["dsPartMaterialDetail"];

                    gvProductSearch.DataSource = dtProductDetail;
                    gvProductSearch.DataBind();
                    gvProductSearch.Visible = true;
                }
                else
                {
                    gvProductSearch.DataSource = null;
                    gvProductSearch.DataBind();
                }
        }

        protected void txtSearchModel_TextChanged(object sender, EventArgs e)
        {

            //if (txtSearchModel.MaxLength ==3)
            //{
            SearchProduct();
            //}
        }
        protected void txtSearchName_TextChanged(object sender, EventArgs e)
        {
            if (txtSearchName.Text.Trim().Length >= 1)
            {
                SearchProduct();
            }
        }

        protected void txtCustomer_TextChanged(object sender, EventArgs e)
        {
            try
            {
                lblError.Text = "";
                string GetCustomerId = txtCustomer.Text;
                string[] SplitGetCustomerId = GetCustomerId.Split('-');

                int i = 0;
              
                if (SplitGetCustomerId.Length > 1)
                {
                    foreach (string word in SplitGetCustomerId)
                    {
                        i = i + 1;

                        if (i == 1)
                        {
                            SearchCustomerID = Convert.ToInt32(word);
                            BindCustomerDetail(SearchCustomerID);
                            BindCustomerDocumentDetail(SearchCustomerID);

                        }
                    }
                }
                else
                {
                    txtCustomer.Text = "";
                    lblError.Text = "Please select a customer";
                }

            }

            catch
            {
                txtCustomer.Text = "";
                lblError.Text = "Please select a customer";
            }
        }
        private void BindCustomerDetail(int custid)
        {
            CustomerBO useradm = new CustomerBO();
            Customer objCustomer = new Customer();
            objCustomer.CustomerID = custid;
             
            Customer objRetCustomer = useradm.GetCustomerByID(objCustomer);
            if (objRetCustomer != null)
            {

                // null all the session
                Session["ProductDetail"] = null;
                Session["IssuedProductList"] = null;
                Session["Files"] = null;
                Session["Count"] = null;
                Session["dsMaterialDetail"] = null;
                ViewState["CustomerID"] = null;
                hdncreditlimit.Value = "";
                hdnCreditLimitUSD.Value = "";
                gvProductDetail.DataSource = null;
                gvProductDetail.DataBind();
                gvProductSearch.DataSource = null;
                gvProductSearch.DataBind();
                txtGrandTotalGourdes.Text = "";
                txtGrandTotalUSD.Text = "";
                txtTotalDeliveryChargeGourdes.Text = "";
                txtTotalDeliveryChargeUSD.Text = "";
                txtTotAmount.Text = "";
                txtTotGourAmount.Text = "";
                txtTotalSalesTaxGourdes.Text = "";
                txtTotalSalesTaxUSD.Text = "";
                lblCreditLimit.Text = "";
                lblCreditLimitUSD.Text = "";
                lblMaxCreditLimit.Text = "";
                lblMaxCreditLimitUSD.Text = "";
             
                //**************************************
                ViewState["CustomerID"] = objRetCustomer.CustomerID;
                //  this.CustomerLedgerID = objRetCustomer.LedgerAccountID;

                //**************************************
                txtCustomer.Text = objRetCustomer.CustomerName;
                txtAddress.Text = objRetCustomer.CustomerAddress;
                txtStreet.Text = objRetCustomer.CustomerStreet;
                txtCity.Text = objRetCustomer.CityName;
                txtCountry.Text = objRetCustomer.CountryName;
                txtFax.Text = objRetCustomer.CustomerFax;
                txtPhone.Text = objRetCustomer.CustomerPhone;
                txtCellPhone.Text = objRetCustomer.CustomerMobile;
                txtDuedate.Text = DateTime.Today.AddDays( objRetCustomer.MaximumDueDays).ToShortDateString();
                txtEmail.Text = objRetCustomer.CustomerEmail;
                txtWebsite.Text = objRetCustomer.CustomerWebsite;              
                hdnSalesTypeID.Value = Convert.ToString(objRetCustomer.SalesTypeID);
                ViewState["StreetChargeID"] = objRetCustomer.StreetChargeID;
                lblCreditLimit.Text = objRetCustomer.OpeningBalance.ToString();
                lblMaxCreditLimit.Text = objRetCustomer.MaxCreditLimit.ToString();
                lblCreditLimitUSD.Text = objRetCustomer.OpeningBalanceUSD.ToString();
                lblMaxCreditLimitUSD.Text = objRetCustomer.MaxCreditLimitUSD.ToString();
                hdncreditlimit.Value = objRetCustomer.MaxCreditLimit.ToString();               
                hdnCreditLimitUSD.Value = objRetCustomer.MaxCreditLimitUSD.ToString();
               
             
                //------------------refrence detail------
            }

        }
        //protected void btnPrintReceipt_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("Report/SaleReport.aspx?ReportType=PreOrder&id="+ txtSalesOrderNumber.Text.Trim()  +"  ");
        //}

        protected void btnPrintProforma_Click(object sender, EventArgs e)
        {
            //Response.Redirect("Report/SaleReport.aspx?ReportType=Proforma&id=Inv0001221");
            Response.Redirect("Report/SaleReport.aspx?ReportType=Proforma&OrderNumber=" + txtSalesOrderNumber.Text.Trim() + "");
        }

        protected void btnPrintFacture_Click(object sender, EventArgs e)
        {
            //  Response.Redirect("Report/SaleReport.aspx?ReportType=Facture&id=Inv0001221");
            Response.Redirect("Report/SaleReport.aspx?ReportType=Facture&OrderNumber=" + txtSalesOrderNumber.Text.Trim() + "");
        }

        //protected void btnOtherCharge_Click(object sender, EventArgs e)
        //{
        //    AddExpenseBox(ExpenseBoxCount);
        //    ExpenseBoxCount++;
        //    AddDescriptionBox(DescBoxCount);
        //    DescBoxCount++;

            
        //    //AddExpenseID(ExpBoxID,id);
        //    string str = lblChargeID.Text;
        //    //lblChargeID.Text = str + ddlOtherChargeID.SelectedValue.ToString() + ",";
        //    ExpBoxID++;
        //}
        //private int ExpenseBoxCount
        //{
        //    get
        //    {
        //        var count1 = ViewState["ExpenseBoxCount"];
        //        return (count1 == null) ? 0 : (int)count1;
        //    }
        //    set { ViewState["ExpenseBoxCount"] = value; }
        //}
        //private int DescBoxCount
        //{
        //    get
        //    {
        //        var count = ViewState["txtBoxCount"];
        //        return (count == null) ? 0 : (int)count;
        //    }
        //    set { ViewState["txtBoxCount"] = value; }
           
        //}

        //private int ExpBoxID
        //{
        //    get
        //    {
        //        var count = ViewState["txtExpBoxID"];
        //        return (count == null) ? 0 : (int)count;
        //    }
        //    set { ViewState["txtExpBoxID"] = value; }
        //}
        //private void AddExpenseBox(int index)
        //{
        //    var txtexp = new TextBox { ID = string.Concat("txtExp", index) };
        //    txtexp.Style.Add("display", "block");
        //    phControls1.Controls.Add(txtexp);
        //}
     
        //New  Function  to contain Expense ID
        //private void AddExpenseID(int index,int id)
        //{
        //    var txtexpID = new TextBox { ID = string.Concat("txtExpID", index) };
        //    txtexpID.Text = id.ToString();
            
        //    txtexpID.Style.Add("display", "block");
        //    txtexpID.Visible = false;
        //    panelExpID.Controls.Add(txtexpID);
        //}
        //private void AddDescriptionBox(int index)
        //{
        //    var txtDesc = new TextBox { ID = string.Concat("txtDesc", index) };
        //   // txtDesc.Text=ddlOtherChargeID.SelectedItem.ToString();
        //    txtDesc.Style.Add("display", "block");
        //    panel1.Controls.Add(txtDesc);
           
        //}

        protected void txtStreetName_TextChanged(object sender, EventArgs e)
        {


            BindStreetDetail(txtStreetName.Text);

        }
        private void BindStreetDetail(string StreetName)
        {
            StreetBO useradm = new StreetBO();
            Street objStreet = new Street();
            objStreet.StreetName = StreetName;
            Street objRetStreet = useradm.GetStreetByName(objStreet);
            if (objRetStreet != null)
            {
                //  Int64 price = Convert.ToInt64(objRetStreet.ChargePrice);
                txtStreetName.Text = objRetStreet.StreetName;
                // txtStreetCharges.Text = Convert.ToString(price);
                ViewState["StreetID"] = objRetStreet.StreetID;
                //------------------refrence detail------
            }

        }



        protected void rdProductName_CheckedChanged(object sender, EventArgs e)
        {
            if (rdReferenceName.Checked)
            {
                rdReferenceName.Checked = false;
            }

        }

        protected void rdReferenceName_CheckedChanged(object sender, EventArgs e)
        {
            if (rdProductName.Checked)
            {
                rdProductName.Checked = false;
            }

        }

        protected void rdIsStreet_CheckedChanged(object sender, EventArgs e)
        {
            if (rdIsNotStreet.Checked)
            {
                rdIsNotStreet.Checked = false;
            }
            if (rdIsStreet.Checked)
            {

                txtStreetName.Enabled = true;
            }
            else
            {

                txtStreetName.Enabled = false;
            }

        }

        protected void rdIsNotStreet_CheckedChanged(object sender, EventArgs e)
        {
            if (rdIsStreet.Checked)
            {
                rdIsStreet.Checked = false;
            }

            if (rdIsNotStreet.Checked)
            {

                txtStreetName.Enabled = false;
                txtStreetName.Text = "";
            }
            else
            {

                txtStreetName.Enabled = true;
            }

        }

        protected void btnSearchSelesOrder_Click(object sender, EventArgs e)
        {
            Session[VS_SEARCH] = null;
            dsOrderdetails = null;
            Order objOrder = new Order();
            objOrder.OrderNumber = txtSalesOrderNumber.Text.Trim();
            objOrder.GroupType = 2;
            Session[VS_SEARCH] = objOrder;
            ds = SearchOrder(objOrder);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtTotGourAmount.Text = "";
                txtTotalDeliveryChargeGourdes.Text = "";
                txtTotalSalesTaxGourdes.Text = "";
                txtGrandTotalGourdes.Text = "";
                txtTotAmount.Text = "";
                txtTotalDeliveryChargeUSD.Text = "";
                txtTotalSalesTaxUSD.Text = "";
                txtGrandTotalUSD.Text = "";
                btnsave.Enabled = false;
                btnSearch.Enabled = false;
                txtCustomer.Enabled = false;

                ViewState["custid"] = ds.Tables[0].Rows[0]["CustomerID"].ToString();
                //  int cid =Convert.ToInt32(ViewState["custid"]);  
                txtCustomer.Text = ds.Tables[0].Rows[0]["CustomerName"].ToString();
                txtAddress.Text = ds.Tables[0].Rows[0]["CustomerAddress"].ToString();
                txtStreet.Text = ds.Tables[0].Rows[0]["CustomerStreet"].ToString();
                // txtCity.Text = ds.Tables[0].Rows[0]["City"].ToString();
                //  txtCountry.Text = ds.Tables[0].Rows[0]["Country"].ToString();
                txtPhone.Text = ds.Tables[0].Rows[0]["CustomerPhone"].ToString();
                txtCellPhone.Text = ds.Tables[0].Rows[0]["CustomerMobile"].ToString();
                txtFax.Text = ds.Tables[0].Rows[0]["CustomerFax"].ToString();
                txtEmail.Text = ds.Tables[0].Rows[0]["CustomerEmail"].ToString();
                txtWebsite.Text = ds.Tables[0].Rows[0]["CustomerWebsite"].ToString();
                ddlCurrency.SelectedValue = ds.Tables[0].Rows[0]["CurrencyID"].ToString();
                if (ds.Tables[0].Rows[0][19].ToString() != "")
                {
                    ddlStore.SelectedValue = ds.Tables[0].Rows[0]["StoreID"].ToString();
                }
           
                //txtCreditAmount.Text = ds.Tables[0].Rows[0]["DueUSDAmount"].ToString();
                //txtPaidAmount.Text = ds.Tables[0].Rows[0]["PaidUSDAmount"].ToString();
                int currencyid=Convert.ToInt32(ds.Tables[0].Rows[0]["CurrencyID"]);


                txtTotGourAmount.Text = ds.Tables[0].Rows[0]["TotalGourdesAmount"].ToString();
                txtTotalDeliveryChargeGourdes.Text = ds.Tables[0].Rows[0]["DeliveryChargeGourdes"].ToString();
                txtTotalSalesTaxGourdes.Text = ds.Tables[0].Rows[0]["TotalSalesTaxGourdes"].ToString();
                txtGrandTotalGourdes.Text = ds.Tables[0].Rows[0]["TotalGrandTotalGourdes"].ToString();

                txtTotAmount.Text = ds.Tables[0].Rows[0]["TotalUSDAmount"].ToString();
                txtTotalDeliveryChargeUSD.Text = ds.Tables[0].Rows[0]["TotalDeliveryChargesUSD"].ToString();
                txtTotalSalesTaxUSD.Text = ds.Tables[0].Rows[0]["TotalSalesTaxUSD"].ToString();
                txtGrandTotalUSD.Text = ds.Tables[0].Rows[0]["TotalGrandTotalUSD"].ToString();

                //DataTable dt = ds.Tables[0];
                //DataRow dr;
                //if (currencyid == 1)
                //{
                //    for (int i = 0; i < dt.Rows.Count; i++)
                //    {
                //         dr = dt.Rows[i];
                //         txtTotGourAmount.Text = (Convert.ToDecimal(txtTotGourAmount.Text == "" ? 0 : Convert.ToDecimal(txtTotGourAmount.Text)) + Convert.ToDecimal(dr["TotalAmount"])).ToString(".00");
                //        txtTotalDeliveryChargeGourdes.Text = (Convert.ToDecimal(txtTotalDeliveryChargeGourdes.Text == "" ? 0 :Convert.ToDecimal(txtTotalDeliveryChargeGourdes.Text)) + Convert.ToDecimal(dr["DeliveryChargeGourdes"])).ToString(".00");
                //        txtTotalSalesTaxGourdes.Text = (Convert.ToDecimal(txtTotalSalesTaxGourdes.Text == "" ? 0 : Convert.ToDecimal(txtTotalSalesTaxGourdes.Text)) + Convert.ToDecimal(dr["SaleTaxGourdes"])).ToString(".00");                           
                        
                //    }
                //    txtGrandTotalGourdes.Text = (Convert.ToDecimal(txtTotGourAmount.Text) + Convert.ToDecimal(txtTotalDeliveryChargeGourdes.Text) + Convert.ToDecimal(txtTotalSalesTaxGourdes.Text)).ToString(".00");
                //}
                //else
                //{
                //    for (int i = 0; i < dt.Rows.Count; i++)
                //    {
                //       dr = dt.Rows[i];
                //       txtTotAmount.Text = (Convert.ToDecimal(txtTotAmount.Text == "" ? 0 : Convert.ToDecimal(txtTotAmount.Text)) + Convert.ToDecimal(dr["TotalAmount"])).ToString(".00");
                //        txtTotalDeliveryChargeUSD.Text = (Convert.ToDecimal(txtTotalDeliveryChargeUSD.Text == "" ? 0 : Convert.ToDecimal(txtTotalDeliveryChargeUSD.Text)) + Convert.ToDecimal(dr["DeliveryChargeGourdes"])).ToString(".00");
                //        txtTotalSalesTaxUSD.Text = (Convert.ToDecimal(txtTotalSalesTaxUSD.Text == "" ? 0 : Convert.ToDecimal(txtTotalSalesTaxUSD.Text)) + Convert.ToDecimal(dr["SaleTaxGourdes"])).ToString(".00");                           
                //    }
                //    txtGrandTotalUSD.Text = (Convert.ToDecimal(txtTotAmount.Text) + Convert.ToDecimal(txtTotalDeliveryChargeUSD.Text) + Convert.ToDecimal(txtTotalSalesTaxUSD.Text)).ToString(".00");
                //}
                ////txtGourCreditAmount.Text = ds.Tables[0].Rows[0]["DueGrourdesAmount"].ToString();
                // txtGourPaidAmount.Text = ds.Tables[0].Rows[0]["PaidGourdesAmount"].ToString();
                txtDate.Text = ds.Tables[0].Rows[0]["InvoiceDate"].ToString();
                txtStreetName.Text = ds.Tables[0].Rows[0]["StreetName"].ToString();
                txtStreetCharges.Text = ds.Tables[0].Rows[0]["ChargePrice"].ToString();
                txtRemark.Text = ds.Tables[0].Rows[0]["Remarks"].ToString();
                txtDuedate.Text = Convert.ToDateTime(ds.Tables[0].Rows[0]["BillDueDate"].ToString()).ToShortDateString();               
                ddlPaymentMode.SelectedValue = ds.Tables[0].Rows[0]["PaymentMode"].ToString();

                lblMaxCreditLimit.Text = ds.Tables[0].Rows[0]["MaxCreditLimit"].ToString();
                lblMaxCreditLimitUSD.Text = ds.Tables[0].Rows[0]["MaxCreditLimitUSD"].ToString();

                lblCreditLimit.Text = ds.Tables[0].Rows[0]["OpeningBalance"].ToString();
                lblCreditLimitUSD.Text = ds.Tables[0].Rows[0]["OpeningBalanceUSD"].ToString();

                txtCity.Text = ds.Tables[0].Rows[0]["CityName"].ToString();
                txtCountry.Text = ds.Tables[0].Rows[0]["CountryName"].ToString();
                txtGourdesConverter.Text = ds.Tables[0].Rows[0]["CurrencyRate"].ToString();
                btnPrint.Enabled = true;
                btnsave.Enabled = false;
                BindCustomerDocumentDetail(Convert.ToInt32(ViewState["custid"]));
                if (ds.Tables[0].Rows.Count > 0)
                {
                    gvProductDetail.DataSource = ds.Tables[0].DefaultView;
                    gvProductDetail.DataBind();
                  //  gvProductDetail.Visible = true;
                    lblError.Text = "";
                   
                    //    ShowLabelControls(true);
                }
                else
                {
                    ShowError("No Records Found!");
                  
                    //     ShowLabelControls(false);
                }
                
            }
            else
            {
                //System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=JavaScript>alert('Order No. not found')</SCRIPT>");
                lblError.Visible = true;
                lblError.Text = "This Order No.: " + txtSalesOrderNumber.Text + "  dose not exist, please enter another order number and try again!";
                gvProductDetail.Visible = false;
            }
        }
        #region Get Customer Document By Customer Id
        private void addfiletable()
        {
            t = new Table();
            t.Rows.Clear();
            t.BorderStyle = BorderStyle.Solid;

            TableHeaderRow th = new TableHeaderRow();
            th.BorderStyle = BorderStyle.Solid;
            TableCell c1 = new TableCell();
            c1.Text = "S.No.";
            c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

            TableCell c2 = new TableCell();
            c2.Text = "Uploaded Files";
            c2.Style.Add(HtmlTextWriterStyle.Width, "25%");

            TableCell c3 = new TableCell();
            c3.Text = "Document Type";
            c3.Style.Add(HtmlTextWriterStyle.Width, "8%");
            c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c4 = new TableCell();
            c4.Text = "Document ID";
            c4.Style.Add(HtmlTextWriterStyle.Width, "20%");
            c4.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c5 = new TableCell();
            c5.Text = "Remarks";
            c5.Style.Add(HtmlTextWriterStyle.Width, "10%");
            c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");

            TableCell c6 = new TableCell();
            c6.Style.Add(HtmlTextWriterStyle.Width, "1%");
            c6.Text = "Checked";
            c6.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");



            th.Cells.Add(c1);
            th.Cells.Add(c2);
            th.Cells.Add(c3);
            th.Cells.Add(c4);
            th.Cells.Add(c5);
            th.Cells.Add(c6);



            Style myStyle = new Style();
            myStyle.ForeColor = System.Drawing.Color.Black;
            myStyle.BackColor = System.Drawing.Color.LightGray;
            myStyle.Font.Bold = true;
            myStyle.BorderStyle = BorderStyle.Solid;

            th.ApplyStyle(myStyle);
            // th.Font.Size =Unit.Percentage(12);
            th.BorderStyle = BorderStyle.Solid;
            th.BorderWidth = Unit.Pixel(1);

            t.Rows.Add(th);

        }
        private void BindCustomerDocumentDetail(int id)
        {
            CheckBox chk;
            CustomerBO objCust = new CustomerBO();
            List<CustomerDocument> lst = new List<CustomerDocument>();
            lst = objCust.SearchCustomerDocument(id);
            if(t!=null)
            t.Rows.Clear();
            addfiletable();
            //GridView1.DataSource = lst;
            //GridView1.DataBind();


            Count = 1;

            if (lst != null)
            {
                foreach (CustomerDocument obj in lst)
                {

                    HyperLink lnk = new HyperLink();
                    lnk.EnableViewState = true;
                    lnk.ID = "lnk" + Count.ToString();
                    lnk.Text = obj.FriendlyName;
                    lnk.NavigateUrl = "~/CustomerScanID/" + obj.CustomerID.ToString() + "/" + obj.CustomerScanID;
                    lnk.Visible = true;
                    lnk.Target = "_blank";

                    tb = new TextBox();
                    tb.EnableViewState = true;
                    tb.ID = "txt" + Count.ToString();
                    tb.MaxLength = 150;
                    tb.Text = obj.CustomerDescription;
                    tb.Enabled = false;


                    chk = new CheckBox();
                    chk.Checked = true;
                    chk.ID = "chk" + Count.ToString();
                    chk.Enabled = false;

                    Label Uid = new Label();
                    Uid.EnableViewState = true;
                    Uid.ID = "label2" + Count.ToString();
                    Uid.Text = Convert.ToString(obj.ScanID);
                    Uid.Visible = false;


                    Label uName = new Label();
                    uName.EnableViewState = true;
                    uName.ID = "label3" + Count.ToString();
                    uName.Text = obj.CustomerScanID;
                    uName.Visible = false;



                    TableRow dr = new TableRow();
                    TableCell c1 = new TableCell();
                    TableCell c3 = new TableCell();
                    TableCell c4 = new TableCell();
                    TableCell c5 = new TableCell();
                    TableCell C6 = new TableCell();
                    TableCell c7 = new TableCell();
                    TableCell c8 = new TableCell();
                    TableCell c9 = new TableCell();

                    Label DocType = new Label();
                    DocType.EnableViewState = true;
                    DocType.ID = "lblDocType" + Count.ToString();
                    DocType.Text = obj.DocumentType;
                    DocType.Visible = true;


                    Label DocID = new Label();
                    DocID.EnableViewState = true;
                    DocID.ID = "lblDocID" + Count.ToString();
                    DocID.Text = obj.DocumentID;
                    DocID.Visible = true;

                    c8.Controls.Add(DocType);
                    c9.Controls.Add(DocID);


                    c7.Controls.Add(uName);
                    //c8.Controls.Add(filePath);

                    c3.Text = "File" + Count.ToString(); ;
                    c3.Style.Add(HtmlTextWriterStyle.Width, "1%");
                    //  c1.Style.Add(HtmlTextWriterStyle.Width, "30%");
                    TableCell c2 = new TableCell();
                    //   c2.Style.Add(HtmlTextWriterStyle.Width, "30%");
                    //   c4.Style.Add(HtmlTextWriterStyle.Width, "4%");
                    //   c5.Style.Add(HtmlTextWriterStyle.Width, "2%");
                    c2.Controls.Add(tb);
                    c1.Controls.Add(lnk);
                    c5.Controls.Add(chk);
                    C6.Controls.Add(Uid);

                    c1.Style.Add(HtmlTextWriterStyle.Width, "25%");
                    c2.Style.Add(HtmlTextWriterStyle.Width, "5%");

                    //  c3.Style.Add(HtmlTextWriterStyle.Width, "3%");
                    c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                    c8.Style.Add(HtmlTextWriterStyle.Width, "8%");
                    c8.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                    c9.Style.Add(HtmlTextWriterStyle.Width, "20%");
                    c9.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                    c5.Style.Add(HtmlTextWriterStyle.Width, "1%");
                    c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");


                    dr.Cells.Add(c3);
                    dr.Cells.Add(c1);
                    dr.Cells.Add(c8);
                    dr.Cells.Add(c9);
                    // dr.Cells.Add(c4);
                    dr.Cells.Add(c2);
                    dr.Cells.Add(c5);
                    dr.Cells.Add(C6);
                    dr.Cells.Add(c7);

                    Style myStyle = new Style();
                    myStyle.ForeColor = System.Drawing.Color.Black;
                    myStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                    myStyle.Font.Bold = false;


                    c1.ApplyStyle(myStyle);
                    c8.ApplyStyle(myStyle);
                    c3.ApplyStyle(myStyle);
                    c9.ApplyStyle(myStyle);
                    c5.ApplyStyle(myStyle);
                    c2.ApplyStyle(myStyle);

                    t.Rows.Add(dr);
                    phControls.Controls.Add(t);
                    Count++;

                }
                

                phControls.Controls.Add(t);
                Session["Files"] = t;
                Session["Count"] = Count;
            }
        }

        #endregion
        private DataSet SearchOrder(Order objOrder)
        {
            //Call service operation to get data from database source
            OrderBO odr = new OrderBO();
            lstOrder = odr.SearchOrder(objOrder);
            //    lstCustomer  = UserAdminServiceAgent.SearchCustomer(objCustomer);
            DataTable dt = ORHelper<Order>.GenericListToDataTable(lstOrder);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        protected void ShowError(string a_sMsg)
        {
           // errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            if (a_sMsg.Length > 0)
            {
         //       errorMessage.Visible = true;
            }
            else
            {
          //      errorMessage.Visible = false;
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            Session["ProductDetail"] = null;
            Session["Files"] = null;
            Session["Count"] = Count;
            Session["IssuedProductList"] = null;
            //Session["dsProductDetail"] = null;
            Session["dsPartMaterialDetail"] = null;
            //Session["txtMaterialCode"] = null;
            //Session["txtProductName"] = null;
            //Session["txtAvailiable"] = null;
            //Session["txtRate"] = null;
            //Session["txtQuantity"] = null;
            //Session["txtTotalAmount"] = null;
            Response.Redirect("~/SAL/PartSales.aspx");
        }

        protected void ddlUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                if (ddlUnit.SelectedIndex > 0)
                {
                    //  txtUnit.Text = ddlUnit.SelectedItem.Text;
                   // hdnUnitID.Value = ddlUnit.SelectedValue;
                    Product objProduct = new Product();
                    Product objProductRET = new Product();
                    ProductUnitPriceBO objBO = new ProductUnitPriceBO();
                    objProduct.ProductPriceID = Convert.ToInt32(ddlUnit.SelectedValue.ToString());
                    objProduct.CustomerID = Convert.ToInt32(ViewState["CustomerID"]);
                    objProductRET = objBO.GetProductUnitByID(objProduct);
                    txtQuantity.Text = "";
                    //VehicleBO objVehicle = new VehicleBO();
                    //objProduct.UnitId = Convert.ToInt32(ddlUnit.SelectedValue);
                    //  Product objRetUnit = objVehicle.GetUnitDetailsByID(objProduct);
                    if (objProductRET != null)
                    {
                        decimal EquivalentUnit = objProductRET.EquivalentUnit;
                        txtEquivalentUnit.Text = objProductRET.EquivalentUnit.ToString();
                        //txtTotalAmount.Text = (Convert.ToDecimal(String.Format("{0:0.00}", txtTotalAmount.Text != "" ? Convert.ToDecimal(txtTotalAmount.Text) : 0)) * EquivalentUnit).ToString();
                        txtRate.Text = (objProductRET.Rate/Convert.ToDecimal(txtGourdesConverter.Text) ).ToString("0.00");
                        hdnRate.Value = (objProductRET.Rate / Convert.ToDecimal(txtGourdesConverter.Text)).ToString("0.00");
                        //btnAddMaterial.Enabled = true;
                    }
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                lblError.Text = "Error while Rate loading for the product : " + ex.Message;
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
            }
        }

        protected void gvProductSearch_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "ShowProductDetails")
            {

                int id = Convert.ToInt32(e.CommandArgument.ToString());
                //btnAddMaterial.Enabled = true;
                GridViewRow gr = gvProductSearch.Rows[id];

                LinkButton lnk = (LinkButton)gr.Cells[1].FindControl("lnkProductID");
                txtRate.Text = "";
                txtEquivalentUnit.Text = "";

                txtProductID.Text = lnk.Text;
                txtProductName.Text = gr.Cells[3].Text.ToString();
                txtModeNumber.Text = gr.Cells[2].Text.ToString();
                txtSCharge.Text = gr.Cells[4].Text.ToString();
                txtTax.Text = gr.Cells[5].Text.ToString();
                Product objUnitProduct = new Product();

                objUnitProduct.ProductID = Convert.ToInt32(lnk.Text);
                if (ViewState["CustomerID"] == null)
                {
                    lblError.Text = "Invalid Customer Selected";
                    return;
                }
                else
                {
                    objUnitProduct.CustomerID = Convert.ToInt32(ViewState["CustomerID"]);
                }
                List<Product> lstUnitProduct = new List<Product>();
                ProductUnitPriceBO objUnitPriceBO = new ProductUnitPriceBO();
                objUnitProduct.IsActive = true;
                lstUnitProduct = objUnitPriceBO.SearchProductUnitList(objUnitProduct);

                ddlUnit.DataSource = lstUnitProduct;
                ddlUnit.DataTextField = "UnitName";
                ddlUnit.DataValueField = "ProductPriceID";
                ddlUnit.DataBind();
                ddlUnit.Items.Insert(0, new ListItem("--Select--","0"));
                
                txtAvailiable.Text = gr.Cells[7].Text;
                List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
                if (listProduct.Count > 0)
                {
                    ddlCurrency.Enabled = false;
                }
                else
                { 
                    ddlCurrency.Enabled = true; 
                
                }

            }


        }

        protected void gvProductSearch_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void gvProductDetail_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }


        //#region  Account Entry
        
        //private int CustomerLedgerID
        //{
        //    get
        //    {
        //        int x;
        //        Int32.TryParse(hdnCustomerLedgerID.Value, out x);
        //        return x;
        //    }

        //    set { hdnCustomerLedgerID.Value = Convert.ToString(value); }

        //}


        //private void BindLedgerAccountList()
        //{
        //    try
        //    {
        //        LedgerHeader objLedgerHeader = new LedgerHeader();
        //        LedgerHeaderBO objLedgerHeaderBO = new LedgerHeaderBO();
        //        List<LedgerHeader> lstLedgerHeader = new List<LedgerHeader>();
        //        objLedgerHeader.IsActive = true;
        //        objLedgerHeader.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
        //        objLedgerHeader.AccountGroupID = Convert.ToInt32(ddlLedgerGroup.SelectedValue.ToString());
        //        lstLedgerHeader = objLedgerHeaderBO.GetSearchLedgerHeader(objLedgerHeader);
        //        objLedgerHeader.IsActive = true;
        //        ddlLedgerName.DataSource = lstLedgerHeader;
        //        ddlLedgerName.DataValueField = "LedgerAccountID";
        //        ddlLedgerName.DataTextField = "AccountName";
        //        ddlLedgerName.DataBind();
        //        ddlLedgerName.Items.Insert(0, new ListItem("--Select--", "--Select--"));
        //    }
        //    catch (Exception Ex)
        //    {
        //        lblError.Text = "Error While Fetching Bank Account List : " + Ex.Message;
        //    }
        //}
        //private void BindLedgerGroup()
        //{
        //    AccountGroup objAccountGroup = new AccountGroup();
        //    AccountGroupBO objAccountGroupBO = new AccountGroupBO();
        //    List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
        //    objAccountGroup.CompanyID = LoginToken.CompanyID;
        //    objAccountGroup.GroupName = "Sales";
        //    objAccountGroup.IsActive = true;
        //    lstAccountGroup = objAccountGroupBO.GetSearchAccountGroup(objAccountGroup);
        //    ddlLedgerGroup.DataSource = lstAccountGroup;
        //    ddlLedgerGroup.DataValueField = "AccountGroupID";
        //    ddlLedgerGroup.DataTextField = "GroupName";
        //    ddlLedgerGroup.DataBind();
        //    ddlLedgerGroup.Items.Insert(0, new ListItem("--Select--", "--Select--"));

        
        //}

        //protected void ddlLedgerGroup_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    BindLedgerAccountList();

        //}


        //protected bool SaveLedgerEntry(string Order)
        //{
        //    bool result = false;
        //    decimal Amount = ddlCurrency.SelectedValue == "1" ? Convert.ToDecimal(txtGrandTotalGourdes.Text) : (Convert.ToDecimal(txtGrandTotalUSD.Text) * Convert.ToDecimal(txtGourdesConverter.Text));

        //    JournalDetails objJournalDetails = new JournalDetails();
        //    JournalDetailsBO objJournalDetailsBO = new JournalDetailsBO();

        //    objJournalDetails.Details = "Parts/Product Sold for " + Order +" : "+txtMemoNote.Text ;
        //    objJournalDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
        //    objJournalDetails.CompanyID = (Int16)LoginToken.CompanyID;
        //    objJournalDetails.ActionType = EnumActionType.Insert;
        //    objJournalDetails.EntryDate = txtDate.Text;
        //    objJournalDetails.AddedBy = LoginToken.LoginId;
        //    objJournalDetails.IsActive = true;
        //    objJournalDetails.IsLocked = false;


        //    List<JournalDetails> lstJournalDetails = new List<JournalDetails>();
        //    JournalDetails objJournalDetailsNew;

        //    //To prepare Debit entry collection 
        //    //Read values one by one from Grid

        //    #region To prepare debit entry details

        //    objJournalDetailsNew = new JournalDetails();
        //    objJournalDetailsNew.JournalDetailsID = 0;
        //    //Get LedgerAccountID for pay order to From dataKeyValues
        //    objJournalDetailsNew.LedgerAccountID = Convert.ToInt32(CustomerLedgerID);
        //    objJournalDetailsNew.TType = "DR";
        //    objJournalDetailsNew.LF = "";
        //    objJournalDetailsNew.DebitAmount =Amount;
        //    objJournalDetailsNew.CreditAmount = 0;
        //    //Adding the object to the JournalDetails collection
        //    lstJournalDetails.Add(objJournalDetailsNew);

        //    #endregion

        //    #region To prepare creadit entry details

        //    objJournalDetailsNew = new JournalDetails();
        //    objJournalDetailsNew.JournalDetailsID = 0;
        //    //Get LedgerAccountID for pay order to From dataKeyValues
        //    objJournalDetailsNew.LedgerAccountID = Convert.ToInt32(ddlLedgerName.SelectedValue);
        //    objJournalDetailsNew.TType = "CR";
        //    objJournalDetailsNew.LF = "";
        //    objJournalDetailsNew.DebitAmount = 0;

        //    objJournalDetailsNew.CreditAmount = Amount;
        //    //Adding the object to the JournalDetails collection
        //    lstJournalDetails.Add(objJournalDetailsNew);
        //    #endregion


        //    //Creating XML for Credit/Debit transactions
        //    objJournalDetails.XMLData = XMLConverter.JournalDetailsListToXML(lstJournalDetails).ToString();

        //    //Inserting transaction to JournalDetails table
        //    if (objJournalDetailsBO.SaveJournalEntry(objJournalDetails))
        //    {
        //        lblError.Text = "Ledger Transaction for sales added successfully.";
        //        result = true;
              
        //    }
        //    return result;

        //}

        //#endregion
    }
}