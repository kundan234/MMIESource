﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.SAL
{
    public partial class CloseTransaction : BasePage
    {
        protected void PagePermission()
        {
            if (LoginToken != null)
            {

                dllBranch.SelectedValue = Convert.ToString(LoginToken.CompanyID);
                dllBranch.Enabled = LoginToken.IsChangeBranchOn;
                ddlFinancialYear.SelectedValue = Convert.ToString(LoginToken.FinancialYearID);
                ddlFinancialYear.Enabled = LoginToken.IsChangeBranchOn;
                btnPrint.Enabled = LoginToken.IsPrintOn;
                txtStartDate.Enabled = LoginToken.IsChangeDateOn;
                txtEndDate.Enabled = LoginToken.IsChangeDateOn;
               txtLoginID.Enabled=LoginToken.IsChangeBranchOn;
               
                

            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            txtEndDate.Attributes.Add("ReadOnly", "True");
            txtStartDate.Attributes.Add("ReadOnly", "True");
            if (!IsPostBack)
            {
                BindBranchDetails();
                BindFinancialYear();
                //BindLegerAccount();
                txtEndDate.Text = System.DateTime.Now.ToShortDateString();
                txtStartDate.Text = System.DateTime.Now.ToShortDateString();
                txtLoginID.Text = LoginToken.LoginId;
                btnPrint.Enabled = false;

            }

            PagePermission();
        }


        protected void BindBranchDetails()
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
            dllBranch.Items.Insert(0, "--Select--");

        }

        protected void BindFinancialYear()
        {

            MasterLookupBO mstlookup = new MasterLookupBO();
            BindDropDownControl(ddlFinancialYear, mstlookup.GetLookupsList(LookupNames.FinancialYear));
            ddlFinancialYear.Items.Insert(0, "--Select--");
        }



        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }



        protected void btnCheckout_Click(object sender, EventArgs e)
        {
            try
            {
                //UserAdminBO objUserBO = new UserAdminBO();
                //UserLogin objLogin = new UserLogin();

                //objLogin.LoginId = LoginToken.LoginId;
                //objLogin.CompanyID =(Int16) LoginToken.CompanyID;
                //objLogin.IsCheckOut =true ;
                //objLogin.LastModBy = LoginToken.LoginId;
                //objLogin.ActionType = EnumActionType.Insert;
                //objLogin.FinancialYearID =(Int16) LoginToken.FinancialYearID;

                //if (objUserBO.CheckoutUser(objLogin))
                //{
                // lblError.Text="User : "+objLogin.LoginId +"CheckedOut Sucessfully"  ;
                // btnCheckout.Enabled = false;
                // LoginToken objLoginToken = new LoginToken();

                // objLoginToken = (LoginToken)Session["LoginToken"];
                // objLogin.IsCheckOut = true;

                //    Session["LoginToken"] = objLoginToken;
                //    btnPrint.Enabled = true;
                //}


                PaymentDetails objPayment = new PaymentDetails();
                PaymentDetailsBO objPaymentBO = new PaymentDetailsBO();

                objPayment.CompanyID = LoginToken.CompanyID;
                objPayment.FinancialYearID = LoginToken.FinancialYearID;
                objPayment.LastModBy = LoginToken.LoginId;
                objPayment.XMLData = CreateGridToXML();

                if (objPaymentBO.SaveCheckOutPaymentDetails(objPayment))
                {
                    lblError.Text = "User : " + objPayment.AddedBy + " CheckedOut Data Saved Sucessfully";
                    btnPrint.Enabled = LoginToken.IsPrintOn ? true : false;
                }

                this.Reset();
            }
            catch(Exception ex)
            {

                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Closing Transaction : " + ex.Message;  

      
            
            }

        }


        protected string CreateGridToXML()
        {
            StringBuilder objBuilder = new StringBuilder();
            CheckBox chk = new CheckBox();
            TextBox chk1 = new TextBox();

            foreach (GridViewRow gr in grdPaymentTransaction.Rows)
            {

                chk = (CheckBox)gr.Cells[5].FindControl("chkIsCheckin");
                chk1 = (TextBox)gr.Cells[6].FindControl("txtRemarksCheck");
              
                    objBuilder.Append("<PaymentDetails PaymentDetailsID= \"" + gr.Cells[1].Text.ToString() + "\" ");
                    objBuilder.Append(" RemarksCheck  = \"" + chk1.Text + "\" ");

                    objBuilder.Append(" Ischecked = \"" + chk.Checked.ToString() + "\" ");
                    objBuilder.Append("/>");
              

            }

            return objBuilder.ToString();
        }


        protected void TotalAmount()
        {
          decimal TotalGourdes;

            TotalGourdes=0;
          


            foreach (GridViewRow gr in grdPaymentTransaction.Rows)
            {

                TotalGourdes += Convert.ToDecimal(gr.Cells[4].Text.ToString());
                //TotalUSD += Convert.ToDecimal(gr.Cells[8].Text.ToString());
 


            }
            lblTotalGourdes.Text = TotalGourdes.ToString();
           // lblTotalUSD.Text = TotalUSD.ToString();
            
        }



        protected void BindPaymentDetils()
        {


            PaymentDetails objPayment = new PaymentDetails();

            PaymentDetailsBO objPaymentBO = new PaymentDetailsBO();

            objPayment.IsActive = true;
            objPayment.AddedBy = txtLoginID.Text;
            objPayment.StartDate = Convert.ToDateTime(txtStartDate.Text);
            objPayment.EndDate = Convert.ToDateTime(txtEndDate.Text);
            objPayment.CompanyID = LoginToken.CompanyID;
            objPayment.FinancialYearID = LoginToken.FinancialYearID;
            objPayment.CurrencyID = Convert.ToInt32(ddlType.SelectedValue.ToString());

            List<PaymentDetails> lstPayment = new List<PaymentDetails>();
            lstPayment = objPaymentBO.GetSearchPaymentDetails(objPayment);

            grdPaymentTransaction.DataSource = lstPayment;
            grdPaymentTransaction.DataBind();

            TotalAmount();



        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindPaymentDetils();


        }

        protected void grdPaymentTransaction_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
           
                // Display an error message.
                int newPageNumber = e.NewPageIndex + 1;
                lblError.Text = "All Changes Saved before moving to page " +
                  newPageNumber.ToString() + ".";
             
            grdPaymentTransaction.PageIndex = e.NewPageIndex;
            BindPaymentDetils();

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            this.Reset();

        }

        protected void Reset()
        {
          
            txtEndDate.Text = DateTime.Now.ToShortDateString();
            txtLoginID.Text = LoginToken.LoginId;
            txtStartDate.Text = DateTime.Now.ToShortDateString();
            ddlFinancialYear.SelectedValue = LoginToken.FinancialYearID.ToString();
            dllBranch.SelectedValue = LoginToken.CompanyID.ToString();
            lblTotalGourdes.Text = "";
            lblTotalUSD.Text = "";
            grdPaymentTransaction.DataSource = null;
            grdPaymentTransaction.DataBind();
        }
    }
}