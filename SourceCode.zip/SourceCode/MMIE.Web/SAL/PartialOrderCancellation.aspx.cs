﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.Web;
using System.Data;
using MMIE.Data.Common;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.Util;
using System.Text;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;

namespace MMIE.SAL
{
    public partial class PartialOrderCancellation : BasePage
    {
        List<Customer> lstOrder = null;
        const string VS_SEARCH = "VS_SEARCH";
        protected void Page_Load(object sender, EventArgs e)
        {


        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                btnsave.Enabled = false;
                btnPrint.Enabled = false;

                Customer objOrder = new Customer();
                PartBO odr = new PartBO();
                objOrder.OrderNo = txtSearchOrder.Text.Trim();
                objOrder.CustomerName = txtSearchCustomerName.Text.Trim();
                objOrder.CustomerPhone = txtSearchPhone.Text.Trim();
                lstOrder = odr.GetPartialOrderSearch(objOrder);

                if (lstOrder.Count > 0)
                {
                    gvOrderSearch.DataSource = lstOrder;
                    gvOrderSearch.DataBind();
                    gvOrderSearch.Visible = true;
                    ShowError("");
                }
                else
                {
                    ShowError("No Records Found");
                    gvOrderSearch.Visible = false;
                    gvOrderPartDetail.Visible = false;

                }
            }

            catch (Exception Ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, Ex, "1000001");
                LogManager.WriteErrorLogInDB(Ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Order Records : " + Ex.Message;
                lblError.Visible = true;
            }
        }


        protected void ShowError(string a_sMsg)
        {
            errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            if (a_sMsg.Length > 0)
            {
                errorMessage.Visible = true;
            }
            else
            {
                errorMessage.Visible = false;
            }
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                string ORDNO = lblORD.Text;
                string GroupType = hdGroupType.Value;
                string CustomerID = hdCustomerID.Value;
                string ProdID = "", UnitPrice = "", PendingQty = "", CancelQty = "", CurrencyRate = "", TaxRate = "", ProductSaleID = "";
                StringBuilder objBuilder = new StringBuilder();
                decimal OpeningBalance = 0, CancelAmt = 0;
                for (int i = 0; i < gvOrderPartDetail.Rows.Count; i++)
                {
                    ProdID = gvOrderPartDetail.DataKeys[i]["ProductID"].ToString();
                    UnitPrice = gvOrderPartDetail.DataKeys[i]["UnitPriceGourdes"].ToString();
                    PendingQty = gvOrderPartDetail.DataKeys[i]["PendingQty"].ToString();
                    CurrencyRate = gvOrderPartDetail.DataKeys[i]["CurrencyRate"].ToString();
                    ProductSaleID = gvOrderPartDetail.DataKeys[i]["ProductSaleID"].ToString();

                    TaxRate = gvOrderPartDetail.DataKeys[i]["TaxRate"].ToString();
                    CancelQty = (gvOrderPartDetail.Rows[i].FindControl("txtCancelQty") as TextBox).Text;
                    if (CancelQty.Trim() != "")
                    {
                        OpeningBalance = OpeningBalance + Convert.ToDecimal(UnitPrice) * Convert.ToInt32(CancelQty)
                                                           + (Convert.ToDecimal(UnitPrice) * Convert.ToInt32(CancelQty) * Convert.ToDecimal(TaxRate)) / 100;

                        CancelAmt = CancelAmt + (Convert.ToDecimal(UnitPrice) * Convert.ToInt32(CancelQty)
                                                         + (Convert.ToDecimal(UnitPrice) * Convert.ToInt32(CancelQty) * Convert.ToDecimal(TaxRate)) / 100
                                                        );

                        objBuilder.Append("<PartialCancel  ProductSaleID= \"" + ProductSaleID + "\" ");
                        objBuilder.Append(" CancelQty  = \"" + CancelQty + "\" ");
                        objBuilder.Append("/>");

                    }
                }

                Order obj = new Order();
                obj.BillHeaderID = Convert.ToInt64(hdBillHeaderID.Value);
                obj.CustomerID = Convert.ToInt32(CustomerID);
                obj.OpeningBalance = OpeningBalance;
                obj.CancelAmt = CancelAmt;
                obj.XMLData = objBuilder.ToString();
                obj.LastModBy = LoginToken.LoginId;
                PartBO dal = new PartBO();
                bool status = dal.UpdatePartPartialCancel(obj);
                if (status)
                {

                    lblError.Text = "Partial Cancellation successfully.";
                    lblError.Visible = true;
                    BindPartDetails();
                }

            }
            catch (Exception Ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, Ex, "1000001");
                LogManager.WriteErrorLogInDB(Ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Partial Cancel Order : " + Ex.Message;
                lblError.Visible = true;
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            gvOrderPartDetail.DataSource = null;
            gvOrderPartDetail.DataBind();
            gvOrderSearch.DataSource = null;
            gvOrderSearch.DataBind();
            txtSearchCustomerName.Text = "";
            txtSearchOrder.Text = "";
            txtSearchPhone.Text = "";
            lblDetails.Text = "Part Details";

        }

        void GridViewRowColor()
        {
            foreach (GridViewRow gvRow in gvOrderSearch.Rows)
            {
                gvRow.BackColor = System.Drawing.Color.White;
            }
        }

        private void BindPartDetails()
        {
            try
            {
                Order objCustomer = new Order();
                objCustomer.OrderNumber = lblORD.Text;
                objCustomer.GroupType = Convert.ToInt32(hdGroupType.Value);
                BillHeaderDetailsBO st = new BillHeaderDetailsBO();
                List<Order> lstProducts = st.GetSearchOrderDetails(objCustomer);
                gvOrderPartDetail.DataSource = lstProducts.FindAll(x => x.PendingQty != 0);
                gvOrderPartDetail.DataBind();
                gvOrderPartDetail.Visible = true;
                //if (hdGroupType.Value == "2")
                //{
                //    lblDetails.Text = "Part Details";
                //}
                //else if (hdGroupType.Value == "1")
                //{
                //    lblDetails.Text = "Vehicle Details";
                //}
            }
            catch (Exception Ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, Ex, "1000001");
                LogManager.WriteErrorLogInDB(Ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Order Parts Details Records : " + Ex.Message;
                lblError.Visible = true;
            }
        }

        protected void gvOrderSearch_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "ShowDetails")
                {
                    GridViewRow grArtist = ((Control)
                       (e.CommandSource)).NamingContainer as GridViewRow;
                    GridViewRowColor();
                    grArtist.BackColor = System.Drawing.Color.LightBlue;
                    string OrderNo = gvOrderSearch.DataKeys[grArtist.RowIndex]["OrderNo"].ToString();
                    string BillHeaderID = gvOrderSearch.DataKeys[grArtist.RowIndex]["BillHeaderID"].ToString();
                    int GroupType = Convert.ToInt32(gvOrderSearch.DataKeys[grArtist.RowIndex]["GroupType"].ToString());
                    string CustomerID = gvOrderSearch.DataKeys[grArtist.RowIndex]["CustomerID"].ToString();
                    Order objCustomer = new Order();
                    objCustomer.OrderNumber = OrderNo;
                    objCustomer.GroupType = GroupType;
                    objCustomer.BillHeaderID = Convert.ToInt64(BillHeaderID);
                    hdGroupType.Value = GroupType.ToString();
                    hdCustomerID.Value = CustomerID;
                    lblORD.Text = OrderNo;
                    hdBillHeaderID.Value = BillHeaderID;
                    BillHeaderDetailsBO st = new BillHeaderDetailsBO();
                    List<Order> lstProducts = st.GetSearchOrderDetails(objCustomer);
                    gvOrderPartDetail.DataSource = lstProducts.FindAll(x => x.PendingQty != 0);
                    gvOrderPartDetail.DataBind();
                    gvOrderPartDetail.Visible = true;

                    if (GroupType == 2)
                    {
                        lblDetails.Text = "Part Details (" + "Order No# " + OrderNo + ")";
                    }
                    else if (GroupType == 1)
                    {
                        lblDetails.Text = "Vehicle Details (" + "Order No# " + OrderNo + ")";
                    }
                    if (gvOrderPartDetail.Rows.Count > 0)
                    {
                        btnsave.Enabled = true;
                        btnPrint.Enabled = true;
                    }
                    else
                    {
                        btnsave.Enabled = false;
                        btnPrint.Enabled = true;
                    }

                }
            }
            catch (Exception Ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, Ex, "1000001");
                LogManager.WriteErrorLogInDB(Ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Order Parts Details Records : " + Ex.Message;
                lblError.Visible = true;
            }

        }
    }
}