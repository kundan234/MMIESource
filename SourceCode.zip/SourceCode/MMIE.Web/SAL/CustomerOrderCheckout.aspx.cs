﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;


namespace MMIE.SAL
{
    public partial class CustomerOrderCheckout : BasePage
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCurrencyDropDown();
                BindBankDetails();
            }

        }

        protected void gvOrderSearch_RowCreated(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                    if (e.Row.RowIndex % 2 == 0)
                    {
                        //Change row colour on mouseover and mouseout
                        e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                    }
                    else
                    {
                        //Change row colour on mouseover and mouseout
                        e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                    }
                }
            }
            catch (Exception ex)
            {
                
                  LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
            }

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Order objOrder = new Order();
                OrderBO objOrderBO = new OrderBO();
                int SearchCustomerID = Convert.ToInt32(hdnCustomerId.Value.Trim());
                objOrder.CustomerID = SearchCustomerID;
                objOrder.CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());

                List<Order> lstOrder = new List<Order>();
                lstOrder = objOrderBO.SearchCustomerOrder(objOrder);
                decimal PaymentAmount = Convert.ToDecimal(txtTotalPayingAmount.Text.Trim());
                PaymentDetails objPaymentDetails = new PaymentDetails();
                foreach (Order item in lstOrder)
                {
                    #region Save Payment Details

                    objPaymentDetails.BillHeaderID = Convert.ToInt32(item.BillHeaderID);
                    objPaymentDetails.SalesStatus = 4;//CreatCheckOut
                    if (ddlPaymentMode.SelectedItem.Text == "Check" || ddlPaymentMode.SelectedItem.Text == "Card")
                    {
                        objPaymentDetails.PaymentModeNo = txtPaymentModeNo.Text;
                        objPaymentDetails.Expirationdate = Convert.ToDateTime(txtPaymentExpirationDate.Text);
                        objPaymentDetails.BankID = Convert.ToUInt16(ddlBank.SelectedValue.ToString());
                    }
                    objPaymentDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                    objPaymentDetails.CompanyID = (Int16)LoginToken.CompanyID;
                    objPaymentDetails.AddedBy = LoginToken.LoginId;

                    objPaymentDetails.CustomerID = SearchCustomerID;

                    objPaymentDetails.IsChecked = false;
                    objPaymentDetails.IsSafeBox = false;
                    objPaymentDetails.ParentID = 0;


                    objPaymentDetails.OrderNumber = item.OrderNumber;
                    objPaymentDetails.PaymentMode = ddlPaymentMode.SelectedItem.ToString();
                    objPaymentDetails.PaymentSourceID = int.Parse(ddlPaymentMode.SelectedValue);
                    objPaymentDetails.IsActive = true;
                    objPaymentDetails.ActionType = EnumActionType.Insert;




                    objPaymentDetails.TType = "CR";
                    objPaymentDetails.Remarks = txtRemarks.Text.Trim();

                    objPaymentDetails.TransactionType = "MultiOrderPayment";
                    objPaymentDetails.CurrencyID = ddlCurrency.SelectedIndex > 0 ? Convert.ToInt32(ddlCurrency.SelectedValue.ToString()) : 0;
                    objPaymentDetails.IsSales = true;
                    objPaymentDetails.CurrencyRate = Convert.ToDecimal(txtGourdesConverter.Text);
                    PaymentDetailsBO objPaymentBO = new PaymentDetailsBO();
                    

                    #endregion
                    if (ddlCurrency.SelectedValue == "1")
                    {
                        if (item.GrandTotalAmountDue > PaymentAmount || item.GrandTotalAmountDue == PaymentAmount)
                        {
                            objPaymentDetails.DueGourdesAmt = item.GrandTotalAmountDue - PaymentAmount;
                            objPaymentDetails.PaidGourdesAmt = PaymentAmount;
                            PaymentAmount = 0;
                           // objPaymentBO.SaveBillPaymentDetails(objPaymentDetails);
                            break;
                        }
                        else
                        {
                            objPaymentDetails.DueGourdesAmt = 0 ;
                            objPaymentDetails.PaidGourdesAmt = item.GrandTotalAmountDue;
                            PaymentAmount = PaymentAmount - objPaymentDetails.PaidGourdesAmt;
                            //objPaymentBO.SaveBillPaymentDetails(objPaymentDetails);
                        }
                    }
                    else if (ddlCurrency.SelectedValue == "2")
                    {
                        if (item.GrandTotalAmountDue > PaymentAmount || item.GrandTotalAmountDue == PaymentAmount)
                        {
                            objPaymentDetails.DueUSDAmt = item.GrandTotalAmountDue - PaymentAmount;
                            objPaymentDetails.PaidUSDAmt = PaymentAmount;
                            PaymentAmount = 0;
                            //objPaymentBO.SaveBillPaymentDetails(objPaymentDetails);
                            break;
                        }
                        else
                        {
                            objPaymentDetails.DueUSDAmt = 0;
                            objPaymentDetails.PaidUSDAmt = item.GrandTotalAmountDue;
                            PaymentAmount = PaymentAmount - objPaymentDetails.PaidUSDAmt;
                            //objPaymentBO.SaveBillPaymentDetails(objPaymentDetails);
                        }
                    }

                    
                }
                lblError.Text = lblError.Text + "\nPayment Completed Successfully";
                if (PaymentAmount > 0)
                {
                   // DepositRemainingAmount(SearchCustomerID, PaymentAmount);

                }

                BindOrderDetails(SearchCustomerID);


            }
            catch (Exception ex)
            {
                 lblError.Text = lblError.Text + "\nPayment Not Completed Successfully";
                 LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
            }
        }

        private void DepositRemainingAmount(int SearchCustomerID, decimal PaymentAmount)
        {
            DepositTransaction objDeposit = new DepositTransaction();
            DepositTransactionBO objDeositBO = new DepositTransactionBO();
            CurrencyBO objCurrencyBO = new CurrencyBO();
            Customer objCustomer = new Customer();
            CustomerBO objCustomerBO = new CustomerBO();
            Currency objCurrency = new Currency();
            if (ddlCurrency.SelectedIndex > 0)
            {
                objCurrency = objCurrencyBO.GetCurrencyByID(Convert.ToInt32(ddlCurrency.SelectedValue.ToString()));
                objDeposit.Rate = objCurrency.Rate;
                objDeposit.CurrencyID = objCurrency.CurrencyID;
                objDeposit.FinancialYearID = LoginToken.FinancialYearID;
                objDeposit.DepositID = 0;
                objDeposit.CompanyID = LoginToken.CompanyID;
                objDeposit.IsActive = true;
                objDeposit.AddedBy = LoginToken.LoginId;

                //decimal AmountUSD = (Amount / objCurrency.Rate);
                objCustomer.CustomerID = SearchCustomerID;

                Customer objRetCustomer = objCustomerBO.GetCustomerByID(objCustomer);
                if (ddlCurrency.SelectedValue == "1")
                {
                    objDeposit.Amount = PaymentAmount;
                    objDeposit.AmountUSD = 0;
                    objDeposit.ClosingAmount = ((decimal)ViewState["OpeningBalance"] + PaymentAmount);

                }
                else
                {
                    objDeposit.Amount = 0;
                    objDeposit.AmountUSD = PaymentAmount;
                    objDeposit.ClosingAmountUSD = ((decimal)ViewState["OpeningBalanceUSD"] + PaymentAmount);
                }

                objDeposit.Remarks = txtRemarks.Text;
                objDeposit.ActionType = 1;
                objDeposit.TType = "CR";
                objDeposit.PaymentMode = "Deposit";

                int result = objDeositBO.CreditAmount(objDeposit);
                if (result > 0)
                {
                    if (lblError.Text.Trim() != "")
                    {
                        lblError.Text = lblError.Text+"\nAmount Deposited Successfully";
                    }
                }
            }
        }

        protected void txtCustomer_TextChanged(object sender, EventArgs e)
        {


            try
            {
                int SearchCustomerID;

                lblError.Text = "";
                string GetCustomerId = txtCustomer.Text;
                string[] SplitGetCustomerId = GetCustomerId.Split('-');

                int i = 0;

                if (SplitGetCustomerId.Length > 1)
                {
                    foreach (string word in SplitGetCustomerId)
                    {
                        i = i + 1;

                        if (i == 1)
                        {
                            SearchCustomerID = Convert.ToInt32(word);
                            BindOrderDetails(SearchCustomerID);

                            hdnCustomerId.Value = SearchCustomerID.ToString();
                        }
                    }
                }
                else
                {
                    txtCustomer.Text = "";
                    lblError.Text = "Please select a customer";
                }

            }

            catch(Exception ex)
            {
                txtCustomer.Text = "";
                lblError.Text = "Please select a customer";
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
            }


        }

        private void BindCustomerDetail(int custid)
        {
            CustomerBO useradm = new CustomerBO();
            Customer objCustomer = new Customer();
            objCustomer.CustomerID = custid;

            Customer objRetCustomer = useradm.GetCustomerByID(objCustomer);
            if (objRetCustomer != null)
            {

                // null all the session
                Session["ProductDetail"] = null;
                Session["IssuedProductList"] = null;
                Session["Files"] = null;
                Session["Count"] = null;
                Session["dsMaterialDetail"] = null;
                ViewState["CustomerID"] = null;
                ViewState["OpeningBalance"] = null;
                ViewState["OpeningBalanceUSD"] = null;
                
                gvOrderSearch.DataSource = null;
                gvOrderSearch.DataBind();


                //**************************************
                ViewState["CustomerID"] = objRetCustomer.CustomerID;
                ViewState["OpeningBalance"] = objRetCustomer.OpeningBalance;
                ViewState["OpeningBalanceUSD"] = objRetCustomer.OpeningBalanceUSD; 
                txtCustomer.Text = objRetCustomer.CustomerName;
                txtAddress.Text = objRetCustomer.CustomerAddress;
                txtStreet.Text = objRetCustomer.CustomerStreet;
                txtCity.Text = objRetCustomer.CityName;
                txtCountry.Text = objRetCustomer.CountryName;
                txtFax.Text = objRetCustomer.CustomerFax;
                txtPhone.Text = objRetCustomer.CustomerPhone;
                txtCellPhone.Text = objRetCustomer.CustomerMobile;
              
                txtEmail.Text = objRetCustomer.CustomerEmail;
                txtWebsite.Text = objRetCustomer.CustomerWebsite;
              
              
                //------------------refrence detail------
            }

        }

        protected void BindOrderDetails(int SearchCustomerID)
        {
            try
            {
                Order objOrder = new Order();
                OrderBO objOrderBO = new OrderBO();

                BindCustomerDetail(SearchCustomerID);

                objOrder.CustomerID = SearchCustomerID;
                objOrder.CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());

                List<Order> lstOrder = new List<Order>();
                lstOrder = objOrderBO.SearchCustomerOrder(objOrder);
                
                gvOrderSearch.DataSource = lstOrder;
                gvOrderSearch.DataBind();
            }

            catch(Exception ex)

            {

                lblError.Text = "Error While Loading Order Details : " + ex.Message;
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
            }


        
        }

        protected void BindCurrencyDropDown()
        {


            try
            {
                CurrencyBO objCurrencyBO = new CurrencyBO();
                
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlCurrency.SelectedIndex = 1;
                txtGourdesConverter.Text = ddlCurrency.SelectedValue.ToString();

            }
            catch (Exception ex)
            {

                lblError.Text = "Error : " + ex.Message;
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
            }

        }

        decimal TotalDueAmount = 0M;
        decimal totalStock = 0M; 

        protected void gvOrderSearch_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    //Label lblPrice = (Label)e.Row.FindControl("lblPrice");
                    // Label lblUnitsInStock = (Label)e.Row.FindControl("lblUnitsInStock");

                    decimal Amount = Decimal.Parse(e.Row.Cells[4].Text);
                    //   decimal stock = Decimal.Parse(lblUnitsInStock.Text);

                    TotalDueAmount += Amount;



                }

                if (e.Row.RowType == DataControlRowType.Footer)
                {
                    //Label lblTotalPrice = (Label)e.Row.FindControl("lblTotalPrice");
                    //Label lblTotalUnitsInStock = (Label)e.Row.FindControl("lblTotalUnitsInStock");

                    //lblTotalPrice.Text = totalPrice.ToString();
                    //lblTotalUnitsInStock.Text = totalStock.ToString();
                    txtTotalDueAmount.Text = TotalDueAmount.ToString("0.00");


                }
            }
            catch (Exception ex)
            {
                
                  LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
            }
        }

        private void BindBankDetails()
        {
            BankBO objPaymentDetailsBO = new BankBO();
            List<Bank> lstPaymentHistory = new List<Bank>();
            lstPaymentHistory = objPaymentDetailsBO.GetBankList(false);
            if (lstPaymentHistory != null)
            {
                ddlBank.DataSource = lstPaymentHistory;
                ddlBank.DataBind();

                ddlBank.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }

        protected void ddlCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (hdnCustomerId.Value.Trim() != "")
            {
                BindOrderDetails(Convert.ToInt32(hdnCustomerId.Value));
            }
        }
    }
}