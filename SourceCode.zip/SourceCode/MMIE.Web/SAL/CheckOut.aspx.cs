﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Data.ACC;
using MMIE.BusinessProcess.ACC;

namespace MMIE.SAL
{
    public partial class CheckOut : BasePage
    {
        DataSet ds = null;
        List<Order> lstOrder = null;
        DataSet dsOrderdetails = null;
        List<Customer> lstStore = null;
        const string VS_SEARCH = "VS_SEARCH";
        private Currency objCurrency = new Currency();
        private CurrencyBO objCurrencyBO = new CurrencyBO();
        private int Count = 1;
        private Table t;
        TextBox tb;
    //    CheckBox chk;


        protected void PagePermission()
        {
            if (LoginToken != null)
            {
              //  btnPrintReceipt.Enabled = LoginToken.IsPrintOn;
                btnsave.Enabled = LoginToken.IsAddOn;
                //if (LoginToken.IsCheckOut)
                //{
                //    lblError.Text = "Sorry You Are Checked Out Please Contact to your System Administrator for Checked In";
                //    btnsave.Enabled = false;
                //    btnSearch.Enabled = false;
                //    return;
                //}
                
                                
            }
        }


        private void BindPaymentDetails(string order)
        {
              PaymentDetailsBO objPaymentDetailsBO = new PaymentDetailsBO();
                    List<PaymentDetails> lstPaymentHistory = new List<PaymentDetails>();
                    lstPaymentHistory = objPaymentDetailsBO.GetPaymentDetailsListByOrderCR(order);
                    if (lstPaymentHistory != null)
                    {
                        grdTransaction.DataSource = lstPaymentHistory;
                        grdTransaction.DataBind();
                    }
        }

        private void BindBankDetails()
        {
            BankBO objPaymentDetailsBO = new BankBO();
            List<Bank> lstPaymentHistory = new List<Bank>();
            lstPaymentHistory = objPaymentDetailsBO.GetBankList(false);
            if (lstPaymentHistory != null)
            {
                ddlBank.DataSource = lstPaymentHistory;
                ddlBank.DataBind();

                ddlBank.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }

        protected void SearchOrderDetails()
        {
            Order objOrder = new Order();
            OrderBO objOrderBO = new OrderBO();

            objOrder.OrderNumber = txtSearchOrder.Text.Trim();
            objOrder.CustomerName = txtSearchCustomerName.Text.Trim();
            objOrder.CustomerPhone = txtSearchPhone.Text.Trim();

            List<Order> lstOrderDetails = new List<Order>();
            lstOrderDetails = objOrderBO.SearchActiveOrderList(objOrder);
            
            gvOrderSearch.DataSource = lstOrderDetails;
            gvOrderSearch.DataBind();

        
        }

      protected void  BindOrderDetails(string OrderNumber,int GroupType)
        {
            Order objOrder = new Order();
            OrderBO objOrderBO = new OrderBO();
            List<Order> lstOrderDetails = new List<Order>();
            objOrder.OrderNumber = OrderNumber;
            objOrder.GroupType = GroupType;
            lstOrderDetails = objOrderBO.SearchOrder(objOrder);


            if (lstOrderDetails != null && lstOrderDetails.Count > 0)
            {

                ddlCurrency.SelectedValue = lstOrderDetails[0].CurrencyID.ToString();
                ViewState["BillHeaderID"] = lstOrderDetails[0].BillHeaderID.ToString();
                ViewState["OrderNumber"] = lstOrderDetails[0].OrderNumber;
                ViewState["custid"] = lstOrderDetails[0].CustomerID;
               // CustomerLedgerID = lstOrderDetails[0].LedgerAccountID;
                txtGourdesConverter.Text = lstOrderDetails[0].CurrencyRate.ToString();
                BindCustomerDocumentDetail(lstOrderDetails[0].CustomerID);
                //New column currencyID is fetched and bind to the dropdown currency

                // btnPrintReceipt.Enabled = true;
               // ViewState["DueAmountGourdes"] = 0;
                if (lstOrderDetails[0].GroupType == 1)
                {

                    gvOrderVehicleDetail.DataSource = lstOrderDetails;
                    gvOrderVehicleDetail.DataBind();
                    txtTotAmount.Text = lstOrderDetails[0].TotalGrandTotalUSD.ToString();
                    txtGourdesAmount.Text = lstOrderDetails[0].TotalGrandTotalGourdes.ToString();

                    lblDepositInGourdes.Text = lstOrderDetails[0].OpeningBalance.ToString();
                    lblDepositInUSD.Text = lstOrderDetails[0].OpeningBalanceUSD.ToString();

                    lblCreditLimitInGourdes.Text = lstOrderDetails[0].MaxCreditLimit.ToString();
                    lblCreditLimitInUSD.Text = lstOrderDetails[0].MaxCreditLimitUSD.ToString();

                    lblDebtAmountInGourdes.Text = lstOrderDetails[0].DebtAmountGourdes.ToString();
                    lblDebtAmtInUSD.Text = lstOrderDetails[0].DebtAmountUSD.ToString();

                   // ViewState["DueAmountGourdes"] = lstOrderDetails[0].DueGrourdesAmount.ToString();
                    //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                    // txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                    txtTotalDueAmountUSD.Text = lstOrderDetails[0].DueUSDAmount.ToString();
                    txtTotalDueAmount.Text = lstOrderDetails[0].DueGrourdesAmount.ToString();
                  //  ddlPaymentMode.SelectedValue = lstOrderDetails[0].PaymentMode.ToString();
                    Remarks.Text = lstOrderDetails[0].Remarks;

                    ShowLabelControls(true);
                              PagePermission();
                    BindPaymentDetails(lstOrderDetails[0].OrderNumber);

              
                }
                else if (lstOrderDetails[0].GroupType == 2)
                {
                    gvOrderPartDetail.DataSource = lstOrderDetails;
                    gvOrderPartDetail.DataBind();
                    txtTotAmount.Text = lstOrderDetails[0].TotalGrandTotalUSD.ToString();
                    txtGourdesAmount.Text = lstOrderDetails[0].TotalGrandTotalGourdes.ToString();

                    lblDepositInGourdes.Text = lstOrderDetails[0].OpeningBalance.ToString();
                    lblDepositInUSD.Text = lstOrderDetails[0].OpeningBalanceUSD.ToString();

                    lblCreditLimitInGourdes.Text = lstOrderDetails[0].MaxCreditLimit.ToString();
                    lblCreditLimitInUSD.Text = lstOrderDetails[0].MaxCreditLimitUSD.ToString();

                    lblDebtAmountInGourdes.Text = lstOrderDetails[0].DebtAmountGourdes.ToString();
                    lblDebtAmtInUSD.Text = lstOrderDetails[0].DebtAmountUSD.ToString();

                   // ViewState["DueAmountGourdes"] = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                    //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                    // txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                    txtTotalDueAmountUSD.Text = lstOrderDetails[0].DueUSDAmount.ToString();
                    txtTotalDueAmount.Text = lstOrderDetails[0].DueGrourdesAmount.ToString();
                  //  ddlPaymentMode.SelectedValue = lstOrderDetails[0].PaymentMode.ToString();
                    Remarks.Text = lstOrderDetails[0].Remarks;
                    PagePermission();
                    ShowLabelControls(true);
                    BindPaymentDetails(lstOrderDetails[0].OrderNumber);
                }

                //  ViewState["custid"] = dsOrderdetails.Tables[0].Rows[0]["CustomerID"].ToString();

                //  int a =Convert.ToInt32(ViewState["custid"]);
            }
            else
            {
                t = (Table)Session["Files"];
                Count = (int)Session["Count"];
                phControls.Controls.Add(t);
                //Customer objcustOrdr = (Customer)Session[VS_SEARCH];
                //ds = SearchStore(objcustOrdr);
                //gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                //gvOrderSearch.DataBind();
                ShowError("No Records Found");


            }
        
        
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                if (!Page.IsPostBack)
                {
                  //  btnPrintReceipt.Enabled = false;
                    if (!IsPostBack)
                    {

                        t = new Table();
                        Session["Files"] = t;
                        Session["Count"] = Count;
                        BindCurrencyDropDown();
                        BindBankDetails();
                        //  BindLedgerGroup();
                    }
                    
                    else
                    {
                        t = (Table)Session["Files"];
                        Count = (int)Session["Count"];
                        phControls.Controls.Add(t);




                    }
                    #region Old Code Order load



                    //if (Request.QueryString["OrderNo"] != null && Request.QueryString["GroupType"] != null)
                    //{
                    //    if (Session[VS_SEARCH] != null)
                    //    {
                    //        Customer objCust = (Customer)Session[VS_SEARCH];
                    //        txtSearchOrder.Text = objCust.OrderNo;
                    //        txtSearchPhone.Text = objCust.CustomerPhone;
                    //        txtSearchCustomerName.Text = objCust.CustomerName;
                    //    }
                    //    else
                    //    {
                    //        Customer objCust =new Customer() ;
                    //        objCust.OrderNo = txtSearchOrder.Text;
                    //        objCust.CustomerPhone=txtSearchPhone.Text ;
                    //        objCust.CustomerName=txtSearchCustomerName.Text;
                    //        Session[VS_SEARCH] = objCust;
                    //    }

                    //    Currency objCurrency = new Currency();
                    //    CurrencyBO objCurBO = new CurrencyBO();
                    //    string OrderNo = Request.QueryString["OrderNo"].ToString();
                    //    int GroupType = Convert.ToInt32(Request.QueryString["GroupType"].ToString());
                    //    ViewState["OrderNo"] = OrderNo;
                    //    BindPaymentDetails(OrderNo);
                    //    txtSearchOrder.Text = OrderNo;
                    //    Customer objCustomer = new Customer();
                    //    objCustomer.OrderNo = OrderNo;
                    //    objCustomer.GroupType = GroupType;
                    //    dsOrderdetails = BindOrderDetail(objCustomer);
                    //    //-----------------get customer id------------------
                    //    Order objOrder = new Order();
                    //    objOrder.OrderNumber = OrderNo;
                    //    objOrder.GroupType = Convert.ToInt32(Request.QueryString["GroupType"]);
                    //    ds = SearchOrder(objOrder);
                    //    if (Request.QueryString["cust"] != null)
                    //    {
                    //        ViewState["custid"] = Convert.ToInt32(Request.QueryString["cust"]);
                    //        BindCustomerDocumentDetail(Convert.ToInt32(ViewState["custid"]));
                    //    }
                    //    if (ds.Tables[0].Rows.Count > 0)
                    //    {
                    //        ViewState["custid"] = ds.Tables[0].Rows[0]["CustomerID"].ToString();
                    //        BindCustomerDocumentDetail(Convert.ToInt32(ViewState["custid"]));

                    //    }
                    //    //----------------------------
                    //    if (dsOrderdetails.Tables[0].Rows.Count > 0)
                    //    {

                    //        ddlCurrency.SelectedValue = ds.Tables[0].Rows[0]["CurrencyID"].ToString();
                    //        ViewState["BillHeaderID"] = ds.Tables[0].Rows[0]["BillHeaderID"].ToString();
                    //        objCurrency = objCurBO.GetCurrencyByID(Convert.ToInt32(ddlCurrency.SelectedValue));
                    //        txtGourdesConverter.Text = ds.Tables[0].Rows[0]["CurrencyRate"].ToString();
                    //        //New column currencyID is fetched and bind to the dropdown currency

                    //       // btnPrintReceipt.Enabled = true;
                    //        ViewState["DueAmountGourdes"] = 0;
                    //        if (GroupType == 1)
                    //        {

                    //            gvOrderVehicleDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                    //            gvOrderVehicleDetail.DataBind();
                    //            txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalUSDAmt"].ToString();
                    //            txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGourdesAmt"].ToString();

                    //            lblDepositInGourdes.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalance"].ToString();
                    //                lblCreditLimitInGourdes.Text = dsOrderdetails.Tables[0].Rows[0]["MaxCreditLimit"].ToString();
                    //                lblDebtAmountInGourdes.Text = dsOrderdetails.Tables[0].Rows[0]["DebtAmountGourdes"].ToString();

                    //                lblDepositInUSD.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalanceUSD"].ToString();
                    //                lblCreditLimitInUSD.Text = dsOrderdetails.Tables[0].Rows[0]["MaxCreditLimitUSD"].ToString();
                    //                lblDebtAmtInUSD.Text = dsOrderdetails.Tables[0].Rows[0]["DebtAmountUSD"].ToString();


                    //            ViewState["DueAmountGourdes"] = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                    //            //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                    //            // txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                    //            txtTotalDueAmountUSD.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                    //            txtTotalDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                    //            ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString();
                    //            Remarks.Text = dsOrderdetails.Tables[0].Rows[0]["RemarksCheckout"].ToString();
                    //            Customer objcustOrdr = (Customer)Session[VS_SEARCH];

                    //            //objOrder.OrderNumber = objcustOrdr.OrderNo;
                    //            //objOrder.CustomerName = objcustOrdr.CustomerName;
                    //            //objOrder.CustomerPhone = objcustOrdr.CustomerPhone;
                    //            //Changed to search order
                    //            ds = SearchStore(objcustOrdr);
                    //            //ds = SearchOrder(objOrder);
                    //            gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                    //            gvOrderSearch.DataBind();
                    //            PagePermission();
                    //            ShowLabelControls(true);
                    //        }
                    //        else if (GroupType == 2)
                    //        {
                    //            gvOrderPartDetail.DataSource = dsOrderdetails.Tables[0].DefaultView;
                    //            gvOrderPartDetail.DataBind();
                    //            txtTotAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalUSDAmt"].ToString();
                    //            txtGourdesAmount.Text = dsOrderdetails.Tables[0].Rows[0]["TotalGourdesAmt"].ToString();

                    //                lblDepositInGourdes.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalance"].ToString();
                    //                lblCreditLimitInGourdes.Text = dsOrderdetails.Tables[0].Rows[0]["MaxCreditLimit"].ToString();
                    //                lblDebtAmountInGourdes.Text = dsOrderdetails.Tables[0].Rows[0]["DebtAmountGourdes"].ToString();


                    //                lblDepositInUSD.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalanceUSD"].ToString();
                    //                lblCreditLimitInUSD.Text = dsOrderdetails.Tables[0].Rows[0]["MaxCreditLimitUSD"].ToString();
                    //                lblDebtAmtInUSD.Text = dsOrderdetails.Tables[0].Rows[0]["DebtAmountUSD"].ToString();

                    //            // txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                    //            //txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();
                    //            txtTotalDueAmountUSD.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                    //            txtTotalDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                    //            ViewState["DueAmountGourdes"] = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                    //            ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString();
                    //            Remarks.Text = dsOrderdetails.Tables[0].Rows[0]["RemarksCheckout"].ToString();

                    //            //Changed to Search the order
                    //             Customer objcustOrdr = (Customer)Session[VS_SEARCH];

                    //            //objOrder.OrderNumber = objcustOrdr.OrderNo;
                    //            //objOrder.CustomerName = objcustOrdr.CustomerName;
                    //            //objOrder.CustomerPhone = objcustOrdr.CustomerPhone;
                    //            //ds = SearchOrder(objOrder);
                    //             ds = SearchStore(objcustOrdr);
                    //            gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
                    //            gvOrderSearch.DataBind();
                    //            PagePermission();
                    //            ShowLabelControls(true);
                    //        }

                    //        //  ViewState["custid"] = dsOrderdetails.Tables[0].Rows[0]["CustomerID"].ToString();

                    //        //  int a =Convert.ToInt32(ViewState["custid"]);
                    //    }

                    #endregion

                    //}

                }
             
            }

            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Loading Checkout Details : " + ex.Message;  

      

            }

        }
      
        //private DataSet SearchOrder(Order objOrder)
        //{
        //    //Call service operation to get data from database source
        //    OrderBO odr = new OrderBO();
        //    lstOrder = odr.SearchOrder(objOrder);
        //    //    lstCustomer  = UserAdminServiceAgent.SearchCustomer(objCustomer);
        //    DataTable dt = ORHelper<Order>.GenericListToDataTable(lstOrder);
        //    ds = new DataSet();
        //    ds.Tables.Add(dt);
        //    return ds;
        //}
        protected void BindCurrencyDropDown()
        {
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlCurrency.SelectedIndex = 1;
                txtGourdesConverter.Text = ddlCurrency.SelectedValue.ToString();

            }
            catch (Exception ex)
            {

                lblError.Text = "Error : " + ex.Message;
            }

        }
        protected void ddlCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlCurrency.SelectedIndex > 0 && txtTotAmount.Text.Length > 0)
                {
                    int i = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());
                    if (i > 0)
                    {
                        objCurrency = objCurrencyBO.GetCurrencyByID(i);
                    }
                    txtGourdesConverter.Text = objCurrency.Rate.ToString(".00");
                  }
                else
                {
                    txtGourdesConverter.Text = "";
                  
                }

                //if (ddlPaymentMode.SelectedValue == "Check" || ddlPaymentMode.SelectedValue == "Card")
                //{
                //    PaymentDetails.Visible = true;
                //}
                //      else
                //    PaymentDetails.Visible = false;

               
            }
            catch (FormatException)
            {
                lblError.Text = "Enter a valid amount";

            }
            catch (Exception ex)
            {
                lblError.Text = "Error : " + ex.Message;

            }


        }
        protected void ShowError(string a_sMsg)
        {
            errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            if (a_sMsg.Length > 0)
            {
                errorMessage.Visible = true;
            }
            else
            {
                errorMessage.Visible = false;
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {

            SearchOrderDetails();
          //  Session[VS_SEARCH] = null;
          //  dsOrderdetails = null;
          //  Customer objCustomer = new Customer();
          //  objCustomer.OrderNo = txtSearchOrder.Text.Trim();
          //  objCustomer.CustomerName = txtSearchCustomerName.Text.Trim();
          //  objCustomer.CustomerPhone = txtSearchPhone.Text.Trim();
          //  Session[VS_SEARCH] = objCustomer;
          //  ds = SearchStore(objCustomer);
         
            
          //if (ds.Tables[0].Rows.Count > 0)
          //  {
          //      gvOrderSearch.DataSource = ds.Tables[0].DefaultView;
          //      gvOrderSearch.DataBind();
          //     // gvOrderPartDetail.Visible = true;
          //    //  gvOrderVehicleDetail.Visible = true;
          //      gvOrderSearch.Visible = true;
          //      if (ds.Tables[0].Rows.Count == 1)
          //      {
          //          string OrderNo = ds.Tables[0].Rows[0]["OrderNo"].ToString();
          //          int GroupType = Convert.ToInt32(ds.Tables[0].Rows[0]["GroupType"].ToString());
          //        //  int BillHeaderID = Convert.ToInt32(ds.Tables[0].Rows[0]["MaxBillHeaderID"].ToString());
          //          //ViewState["BillHeaderID"] = BillHeaderID;


          //          ViewState["custid"] = Convert.ToInt32(ds.Tables[0].Rows[0]["CustomerID"].ToString());
          //          string path = "CheckOut.aspx?OrderNo=" + OrderNo.ToString().Trim() + "&GroupType=" + GroupType + "&cust=" + Convert.ToInt32(ds.Tables[0].Rows[0]["CustomerID"].ToString());

          //         Response.Redirect(path);



          //      }
          //  //    ShowLabelControls(true);
          //  }
          //  else
          //  {
          //      ShowError("No Records Found");
          //      gvOrderPartDetail.Visible = false;
          //      gvOrderVehicleDetail.Visible = false;
          //      gvOrderSearch.Visible = false;
          //      ShowLabelControls(false);
          //  }
        }

        //private DataSet SearchStore(Customer objStore)
        //{
        //    //Call service operation to get data from database source
        //    PartBO st = new PartBO();
        //    lstStore = st.CheckOutSearchStore(objStore);
        //    DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
        //    ds = new DataSet();
        //    ds.Tables.Add(dt);
        //    return ds;
        //}


        //private DataSet BindOrderDetail(Customer objStore)
        //{
        //    //Call service operation to get data from database source
        //    PartBO st = new PartBO();
        //    lstStore = st.BindOrderDetail(objStore);
        //    DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
        //    ds = new DataSet();
        //    ds.Tables.Add(dt);
        //    return ds;
        //}
        //public string MakeCustomerIDLink(string OrderNo, int GroupType, int CustID)
        //{
        //    string ret;
        //    string str;
        //    string pageName;
        //    pageName = "CheckOut.aspx";
        //    str = pageName + "?OrderNo=" + OrderNo.ToString().Trim() + "&GroupType=" + GroupType + "&cust=" + CustID;
        //    ret = "<a href=\"" + str + "\">" + OrderNo + "</a>";
           
        //    return ret;
        //}

        private void ShowLabelControls(bool flag)
        {
            lblNetAmount0.Visible = flag;
            txtTotAmount.Visible = flag;
            lblGourdesAmount.Visible = flag;
            txtGourdesAmount.Visible = flag;
            //lblUSDDueAmount.Visible = flag;
            //txtUSDDueAmount.Visible = flag;
            //lblGourdesDueAmount.Visible = flag;
            //txtGourdesDueAmount.Visible = flag;
            //lblUSDPaidAmount.Visible = flag;
            //txtUSDPaidAmount.Visible = flag;
            //lblGourdesPaidAmount.Visible = flag;
            //txtGourdesPaidAmount.Visible = flag;
            lblpaymentMode.Visible = flag;
            ddlPaymentMode.Visible = flag;
            lblCurrency.Visible = flag;
            ddlCurrency.Visible = flag;
            txtGourdesConverter.Visible = flag;
            ShowDetails.Visible = flag;
            ddlBank.Visible = flag;
            
            txtPaymentExpirationDate.Visible = flag;
            txtPaymentModeNo.Visible = flag;
           
            //txtTotalDueAmount.Visible = flag;
            //txtTotalDueAmountUSD.Visible = flag;
            //lblTotalDueAmount.Visible = flag;
            //lblTotalDueAmountUSD.Visible = flag;

            PaymentDetailsHistory.Visible = flag;

        }
        protected void btnsave_Click(object sender, EventArgs e)
        {
            //PartBO st = new PartBO();
            //Customer objCust = new Customer();
          
            bool status = false;    
            int BillHeaderID = 0;
          
                #region Save Payment Details
            

                    PaymentDetails objPaymentDetails = new PaymentDetails();

                    PaymentDetailsBO objPaymentBO = new PaymentDetailsBO();
                    if (ViewState["BillHeaderID"] != null && ViewState["OrderNumber"] != null)
                    {
                        BillHeaderID = Convert.ToInt32(ViewState["BillHeaderID"].ToString());
                        objPaymentDetails.OrderNumber = ViewState["OrderNumber"].ToString();
                        //objPaymentDetails.ShipID = "SH" + BillHeaderID;
                    }
                    else
                    {
                        lblError.Text = "Invalid Order Selected";
                        return;
                    }
                    

                   
                    if (ddlPaymentMode.SelectedItem.Text== "Deposit")
                    {

                                objPaymentDetails.SalesStatus = Convert.ToInt16(ddlStatus.SelectedValue);
                                if (txtAdjustAmountUSD.Text != "")
                                objPaymentDetails.PaidUSDAmt = Convert.ToDecimal(txtAdjustAmountUSD.Text.Trim()); // Convert.ToDecimal(txtUSDPaidAmount.Text.Trim());
                                if(txtTotalDueAmountUSD.Text !="")
                                objPaymentDetails.DueUSDAmt = Convert.ToDecimal(txtTotalDueAmountUSD.Text.Trim())- objPaymentDetails.PaidUSDAmt; //Convert.ToDecimal(txtUSDDueAmount.Text.Trim());
                                if (txtAdjustAmount.Text != "")
                                objPaymentDetails.PaidGourdesAmt = Convert.ToDecimal(txtAdjustAmount.Text.Trim()); //Convert.ToDecimal(txtGourdesPaidAmount.Text.Trim());
                                if(txtTotalDueAmount.Text!="")
                                objPaymentDetails.DueGourdesAmt = Convert.ToDecimal(txtTotalDueAmount.Text.Trim()) - objPaymentDetails.PaidGourdesAmt; // Convert.ToDecimal(txtGourdesDueAmount.Text.Trim());
                                // status = st.SaveBulkShipNumber(objCust);
                    }
            else
                    {
                        objPaymentDetails.SalesStatus = Convert.ToInt16(ddlStatus.SelectedValue);
                        //objPaymentDetails.OrderNumber = Request.QueryString["OrderNo"].ToString();
                        if (txtTotalDueAmountUSD.Text != "")
                        {
                            objPaymentDetails.DueUSDAmt = Convert.ToDecimal(txtTotalDueAmountUSD.Text.Trim());
                            objPaymentDetails.PaidUSDAmt = Convert.ToDecimal(txtTotalDueAmountUSD.Text.Trim()); // Convert.ToDecimal(txtUSDPaidAmount.Text.Trim());
                        }
                        if (txtTotalDueAmount.Text != "")
                        {
                            objPaymentDetails.DueGourdesAmt = Convert.ToDecimal(txtTotalDueAmount.Text.Trim());
                            objPaymentDetails.PaidGourdesAmt = Convert.ToDecimal(txtTotalDueAmount.Text.Trim()); //Convert.ToDecimal(txtGourdesPaidAmount.Text.Trim());
                        }       
                       // objPaymentDetails.DueUSDAmt = 0; //Convert.ToDecimal(txtUSDDueAmount.Text.Trim());
                       // objPaymentDetails.DueGourdesAmt = 0; // Convert.ToDecimal(txtGourdesDueAmount.Text.Trim());
                       //// status = st.SaveBulkShipNumber(objCust);
                    }

                    decimal amount = ddlCurrency.SelectedValue.ToString()=="1"?objPaymentDetails.PaidGourdesAmt:(objPaymentDetails.PaidGourdesAmt* Convert.ToDecimal(txtGourdesConverter.Text));
                    
                    objPaymentDetails.BillHeaderID = BillHeaderID;
                    objPaymentDetails.PaymentModeNo = txtPaymentModeNo.Text;
                    objPaymentDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                    objPaymentDetails.CompanyID = (Int16)LoginToken.CompanyID;
                    objPaymentDetails.AddedBy = LoginToken.LoginId;

                    objPaymentDetails.CustomerID = Convert.ToInt32(ViewState["custid"].ToString());
                    objPaymentDetails.BillHeaderID = BillHeaderID;
                    objPaymentDetails.IsChecked = false;
                    objPaymentDetails.IsSafeBox = false;
                    objPaymentDetails.ParentID = 0;
                    if (ddlBank.SelectedIndex > 0)
                    {
                        objPaymentDetails.BankID = Convert.ToUInt16(ddlBank.SelectedValue.ToString());
                    }

                    if (txtPaymentExpirationDate.Text != "")
                    {
                        objPaymentDetails.Expirationdate = Convert.ToDateTime(txtPaymentExpirationDate.Text);
                    }

                //    objPaymentDetails.OrderNumber = Request.QueryString["OrderNo"].ToString();
                    objPaymentDetails.PaymentMode = ddlPaymentMode.SelectedItem.ToString();
                    objPaymentDetails.PaymentSourceID = int.Parse(ddlPaymentMode.SelectedValue); // Added by ankit for source id detail
                    objPaymentDetails.IsActive = true;
                    objPaymentDetails.ActionType = EnumActionType.Insert;
                    //if (txtCodeNo.Text != "")
                    //{
                    //    objPaymentDetails.AuthorizationNo = Convert.ToInt32(txtCodeNo.Text);
                    //}
                    if (ddlPaymentMode.SelectedItem.Text != "Check" && ddlPaymentMode.SelectedItem.Text != "Card")
                    {
                        objPaymentDetails.Expirationdate = System.DateTime.Now;

                    }


                    //if (ViewState["BillHeaderID"] != null)
                    //    objPaymentDetails.BillHeaderID = Convert.ToInt32(ViewState["BillHeaderID"]);
                    objPaymentDetails.TType = "CR";
                    objPaymentDetails.Remarks = "Payment Received for : " + objPaymentDetails.OrderNumber;

                    objPaymentDetails.TransactionType = "Checkout";
                    objPaymentDetails.CurrencyID =   ddlCurrency.SelectedIndex>0?Convert.ToInt32(ddlCurrency.SelectedValue.ToString()):0;
                    objPaymentDetails.IsSales = true;
                    objPaymentDetails.CurrencyRate = Convert.ToDecimal(txtGourdesConverter.Text);
                    objPaymentDetails.PurchaseOrderID = 0;
                    objPaymentDetails.RemarksCheck = Remarks.Text;
                    if (ViewState["BillHeaderID"] != null)
                    {
                        status = objPaymentBO.SaveBillPaymentDetails(objPaymentDetails);
                    }
                        #endregion
                    
                    
                    if (status)
                    {
                        lblError.Text = ExceptionMessage.GetMessage("STR7000001");
                        lblError.Visible = true;
                        //btnPrintReceipt.Enabled = true;
                        btnsave.Enabled = false;
                        ShowDetails.Visible = false;
                        ViewState["BillHeaderID"] = null;
                        Session[VS_SEARCH] = null;
                       // SaveLedgerEntry(objPaymentDetails.OrderNumber,amount);

                        BindPaymentDetails(objPaymentDetails.OrderNumber);
                        PaymentDetailsHistory.Visible = true;

                    }
                    else
                    {
                        lblError.Text = "Error While Saving Payment Details";
                    }



                
                

                //else
                //{
                //    lblError.Text = "No Payment Applicable";
                //}
      
                
            }
        

        protected void btnPrintReceipt_Click(object sender, EventArgs e)
        {
            Response.Redirect("Report/SaleReport.aspx?ReportType=Receipt&id=" + txtSearchOrder.Text.Trim() + "");
        }

        protected void grdTransaction_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (Request.QueryString["OrderNo"] != null && Request.QueryString["GroupType"] != null)
            {
                string OrderNo = ViewState["OrderNumber"].ToString();


                grdTransaction.PageIndex = e.NewPageIndex;
                BindPaymentDetails(OrderNo);
            }

        }

        #region Get Customer Document By Customer Id
        private void addfiletable()
        {
            t = new Table();
            t.Rows.Clear();
            t.BorderStyle = BorderStyle.Solid;

            TableHeaderRow th = new TableHeaderRow();
            th.BorderStyle = BorderStyle.Solid;
            TableCell c1 = new TableCell();
            c1.Text = "S.No.";
            c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

            TableCell c2 = new TableCell();
            c2.Text = "Uploaded Files";
            c2.Style.Add(HtmlTextWriterStyle.Width, "25%");

            //TableCell c3 = new TableCell();
            //c3.Text = "Document Type";
            //c3.Style.Add(HtmlTextWriterStyle.Width, "8%");
            //c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c4 = new TableCell();
            c4.Text = "Document ID";
            c4.Style.Add(HtmlTextWriterStyle.Width, "20%");
            c4.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c5 = new TableCell();
            c5.Text = "Remarks";
            c5.Style.Add(HtmlTextWriterStyle.Width, "10%");
            c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");

            


            th.Cells.Add(c1);
            th.Cells.Add(c2);
          
            th.Cells.Add(c4);
            th.Cells.Add(c5);
    



            Style myStyle = new Style();
            myStyle.ForeColor = System.Drawing.Color.Black;
            myStyle.BackColor = System.Drawing.Color.LightGray;
            myStyle.Font.Bold = true;
            myStyle.BorderStyle = BorderStyle.Solid;

            th.ApplyStyle(myStyle);
            // th.Font.Size =Unit.Percentage(12);
            th.BorderStyle = BorderStyle.Solid;
            th.BorderWidth = Unit.Pixel(1);

            t.Rows.Add(th);

        }
        private void BindCustomerDocumentDetail(int id)
        {
            //CheckBox chk;
            CustomerBO objCust = new CustomerBO();
            List<CustomerDocument> lst = new List<CustomerDocument>();
            lst = objCust.SearchCustomerDocument(id);
            addfiletable();
            t.Rows.Clear();
            addfiletable();

            Count = 1;
            foreach (CustomerDocument obj in lst)
            {

                HyperLink lnk = new HyperLink();
                lnk.EnableViewState = true;
                lnk.ID = "lnk" + Count.ToString();
                lnk.Text = obj.FriendlyName;
                lnk.NavigateUrl = "~/CustomerScanID/" + obj.CustomerID.ToString() + "/" + obj.CustomerScanID;
                lnk.Visible = true;
                lnk.Target = "_blank";

                tb = new TextBox();
                tb.EnableViewState = true;
                tb.ID = "txt" + Count.ToString();
                tb.MaxLength = 150;
                tb.Text = obj.CustomerDescription;
                tb.Enabled = false;


                //chk = new CheckBox();
                //chk.Checked = true;
                //chk.ID = "chk" + Count.ToString();
                //chk.Enabled = false;

                //Label Uid = new Label();
                //Uid.EnableViewState = true;
                //Uid.ID = "label2" + Count.ToString();
                //Uid.Text = Convert.ToString(obj.ScanID);
                //Uid.Visible = false;


                Label uName = new Label();
                uName.EnableViewState = true;
                uName.ID = "label3" + Count.ToString();
                uName.Text = obj.CustomerScanID;
                uName.Visible = false;



                TableRow dr = new TableRow();
                TableCell c1 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();
                //TableCell c5 = new TableCell();
                TableCell C6 = new TableCell();
                TableCell c7 = new TableCell();
                //TableCell c8 = new TableCell();
                TableCell c9 = new TableCell();

                //Label DocType = new Label();
                //DocType.EnableViewState = true;
                //DocType.ID = "lblDocType" + Count.ToString();
                //DocType.Text = obj.DocumentType;
                //DocType.Visible = true;


                Label DocID = new Label();
                DocID.EnableViewState = true;
                DocID.ID = "lblDocID" + Count.ToString();
                DocID.Text = obj.DocumentID;
                DocID.Visible = true;

                //c8.Controls.Add(DocType);
                c9.Controls.Add(DocID);


                c7.Controls.Add(uName);
                //c8.Controls.Add(filePath);

                c3.Text = "File" + Count.ToString(); ;
                c3.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //  c1.Style.Add(HtmlTextWriterStyle.Width, "30%");
                TableCell c2 = new TableCell();
                //   c2.Style.Add(HtmlTextWriterStyle.Width, "30%");
                //   c4.Style.Add(HtmlTextWriterStyle.Width, "4%");
                //   c5.Style.Add(HtmlTextWriterStyle.Width, "2%");
                c2.Controls.Add(tb);
                c1.Controls.Add(lnk);
                //c5.Controls.Add(chk);
                //C6.Controls.Add(Uid);

                c1.Style.Add(HtmlTextWriterStyle.Width, "25%");
                c2.Style.Add(HtmlTextWriterStyle.Width, "5%");

                //  c3.Style.Add(HtmlTextWriterStyle.Width, "3%");
                c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                //c8.Style.Add(HtmlTextWriterStyle.Width, "8%");
                //c8.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c9.Style.Add(HtmlTextWriterStyle.Width, "20%");
                c9.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                //c5.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");


                dr.Cells.Add(c3);
                dr.Cells.Add(c1);
                //dr.Cells.Add(c8);
                dr.Cells.Add(c9);
                // dr.Cells.Add(c4);
                dr.Cells.Add(c2);
                //dr.Cells.Add(c5);
                dr.Cells.Add(C6);
                dr.Cells.Add(c7);

                Style myStyle = new Style();
                myStyle.ForeColor = System.Drawing.Color.Black;
                myStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                myStyle.Font.Bold = false;


                c1.ApplyStyle(myStyle);
                //c8.ApplyStyle(myStyle);
                c3.ApplyStyle(myStyle);
                c9.ApplyStyle(myStyle);
                //c5.ApplyStyle(myStyle);
                c2.ApplyStyle(myStyle);

                t.Rows.Add(dr);
                phControls.Controls.Add(t);
                Count++;

            }
            phControls.Controls.Add(t);
            Session["Files"] = t;
            Session["Count"] = Count;

        }

        #endregion 

        protected void gvOrderSearch_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdTransaction_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ViewState["BillHeaderID"] = null;
            Session[VS_SEARCH] = null;
            ViewState["OrderNo"] = null;
            ViewState["custid"] = null;
            Session["Files"] = null;
            Session["Count"] = null;
            Response.Redirect("~/SAL/CheckOut.aspx");
        }


        //#region  Account Entry

        //private int CustomerLedgerID
        //{
        //    get
        //    {
        //        int x;
        //        Int32.TryParse(hdnCustomerLedgerID.Value, out x);
        //        return x;
        //    }

        //    set { hdnCustomerLedgerID.Value = Convert.ToString(value); }

        //}


        //private void BindLedgerAccountList()
        //{
        //    try
        //    {
        //        LedgerHeader objLedgerHeader = new LedgerHeader();
        //        LedgerHeaderBO objLedgerHeaderBO = new LedgerHeaderBO();
        //        List<LedgerHeader> lstLedgerHeader = new List<LedgerHeader>();
        //        objLedgerHeader.IsActive = true;
        //        objLedgerHeader.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
        //        objLedgerHeader.AccountGroupID = Convert.ToInt32(ddlLedgerGroup.SelectedValue.ToString());

        //        lstLedgerHeader = objLedgerHeaderBO.GetSearchLedgerHeader(objLedgerHeader);
        //        objLedgerHeader.IsActive = true;
        //        ddlLedgerName.DataSource = lstLedgerHeader;
        //        ddlLedgerName.DataValueField = "LedgerAccountID";
        //        ddlLedgerName.DataTextField = "AccountName";
        //        ddlLedgerName.DataBind();
        //        ddlLedgerName.Items.Insert(0, new ListItem("--Select--", "--Select--"));
        //    }
        //    catch (Exception Ex)
        //    {
        //        lblError.Text = "Error While Fetching Bank Account List : " + Ex.Message;
        //    }
        //}
        //private void BindLedgerGroup(string Search)
        //{
        //    AccountGroup objAccountGroup = new AccountGroup();
        //    AccountGroupBO objAccountGroupBO = new AccountGroupBO();
        //    List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
        //    objAccountGroup.CompanyID = LoginToken.CompanyID;
        //    objAccountGroup.GroupName = Search;

        //    objAccountGroup.IsActive = true;
        //    lstAccountGroup = objAccountGroupBO.GetSearchAccountGroup(objAccountGroup);
        //    ddlLedgerGroup.DataSource = lstAccountGroup;
        //    ddlLedgerGroup.DataValueField = "AccountGroupID";
        //    ddlLedgerGroup.DataTextField = "GroupName";
        //    ddlLedgerGroup.DataBind();
        //    ddlLedgerGroup.Items.Insert(0, new ListItem("--Select--", "--Select--"));
        //    ddlLedgerName.Items.Clear();

        //}

        //protected void ddlLedgerGroup_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    BindLedgerAccountList();

        //}


        //protected bool SaveLedgerEntry(string Order, decimal Amount)
        //{
        //    bool result = false;  
            

        //    JournalDetails objJournalDetails = new JournalDetails();
        //    JournalDetailsBO objJournalDetailsBO = new JournalDetailsBO();

        //    objJournalDetails.Details = "Payment Recieved for " + Order + " : " + txtMemoNote.Text;
        //    objJournalDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
        //    objJournalDetails.CompanyID = (Int16)LoginToken.CompanyID;
        //    objJournalDetails.ActionType = EnumActionType.Insert;
        //    objJournalDetails.EntryDate = System.DateTime.Now.ToShortDateString();
        //    objJournalDetails.AddedBy = LoginToken.LoginId;
        //    objJournalDetails.IsActive = true;
        //    objJournalDetails.IsLocked = false;


        //    List<JournalDetails> lstJournalDetails = new List<JournalDetails>();
        //    JournalDetails objJournalDetailsNew;

        //    //To prepare Debit entry collection 
        //    //Read values one by one from Grid


        //    #region To prepare debit entry details

        //    objJournalDetailsNew = new JournalDetails();
        //    objJournalDetailsNew.JournalDetailsID = 0;
        //    //Get LedgerAccountID for pay order to From dataKeyValues
        //    objJournalDetailsNew.LedgerAccountID = Convert.ToInt32(ddlLedgerName.SelectedValue.ToString());
        //    objJournalDetailsNew.TType = "DR";
        //    objJournalDetailsNew.LF = "";
        //    objJournalDetailsNew.DebitAmount = Amount;
        //    objJournalDetailsNew.CreditAmount = 0;
        //    //Adding the object to the JournalDetails collection
        //    lstJournalDetails.Add(objJournalDetailsNew);

        //    #endregion


        //    #region To prepare creadit entry details

        //    objJournalDetailsNew = new JournalDetails();
        //    objJournalDetailsNew.JournalDetailsID = 0;
        //    //Get LedgerAccountID for pay order to From dataKeyValues
        //    objJournalDetailsNew.LedgerAccountID = Convert.ToInt32(CustomerLedgerID);
        //    objJournalDetailsNew.TType = "CR";
        //    objJournalDetailsNew.LF = "";
        //    objJournalDetailsNew.DebitAmount = 0;

        //    objJournalDetailsNew.CreditAmount = Amount;
        //    //Adding the object to the JournalDetails collection
        //    lstJournalDetails.Add(objJournalDetailsNew);
        //    #endregion
          
     


        //    //Creating XML for Credit/Debit transactions
        //    objJournalDetails.XMLData = XMLConverter.JournalDetailsListToXML(lstJournalDetails).ToString();

        //    //Inserting transaction to JournalDetails table
        //    if (objJournalDetailsBO.SaveJournalEntry(objJournalDetails))
        //    {
        //        lblError.Text = "Ledger Transaction for sales added successfully.";
        //        result = true;

        //    }
        //    return result;

        //}

        //#endregion

        protected void gvOrderSearch_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ShowDetails")
            {
                int Index = Convert.ToInt32(e.CommandArgument.ToString());

                LinkButton lnk = (LinkButton)gvOrderSearch.Rows[Index].FindControl("lnkOrderNo");
                Label lbl = (Label)gvOrderSearch.Rows[Index].FindControl("lblGroupType");

                BindOrderDetails(lnk.Text, Convert.ToInt32(lbl.Text));


                // BindVehicalList(Index);


            }


        }

        protected void ddlPaymentMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlPaymentMode.SelectedValue == "2")
            {
                lblModeNo.Text = "Check No";
                lblDueDate.Text = "Check Due Date";
            }
            else if (ddlPaymentMode.SelectedValue == "3")
            {
                lblModeNo.Text = "Card No";
                lblDueDate.Text = "Card Expiration Date";
            }
            //int x = 0;

            //Int32.TryParse(ddlPaymentMode.SelectedValue.ToString(), out x);

            //if (x == 1)
            //{
            //    BindLedgerGroup("Cash");
            //}else if (x == 2)
            //{
            //    BindLedgerGroup("Bank");
            //}
            //else if (x ==3 )
            //{
            //    BindLedgerGroup("Card");
            //}
            //else if (x == 4)
            //{
            //    BindLedgerGroup("Deposit");
            //}


         
        }
 
    }
}