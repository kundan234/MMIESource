﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.SAL.Report
{
    public partial class CustomerDepositReport : BasePage
    {

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                txtEndDate.Enabled = LoginToken.IsChangeDateOn;
                txtStartDate.Enabled = LoginToken.IsChangeDateOn;
                btnPrint.Enabled = LoginToken.IsPrintOn;
                txtEndDate.Text = System.DateTime.Now.ToShortDateString();
                txtStartDate.Text = System.DateTime.Now.ToShortDateString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
            PagePermission();
        }

      

        private void BindCustomer(int id)
        {
            try
            {

                CustomerBO objCustomerBO = new CustomerBO();
                Customer objCustomer = new Customer();
                objCustomer.CustomerID = id;

                objCustomer = objCustomerBO.GetCustomerByID(objCustomer);
                txtCustomer.Text = objCustomer.CustomerName;
                txtPhone.Text = objCustomer.CustomerPhone;
                txtFaxno.Text = objCustomer.CustomerFax;
                txtEmail.Text = objCustomer.CustomerEmail;
                txtAddress.Text = objCustomer.CustomerAddress;
                txtCity.Text = objCustomer.CityName;
                txtCountry.Text = objCustomer.CountryName;
                txtWebsite.Text = objCustomer.CustomerWebsite;
                //lblOpeningBalance.Text = Convert.ToString(objCustomer.OpeningBalance);
                //lblOpeningBalanceUSD.Text = Convert.ToString(objCustomer.OpeningBalanceUSD);

                //            txtStreet.Text=objCustomer.a

                if (objCustomer.StatusType)
                {
                    rbtStatus.SelectedIndex = 0;

                }
                else
                {
                    rbtStatus.SelectedIndex = 1;
                }

                rbtStatus.Enabled = false;
                ////lblCreditLimit.Text = objCustomer.MaxCreditLimit.ToString();
                ////lblCreditLimitUSD.Text = objCustomer.MaxCreditLimitUSD.ToString() + "$";

                //  txtCustomer.ReadOnly = true;
                txtPhone.ReadOnly = true;
                txtFaxno.ReadOnly = true;
                txtEmail.ReadOnly = true;
                txtAddress.ReadOnly = true;
                txtCity.ReadOnly = true;
                txtCountry.ReadOnly = true;
                txtWebsite.ReadOnly = true;
                ViewState["CustomerID"] = objCustomer.CustomerID;
                ViewState["OpeningBalance"] = objCustomer.OpeningBalance;
                ViewState["OpeningBalanceUSD"] = objCustomer.OpeningBalanceUSD;
                hdnBranch.Value = objCustomer.CompanyID.ToString();

                txtID.Text=objCustomer.CustomerID.ToString();
                //BindDepositTransaction();
                
            }
            catch (Exception ex)
            {

                lblError.Text = "Error while fetching Customer Record : " + ex.Message;
            }
        }

        private void ClearAll()
        {

            ViewState["CustomerID"] = 0;
            ViewState["OpeningBalance"] = 0;
            ViewState["OpeningBalanceUSD"] = 0;
            txtPhone.Text= "";
            txtFaxno.Text = "";
            txtEmail.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            txtCountry.Text = "";
            txtWebsite.Text = "";
            //txtAmount.Text = "";
            //lblAmountUSD.Text = "";
            //lblCreditLimit.Text = "";
            //lblCreditLimitUSD.Text = "";
            //txtCustomer.Text = "";
            //lblOpeningBalance.Text = "";
            //lblOpeningBalanceUSD.Text = "";
            
        }




        //private void BindDepositTransaction()
        //{
        //    try
        //    {

        //        DepositTransactionBO objDepositBO = new DepositTransactionBO();
        //        List<DepositTransaction> lstDeposit = new List<DepositTransaction>();

        //        if (ViewState["CustomerID"] != null)
        //        {
        //            lstDeposit = objDepositBO.GetDepositTransactionList((int)ViewState["CustomerID"]);

        //        }

        //        //grdDepositTransaction.DataSource = lstDeposit;
        //        //grdDepositTransaction.DataBind();
        //    }
        //    catch (Exception ex)
        //    {

        //        lblError.Text = "Error on fetching Deposit list: " + ex.Message;
        //    }
        //}

        protected void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtCustomer_TextChanged(object sender, EventArgs e)
        {
            try
            {


                string GetCustomerId = (txtCustomer.Text).Trim();
                int id = 0;
                string[] SplitGetCustomerId = GetCustomerId.Split('-');

                if (SplitGetCustomerId.Length > 1)
                {

                    id = Convert.ToInt32(SplitGetCustomerId[0]);

                }

                if (id > 0)
                    BindCustomer(id);

            }
            catch (Exception ex)
            {

                lblError.Text = "Error while fetching Customer Record: " + ex.Message;
            }
        }

       




      
 
        protected void btnSearchCustomer_Click(object sender, EventArgs e)
        {
            if (txtID.Text != "")
            {
                BindCustomer(Convert.ToInt32(txtID.Text));

            }

        }

        protected void txtStartDate_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ClearAll();
            lblError.Text = "";
        }

     

        //protected void grdDepositTransaction_PageIndexChanging(object sender, GridViewPageEventArgs e)
        //{
        //    grdDepositTransaction.PageIndex = e.NewPageIndex;
        //    BindDepositTransaction();
        //}

        
    }
    
}