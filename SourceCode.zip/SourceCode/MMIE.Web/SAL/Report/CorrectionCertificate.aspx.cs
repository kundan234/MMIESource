﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.Common;
//using MMIE.Data.ADM;
using MMIE.Data.ACC;
using MMIE.BusinessProcess.SAL;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.SAL.Report
{
    public partial class CorrectionCertificate : BasePage
    {

        protected void PagePermission()
        {
            if (LoginToken != null)
            {



                btnModify.Enabled = LoginToken.IsAddOn;
                btnModify.Enabled = LoginToken.IsModify;
            }
        }

    
        protected void Page_Load(object sender, EventArgs e)
        {
            PagePermission();
            MasterLookupBO mstlookup = new MasterLookupBO();
            if (!IsPostBack)
            {

                BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
                dllBranch.Items.Insert(0, "--Select--");


            }
        }

        protected void btnModify_Click(object sender, EventArgs e)
        {
            Product objOrderData = new Product();
            CorrectionCertificateBO objCertificateBO = new CorrectionCertificateBO();
            if (ViewState["VehicalDeliveryID"] != null)
            {
                // objOrderData.CertificateCorrectionID = (ViewState["CorrectionCertificateID"]).ToString();
                objOrderData.CustomerName = txtName.Text;
                objOrderData.VINNO = txtVIN.Text;
                objOrderData.EngineNo = txtEngineNo.Text;
                objOrderData.DeliveryDate = txtdate.Text;
                // objOrderData.Brand = txtBrand.Text;
                objOrderData.Model = txtModelNo.Text;
                objOrderData.ProductSaleDeleveryID = Convert.ToInt32(ViewState["VehicalDeliveryID"]);

                if (objCertificateBO.UpdateCorrectionCertificate(objOrderData))
                {
                    ViewState["VehicalDeliveryID"] = null;
                    lblError.Text = "Certificate Updated successfully.";
                    BindCertiFicateList();
                }
            }

            else
            {
                lblError.Text = "Select a valid certificate and try again...!";
            }
            Reset();
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        //protected void btnSearch_Click(object sender, EventArgs e)
        //{
        //    BindSearchCorrectionList();
        //}

        //private void BindSearchCorrectionList()
        //{
        //    Order objOrderData = new Order();
        //    if (txtEngineNo.Text != "")
        //        objOrderData.EngineNo = txtEngineNo.Text;
        //    else
        //        objOrderData.EngineNo = null;
        //    if (txtModelNo.Text != "")
        //        objOrderData.ModelNO = txtModelNo.Text;
        //    else
        //        objOrderData.ModelNO = null;
        //    if (txtVIN.Text != "")
        //        objOrderData.VinNo = txtVIN.Text;
        //    else
        //        objOrderData.VinNo = null;
        //    if (txtName.Text != "")
        //        objOrderData.CustomerName = txtName.Text;
        //    else
        //        objOrderData.CustomerName = null;
        //    if (txtdate.Text != "")
        //        objOrderData.CertificateDate = Convert.ToDateTime(txtdate.Text);
        //    else
        //        objOrderData.CertificateDate = Convert.ToDateTime(null);
                
        //    //if (txtBrand.Text != "")
        //    //    objOrderData.Brand = txtBrand.Text;
        //    //else
        //    //    objOrderData.Brand = null;

        //    CorrectionCertificateBO objCertificateBO = new CorrectionCertificateBO();
        //    List<Order> lstCertificate = new List<Order>();
        //    lstCertificate = objCertificateBO.SearchCorrectionCertificate(objOrderData);
        //    gvOrderVehicleDetail.DataSource = lstCertificate;
        //    gvOrderVehicleDetail.DataBind();
        //}

        //protected void gvOrderVehicleDetail_RowCommand(object sender, GridViewCommandEventArgs e)
        //{
        //    if (e.CommandName == "REdit")
        //    {
        //        int id = Convert.ToInt32(e.CommandArgument.ToString());
        //        GridViewRow gr = gvOrderVehicleDetail.Rows[id];
        //        LinkButton lblID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");
        //        Order objOrderData = new Order();
        //        Order objOrderDataCorrection = new Order();
        //        CorrectionCertificateBO objCertificateBO = new CorrectionCertificateBO();
        //        objOrderData.CertificateCorrectionID =(lblID.Text);
        //        objOrderDataCorrection = objCertificateBO.GetAccountGroupTypeByID(objOrderData);
                
        //        txtName.Text = objOrderDataCorrection.CustomerName;
        //        txtVIN.Text = objOrderDataCorrection.VinNo;
        //        txtEngineNo.Text = objOrderDataCorrection.EngineNo;
        //        txtModelNo.Text = objOrderDataCorrection.ModelNO;
        //        //txtBrand.Text = objOrderDataCorrection.Brand;
        //        txtdate.Text = objOrderDataCorrection.CertificateDate.ToShortDateString();
        //        ViewState["CorrectionCertificateID"] = objOrderDataCorrection.CertificateCorrectionID;
        //    }
        //}

        private void Reset()
        {
            txtName.Text = "";
            txtVIN.Text = "";
            txtEngineNo.Text = "";
            txtModelNo.Text = "";
            //txtBrand.Text = "";
            txtdate.Text = "";
            txtCertificateID.Text = "";

            
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {

            Reset();
            lblError.Text = "";
            grdCertificateList.DataSource = null;
            grdCertificateList.DataBind();


        }

        protected void grdCertificateList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCertificateList.PageIndex = e.NewPageIndex;
            BindCertiFicateList();


        }

        protected void grdCertificateList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdCertificateList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
                int id = Convert.ToInt32(e.CommandArgument.ToString());


                if (e.CommandName == "ProductSalesID")
                {

                    Product objProduct = new Product();
                    GridViewRow gr = grdCertificateList.Rows[id];
                    LinkButton lblID = (LinkButton)gr.Cells[1].FindControl("lnkProdID");

                    ViewState["VehicalDeliveryID"] = lblID.Text;
                    
                    txtName.Text = gr.Cells[2].Text;
                    txtVIN.Text = gr.Cells[5].Text;
                    txtEngineNo.Text = gr.Cells[6].Text;
                    
                    txtdate.Text = gr.Cells[8].Text;
                    txtModelNo.Text = gr.Cells[9].Text;

                    txtCertificateID.Text = lblID.Text;

                }
        }

        protected void BindCertiFicateList()
        {
            Product objProduct = new Product();

            List<Product> lstProduct = new List<Product>();

            VehicleBO objVehicleBO = new VehicleBO();


            try
            {
                DateTime dat = new DateTime();
                DateTime.TryParse(txtdatefrom.Text, out dat);
                objProduct.StartDate = dat.ToShortDateString();
                
                objProduct.CustomerName = txtCustomerName.Text;

                DateTime.TryParse(txtdateto.Text, out dat);
                objProduct.EndDate = dat.ToShortDateString();
                objProduct.VINNO = txtSearchVIN.Text;
                lstProduct = objVehicleBO.SearchSalesCertificateList(objProduct);
                grdCertificateList.DataSource = lstProduct;
                grdCertificateList.DataBind();

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Loading Certificate : " + ex.Message;
            }



        }



        protected void btnDeliverySearch_Click(object sender, EventArgs e)
        {
            BindCertiFicateList();
        }
        
    }
}