﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE
{
    public partial class CustomerEntry : BasePage
    {

        //    string fName = "";
        //    string slocation;
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;
        List<Customer> lstCustomer = null;
        DataSet ds = null;
        private int Count = 1;
        private Table t;
        TextBox tb;
        CheckBox chk;
        int iPageCount = 0;

        private void addfiletable()
        {
            try
            {
                t = new Table();
                t.Rows.Clear();
                t.BorderStyle = BorderStyle.Solid;

                TableHeaderRow th = new TableHeaderRow();
                th.BorderStyle = BorderStyle.Solid;
                TableCell c1 = new TableCell();
                c1.Text = "S.No.";
                c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

                TableCell c2 = new TableCell();
                c2.Text = "Uploaded Files";
                c2.Style.Add(HtmlTextWriterStyle.Width, "25%");

                TableCell c3 = new TableCell();
                c3.Text = "Document Type";
                c3.Style.Add(HtmlTextWriterStyle.Width, "8%");
                c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                TableCell c4 = new TableCell();
                c4.Text = "Document ID";
                c4.Style.Add(HtmlTextWriterStyle.Width, "20%");
                c4.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                TableCell c5 = new TableCell();
                c5.Text = "Remarks";
                c5.Style.Add(HtmlTextWriterStyle.Width, "10%");
                c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");

                TableCell c6 = new TableCell();
                c6.Style.Add(HtmlTextWriterStyle.Width, "1%");
                c6.Text = "Checked";
                c6.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");



                th.Cells.Add(c1);
                th.Cells.Add(c2);
                th.Cells.Add(c3);
                th.Cells.Add(c4);
                th.Cells.Add(c5);
                th.Cells.Add(c6);



                Style myStyle = new Style();
                myStyle.ForeColor = System.Drawing.Color.Black;
                myStyle.BackColor = System.Drawing.Color.LightGray;
                myStyle.Font.Bold = true;
                myStyle.BorderStyle = BorderStyle.Solid;

                th.ApplyStyle(myStyle);
                // th.Font.Size =Unit.Percentage(12);
                th.BorderStyle = BorderStyle.Solid;
                th.BorderWidth = Unit.Pixel(1);

                t.Rows.Add(th);
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While add the file in table : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }


        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnCustomerSubmit.Enabled = LoginToken.IsAddOn;

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {



            try
            {
                btnCustomerSubmit.Attributes.Add("onclick", "return validate()");

                PagePermission();
                if (!IsPostBack)
                {
                    addfiletable();

                    Session["Files"] = t;
                    Session["Count"] = Count;
                    BindSalesType();
                    BindCurrencyDetails();
                    ViewState["IsEdit"] = false;

                }
             
                t = (Table)Session["Files"];
                Count = (Count = Convert.ToInt32(Session["Count"]));
                phControls.Controls.Add(t);

                lblError.Text = "";
                lblError.Visible = false;
                //errorMessage.InnerHtml = "";
                //errorMessage.Visible = false;


                if (!Page.IsPostBack)
                {
                    MasterLookupBO mstlookup = new MasterLookupBO();
                    //BindDropDownControl(ddlCity, mstlookup.GetLookupsList(LookupNames.City));
                    //ddlCity.Items.Insert(0, "Select City");

                    //BindDropDownControl(ddlCountry, mstlookup.GetLookupsList(LookupNames.Country));
                    //ddlCountry.Items.Insert(0, "Select Country");
                    //BindDropDownControl(ddlCustReferencecity, mstlookup.GetLookupsList(LookupNames.City));
                    //ddlCustReferencecity.Items.Insert(0, "Select City");
                    //BindDropDownControl(ddlCustReferenceCountry, mstlookup.GetLookupsList(LookupNames.Country));
                    //ddlCustReferenceCountry.Items.Insert(0, "Select Country");
                    ////-------------code for gridview-----------
                    grdCustomer.PageSize = GRID_PAGESIZE;

                    //------------
                    TabContainerCustomer_ActiveTabChanged(TabCustomerDetail, null);
                    if (Request.QueryString["custid"] != null)
                    {
                        int custid = Convert.ToInt32(Request.QueryString["custid"].ToString());
                        ViewState["custid"] = custid;
                        BindCustomerDetail(custid);
                    }
                }
                else
                {
                    string eventTarget = Request.Form["__EVENTTARGET"];
                    if (eventTarget != null)
                    {
                        if (eventTarget.IndexOf("nav") >= 0)
                        {

                            int pageIndexPos = eventTarget.LastIndexOf("_");
                            string strIndex = eventTarget.Substring(pageIndexPos + 1);
                            int iNewIndex = Convert.ToInt32(strIndex);
                            ViewState["SubmittedNewIndex"] = iNewIndex;
                            if (iNewIndex > 0)
                                BindData(iNewIndex - 1);
                            else
                                BindData(iNewIndex);
                        }

                    }
                    //Recreate Buttons for Paging
                    CreateNavigation();
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        protected void TabContainerCustomer_ActiveTabChanged(object sender, EventArgs e)
        {


            try
            {
                lblError.Text = "";

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While change the tab : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
            finally
            {

            }
        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemid";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
        }
        protected void btnCustomerSubmit_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records Please contact to your System Administrator";
                lblError.Visible = true;
                return;

            }

            SetErrorMessage();
            try
            {
                if (Page.IsValid)
                {
                    //Set Customer Detail
                    Customer objCustomer = new Customer();
                    objCustomer.CustomerName = txtName.Text;
                    objCustomer.CustomerAddress = txtAddress.Text;
                    objCustomer.CustomerStreet = txtStreet.Text;
                    //objCustomer.CustomerCountryID = Convert.ToInt32(ddlCountry.SelectedValue);
                    //objCustomer.CustomerCityID = Convert.ToInt32(ddlCity.SelectedValue);
                    objCustomer.CustomerPhone = txtPhone.Text;
                    objCustomer.CustomerMobile = txtCellno.Text;
                    objCustomer.CustomerFax = txtFaxno.Text;
                    objCustomer.CustomerEmail = txtEmail.Text;
                    objCustomer.CustomerWebsite = txtWebsite.Text;
                    //------------------refrence detail------
                    objCustomer.CustReferenceName = txtCustReferencename.Text;
                    objCustomer.CustReferenceAddress = txtCustReferenceaddress.Text;
                    objCustomer.CustReferenceStreet = txtCustReferencestreet.Text;
                    //objCustomer.CustReferenceCountryID = Convert.ToInt32(ddlCustReferenceCountry.SelectedValue);
                    //objCustomer.CustReferenceCityID = Convert.ToInt32(ddlCustReferencecity.SelectedValue);
                    objCustomer.CustomerCityID = int.Parse(ViewState["CityID"].ToString());
                    objCustomer.CustomerCountryID = int.Parse(ViewState["CountryID"].ToString());


                    if (ViewState["CCityID"] != null || ViewState["CCountryID"] != null)
                    {
                        objCustomer.CustReferenceCityID = int.Parse(ViewState["CCityID"].ToString());
                        objCustomer.CustReferenceCountryID = int.Parse(ViewState["CCountryID"].ToString());

                    }
                    else
                    {

                        objCustomer.CustReferenceCityID = int.Parse(ViewState["CityID"].ToString());
                        objCustomer.CustReferenceCountryID = int.Parse(ViewState["CountryID"].ToString());
                    }

                    objCustomer.CustReferencePhone = txtCustReferencephone.Text;
                    objCustomer.CustReferenceMobile = txtCustReferencecellno.Text;
                    objCustomer.CustReferenceFax = txtCustReferencefaxno.Text;
                    objCustomer.CustReferenceEmail = txtCustReferenceemail.Text;
                    objCustomer.CustReferenceWebsite = txtCustReferencewebsite.Text;
                    //---------
                    objCustomer.AddedBy = LoginToken.LoginId;
                    objCustomer.LastModBy = LoginToken.LoginId;
                    objCustomer.CompanyID = (short)LoginToken.CompanyID;
                    objCustomer.SalesTypeID = Convert.ToInt32(ddlSalesType.SelectedValue.ToString());
                    // if (flScanID.PostedFile.ContentLength > 0)
                    // {
                    //    fName = System.IO.Path.GetFileName(flScanID.PostedFile.FileName);
                    //    slocation = Server.MapPath("CustomerScanID") + "\\" + fName;
                    //    flScanID.PostedFile.SaveAs(slocation);

                    //}
                    //objCustomer.FinancialYearID = (short)LoginToken.FinancialYearID;


                    if (rbtPrice.SelectedIndex == 0)
                    {
                        objCustomer.IsPriceVisible = true;
                    }
                    else
                    {
                        objCustomer.IsPriceVisible = false;
                    }



                    if (ddlCustomerType.SelectedIndex == 1)
                    {
                        objCustomer.CustomerType = "CASH";
                        if (txtCCity.Text == "")
                        {
                            objCustomer.CustReferenceCityID = objCustomer.CustomerCityID;
                            objCustomer.CustReferenceCountryID = objCustomer.CustomerCountryID;
                        }
                    }

                    if (ddlCustomerType.SelectedIndex == 2)
                    {
                        objCustomer.CustomerType = "CREDIT";
                        if (txtMaxCreditLimit.Text != "")
                            objCustomer.MaxCreditLimit = Convert.ToDecimal(txtMaxCreditLimit.Text);
                        else
                            objCustomer.MaxCreditLimit = 0;
                        if (txtMaxCreditLimitUSD.Text != "")
                            objCustomer.MaxCreditLimitUSD = Convert.ToDecimal(txtMaxCreditLimitUSD.Text);
                        else
                            objCustomer.MaxCreditLimitUSD = 0;

                        objCustomer.MaximumDueDays = 0;
                    }
                    if (chkType.SelectedValue == "Supplier")
                    {
                        objCustomer.CType = "Supplier";
                    }
                    else
                    {
                        objCustomer.CType = "Customer";
                    }

                    if (chkType.Items[0].Selected == true && chkType.Items[1].Selected == true)
                    {
                        objCustomer.CType = "Both";
                    }

                    if (rbtStatus.SelectedIndex == 0)
                    {
                        objCustomer.StatusType = true;
                    }
                    else
                    {
                        objCustomer.StatusType = false;

                    }

                    if (ViewState["custid"] != null)
                    {
                        objCustomer.ActionType = EnumActionType.Update;
                        objCustomer.CustomerID = Convert.ToInt32(ViewState["custid"]);
                    }
                    else
                    {
                        objCustomer.ActionType = EnumActionType.Insert;

                    }




                    objCustomer.StreetChargeID = Convert.ToInt32(ddlStreetCharge.SelectedValue.ToString());

                    objCustomer.IsActive = true;



                    //Calling Save operation of IUserAdmin Service
                    CustomerBO Cust = new CustomerBO();
                    int status = 0;
                    status = Cust.SaveCustomer(objCustomer);




                    # region New  Region Saving Customer Files

                    if (status > 0)
                    {
                        int action = 0;
                        int id;
                        if (ViewState["custid"] != null)
                        {
                            id = Convert.ToInt32(ViewState["custid"]);
                            action = 2;
                        }
                        else
                        {
                            id = status;
                            action = 1;
                        }


                        List<CustomerDocument> lstCustomerDoc = new List<CustomerDocument>();
                        string CType = "CustomerScanID";

                        HttpFileCollection Files = Request.Files;
                        //     HttpPostedFile objFile;

                        string newpath = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + CType + "\\" + id.ToString() + "\\";
                        //  string oldpath;
                        System.IO.DirectoryInfo fs = new System.IO.DirectoryInfo(newpath);

                        if (!fs.Exists)
                        {
                            fs.Create();
                        }

                        for (int i = 1; i < t.Rows.Count; i++)
                        {
                            action = 0;
                            TableRow tr = t.Rows[i];

                            CustomerDocument objDoc = new CustomerDocument();

                            //FileUpload fl = new FileUpload();
                            HyperLink hl = new HyperLink();
                            hl = (HyperLink)tr.Cells[1].Controls[0];

                            CheckBox chk = new CheckBox();
                            chk = (CheckBox)tr.Cells[5].Controls[0];

                            TextBox tx = new TextBox();

                            Label lbl = new Label();
                            Label lbl2 = new Label();

                            Label lblDocType = new Label();
                            Label lblDocID = new Label();

                            Label lbl3 = new Label();
                            //Label filePath = new Label();
                            //filePath = (Label)tr.Cells[7].Controls[0];

                            lbl3 = (Label)tr.Cells[7].Controls[0];
                            lbl2 = (Label)tr.Cells[6].Controls[0];
                            tx = (TextBox)tr.Cells[4].Controls[0];
                            lblDocType = (Label)tr.Cells[2].Controls[0];
                            lblDocID = (Label)tr.Cells[3].Controls[0];

                            objDoc.FriendlyName = hl.Text;
                            objDoc.CustomerScanID = lbl3.Text;
                            objDoc.CustomerDescription = tx.Text;
                            objDoc.CustomerID = id;
                            objDoc.DocumentID = lblDocID.Text;
                            objDoc.DocumentType = lblDocType.Text;


                            if (chk.Checked)
                            {



                                if (lbl2.Text == "")
                                {


                                    if (chk.Checked && lbl2.Text == "")
                                    {
                                        objDoc.ScanID = 0;
                                        //   filePath.Text= Server.MapPath(filePath.Text);
                                        string oldpath1 = Server.MapPath(("~/TempUpload/" + lbl3.Text));
                                        string newpath1 = Server.MapPath(("~/CustomerScanID/" + id.ToString()));
                                        System.IO.File.Move(oldpath1, (newpath1 + "/" + lbl3.Text));

                                        //    filePath.Text = ("~/CustomerScanID/" + id.ToString() +"/"+ lbl3.Text);
                                        action = 1;
                                    }
                                    action = 1;

                                }
                                else if (lbl2.Text != "")
                                {

                                    action = 2;

                                    objDoc.ScanID = Convert.ToInt32(lbl2.Text);

                                }



                            }

                            else
                            {


                                if (lbl2.Text != "")
                                {
                                    action = 3;
                                    objDoc.ScanID = Convert.ToInt32((lbl2.Text));
                                }

                                string mappath = Server.MapPath(hl.NavigateUrl);
                                System.IO.FileInfo temfile = new System.IO.FileInfo(mappath);
                                temfile.Delete();


                            }

                            objDoc.ActionType = action;
                            //objDoc.FilePath = filePath.Text;

                            lstCustomerDoc.Add(objDoc);
                        }
                        Cust.SaveCustomerDocument(lstCustomerDoc);
                        t.Rows.Clear();
                        Count = 1;
                    }

                    #endregion


                    if (status > 0)
                    {
                        //display succuss message

                        if (ViewState["custid"] != null)
                            lblError.Text = ExceptionMessage.GetMessage("C000018");
                        else
                            lblError.Text = ExceptionMessage.GetMessage("C000016");
                        lblError.Visible = true;
                        ViewState["IsEdit"] = false;
                        cleartextbox();
                    }
                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");

                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While save the customer record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;

            }
        }

        #region Client Side Validation

        protected void SetErrorMessage()
        {
            //reqName.ErrorMessage = ExceptionMessage.GetMessage("C000000");
            //reqaddress.ErrorMessage = ExceptionMessage.GetMessage("C000001");
            //reqCity.ErrorMessage = ExceptionMessage.GetMessage("C000002");
            //reqCountry.ErrorMessage = ExceptionMessage.GetMessage("C000003");
            //reqPhone.ErrorMessage = ExceptionMessage.GetMessage("C000004");
            //reqEmail.ErrorMessage = ExceptionMessage.GetMessage("C000005");


            //reqRefName.ErrorMessage = ExceptionMessage.GetMessage("C000007");
            //reqRefaddress.ErrorMessage = ExceptionMessage.GetMessage("C000008");
            //reqRefcity.ErrorMessage = ExceptionMessage.GetMessage("C000009");
            //reqRefCountry.ErrorMessage = ExceptionMessage.GetMessage("C000010");
            //reqRefemail.ErrorMessage = ExceptionMessage.GetMessage("C000015");
            //reqRefphone.ErrorMessage = ExceptionMessage.GetMessage("C000012");


        }

        #endregion

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                ViewState["IsEdit"] = false;

                if (Request.QueryString["custid"] == null)
                {
                    this.cleartextbox();
                }
                else
                {
                    BindCustomerDetail(Convert.ToInt16(Request.QueryString["custid"]));

                }

                //TODO: it will handled by client side function invoking
                //reqaddress.ErrorMessage ="";
                //reqName.ErrorMessage = "";
                //reqPhone.ErrorMessage = "";
                //reqCity.ErrorMessage = "";
                //reqCountry.ErrorMessage = "";
                //reqEmail.ErrorMessage = "";
                //reqPhone.ErrorMessage = "";
                //reqRefaddress.ErrorMessage ="";
                //reqRefemail.ErrorMessage = "";
                //reqRefcity.ErrorMessage = "";
                //reqRefCountry.ErrorMessage = "";
                //reqRefphone.ErrorMessage = "";


                //set client side error message
                SetErrorMessage();
                lblError.Text = "";
                cleartextbox();
            }
            catch (Exception ex) //Exception in agent layer itself
            {

                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While reset the customer record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;

            }
        }
        protected void btnCustpmerSearch_Click(object sender, EventArgs e)
        {
            try
            {
                CallSearch();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");

                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While search the product record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;

            }
        }
        //--------------------------customer serach-----------------
        public string MakeCustomerIDLink(int CustomerID, string Customername)
        {
            string ret;
            string str;
            string pageName;
            pageName = "CustomerEntry.aspx";
            str = pageName + "?custid=" + CustomerID.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + Customername + "</a>";
            return ret;
        }


        public void CallSearch()
        {
            grdCustomer.PageIndex = 0;

            Customer objCustomer = new Customer();
            objCustomer.CustomerName = txtCustsname.Text;
            objCustomer.CustomerStreet = txtCustsstreet.Text;
            objCustomer.CustomerPhone = txtCustphone.Text;
            objCustomer.CustomerMobile = txtCustcellno.Text;
            objCustomer.CurrentIndex = 0;
            objCustomer.PageSize = GlobalConstant.PageSize;

            //Save Search Options in ViewState
            ViewState[VS_SEARCH] = objCustomer;

            BindData(0);

        }

        private DataSet SearchCustomer(Customer objCustomer)
        {
            //Call service operation to get data from database source
            CustomerBO useradm = new CustomerBO();
            lstCustomer = useradm.SearchCustomer(objCustomer);
            //    lstCustomer  = UserAdminServiceAgent.SearchCustomer(objCustomer);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstCustomer);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        private void BindData(int currentPageIndex)
        {
            try
            {
                grdCustomer.PageIndex = 0;

                PagedDataSource objPagedDataSource = new PagedDataSource();
                objPagedDataSource.AllowCustomPaging = true;
                objPagedDataSource.PageSize = GRID_PAGESIZE;
                objPagedDataSource.CurrentPageIndex = currentPageIndex;

                //Get search option from viewstate
                Customer objCustomer = (Customer)ViewState[VS_SEARCH];
                objCustomer.CurrentIndex = currentPageIndex;
                //Save Search Option again
                ViewState[VS_SEARCH] = objCustomer;

                //Call service operation to get data from database source
                ds = SearchCustomer(objCustomer);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.grdCustomer.Visible = true;
                    //Bind data in ViewGrid.
                    objPagedDataSource.VirtualCount = Convert.ToInt32(ds.Tables[0].Rows[0]["MaximumRows"]);
                    //Save Virtual Count in ViewState
                    ViewState[VS_MAXROWS] = objPagedDataSource.VirtualCount;
                    CreateNavigation(currentPageIndex, objPagedDataSource.PageSize, objPagedDataSource.VirtualCount);

                    objPagedDataSource.DataSource = ds.Tables[0].DefaultView;
                    grdCustomer.DataSource = objPagedDataSource;
                    grdCustomer.DataBind();
                }
                else
                {
                    lblError.Text = "No Records Found";
                    grdCustomer.DataSource = null;
                    grdCustomer.DataBind();
                    pnlNavigation.Visible = false;
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While show the product record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        //protected void ShowError(string a_sMsg)
        //{
        //    errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
        //    if (a_sMsg.Length > 0)
        //    {
        //        errorMessage.Visible = true;
        //    }
        //    else
        //    {
        //        errorMessage.Visible = false;
        //    }
        //}

        #region GridView Event Handler


        private void CreateNavigation()
        {
            if (ViewState[VS_CURRENTINDEX] == null || ViewState[VS_PAGESIZE] == null || ViewState[VS_MAXROWS] == null)
            {
                return;
            }
            else
            {
                CreateNavigation((int)ViewState[VS_CURRENTINDEX], (int)ViewState[VS_PAGESIZE], (int)ViewState[VS_MAXROWS]);
            }
        }

        private void CreateNavigation(int currentPageIndex, int a_iPageSize, int a_iRowCount)
        {
            //Save the arguments in ViewState
            ViewState[VS_CURRENTINDEX] = currentPageIndex;
            ViewState[VS_PAGESIZE] = a_iPageSize;
            ViewState[VS_MAXROWS] = a_iRowCount;
            pnlNavigation.Controls.Clear();
            if (a_iPageSize == 0)
            {
                return;
            }

            //Get the TotalNumber of Pages
            //int iPageCount = 0;
            iPageCount = 0;
            if (a_iRowCount % a_iPageSize == 0)
            {
                iPageCount = a_iRowCount / a_iPageSize;
            }
            else
            {
                iPageCount = (a_iRowCount / a_iPageSize) + 1;
            }

            if (iPageCount <= 1)
            {
                return;
            }

            //Check if LeftDots are to be displayed
            if ((currentPageIndex + 1) - 5 > 1)
            {
                //Start when left dots are visible then show << button also
                LinkButton linkFirst = new LinkButton();
                linkFirst.Text = "<<";
                linkFirst.CssClass = "lftmenu";
                linkFirst.ID = "linkFirst";
                linkFirst.Click += new EventHandler(linkFirst_Click);
                pnlNavigation.Controls.Add(linkFirst);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
                //End when left dots are visible then show << button also

                int iLIndex = (currentPageIndex + 1) - 5 - 1;
                //Add LeftDots
                LinkButton btnLeftDots = new LinkButton();
                btnLeftDots.Text = "...";
                btnLeftDots.CssClass = "lftmenu";
                btnLeftDots.ID = "nav_" + iLIndex.ToString();
                btnLeftDots.Attributes.Add("onclick", "__doPostBack('" + btnLeftDots.ClientID + "',' " + iLIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            int iLeftIndex = 1;

            if (currentPageIndex + 1 - 5 > 1)
            {
                iLeftIndex = currentPageIndex + 1 - 5;
            }

            //Create the Number buttons on the left side of the index
            for (int i = iLeftIndex; i <= currentPageIndex; i++)
            {
                LinkButton btnLeftNumbers = new LinkButton();
                btnLeftNumbers.Text = i.ToString();
                btnLeftNumbers.CssClass = "lftmenu";
                btnLeftNumbers.ID = "nav_" + i.ToString();
                btnLeftNumbers.Attributes.Add("onclick", "__doPostBack('" + btnLeftNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Display the Current Page Number
            Label lblCurrent = new Label();
            lblCurrent.Text = Convert.ToString(currentPageIndex + 1);
            lblCurrent.CssClass = "textNormal";
            pnlNavigation.Controls.Add(lblCurrent);
            pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

            //Create Right Number buttons
            int iRightIndex = iPageCount;

            if (currentPageIndex + 1 + 5 < iRightIndex)
            {
                iRightIndex = 5;//currentPageIndex + 1 + 5;
            }

            for (int i = currentPageIndex + 2; i <= iRightIndex; i++)
            {
                LinkButton btnRightNumbers = new LinkButton();
                btnRightNumbers.Text = i.ToString();
                btnRightNumbers.CssClass = "lftmenu";
                btnRightNumbers.ID = "nav_" + i.ToString();
                btnRightNumbers.Attributes.Add("onclick", "__doPostBack('" + btnRightNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Check if RightDots are to be displayed
            if ((currentPageIndex + 1) + 5 < iPageCount)
            {
                int iRIndex = ((currentPageIndex + 1) + 5) + 1;
                //Add RightDots
                LinkButton btnRightDots = new LinkButton();
                btnRightDots.Text = "...";
                btnRightDots.CssClass = "lftmenu";
                btnRightDots.ID = "nav_" + iRIndex.ToString();
                btnRightDots.Attributes.Add("onclick", "__doPostBack('" + btnRightDots.ClientID + "',' " + iRIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

                //Start when right dots are visible then show >> button also
                LinkButton linkLast = new LinkButton();
                linkLast.Text = ">>";
                linkLast.CssClass = "lftmenu";
                linkLast.ID = "linkLast";
                linkLast.Click += new EventHandler(linkLast_Click);
                pnlNavigation.Controls.Add(linkLast);


                if (pnlNavigation.Controls.Count > 0)
                {
                    pnlNavigation.Visible = true;
                }
                else
                    pnlNavigation.Visible = false;
                //End when left dots are visible then show << button also
            }
        }

        protected void linkFirst_Click(object sender, EventArgs e)
        {
            BindData(0);
        }

        protected void linkLast_Click(object sender, EventArgs e)
        {
            BindData(iPageCount - 1);
        }
        #endregion

        #region  Auto City Code Picker

        protected void txtCity_TextChanged(object sender, EventArgs e)
        {
            BindCityDetail(txtCity.Text);
        }

        protected void txtCCity_TextChanged(object sender, EventArgs e)
        {
            BindContactityDetail(txtCCity.Text);
        }


        private void BindCityDetail(string cityname)
        {
            CustomerBO useradm = new CustomerBO();
            Customer objCustomer = new Customer();
            objCustomer.CityName = cityname.ToString();
            Customer objRetCustomer = useradm.GetCountryByName(objCustomer);
            if (objRetCustomer != null)
            {
                txtCountry.Text = Convert.ToString(objRetCustomer.CountryName);
                ViewState["CityID"] = objRetCustomer.CityID;
                ViewState["CountryID"] = objRetCustomer.CountryID;
            }
            else
            {
                txtCity.Text = "";
                txtCountry.Text = "";
            }

        }
        private void BindContactityDetail(string cityname)
        {
            CustomerBO useradm = new CustomerBO();
            Customer objCustomer = new Customer();

            objCustomer.CityName = Convert.ToString(cityname);
            Customer objRetCustomer = useradm.GetCountryByName(objCustomer);
            if (objRetCustomer != null)
            {
                txtCCountry.Text = Convert.ToString(objRetCustomer.CountryName);
                ViewState["CCityID"] = objRetCustomer.CityID;
                ViewState["CCountryID"] = objRetCustomer.CountryID;
            }
            else
            {
                txtCCountry.Text = "";
                txtCCity.Text = "";

            }
        }
        #endregion









        //--------
        protected void btnCustReset_Click(object sender, EventArgs e)
        {
            txtCustsname.Text = "";
            txtCustsstreet.Text = "";
            txtCustphone.Text = "";
            txtCustcellno.Text = "";
            grdCustomer.DataSource = null;
            grdCustomer.DataBind();
            ViewState[VS_CURRENTINDEX] = 0;
            ViewState[VS_PAGESIZE] = 0;
            ViewState[VS_MAXROWS] = 0;

            pnlNavigation.Controls.Clear();


        }
        public void cleartextbox()
        {
            ddlSalesType.SelectedValue = "0";
            ddlStreetCharge.SelectedIndex = 0;
            ddlCustomerType.SelectedIndex = 0;
            if (chkType.SelectedItem.Selected == true)
                chkType.SelectedItem.Selected = false;
            else
                chkType.SelectedItem.Selected = false;
            ddlCurrency.SelectedIndex = 0;
            rbtPrice.SelectedIndex = 0;
            rbtStatus.SelectedIndex = 0;
            txtMaximumDueDays.Text = "";
            txtName.Text = "";
            txtAddress.Text = "";
            txtStreet.Text = "";
            txtPhone.Text = "";
            txtCellno.Text = "";
            txtFaxno.Text = "";
            txtEmail.Text = "";
            txtWebsite.Text = "";
            txtCity.Text = "";
            txtCountry.Text = "";

            txtID.Text = "";

            //------------------refrence detail------
            txtCustReferencename.Text = "";
            txtCustReferenceaddress.Text = "";
            txtCustReferencestreet.Text = "";

            txtCustReferencephone.Text = "";
            txtCustReferencecellno.Text = "";
            txtCustReferencefaxno.Text = "";
            txtCustReferenceemail.Text = "";
            txtCustReferencewebsite.Text = "";
            txtCCity.Text = "";
            txtCCountry.Text = "";
            txtMaxCreditLimit.Text = "";
            txtMaxCreditLimitUSD.Text = "";

            Count = 1;
            t.Rows.Clear();
            Session["Files"] = t;
            Session["Count"] = Count;
            //  MasterLookupBO mstlookup = new MasterLookupBO();
            //BindDropDownControl(ddlCity, mstlookup.GetLookupsList(LookupNames.City));
            //ddlCity.Items.Insert(0, "Select City");

            //BindDropDownControl(ddlCountry, mstlookup.GetLookupsList(LookupNames.Country));
            //ddlCountry.Items.Insert(0, "Select Country");
            //BindDropDownControl(ddlCustReferencecity, mstlookup.GetLookupsList(LookupNames.City));
            //ddlCustReferencecity.Items.Insert(0, "Select City");
            //BindDropDownControl(ddlCustReferenceCountry, mstlookup.GetLookupsList(LookupNames.Country));
            //ddlCustReferenceCountry.Items.Insert(0, "Select Country");
        }





        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void grdCustomer_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.ToString())
            {
                case "Delet":
                    try
                    {
                        int Customerid = Convert.ToInt32(e.CommandArgument.ToString().Trim());
                        Customer objCustomer = new Customer();
                        objCustomer.CustomerID = Customerid;
                        //objCustomer.LastModBy = LoginToken.LoginId;
                        // objCustomer.ActionType = EnumActionType.Delete;
                        CustomerBO cust = new CustomerBO();
                        bool status = cust.DisableCustomer(objCustomer);
                        if (status)
                        {
                            string newpath = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "CustomerScanID" + "\\" + Customerid.ToString() + "\\";
                            //  string oldpath;
                            System.IO.DirectoryInfo fs = new System.IO.DirectoryInfo(newpath);
                            if (fs.Exists)
                            {
                                fs.Delete(true);
                            }
                            CallSearch();


                            lblError.Text = ExceptionMessage.GetMessage("C000017");
                            //lblError.Visible = true;

                            txtCustsname.Text = "";
                            txtCustsstreet.Text = "";
                            txtCustphone.Text = "";
                            txtCustcellno.Text = "";
                        }

                    }
                    catch (Exception ex) //Exception in agent layer itself
                    {
                        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");

                        LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                        lblError.Text = "Error While delete the customer record : " + ExceptionMessage.GetMessage(ex);
                        lblError.Visible = true;

                    }
                    break;
            }

        }
        private void BindCustomerDetail(int custid)
        {
            try
            {
                CustomerBO useradm = new CustomerBO();
                Customer objCustomer = new Customer();
                objCustomer.CustomerID = custid;
                Customer objRetCustomer = useradm.GetCustomerDetailsByID(objCustomer);
                if (objRetCustomer != null)
                {
                    ViewState["IsEdit"] = true;

                    ddlSalesType.SelectedValue = objRetCustomer.SalesTypeID.ToString();

                    if (objRetCustomer.CustomerType == "CASH")
                    {
                        ddlCustomerType.SelectedIndex = 1;
                        if (objRetCustomer.CustReferenceAddress == "")
                        {
                            objRetCustomer.CityName1 = "";
                            objRetCustomer.CountryName1 = "";
                        }
                    }
                    else if (objRetCustomer.CustomerType == "CREDIT")
                    {
                        ddlCustomerType.SelectedIndex = 2;
                        txtMaxCreditLimit.Text = objRetCustomer.MaxCreditLimit.ToString(".00");
                        txtMaxCreditLimitUSD.Text = objRetCustomer.MaxCreditLimitUSD.ToString(".00");

                    }
                    if (objRetCustomer.StreetChargeID != 0)
                    {
                        ddlStreetCharge.SelectedValue = objRetCustomer.StreetChargeID.ToString();
                    }

                    //txtCustomerCode.Text = objRetCustomer.RoleCode;
                    //txtName.Text = objCustomer.CustomerName;
                    //txtAddress.Text = objCustomer.CustomerAddress ;
                    //txtAddress.Text = objCustomer.CustomerAddress;
                    //txt .Text = objCustomer.CustomerAddress;
                    txtName.Text = objRetCustomer.CustomerName;
                    txtAddress.Text = objRetCustomer.CustomerAddress;
                    txtStreet.Text = objRetCustomer.CustomerStreet;
                    //(ddlCountry.SelectedValue) = objRetCustomer.CustomerCountryID.ToString();
                    //(ddlCity.SelectedValue) = objRetCustomer.CustomerCityID.ToString();
                    //

                    txtPhone.Text = objRetCustomer.CustomerPhone;
                    txtCellno.Text = objRetCustomer.CustomerMobile;
                    txtFaxno.Text = objRetCustomer.CustomerFax;
                    txtEmail.Text = objRetCustomer.CustomerEmail;
                    txtWebsite.Text = objRetCustomer.CustomerWebsite;
                    //------------------refrence detail------
                    txtCustReferencename.Text = objRetCustomer.CustReferenceName;
                    txtCustReferenceaddress.Text = objRetCustomer.CustReferenceAddress;
                    txtCustReferencestreet.Text = objRetCustomer.CustReferenceStreet;
                    //(ddlCustReferenceCountry.SelectedValue) = objRetCustomer.CustReferenceCountryID.ToString();
                    //(ddlCustReferencecity.SelectedValue) = objRetCustomer.CustReferenceCityID.ToString();

                    txtCustReferencephone.Text = objRetCustomer.CustReferencePhone;
                    txtCustReferencecellno.Text = objRetCustomer.CustReferenceMobile;
                    txtCustReferencefaxno.Text = objRetCustomer.CustReferenceFax;
                    txtCustReferenceemail.Text = objRetCustomer.CustReferenceEmail;
                    txtCustReferencewebsite.Text = objRetCustomer.CustReferenceWebsite;
                    txtMaximumDueDays.Text = objRetCustomer.MaximumDueDays.ToString();
                    if (objRetCustomer.CustReferenceCityID != 0)
                    {
                        ViewState["CCityID"] = objRetCustomer.CustReferenceCityID;
                        txtCCity.Text = objRetCustomer.CityName1;
                    }
                    if (objRetCustomer.CustReferenceCountryID != 0)
                    {
                        ViewState["CCountryID"] = objRetCustomer.CustReferenceCountryID;
                        txtCCountry.Text = objRetCustomer.CountryName1;

                    }

                    ViewState["CityID"] = objRetCustomer.CustomerCityID;
                    ViewState["CountryID"] = objRetCustomer.CustomerCountryID;

                    txtCity.Text = objRetCustomer.CityName;

                    txtCountry.Text = objRetCustomer.CountryName;
                    txtMaxCreditLimit.Text = Convert.ToString(objRetCustomer.MaxCreditLimit);
                    txtMaxCreditLimitUSD.Text = Convert.ToString(objRetCustomer.MaxCreditLimitUSD);


                    if (objRetCustomer.IsPriceVisible)
                    {
                        rbtPrice.SelectedIndex = 0;
                    }
                    else
                    {
                        rbtPrice.SelectedIndex = 1;
                    }
                    if (objRetCustomer.CType == "Supplier")
                    {
                        chkType.Items[0].Selected = true;
                    }
                    else
                    {
                        chkType.Items[1].Selected = true;
                    }

                    if (objRetCustomer.CType == "Both")
                    {
                        chkType.Items[0].Selected = true;
                        chkType.Items[1].Selected = true;
                    }

                    if (objRetCustomer.StatusType)
                    {
                        rbtStatus.SelectedIndex = 0;
                    }
                    else
                    {
                        rbtStatus.SelectedIndex = 1;
                    }
                    BindCustomerDocumentDetail(custid);

                    TabContainerCustomer.ActiveTabIndex = 1;
                    btnCustomerSubmit.Enabled = false;
                }
                else
                {
                    lblError.Text = "Customer/Supplier Not Found";
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While shoe the customer detail : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        protected void chkType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkType.SelectedItem.Text != null)
                {
                    //if (chkType.SelectedItem.Text == "Supplier")
                    //{
                    //    chkType.Items[0].Selected = true;

                    //}
                    //if (chkType.SelectedItem.Text == "Customer")
                    //{
                    //          chkType.Items[1].Selected = true;

                    //}
                }
            }

            catch (Exception ex)
            {
                //ex.Message();
            }
        }

        protected void grdCustomer_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton lnkDelete = (LinkButton)e.Row.FindControl("lnkDelete");
                lnkDelete.Attributes.Add("OnClick", "return confirm('Are you sure to Delete this Customer?');");
            }
        }


        #region Get Customer Document By Customer Id

        private void BindCustomerDocumentDetail(int id)
        {
            CustomerBO objCust = new CustomerBO();
            List<CustomerDocument> lst = new List<CustomerDocument>();
            lst = objCust.SearchCustomerDocument(id);
            t.Rows.Clear();
            addfiletable();

            Count = 1;
            foreach (CustomerDocument obj in lst)
            {

                HyperLink lnk = new HyperLink();
                lnk.EnableViewState = true;
                lnk.ID = "lnk" + Count.ToString();
                lnk.Text = obj.FriendlyName;
                lnk.NavigateUrl = "~/CustomerScanID/" + obj.CustomerID.ToString() + "/" + obj.CustomerScanID;
                lnk.Visible = true;
                lnk.Target = "_blank";

                tb = new TextBox();
                tb.EnableViewState = true;
                tb.ID = "txt" + Count.ToString();
                tb.MaxLength = 150;
                tb.Text = obj.CustomerDescription;


                chk = new CheckBox();
                chk.Checked = true;
                chk.ID = "chk" + Count.ToString();

                Label Uid = new Label();
                Uid.EnableViewState = true;
                Uid.ID = "label2" + Count.ToString();
                Uid.Text = Convert.ToString(obj.ScanID);
                Uid.Visible = false;


                Label uName = new Label();
                uName.EnableViewState = true;
                uName.ID = "label3" + Count.ToString();
                uName.Text = obj.CustomerScanID;
                uName.Visible = false;



                TableRow dr = new TableRow();
                TableCell c1 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();
                TableCell c5 = new TableCell();
                TableCell C6 = new TableCell();
                TableCell c7 = new TableCell();
                TableCell c8 = new TableCell();
                TableCell c9 = new TableCell();

                Label DocType = new Label();
                DocType.EnableViewState = true;
                DocType.ID = "lblDocType" + Count.ToString();
                DocType.Text = obj.DocumentType;
                DocType.Visible = true;


                Label DocID = new Label();
                DocID.EnableViewState = true;
                DocID.ID = "lblDocID" + Count.ToString();
                DocID.Text = obj.DocumentID;
                DocID.Visible = true;

                c8.Controls.Add(DocType);
                c9.Controls.Add(DocID);


                c7.Controls.Add(uName);
                //c8.Controls.Add(filePath);

                c3.Text = "File" + Count.ToString(); ;
                c3.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //  c1.Style.Add(HtmlTextWriterStyle.Width, "30%");
                TableCell c2 = new TableCell();
                //   c2.Style.Add(HtmlTextWriterStyle.Width, "30%");
                //   c4.Style.Add(HtmlTextWriterStyle.Width, "4%");
                //   c5.Style.Add(HtmlTextWriterStyle.Width, "2%");
                c2.Controls.Add(tb);
                c1.Controls.Add(lnk);
                c5.Controls.Add(chk);
                C6.Controls.Add(Uid);

                c1.Style.Add(HtmlTextWriterStyle.Width, "25%");
                c2.Style.Add(HtmlTextWriterStyle.Width, "5%");

                //  c3.Style.Add(HtmlTextWriterStyle.Width, "3%");
                c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c8.Style.Add(HtmlTextWriterStyle.Width, "8%");
                c8.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c9.Style.Add(HtmlTextWriterStyle.Width, "20%");
                c9.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c5.Style.Add(HtmlTextWriterStyle.Width, "1%");
                c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");


                dr.Cells.Add(c3);
                dr.Cells.Add(c1);
                dr.Cells.Add(c8);
                dr.Cells.Add(c9);
                // dr.Cells.Add(c4);
                dr.Cells.Add(c2);
                dr.Cells.Add(c5);
                dr.Cells.Add(C6);
                dr.Cells.Add(c7);

                Style myStyle = new Style();
                myStyle.ForeColor = System.Drawing.Color.Black;
                myStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                myStyle.Font.Bold = false;


                c1.ApplyStyle(myStyle);
                c8.ApplyStyle(myStyle);
                c3.ApplyStyle(myStyle);
                c9.ApplyStyle(myStyle);
                c5.ApplyStyle(myStyle);
                c2.ApplyStyle(myStyle);

                t.Rows.Add(dr);
                phControls.Controls.Add(t);
                Count++;

            }
            phControls.Controls.Add(t);
            Session["Files"] = t;
            Session["Count"] = Count;

        }

        #endregion

        protected void Upload_Click(object sender, EventArgs e)
        {


            string serverpath = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "TempUpload" + "\\";

            if (MyFile.HasFile)
            {
                string uid = Guid.NewGuid().ToString();
                string type = System.IO.Path.GetExtension(MyFile.FileName);
                MyFile.SaveAs(serverpath + "\\" + (uid + type));

                #region Save change to the table

                HyperLink lnk = new HyperLink();
                lnk.EnableViewState = true;
                lnk.ID = "lnk" + Count.ToString();
                lnk.Text = MyFile.FileName;
                lnk.NavigateUrl = "~/TempUpload/" + uid + type;
                lnk.Visible = true;
                lnk.Target = "_blank";

                tb = new TextBox();
                tb.EnableViewState = true;
                tb.ID = "txt" + Count.ToString();
                tb.MaxLength = 150;


                chk = new CheckBox();
                chk.Checked = true;
                chk.ID = "chk" + Count.ToString();

                Label lblCustUid = new Label();
                lblCustUid.EnableViewState = true;
                lblCustUid.ID = "label2" + Count.ToString();
                lblCustUid.Text = "";
                lblCustUid.Visible = false;

                Label fileName = new Label();
                fileName.EnableViewState = true;
                fileName.ID = "label3" + Count.ToString();
                fileName.Text = uid + type;
                fileName.Visible = false;

                //Label filePath = new Label();
                //filePath.EnableViewState = true;
                //filePath.ID = "label4" + Count.ToString();
                //filePath.Text = Server.MapPath(lnk.NavigateUrl);
                //filePath.Visible = false;

                TableRow dr = new TableRow();

                TableCell c1 = new TableCell();
                TableCell c3 = new TableCell();

                TableCell c5 = new TableCell();
                TableCell C6 = new TableCell();
                TableCell c7 = new TableCell();

                TableCell c8 = new TableCell();
                TableCell c9 = new TableCell();


                //c4.Style.Add(HtmlTextWriterStyle.Width, "4%");
                //TableCell c4 = new TableCell();
                //TableCell c10 = new TableCell();
                //TableCell c11= new TableCell();
                //c10.Text = "Document Type :";
                //c10.Font.Bold = true;
                //c11.Text = "Document ID :";
                //c11.Font.Bold = true;

                //c4.Text = "Coments :";
                //c4.Font.Bold = true;

                Label DocType = new Label();
                DocType.EnableViewState = true;
                DocType.ID = "lblDocType" + Count.ToString();
                DocType.Text = ddlIDType.SelectedItem.ToString();
                DocType.Visible = true;
                DocType.Width = 100;


                Label DocID = new Label();
                DocID.EnableViewState = true;
                DocID.ID = "lblDocID" + Count.ToString();
                DocID.Text = txtID.Text;
                DocID.Visible = true;

                c8.Controls.Add(DocType);
                c9.Controls.Add(DocID);

                Style myStyle = new Style();
                myStyle.ForeColor = System.Drawing.Color.Black;
                myStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                myStyle.Font.Bold = false;






                c7.Controls.Add(fileName);
                //c8.Controls.Add(filePath);

                c3.Text = "File" + Count.ToString(); ;
                c3.Font.Bold = true;
                c3.Style.Add(HtmlTextWriterStyle.Width, "3%");
                //  c1.Style.Add(HtmlTextWriterStyle.Width, "10%");
                TableCell c2 = new TableCell();
                //   c2.Style.Add(HtmlTextWriterStyle.Width, "30%");
                c1.ApplyStyle(myStyle);
                c8.ApplyStyle(myStyle);
                c3.ApplyStyle(myStyle);
                c9.ApplyStyle(myStyle);
                c5.ApplyStyle(myStyle);
                c2.ApplyStyle(myStyle);



                c2.Controls.Add(tb);
                c1.Controls.Add(lnk);

                c5.Style.Add(HtmlTextWriterStyle.Width, "1%");
                c5.Controls.Add(chk);
                C6.Controls.Add(lblCustUid);

                c1.Style.Add(HtmlTextWriterStyle.Width, "25%");
                c2.Style.Add(HtmlTextWriterStyle.Width, "5%");

                //  c3.Style.Add(HtmlTextWriterStyle.Width, "3%");
                c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c8.Style.Add(HtmlTextWriterStyle.Width, "8%");
                c8.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c9.Style.Add(HtmlTextWriterStyle.Width, "20%");
                c9.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c5.Style.Add(HtmlTextWriterStyle.Width, "10%");
                c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                //c6.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");

                dr.Cells.Add(c3);
                dr.Cells.Add(c1);
                dr.Cells.Add(c8);
                dr.Cells.Add(c9);
                // dr.Cells.Add(c4);
                dr.Cells.Add(c2);
                dr.Cells.Add(c5);
                dr.Cells.Add(C6);
                dr.Cells.Add(c7);
                //Style st = new Style("Back");


                // dr.Cells.Add(c10);


                // dr.Cells.Add(c11);






                //dr.Cells.Add(c8);
                t.Rows.Add(dr);
                phControls.Controls.Add(t);
                Count++;
                Session["Files"] = t;
                Session["Count"] = Count;
                #endregion


            }

            ddlIDType.SelectedIndex = 0;
            txtID.Text = "";

        }

        protected void txtCellno_TextChanged(object sender, EventArgs e)
        {

        }



        #region Bind Sales Type

        private void BindSalesType()
        {
            SalesTypeBO objSalesTypeBO = new SalesTypeBO();
            List<SalesType> lstSalesType = new List<SalesType>();

            lstSalesType = objSalesTypeBO.GetSalesTypeList(false);
            ddlSalesType.DataSource = lstSalesType;
            ddlSalesType.DataTextField = "SalesTypeName";
            ddlSalesType.DataValueField = "SalesTypeID";
            ddlSalesType.DataBind();
            ddlSalesType.Items.Insert(0, new ListItem("----Select----", "0"));
        }


        #endregion

        #region Bind Currency Details

        private void BindCurrencyDetails()
        {
            CurrencyBO objCurrencyBO = new CurrencyBO();
            List<Currency> lstCurrency = new List<Currency>();
            lstCurrency = objCurrencyBO.GetCurrencyList(false);

            ddlCurrency.DataSource = lstCurrency;
            ddlCurrency.DataValueField = "CurrencyID";
            ddlCurrency.DataTextField = "ConvertTO";
            ddlCurrency.DataBind();
            ddlCurrency.Items.Insert(0, new ListItem("----Select----", "0"));
            ddlCurrency.SelectedIndex = 1;
            txtCurrencyConverter.Text = ddlCurrency.SelectedValue.ToString();


        }

        #endregion
        protected void btnNewStore_Click(object sender, EventArgs e)
        {
            Session["Files"] = null;
            Session["Count"] = null;
            ViewState["IsEdit"] = false;

            Response.Redirect("~/CustomerRegistration.aspx");
        }


        protected void ddlCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                CurrencyBO objCurrencyBO = new CurrencyBO();
                Currency objCur = new Currency();

                if (ddlCurrency.SelectedIndex > 0)
                {
                    objCur = objCurrencyBO.GetCurrencyByID(Convert.ToInt32(ddlCurrency.SelectedValue.ToString()));

                    txtCurrencyConverter.Text = objCur.Rate.ToString();
                }
                else
                {
                    lblError.Text = "Invalid Currency Selected";

                }
            }

            catch
            {
                lblError.Text = "Error While getting currency details";


            }
        }
    
    }

    }

