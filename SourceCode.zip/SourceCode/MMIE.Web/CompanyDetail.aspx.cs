﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE
{
    public partial class CompanyDetail : BasePage
    {
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;
        int iPageCount = 0;
        List<Company> lstCompany = null;
        DataSet ds = null;

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSubmit.Enabled = LoginToken.IsAddOn;

            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            if (!IsPostBack)
            {
                ViewState["IsEdit"] = false;
                CallSearch();
                grdCompany.PageSize = GRID_PAGESIZE;
                BindDropDownControl(drFinancialYear, mstlookup.GetLookupsList(LookupNames.FinancialYear));
                if (Request.QueryString["compid"] != null)
                {
                    int compid = Convert.ToInt32(Request.QueryString["compid"].ToString());
                    ViewState["compid"] = compid;
                    BindCompanyDetail(compid);
                }
            }

            else

            {

                CreateNavigation();
            }

            PagePermission();
        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            try
            {
                objDD.DataSource = lstLookups;
                objDD.DataValueField = "ItemId";
                objDD.DataTextField = "ItemName";
                objDD.DataBind();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching the list of compnies : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        private void BindCompanyDetail(int compid)
        {
            try
            {
            ViewState["IsEdit"] = true;
            CompanyBO useradm = new CompanyBO();
            Company objCompany = new Company();
            objCompany.CompanyID =Convert.ToInt16(compid);
            Company objRetCompany = useradm.GetCompanyByID(objCompany);
            if (objRetCompany != null)
            {


              
                ddlType.SelectedValue  = objRetCompany.CompanyType;
                txtCompanyName.Text = objRetCompany.CompanyName;
                txtAcronym.Text = objRetCompany.Acronym;
                txtStreet.Text = objRetCompany.CompanyLandMark ;
                txtVille.Text = objRetCompany.Ville;
                txtCommume.Text = objRetCompany.Commune;
                txtDepartment.Text = objRetCompany.Department ;
                txtPostalCode.Text = objRetCompany.PinNo;
                txtFax.Text = objRetCompany.CompanyFaxNo;
                txtEmail.Text = objRetCompany.CompanyEmailID;
                txtWebsite.Text = objRetCompany.CompanyWebsite ;              
                drFinancialYear.SelectedValue  = objRetCompany.FiscalYear;
                txtStreet.Text = objRetCompany.CompanyLandMark;
                txtPhone.Text = objRetCompany.CompanyPhoneNo;
                txtFax.Text = objRetCompany.CompanyFaxNo; 
                if (objRetCompany.IsActive )
                {
                    rdoStatus.SelectedIndex = 0;
                }
                else
                {
                    rdoStatus.SelectedIndex = 1;
                }
             
            }
            else
            {
                ShowError("Company detail not found");
            }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While shown the company detail : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
            
        }
        public void CallSearch()
        {
            try
            {
                grdCompany.PageIndex = 0;
                Company objCompany = new Company();
                objCompany.CompanyID = 0;
                objCompany.CompanyName = "";
                objCompany.CurrentIndex = 0;
                objCompany.PageSize = GlobalConstant.PageSize;
                //Save Search Options in ViewState
                ViewState[VS_SEARCH] = objCompany;

                BindData(0);
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While shown the company record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

        private void BindData(int currentPageIndex)
        {

            try
            {
                grdCompany.PageIndex = 0;

                PagedDataSource objPagedDataSource = new PagedDataSource();
                objPagedDataSource.AllowCustomPaging = true;
                objPagedDataSource.PageSize = GRID_PAGESIZE;
                objPagedDataSource.CurrentPageIndex = currentPageIndex;

                //Get search option from viewstate
                Company objCompany = (Company)ViewState[VS_SEARCH];
                objCompany.CurrentIndex = currentPageIndex;
                //Save Search Option again
                ViewState[VS_SEARCH] = objCompany;

                //Call service operation to get data from database source
                ds = SearchCompany(objCompany);

                if (ds.Tables[0].Rows.Count > 0)
                {

                    pnlNavigation.Visible = true;
                    this.grdCompany.Visible = true;

                    //Bind data in ViewGrid.
                    objPagedDataSource.VirtualCount = Convert.ToInt32(ds.Tables[0].Rows[0]["MaximumRows"]);
                    //Save Virtual Count in ViewState
                    ViewState[VS_MAXROWS] = objPagedDataSource.VirtualCount;
                    CreateNavigation(currentPageIndex, objPagedDataSource.PageSize, objPagedDataSource.VirtualCount);

                    objPagedDataSource.DataSource = ds.Tables[0].DefaultView;
                    grdCompany.DataSource = objPagedDataSource;
                    grdCompany.DataBind();
                }
                else
                {
                    ShowError("No Records Found");
                    grdCompany.DataSource = null;
                    grdCompany.DataBind();
                    pnlNavigation.Visible = false;
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While show the company detail : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        protected void ShowError(string a_sMsg)
        {
            //errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            //if (a_sMsg.Length > 0)
            //{
            //    errorMessage.Visible = true;
            //}
            //else
            //{
            //    errorMessage.Visible = false;
            //}
        }

        private DataSet SearchCompany(Company objCompany)
        {
            //Call service operation to get data from database source
            CompanyBO st = new CompanyBO();
            lstCompany = st.SearchCompany(objCompany);
            //lstUserLogin = UserAdminServiceAgent.SearchRole(objRole);
            DataTable dt = ORHelper<Company>.GenericListToDataTable(lstCompany);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }
            
            try
            {
                if (Page.IsValid)
                {
                    LoginToken objLoginToken = new LoginToken();
                    Company objCompany = new Company();
                    objCompany.CompanyType = ddlType.SelectedItem.Text;
                    objCompany.CompanyName = txtCompanyName.Text;
                    objCompany.Acronym = txtAcronym.Text;
                    objCompany.Ville = txtVille.Text;
                    objCompany.Commune = txtCommume.Text;
                    objCompany.Department = txtDepartment.Text;
                    objCompany.FiscalYear = drFinancialYear.SelectedItem.Text;
                    objCompany.PinNo = txtPostalCode.Text;
                    objCompany.CompanyPhoneNo = txtPhone.Text;
                    objCompany.CompanyEmailID = txtEmail.Text;
                    objCompany.CompanyWebsite = txtWebsite.Text;
                    objCompany.CompanyStreet  = txtStreet.Text;
                    objCompany.CompanyFaxNo  = txtFax.Text;  
                    objLoginToken.LoginId = LoginToken.LoginId;
                    objCompany.LastModBy = LoginToken.LoginId;
                    
                    if (rdoStatus.SelectedIndex == 0)
                    {
                        objCompany.IsActive  = true;
                    }
                    else
                    {
                        objCompany.IsActive = false;

                    }
                    if (ViewState["compid"] != null)
                    {

                        objCompany.ActionType = EnumActionType.Update;
                        objCompany.CompanyID = Convert.ToInt16(ViewState["compid"]);
                    }
                    else
                    {
                        objCompany.ActionType = EnumActionType.Insert;
                    }

                    CompanyBO Comp = new CompanyBO();
                    bool status = Comp.SaveCompany(objCompany);
                    if (status == true)
                    {
                        CallSearch(); 
                        //display succuss message
                        lblError.Text = ExceptionMessage.GetMessage("C00001");
                        lblError.Visible = true;
                        ddlType.SelectedItem.Text = "Select";
                        txtCompanyName.Text = "";
                        txtAcronym.Text = "";
                        txtVille.Text = "";
                        txtCommume.Text = "";
                        txtDepartment.Text = "";                          
                        txtPostalCode.Text = "";
                        txtPhone.Text = "";
                        txtEmail.Text = "";
                        txtWebsite.Text = "";
                        txtFax.Text = "";
                        txtPostalCode.Text = "";
                        ViewState["IsEdit"] = false;
                    }
                }
               }
            
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                lblError.Text = "Error While save the company detail : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
             ddlType.SelectedValue="Select";
            txtCompanyName.Text="";
            txtAcronym.Text="";
            txtVille.Text="";
            txtCommume.Text="";
            txtDepartment.Text="";
            //txtYear.Text="";
            txtPostalCode.Text="";
            txtPhone.Text="";
            txtEmail.Text="";
            txtWebsite.Text="";
            txtFax.Text = "";
            txtStreet.Text = "";
            txtFax.Text = "";
            txtStreet.Text = "";
            ViewState["IsEdit"] = false;

            ViewState[VS_CURRENTINDEX] = 0;
            ViewState[VS_PAGESIZE] = 0;
            ViewState[VS_MAXROWS] = 0;

            pnlNavigation.Controls.Clear();


        }
        #region Create Paging Navigation and Event handler

        private void CreateNavigation()
        {
            if (ViewState[VS_CURRENTINDEX] == null || ViewState[VS_PAGESIZE] == null || ViewState[VS_MAXROWS] == null)
            {
                return;
            }
            else
            {
                CreateNavigation((int)ViewState[VS_CURRENTINDEX], (int)ViewState[VS_PAGESIZE], (int)ViewState[VS_MAXROWS]);
            }
        }

        private void CreateNavigation(int currentPageIndex, int a_iPageSize, int a_iRowCount)
        {
            //Save the arguments in ViewState
            ViewState[VS_CURRENTINDEX] = currentPageIndex;
            ViewState[VS_PAGESIZE] = a_iPageSize;
            ViewState[VS_MAXROWS] = a_iRowCount;
            pnlNavigation.Controls.Clear();
            if (a_iPageSize == 0)
            {
                return;
            }

            //Get the TotalNumber of Pages
            //int iPageCount = 0;
            iPageCount = 0;
            if (a_iRowCount % a_iPageSize == 0)
            {
                iPageCount = a_iRowCount / a_iPageSize;
            }
            else
            {
                iPageCount = (a_iRowCount / a_iPageSize) + 1;
            }

            if (iPageCount <= 1)
            {
                return;
            }

            //Check if LeftDots are to be displayed
            if ((currentPageIndex + 1) - 5 > 1)
            {
                //Start when left dots are visible then show << button also
                LinkButton linkFirst = new LinkButton();
                linkFirst.Text = " FIRST ";
                linkFirst.CssClass = "lftmenu";
                linkFirst.ID = "linkFirst";
                linkFirst.Click += new EventHandler(linkFirst_Click);
                pnlNavigation.Controls.Add(linkFirst);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
                //End when left dots are visible then show << button also

                int iLIndex = (currentPageIndex + 1) - 5 - 1;
                //Add LeftDots
                LinkButton btnLeftDots = new LinkButton();
                btnLeftDots.Text = " PREVIOUS ";
                btnLeftDots.CssClass = "lftmenu";
                btnLeftDots.ID = "nav_" + iLIndex.ToString();
                btnLeftDots.Attributes.Add("onclick", "__doPostBack('" + btnLeftDots.ClientID + "',' " + iLIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            int iLeftIndex = 1;

            if (currentPageIndex + 1 - 5 > 1)
            {
                iLeftIndex = currentPageIndex + 1 - 5;
            }

            //Create the Number buttons on the left side of the index
            for (int i = iLeftIndex; i <= currentPageIndex; i++)
            {
                LinkButton btnLeftNumbers = new LinkButton();
                btnLeftNumbers.Text = i.ToString();
                btnLeftNumbers.CssClass = "lftmenu";
                btnLeftNumbers.ID = "nav_" + i.ToString();
                btnLeftNumbers.Attributes.Add("onclick", "__doPostBack('" + btnLeftNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Display the Current Page Number
            Label lblCurrent = new Label();
            lblCurrent.Text = Convert.ToString(currentPageIndex + 1);
            lblCurrent.CssClass = "textNormal";
            pnlNavigation.Controls.Add(lblCurrent);
            pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

            //Create Right Number buttons
            int iRightIndex = iPageCount;

            if (currentPageIndex + 1 + 5 < iRightIndex)
            {
                iRightIndex = 5;//currentPageIndex + 1 + 5;
            }

            for (int i = currentPageIndex + 2; i <= iRightIndex; i++)
            {
                LinkButton btnRightNumbers = new LinkButton();
                btnRightNumbers.Text = i.ToString();
                btnRightNumbers.CssClass = "lftmenu";
                btnRightNumbers.ID = "nav_" + i.ToString();
                btnRightNumbers.Attributes.Add("onclick", "__doPostBack('" + btnRightNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Check if RightDots are to be displayed
            if ((currentPageIndex + 1) + 5 < iPageCount)
            {
                int iRIndex = ((currentPageIndex + 1) + 5) + 1;
                //Add RightDots
                LinkButton btnRightDots = new LinkButton();
                btnRightDots.Text = " NEXT ";
                btnRightDots.CssClass = "lftmenu";
                btnRightDots.ID = "nav_" + iRIndex.ToString();
                btnRightDots.Attributes.Add("onclick", "__doPostBack('" + btnRightDots.ClientID + "',' " + iRIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

                //Start when right dots are visible then show >> button also
                LinkButton linkLast = new LinkButton();
                linkLast.Text = " LAST ";
                linkLast.CssClass = "lftmenu";
                linkLast.ID = "linkLast";
                linkLast.Click += new EventHandler(linkLast_Click);
                pnlNavigation.Controls.Add(linkLast);
                //End when left dots are visible then show << button also

                if (pnlNavigation.Controls.Count > 0)
                {
                    pnlNavigation.Visible = true;
                }
                else
                    pnlNavigation.Visible = false;
            }
        }

        protected void linkFirst_Click(object sender, EventArgs e)
        {
            BindData(0);
        }

        protected void linkLast_Click(object sender, EventArgs e)
        {
            BindData(iPageCount - 1);
        }
        #endregion
        public string MakeCustomerIDLink(int CompanyID, string CompanyName)
        {
            string ret;
            string str;
            string pageName;
            pageName = "CompanyDetail.aspx";
            str = pageName + "?compid=" + CompanyID.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + CompanyName + "</a>";
            return ret;
        }

        protected void btnNewCompany_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/CompanyDetail.aspx");
        }
    }
}