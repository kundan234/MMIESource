﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE
{
    public partial class FinancialYearMST : BasePage
    {

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsAddOn;
                btnSave.Enabled = LoginToken.IsModify;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               
                ViewState["IsEdit"] = false;
            }

            PagePermission();
        }


    
        protected void bntSearch_Click(object sender, EventArgs e)
        {
            try
            {
                this.BindFinancialYearList();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While search the year list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        private void BindFinancialYearList()
        {
            FinancialYear objfinancialyear = new FinancialYear();
            FinancialYearBO objFinancialYearBO = new FinancialYearBO();
            List<FinancialYear> lstFinancialYear = new List<FinancialYear>();

            if (txtName.Text != "")
                objfinancialyear.Name = (txtName.Text);
            else
                objfinancialyear.Name = null;
                
            if (txtDescription.Text != "")
                objfinancialyear.Description = txtDescription.Text;
            else
                objfinancialyear.Description = null;

            if (rbtIsActive.SelectedIndex > 0)
                objfinancialyear.IsActive = false;
            else
                objfinancialyear.IsActive = true;
           
            lstFinancialYear = objFinancialYearBO.GetSearchFinancialYear(objfinancialyear);
            grdFinancialYearMST.DataSource = lstFinancialYear;
            grdFinancialYearMST.DataBind();
            grdFinancialYearMST.Visible = true;
        }


        private void Reset()
        {
            txtName.Text = "";
            
            txtDescription.Text = "";
            lblError.Text = "";
            ViewState["YearID"] = null;
            ViewState["IsEdit"] = false;
            rbtIsActive.SelectedIndex = 0;
            grdFinancialYearMST.DataSource = null;
            grdFinancialYearMST.DataBind();
            grdFinancialYearMST.Visible = false;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            this.Reset();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records Please contact to your System Administrator";
                return;

            }
            try
            {
                FinancialYear objfinancialyear = new FinancialYear();
                FinancialYearBO objFinancialYearBO = new FinancialYearBO();
                objfinancialyear.Name = txtName.Text;
                objfinancialyear.Description = txtDescription.Text;

                if (rbtIsActive.SelectedIndex > 0)
                    objfinancialyear.IsActive = false;
                else
                    objfinancialyear.IsActive = true;

                List<FinancialYear> lstFinancialYear = new List<FinancialYear>();


                if (ViewState["YearID"] != null)
                {

                    objfinancialyear.FinancialYearID = Convert.ToInt16(ViewState["YearID"].ToString());
                    objfinancialyear.ActionType = EnumActionType.Update;
                    objfinancialyear.LastModBy = LoginToken.LoginId;
                    objfinancialyear.CompanyID = Convert.ToInt16(LoginToken.CompanyID);


                }
                else
                {
                    objfinancialyear.FinancialYearID = 0;
                    objfinancialyear.ActionType = EnumActionType.Insert;
                    objfinancialyear.AddedBy = LoginToken.LoginId;
                    objfinancialyear.CompanyID = Convert.ToInt16(LoginToken.CompanyID);

                }

                if (objFinancialYearBO.UpdateFinancialYear(objfinancialyear))
                {
                    if (ViewState["YearID"] != null)
                        lblError.Text = "Financial Year Updated Successfully";
                    else
                        lblError.Text = "Financial Year Added Successfully";

                    ViewState["YearID"] = null;
                    ViewState["IsEdit"] = false;

                    txtName.Text = "";
                    txtDescription.Text = "";
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While save the year records : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void grdFinancialYearMST_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "REdit")
                {
                    FinancialYear objfinancialyearMST = new FinancialYear();
                    FinancialYear objfinancialyear = new FinancialYear();
                    FinancialYearBO objFinancialYearBO = new FinancialYearBO();
                    List<FinancialYear> lstFinancialYear = new List<FinancialYear>();
                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    GridViewRow gr = grdFinancialYearMST.Rows[id];
                    LinkButton lblYeareID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");

                    Label lblName = (Label)gr.Cells[2].FindControl("lblName");
                    Label lblDescription = (Label)gr.Cells[3].FindControl("lblDescription");
                    txtDescription.Text = lblDescription.Text;
                  txtName.Text = lblName.Text;
                    ViewState["YearID"] = lblYeareID.Text;
                    ViewState["IsEdit"] = true;
                    if (objfinancialyear.IsActive)
                    {
                        rbtIsActive.SelectedIndex = 1;

                    }
                    else
                    {
                        rbtIsActive.SelectedIndex = 0;

                    }


                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While fetching the year records: " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
    }
}