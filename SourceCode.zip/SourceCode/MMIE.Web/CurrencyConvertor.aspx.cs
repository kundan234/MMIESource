﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE
{
    public partial class CurrencyConvertor : BasePage
    {

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnAdd.Enabled = LoginToken.IsAddOn;

            }
        }

        
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                BindCurrency();
                ViewState["IsEdit"] = false;
            }
            PagePermission();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }

            try
            {
                CurrencyBO objCurrencyBO = new CurrencyBO();
                Currency objCurrency = new Currency();
                objCurrency.ConvertTO = txtConvertTo.Text;
                if (txtRate.Text != "")
                    objCurrency.Rate = Convert.ToDecimal (txtRate.Text);

                if (rbtStatus.SelectedIndex == 0)
                {

                    objCurrency.IsActive = true;
                }
                else
                {
                    objCurrency.IsActive = false;
                }
                
                objCurrency.BaseFormat = txtBaseFormat.Text;
                
                

                if (ViewState["CurrencyID"] != null)
                {
                    objCurrency.CurrencyID = Convert.ToInt32(ViewState["CurrencyID"]);
                    objCurrency.ActionType = 2;
                    objCurrency.LastModBy = LoginToken.LoginId;
                    objCurrency.CompanyID = LoginToken.CompanyID;
                    objCurrency.FinancialYearID = LoginToken.FinancialYearID;

                }
                else
                {
                    objCurrency.CurrencyID = 0;
                    objCurrency.AddedBy = LoginToken.LoginId;
                    objCurrency.ActionType = 1;
                    objCurrency.CompanyID = LoginToken.CompanyID;
                    objCurrency.FinancialYearID = LoginToken.FinancialYearID;
                }


                if (objCurrencyBO.SaveCurrency(objCurrency))
                {
                    txtConvertTo.Text = "";
                    txtRate.Text = "";
                    BindCurrency();
                    if (ViewState["CurrencyID"] != null)
                    {
                        lblError.Text = ExceptionMessage.GetMessage("CR00002");
                        ViewState["IsEdit"] = false;
                    }
                    else
                        lblError.Text = ExceptionMessage.GetMessage("CR00001");

                    lblError.Visible = true;

                    ViewState["CurrencyID"] = null;
                }
            }

            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While save the currency record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }


        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtConvertTo.Text = "";
            txtRate.Text = "";
            lblError.Text = "";
            ViewState["CurrencyID"] = null;
            rbtStatus.SelectedIndex = 0;
            BindCurrency();

        }

        protected void grdCurrency_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCurrency.PageIndex = e.NewPageIndex;
            BindCurrency();
        }

        protected void grdCurrency_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdCurrency.EditIndex = -1;
            BindCurrency();
        }

        protected void grdCurrency_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                //if (e.CommandName == "Delete")
                //{
                //    int i = Convert.ToInt16(e.CommandArgument);
                //    CurrencyBO objCurrencyBO = new CurrencyBO();
                //    Currency objCurrency = new Currency();
                //    objCurrency.CurrencyID = i;
                //    objCurrency.StatusType = false;
                //    objCurrency.ActionType = 3;
                //    objCurrency.LastModBy = LoginToken.LoginId;
                //    if (objCurrencyBO.SaveCurrency(objCurrency))
                //    {
                //        BindCurrency();
                //        lblError.Text = ExceptionMessage.GetMessage("CR00003");
                //        lblError.Visible = true;
                //        BindCurrency();
                //    }
                //}

                if (e.CommandName == "REdit")
                {
                    int i = Convert.ToInt32(e.CommandArgument.ToString());

                    GridViewRow gr= grdCurrency.Rows[i];

                    LinkButton lblID = (LinkButton)gr.Cells[1].FindControl("lblCurrencyID");
                    Label lblBaseFormat = (Label)gr.Cells[2].FindControl("lblBaseFormat");
                    Label lblConvertTo = (Label)gr.Cells[3].FindControl("lblConvertTO");
                    Label lblRate = (Label)gr.Cells[4].FindControl("lblRate");
                    CheckBox chkStatus = (CheckBox)gr.Cells[4].FindControl("chkStatus");
                    if (chkStatus.Checked)
                        rbtStatus.SelectedIndex = 0;
                    else
                        rbtStatus.SelectedIndex = 1;
                        txtBaseFormat.Text = lblBaseFormat.Text;
                    txtConvertTo.Text=lblConvertTo.Text;
                    txtRate.Text=lblRate.Text;
                    ViewState["CurrencyID"] = Convert.ToInt32(lblID.Text);
                    ViewState["IsEdit"] = true;
                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While fetch the currency record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }


        }

        //protected void grdCurrency_RowDeleting(object sender, GridViewDeleteEventArgs e)
        //{

        //}

        //protected void grdCurrency_RowEditing(object sender, GridViewEditEventArgs e)
        //{
        //    grdCurrency.EditIndex = e.NewEditIndex;
        //    BindCurrency();
        //}

        //protected void grdCurrency_RowUpdating(object sender, GridViewUpdateEventArgs e)
        //{
        //    try
        //    {
        //        Label lblID = (Label)grdCurrency.Rows[e.RowIndex].FindControl("lblCurrencyID");
        //        Label lblBaseFormat = (Label)grdCurrency.Rows[e.RowIndex].FindControl("lblBaseFormat");
        //        TextBox txtConvertTo1 = (TextBox)grdCurrency.Rows[e.RowIndex].FindControl("txtConvertTO");
        //        TextBox txtRate1 = (TextBox)grdCurrency.Rows[e.RowIndex].FindControl("txtRate");


        //        CurrencyBO objCurrencyBO = new CurrencyBO();
        //        Currency objCurrency = new Currency();
        //        objCurrency.CurrencyID = Convert.ToInt32(lblID.Text);
        //        objCurrency.BaseFormat = lblBaseFormat.Text;
        //        objCurrency.ConvertTO = txtConvertTo1.Text;
        //        objCurrency.Rate = Convert.ToDecimal(txtRate1.Text);
        //        objCurrency.StatusType = true;
        //        objCurrency.ActionType = 2;
        //        objCurrency.LastModBy = LoginToken.LoginId;
        //        if (objCurrencyBO.SaveCurrency(objCurrency))
        //        {
        //            grdCurrency.EditIndex = -1;
        //            lblError.Text = ExceptionMessage.GetMessage("CR00002");
        //            lblError.Visible = true;

        //        }
        //        BindCurrency();
        //    }
        //    catch (Exception ex)
        //    {
        //        lblError.Text = "Error In Data Updation : " + ex.Message;
        //        lblError.Visible = true;

        //    }


        //}

        private void BindCurrency()
        {
            try
            {

                CurrencyBO objCurrencyBO = new CurrencyBO();

                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(true);
                grdCurrency.DataSource = lstCurrency;
                grdCurrency.DataBind();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While show the currency list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }
    }
}