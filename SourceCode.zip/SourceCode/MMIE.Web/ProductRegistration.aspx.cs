﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;
using System.Text;

namespace MMIE
{
    public partial class ProductRegistration : BasePage
    {
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;

        string fName;
        string MyString;


        List<Product> lstProduct = null;
        DataSet ds = null;
        int iPageCount = 0;
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSubmit.Enabled = LoginToken.IsAddOn;
                btnResetSearch.Enabled = LoginToken.IsAddOn;
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
     
            btnSubmit.Attributes.Add("onclick", "return validate()");

            // btnSearch.Attributes.Add("onclick", "return validate1()");
            lblError.Text = "";
            lblError.Visible = false;
            errorMessage.InnerHtml = "";
            errorMessage.Visible = false;
            //valSummaryMessage.InnerHtml = "";
            //valSummaryMessage.Visible = false;
            //set client side error message
            //    SetErrorMessage();
          

            MasterLookupBO mstlookup = new MasterLookupBO();
            if (!IsPostBack)
            {
                tdVehicleDetail.Visible = false;
                grdProductDetail.PageSize = GRID_PAGESIZE;

                TabContainerproductRegistration_ActiveTabChanged(TabProductSearch, null);
                BindDropDownControl(ddlGroupname, mstlookup.GetLookupsList(LookupNames.Group));
                ddlGroupname.Items.Insert(0, "Select Group");
                BindDropDownControl(ddlGroupSearchType, mstlookup.GetLookupsList(LookupNames.Group));
                BindUnit();
                ddlGroupSearchType.Items.Insert(0, "Select Group");
                //BindDropDownControl(ddlUnit, mstlookup.GetLookupsList(LookupNames.Unit));
                //ddlUnit.Items.Insert(0, "Select Unit");
                TabContainerproductRegistration_ActiveTabChanged(Tabproductdetail, null);
                if (Request.QueryString["proid"] != null)
                {
                    int proid = Convert.ToInt32(Request.QueryString["proid"].ToString());
                    ViewState["proid"] = proid;
                    BindProductDetail(proid);
                }

                ViewState["IsEdit"] = false;
                Session["ProductPrice"] = null;
                if (Request.QueryString["proid"] != null)
                {
                    BindProductDetail(Convert.ToInt32(Request.QueryString["proid"].ToString()));

                }
            }
            else
            {

                string eventTarget = Request.Form["__EVENTTARGET"];
                if (eventTarget != null)
                {
                    if (eventTarget.IndexOf("nav") >= 0)
                    {

                        int pageIndexPos = eventTarget.LastIndexOf("_");
                        string strIndex = eventTarget.Substring(pageIndexPos + 1);
                        int iNewIndex = Convert.ToInt32(strIndex);
                        ViewState["SubmittedNewIndex"] = iNewIndex;
                        if (iNewIndex > 0)
                            BindData(iNewIndex - 1);
                        else
                            BindData(iNewIndex);
                    }

                }
                //Recreate Buttons for Paging
                CreateNavigation();
            }

            PagePermission();
        }
        protected void TabContainerproductRegistration_ActiveTabChanged(object sender, EventArgs e)
        {

        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }

            try
            {
                if (Page.IsValid)
                {
                    //valSummaryMessage.Visible = true ;
                    LoginToken objLoginToken = new LoginToken();
                    //Set Product Detail
                    Product objProduct = new Product();
                    objProduct.ProductName = txtProductName.Text;
                    objProduct.ReferenceName = txtReferenceName.Text;
                    objProduct.Model = txtModel.Text;
                    objProduct.Color = txtColor.Text;
                    objProduct.Descriptions = txtDescription.Text;
                    objProduct.VehicalPower = txtVehiclePower.Text;
                    objProduct.FuelType = txtFuel.Text;
                    if (txtCylainderNo.Text != "")
                        objProduct.CylendorNo = Convert.ToInt32(txtCylainderNo.Text);
                    else
                        objProduct.CylendorNo = 0;
                  
                    if (ddlCategory.SelectedIndex > 0)
                    {
                        objProduct.CategoryID = Convert.ToInt32(ddlCategory.SelectedValue.ToString());

                    }

                    if (rbtCharges.SelectedIndex == 0)
                    {
                        objProduct.ApplyDeliveryCharges = true;
                    }
                    else
                    {
                        objProduct.ApplyDeliveryCharges = false;
                    }

                    if (flFileUpload.PostedFile.ContentLength > 0)
                    {


                        try
                        {
                            fName = flFileUpload.PostedFile.FileName;
                            int ExtractPos = fName.LastIndexOf("\\") + 1;
                            String UploadedFileName = fName.Substring(ExtractPos, fName.Length - ExtractPos);
                            flFileUpload.PostedFile.SaveAs(Server.MapPath("ProdoctsImage") + "\\" + "big" + "\\" + UploadedFileName);
                       
                            String imageUrl = UploadedFileName;
                            int MaxSideSize = 180;
                            System.Drawing.Image objImage = System.Drawing.Image.FromFile(Server.MapPath("ProdoctsImage") + "\\" + "big" + "\\" + UploadedFileName);

                            int intOldWidth = objImage.Width;
                            int intOldHeight = objImage.Height;

                            int intNewWidth = 180;
                            int intNewHeight = 180;

                            int intMaxSide = 180;

                            if (intOldWidth >= intOldHeight)
                            {
                                intMaxSide = intOldWidth;
                            }
                            else
                            {
                                intMaxSide = intOldHeight;
                            }

                            if (intMaxSide > MaxSideSize)
                            {

                                double dblCoef = MaxSideSize / (double)intMaxSide;
                                intNewWidth = Convert.ToInt32(dblCoef * intOldWidth);
                                intNewHeight = Convert.ToInt32(dblCoef * intOldHeight);
                            }
                            else
                            {
                                intNewWidth = intOldWidth;
                                intNewHeight = intOldHeight;
                            }

                            if (imageUrl.IndexOf("/") >= 0 || imageUrl.IndexOf("\\") >= 0)
                            {

                                Response.End();
                            }

                            imageUrl = "ProdoctsImage/" + imageUrl;

                            System.Drawing.Image fullSizeImg = System.Drawing.Image.FromFile(Server.MapPath("ProdoctsImage") + "\\" + "big" + "\\" + UploadedFileName);

                            System.Drawing.Image.GetThumbnailImageAbort dummyCallBack = new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);

                            System.Drawing.Image thumbNailImg = fullSizeImg.GetThumbnailImage(intNewWidth, intNewHeight, dummyCallBack, IntPtr.Zero);

                            MyString = fName;
                            thumbNailImg.Save(Server.MapPath("ProdoctsImage") + "\\" + MyString, ImageFormat.Jpeg);
                            thumbNailImg.Dispose();

                        }

                        catch (Exception ex)
                        {
                            Response.Write("An error occurred - " + ex.ToString());
                        }
                    }
                    objProduct.ProductImg = fName;
                    objProduct.GroupType = Convert.ToInt32(ddlGroupname.SelectedValue);
                   
                    objLoginToken.LoginId = LoginToken.LoginId;
                    objProduct.AddedBy = LoginToken.LoginId;
                    objProduct.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                    objProduct.LastModBy = LoginToken.LoginId;

                    if (ViewState["proid"] != null)
                    {
                        if (fName == null)
                        {
                            if (Session["ProductImg"] != null)
                            {
                                objProduct.ProductImg = Session["ProductImg"].ToString();
                                Session["ProductImg"] = "";
                            }
                        }
                        else
                        {
                            objProduct.ProductImg = fName;
                        }
                        objProduct.ActionType = EnumActionType.Update;
                        objProduct.ProductID = Convert.ToInt32(ViewState["proid"]);
                    }
                    else
                    {
                        objProduct.ActionType = EnumActionType.Insert;
                    }

                    if (rbtStatus.SelectedIndex == 0)
                    {
                        objProduct.StatusType = true;
                    }
                    else
                    {
                        objProduct.StatusType = false;

                    }
                    if (rdoTaxable.SelectedIndex == 0)
                    {
                        objProduct.Taxable = true;
                    }
                    else
                    {
                        objProduct.Taxable = false;

                    }


                    objProduct.InsertXML = CreateGridToXML(1);
                    objProduct.UpdateXML = CreateGridToXML(2);


                    //Calling Save operation of IUserAdmin Service
                    ProductBO Cust = new ProductBO();
                    bool status = Cust.SaveProduct(objProduct);
                    if (status == true)
                    {
                        //display succuss message
                        if (ViewState["proid"] != null)
                        {
                            lblError.Text = "Product updated successfully.";
                        }
                        else
                        lblError.Text = ExceptionMessage.GetMessage("P000006");
                        lblError.Visible = true;
                        txtProductName.Text = "";
                        txtReferenceName.Text = "";
                        txtEquivalentUnit.Text = "";
                        txtretailer1.Text = "";
                        txtretailer2.Text = "";
                        txtCreditRate.Text = "";
                        txtdealer.Text = "";
                        ddlCategory.SelectedIndex = 0;
                        ddlGroupname.SelectedIndex = 0;
                        ddlUnit.SelectedIndex = 0;
                        rbtStatus.SelectedIndex = 0;
                        rdoTaxable.SelectedIndex = 1;
                        rbtCharges.SelectedIndex = 1;
                        txtModel.Text = "";
                        txtColor.Text = "";
                        txtCylainderNo.Text = "";
                        txtFuel.Text = "";
                        txtVehiclePower.Text = "";
                        txtDescription.Text = "";
                        ViewState["IsEdit"] = false;
                        grdProductRate.DataSource = null;
                        grdProductRate.DataBind();

                        Session["ProductPrice"] = null;

                    }
                }

            }
           
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While save the product record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                //TODO: it will handled by client side function invoking
                //reqColor.ErrorMessage = "";
                //reqProductName.ErrorMessage = "";
                //reqRefname.ErrorMessage = "";
                //reqModel.ErrorMessage = "";
                //reqGName.ErrorMessage = "";
                //txtProductName.Text = "";
                //txtReferenceName.Text = "";
                //txtModel.Text = "";
                //txtColor.Text = "";
                //txtDescription.Text = "";

                ////set client side error message
                //SetErrorMessage();
                ddlCategory.SelectedIndex = 0;
                ddlGroupname.SelectedIndex = 0;
                txtProductName.Text = "";
                txtReferenceName.Text = "";
                txtModel.Text = "";
                txtDescription.Text = "";
                txtColor.Text = "";
                txtretailer1.Text = "";
                txtretailer2.Text = "";
                txtCreditRate.Text = "";
                txtdealer.Text = "";
                txtCylainderNo.Text = "";
                txtVehiclePower.Text = "";
                txtFuel.Text = "";
                ddlUnit.SelectedIndex = 0;
                rbtStatus.SelectedIndex = 0;
                rdoTaxable.SelectedIndex = 1;
                rbtCharges.SelectedIndex = 1;
                Session["ProductPrice"] = null;
                ViewState["IsEdit"] = false;
            }
          
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While reset the product record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        protected void SetErrorMessage()
        {
            //reqGName.ErrorMessage = ExceptionMessage.GetMessage("P000000");
            //reqProductName.ErrorMessage = ExceptionMessage.GetMessage("P000001");
            //reqRefname.ErrorMessage = ExceptionMessage.GetMessage("P000002");
            //reqModel.ErrorMessage = ExceptionMessage.GetMessage("P000003");
            //reqColor.ErrorMessage = ExceptionMessage.GetMessage("P000004");
            //reqUnit.ErrorMessage = ExceptionMessage.GetMessage("P000005");

        }
        
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                CallSearch();
            }          
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While search the product record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        public void CallSearch()
        {
            grdProductDetail.PageIndex = 0;

            Product objProduct = new Product();

            objProduct.GroupType = Convert.ToInt32(ddlGroupSearchType.SelectedValue);

            objProduct.ProductName = txtSearchName.Text;
            objProduct.ReferenceName = txtSearchRefname.Text;
            objProduct.Model = txtSearchModel.Text;
            objProduct.CurrentIndex = 0;
            objProduct.PageSize = GlobalConstant.PageSize;

            //Save Search Options in ViewState
            ViewState[VS_SEARCH] = objProduct;

            BindData(0);

        }

        private void BindData(int currentPageIndex)
        {

            try
            {
                grdProductDetail.PageIndex = 0;

                PagedDataSource objPagedDataSource = new PagedDataSource();
                objPagedDataSource.AllowCustomPaging = true;
                objPagedDataSource.PageSize = GRID_PAGESIZE;
                objPagedDataSource.CurrentPageIndex = currentPageIndex;

                //Get search option from viewstate
                Product objProduct = (Product)ViewState[VS_SEARCH];
                objProduct.CurrentIndex = currentPageIndex;
                //Save Search Option again
                ViewState[VS_SEARCH] = objProduct;

                //Call service operation to get data from database source
                ds = SearchProduct(objProduct);

                if (ds.Tables[0].Rows.Count > 0)
                {

                    pnlNavigation.Visible = true;
                    this.grdProductDetail.Visible = true;

                    //Bind data in ViewGrid.
                    objPagedDataSource.VirtualCount = Convert.ToInt32(ds.Tables[0].Rows[0]["MaximumRows"]);
                    //Save Virtual Count in ViewState
                    ViewState[VS_MAXROWS] = objPagedDataSource.VirtualCount;
                    CreateNavigation(currentPageIndex, objPagedDataSource.PageSize, objPagedDataSource.VirtualCount);

                    objPagedDataSource.DataSource = ds.Tables[0].DefaultView;
                    grdProductDetail.DataSource = objPagedDataSource;
                    grdProductDetail.DataBind();
                }
                else
                {
                    ShowError("No Records Found");
                    grdProductDetail.DataSource = null;
                    grdProductDetail.DataBind();
                    pnlNavigation.Visible = false;
                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While shown the product record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        private DataSet SearchProduct(Product objProduct)
        {
            //Call service operation to get data from database source
            ProductBO prod = new ProductBO();
            lstProduct = prod.SearchProudct(objProduct);
            //lstUserLogin = UserAdminServiceAgent.SearchRole(objRole);
            DataTable dt = ORHelper<Product>.GenericListToDataTable(lstProduct);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }


        protected void ShowError(string a_sMsg)
        {
            errorMessage.InnerHtml = "<p class='errorText'><font class='errorText'>" + a_sMsg + "</font></p>";
            if (a_sMsg.Length > 0)
            {
                errorMessage.Visible = true;
            }
            else
            {
                errorMessage.Visible = false;
            }
        }
        public string MakeProductIDLink(int ProductId, string ProductName)
        {
            string ret;
            string str;
            string pageName;
            pageName = "ProductRegistration.aspx";
            str = pageName + "?proid=" + ProductId.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + ProductName + "</a>";
            return ret;
        }
        private void BindProductDetail(int proid)
        {

            try
            {
                ViewState["IsEdit"] = true;

                ProductBO useradm = new ProductBO();
                Product objProduct = new Product();
                objProduct.ProductID = proid;
                Product objRetProduct = useradm.GetProductEntryByID(objProduct);
            if(objRetProduct!=null)
                {
                txtProductName.Text = objRetProduct.ProductName;
                txtReferenceName.Text = objRetProduct.ReferenceName;
                txtModel.Text = objRetProduct.Model;

                if (objRetProduct.GroupId !=0)
                {
                    ddlGroupname.SelectedValue = objRetProduct.GroupId.ToString();                 
                    BindCategory(objRetProduct.GroupId);
                    if (ddlGroupname.SelectedIndex != 1)
                        tdVehicleDetail.Visible = false;
                    else
                        tdVehicleDetail.Visible = true;
                }


                
                txtColor.Text = objRetProduct.Color;
                txtDescription.Text = objRetProduct.Descriptions;
                //txtretailer1.Text = objRetProduct.Retailer1.ToString();
                //txtretailer2.Text = objRetProduct.Retailer2.ToString();
                //txtdealer.Text = objRetProduct.Dealer.ToString();
                //txtCreditRate.Text = objRetProduct.CreditRate.ToString();
                txtFuel.Text = objRetProduct.FuelType;
                txtCylainderNo.Text =(objRetProduct.CylendorNo).ToString();
                txtVehiclePower.Text = objRetProduct.VehicalPower;

                if (objRetProduct.Taxable)
                {
                    rdoTaxable.SelectedIndex = 0;
                }
                else
                {
                    rdoTaxable.SelectedIndex = 1;
                }

                if (objRetProduct.StatusType)
                {
                    rbtStatus.SelectedIndex = 0;
                }
                else
                {
                    rbtStatus.SelectedIndex = 1;
                }

                if (objRetProduct.ApplyDeliveryCharges)
                {

                    rbtCharges.SelectedIndex = 0;
                }
                else
                    rbtCharges.SelectedIndex = 1;
                if (objRetProduct.CategoryID != 0)
                    ddlCategory.SelectedValue = objRetProduct.CategoryID.ToString();

               
                Product objunit = new Product();
                objunit.ProductID = objRetProduct.ProductID;
                objunit.IsActive = false;
                ProductUnitPriceBO objPriceBO = new ProductUnitPriceBO();
                List<Product> objPR = new List<Product>();
              

                objPR = objPriceBO.SearchProductUnitList(objunit);
                Session["ProductPrice"] = objPR;
                grdProductRate.DataSource = objPR;
                grdProductRate.DataBind();

               // ddlUnit.SelectedValue = objRetProduct.UnitId.ToString();
                imgProduct.ImageUrl = "~/ProdoctsImage/" + objRetProduct.ProductImage;
                Session["ProductImg"] = objRetProduct.ProductImage;
                }
            }

            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While show the product list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        #region GridView Event Handler





        protected void grdProductDetail_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdProductDetail.PageIndex = e.NewPageIndex;
            BindData(grdProductDetail.PageIndex + 1);
        }

        #endregion

        #region Create Paging Navigation and Event handler

        private void CreateNavigation()
        {
            if (ViewState[VS_CURRENTINDEX] == null || ViewState[VS_PAGESIZE] == null || ViewState[VS_MAXROWS] == null)
            {
                return;
            }
            else
            {
                CreateNavigation((int)ViewState[VS_CURRENTINDEX], (int)ViewState[VS_PAGESIZE], (int)ViewState[VS_MAXROWS]);
            }
        }

        private void CreateNavigation(int currentPageIndex, int a_iPageSize, int a_iRowCount)
        {
            //Save the arguments in ViewState
            ViewState[VS_CURRENTINDEX] = currentPageIndex;
            ViewState[VS_PAGESIZE] = a_iPageSize;
            ViewState[VS_MAXROWS] = a_iRowCount;
            pnlNavigation.Controls.Clear();
            if (a_iPageSize == 0)
            {
                return;
            }

            //Get the TotalNumber of Pages
            //int iPageCount = 0;
            iPageCount = 0;
            if (a_iRowCount % a_iPageSize == 0)
            {
                iPageCount = a_iRowCount / a_iPageSize;
            }
            else
            {
                iPageCount = (a_iRowCount / a_iPageSize) + 1;
            }

            if (iPageCount <= 1)
            {
                return;
            }

            //Check if LeftDots are to be displayed
            if ((currentPageIndex + 1) - 5 > 1)
            {
                //Start when left dots are visible then show << button also
                LinkButton linkFirst = new LinkButton();
                linkFirst.Text = "FIRST";
                linkFirst.CssClass = "lftmenu";
                linkFirst.ID = "linkFirst";
                linkFirst.Click += new EventHandler(linkFirst_Click);
                pnlNavigation.Controls.Add(linkFirst);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
                //End when left dots are visible then show << button also

                int iLIndex = (currentPageIndex + 1) - 5 - 1;
                //Add LeftDots
                LinkButton btnLeftDots = new LinkButton();
                btnLeftDots.Text = "PREVIOUS";
                btnLeftDots.CssClass = "lftmenu";
                btnLeftDots.ID = "nav_" + iLIndex.ToString();
                btnLeftDots.Attributes.Add("onclick", "__doPostBack('" + btnLeftDots.ClientID + "',' " + iLIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            int iLeftIndex = 1;

            if (currentPageIndex + 1 - 5 > 1)
            {
                iLeftIndex = currentPageIndex + 1 - 5;
            }

            //Create the Number buttons on the left side of the index
            for (int i = iLeftIndex; i <= currentPageIndex; i++)
            {
                LinkButton btnLeftNumbers = new LinkButton();
                btnLeftNumbers.Text = i.ToString();
                btnLeftNumbers.CssClass = "lftmenu";
                btnLeftNumbers.ID = "nav_" + i.ToString();
                btnLeftNumbers.Attributes.Add("onclick", "__doPostBack('" + btnLeftNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Display the Current Page Number
            Label lblCurrent = new Label();
            lblCurrent.Text = Convert.ToString(currentPageIndex + 1);
            lblCurrent.CssClass = "textNormal";
            pnlNavigation.Controls.Add(lblCurrent);
            pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

            //Create Right Number buttons
            int iRightIndex = iPageCount;

            if (currentPageIndex + 1 + 5 < iRightIndex)
            {
                iRightIndex = 5;//currentPageIndex + 1 + 5;
            }

            for (int i = currentPageIndex + 2; i <= iRightIndex; i++)
            {
                LinkButton btnRightNumbers = new LinkButton();
                btnRightNumbers.Text = i.ToString();
                btnRightNumbers.CssClass = "lftmenu";
                btnRightNumbers.ID = "nav_" + i.ToString();
                btnRightNumbers.Attributes.Add("onclick", "__doPostBack('" + btnRightNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Check if RightDots are to be displayed
            if ((currentPageIndex + 1) + 5 < iPageCount)
            {
                int iRIndex = ((currentPageIndex + 1) + 5) + 1;
                //Add RightDots
                LinkButton btnRightDots = new LinkButton();
                btnRightDots.Text = "NEXT";
                btnRightDots.CssClass = "lftmenu";
                btnRightDots.ID = "nav_" + iRIndex.ToString();
                btnRightDots.Attributes.Add("onclick", "__doPostBack('" + btnRightDots.ClientID + "',' " + iRIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

                //Start when right dots are visible then show >> button also
                LinkButton linkLast = new LinkButton();
                linkLast.Text = "LAST";
                linkLast.CssClass = "lftmenu";
                linkLast.ID = "linkLast";
                linkLast.Click += new EventHandler(linkLast_Click);
                pnlNavigation.Controls.Add(linkLast);
                //End when left dots are visible then show << button also

                if (pnlNavigation.Controls.Count > 0)
                {
                    pnlNavigation.Visible = true;
                }
                else
                    pnlNavigation.Visible = false;
            }
        }

        protected void linkFirst_Click(object sender, EventArgs e)
        {
            BindData(0);
        }

        protected void linkLast_Click(object sender, EventArgs e)
        {
            BindData(iPageCount - 1);
        }

        #endregion

        protected void grdProductDetail_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.ToString())
            {
                case "Delet":
                    try
                    {
                        int Productid = Convert.ToInt32(e.CommandArgument.ToString().Trim());
                        Product objProduct = new Product();
                        objProduct.ProductID = Productid;
                        objProduct.LastModBy = LoginToken.LoginId;
                        objProduct.ActionType = EnumActionType.Delete;
                        ProductBO prod = new ProductBO();
                        bool status = prod.DeleteProduct(objProduct);
                        if (status)
                        {
                            CallSearch();

                            lblError.Text = ExceptionMessage.GetMessage("1000017");
                            lblError.Visible = true;
                        }

                    }
                   
                    catch (Exception ex) //Exception in agent layer itself
                    {
                        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                        LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                        lblError.Text = "Error While delete the product record : " + ExceptionMessage.GetMessage(ex);
                        lblError.Visible = true;
                    }
                    break;
            }
        }
        protected void btnResetSearch_Click(object sender, EventArgs e)
        {
            txtSearchName.Text = "";
            txtSearchRefname.Text = "";
            txtSearchModel.Text = "";
            ddlGroupSearchType.SelectedIndex = 0;
            grdProductDetail.DataSource = null;
            grdProductDetail.DataBind();
            

            ViewState[VS_CURRENTINDEX] = 0;
            ViewState[VS_PAGESIZE] = 0;
            ViewState[VS_MAXROWS] = 0;
            pnlNavigation.Controls.Clear();
        }
        public bool ThumbnailCallback()
        {
            return false;
        }

        protected void grdProductDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton lnkDelete = (LinkButton)e.Row.FindControl("lnkDelete");
                lnkDelete.Attributes.Add("OnClick", "return confirm('Are you sure to Delete this Product?');");
              
            }
        }



        private void BindCategory(int ID )
        {
            try
            {
                List<ProductCategory> lstProductCategory = new List<ProductCategory>();
                 ProductCategoryBO objProductCategoryBO = new ProductCategoryBO();
                 ProductCategory objcategory = new ProductCategory();
                 objcategory.GroupID = ID;
                 objcategory.IsActive = true;

                lstProductCategory = objProductCategoryBO.GerSearchProductCategory(objcategory);

                if (lstProductCategory.Count != 0)
                {
                    ddlCategory.DataSource = lstProductCategory;
                    ddlCategory.DataTextField = "ProductCategoryName";
                    ddlCategory.DataValueField = "ProductCategoryID";
                    ddlCategory.DataBind();
                }
                ddlCategory.Items.Insert(0, "--Select--");
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While show the category list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        //protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (ddlCategory.SelectedIndex > 0)
        //    {

        //        BindUnit(Convert.ToInt32(ddlCategory.SelectedValue));
        //    }
        //}

        private void BindUnit()
        {
            try
            {
                UnitDT objUnit = new UnitDT();
              //  objUnit.ProductCategoryID = CategoryID;
                objUnit.IsActive = true;
                List<UnitDT> lstUnit = new List<UnitDT>();
                UnitBO objProductCategoryBO = new UnitBO();
                lstUnit = objProductCategoryBO.GetSearchUnitList(objUnit);



                if (lstUnit.Count != 0)
                {
                    ddlUnit.DataSource = lstUnit;
                    ddlUnit.DataTextField = "UnitName";
                    ddlUnit.DataValueField = "UnitID";
                    ddlUnit.DataBind();
                }
                ddlUnit.Items.Insert(0, "--Select--");
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While show the category list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void ddlGroupname_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ProductCategory objProductCategory = new ProductCategory();

                if (ddlGroupname.SelectedIndex > 0)
                {
                    objProductCategory.GroupID = Convert.ToInt32(ddlGroupname.SelectedValue);
                    objProductCategory.IsActive = true;
                    BindCategory(Convert.ToInt32(ddlGroupname.SelectedValue.ToString()));
                    if (ddlGroupname.SelectedIndex != 1)
                        tdVehicleDetail.Visible = false;
                    else
                        tdVehicleDetail.Visible = true;
                }
                else
                {
                    ddlCategory.Items.Clear();
                    ddlCategory.Items.Insert(0, "--Select--");
                }
               
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Change the Group name : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

        protected void grdProductRate_RowCommand(object sender, GridViewCommandEventArgs e)
        {
           
                if (e.CommandName == "RDelete")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    List<Product> lstProductRates = Session["ProductPrice"] == null ? new List<Product>() : (List<Product>)Session["ProductPrice"];
                    lstProductRates.RemoveAt(id - 1); ;

                    Session["ProductPrice"] = lstProductRates;
                    grdProductRate.DataSource = lstProductRates;
                    grdProductRate.DataBind();


                }

        }

        protected void grdProductRate_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void btnAddRates_Click(object sender, EventArgs e)
        {
            List<Product> lstProductRates = Session["ProductPrice"] == null ? new List<Product>() : (List<Product>)Session["ProductPrice"];
            Product objProductRate = new Product();
            lblIsUnitExist.Text = "";
            foreach (Product objPr in lstProductRates)
            {
                if (objPr.UnitId == Convert.ToInt32(ddlUnit.SelectedValue))
                {
                    lblIsUnitExist.Text = "Unit Already Exist";
                    return;
                }


            }


            objProductRate.UnitId = Convert.ToInt32(ddlUnit.SelectedValue);
            objProductRate.UnitName = ddlUnit.SelectedItem.Text;
            objProductRate.EquivalentUnit = Convert.ToDecimal(txtEquivalentUnit.Text);
            objProductRate.Retailer1 = Convert.ToDecimal(txtretailer1.Text);
            objProductRate.Retailer2 = Convert.ToDecimal(txtretailer2.Text);
            objProductRate.CreditRate = Convert.ToDecimal(txtCreditRate.Text);
            objProductRate.Dealer = Convert.ToDecimal(txtdealer.Text);
            objProductRate.IsActive = true;

            if (ViewState["ProductID"] != null)
            {

                objProductRate.ActionType = EnumActionType.Insert;
                objProductRate.ProductID = Convert.ToInt32(ViewState["ProductID"]);
                       


            }
            else
            {
                objProductRate.ProductID = 0;
             
            }

            lstProductRates.Add(objProductRate);
            Session["ProductPrice"] = lstProductRates;
            grdProductRate.DataSource = lstProductRates;
            grdProductRate.DataBind();
            ddlUnit.SelectedIndex = 0;
            txtEquivalentUnit.Text = "";
            txtdealer.Text = "";
            txtretailer1.Text = "";
            txtretailer2.Text = "";
            txtCreditRate.Text = "";
        
        }

        protected void grdProductRate_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        

        protected void grdProductRate_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdProductRate.EditIndex = e.NewEditIndex;

            List<Product> lstProductRates = Session["ProductPrice"] == null ? new List<Product>() : (List<Product>)Session["ProductPrice"];
            //Session["ProductPrice"] = lstProductRates;
            grdProductRate.DataSource = lstProductRates;
            grdProductRate.DataBind();
        }

        protected void grdProductRate_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            grdProductRate.EditIndex = e.RowIndex;
            
            List<Product> lstProductRates = Session["ProductPrice"] == null ? new List<Product>() : (List<Product>)Session["ProductPrice"];
            Product objProductUnit = new Product();
            
    //        objProductUnit=  lstProduct[grdProductRate.EditIndex];
            
    //           GridViewRow row = TaskGridView.Rows[e.RowIndex];

    //           objProductUnit.EquivalentUnit = Convert.ToDecimal(((TextBox)(row.Cells[2].Controls[0])).Text);
    //           objProductUnit.Retailer1 = Convert.ToDecimal( ((TextBox)(row.Cells[1].Controls[0])).Text);
    //           objProductUnit.Retailer2 = Convert.ToDecimal(((TextBox)(row.Cells[2].Controls[0])).Text);
    //           objProductUnit.Retailer1 = Convert.ToDecimal(((TextBox)(row.Cells[2].Controls[0])).Text);
    //           objProductUnit.Retailer1 = Convert.ToDecimal(((TextBox)(row.Cells[2].Controls[0])).Text);
    //dt.Rows[row.DataItemIndex]["IsComplete"] = ((CheckBox)(row.Cells[3].Controls[0])).Checked;

            
 
           

            
            
            Session["ProductPrice"] = lstProductRates;


            grdProductRate.DataSource = lstProductRates;
            grdProductRate.DataBind();
        }

        protected void grdProductRate_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdProductRate.EditIndex = -1;
            List<Product> lstProductRates = Session["ProductPrice"] == null ? new List<Product>() : (List<Product>)Session["ProductPrice"];
           
            
            Session["ProductPrice"] = lstProductRates;
             grdProductRate.DataSource = lstProductRates;
            grdProductRate.DataBind();
        }




        protected string CreateGridToXML(int Action)
        {
            StringBuilder objBuilder = new StringBuilder();
            CheckBox chk = new CheckBox();
            

            foreach (GridViewRow gr in grdProductRate.Rows)
            {

                chk = (CheckBox)gr.Cells[7].FindControl("chkIsActive");

                int PriceID = Convert.ToInt32(((Label)(gr.FindControl("lblProductPriceID"))).Text);
                if(PriceID ==0  && Action==1)
                {
                    objBuilder.Append("<ProductRatesInsert ProductPriceID= \"" + PriceID.ToString() + "\" ");
                objBuilder.Append(" ProductID= \"" + ((Label)(gr.FindControl("lblProductID"))).Text + "\" ");
                objBuilder.Append(" UnitID= \"" + ((Label)(gr.FindControl("lblUnitID"))).Text + "\" ");
                objBuilder.Append(" EquivalentUnit  = \"" + ((TextBox)(gr.FindControl("txtEquivalentUnit"))).Text + "\" ");
                objBuilder.Append(" Retailer1  = \"" + ((TextBox)(gr.FindControl("txtRetailer1"))).Text + "\" ");
                objBuilder.Append(" Retailer2  = \"" + ((TextBox)(gr.FindControl("txtRetailer2"))).Text + "\" ");
                objBuilder.Append(" Dealer  = \"" + ((TextBox)(gr.FindControl("txtDealer"))).Text + "\" ");
                objBuilder.Append(" CreditRate  = \"" + ((TextBox)(gr.FindControl("txtCreditRate"))).Text + "\" ");
                objBuilder.Append(" IsActive = \"" + chk.Checked.ToString() + "\" ");
                objBuilder.Append("/>");

                }
                else if(PriceID !=0  && Action==2)
                {
                    objBuilder.Append("<ProductRatesUpdate ProductPriceID= \"" + PriceID.ToString() + "\" ");
                objBuilder.Append(" ProductID= \"" + ((Label)(gr.FindControl("lblProductID"))).Text + "\" ");
                objBuilder.Append(" UnitID= \"" + ((Label)(gr.FindControl("lblUnitID"))).Text + "\" ");
                
                objBuilder.Append(" EquivalentUnit  = \"" + ((TextBox)(gr.FindControl("txtEquivalentUnit"))).Text + "\" ");
                objBuilder.Append(" Retailer1  = \"" + ((TextBox)(gr.FindControl("txtRetailer1"))).Text + "\" ");
                objBuilder.Append(" Retailer2  = \"" + ((TextBox)(gr.FindControl("txtRetailer2"))).Text + "\" ");
                objBuilder.Append(" Dealer  = \"" + ((TextBox)(gr.FindControl("txtDealer"))).Text + "\" ");
                objBuilder.Append(" CreditRate  = \"" + ((TextBox)(gr.FindControl("txtCreditRate"))).Text + "\" ");

                objBuilder.Append(" IsActive = \"" + chk.Checked.ToString() + "\" ");
                objBuilder.Append("/>");

                }

            }

            return objBuilder.ToString();
        }

        protected void grdProductDetail_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }


    }
}