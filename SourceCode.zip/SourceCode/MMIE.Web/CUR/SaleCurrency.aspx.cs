﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Data.CUR;
using MMIE.BusinessProcess.CUR;


namespace MMIE.CUR
{
    public partial class SaleCurrency : System.Web.UI.Page
    {
        DataSet ds = null;
        int SearchCustomerID = 0;
        List<Order> lstOrder = null;
        DataSet dsOrderdetails = null;
        const string VS_SEARCH = "VS_SEARCH";
        private int Count = 1;
        private Table t;
        TextBox tb;
        LoginToken objLoginToken;
        private Currency objCurrency = new Currency();
        private CurrencyBO objCurrencyBO = new CurrencyBO();
        protected void Page_Load(object sender, EventArgs e)
        {

            objLoginToken = (LoginToken)Session["LoginToken"];
            if (!IsPostBack)
            {
                
                CurrencyBO objCurrencyBO = new CurrencyBO();    
                ddlSaleCurrency.DataSource = objCurrencyBO.GetCurrencyList(false);
                ddlSaleCurrency.DataTextField = "ConvertTo";
                ddlSaleCurrency.DataValueField = "CIDRate";
                ddlSaleCurrency.DataBind();

                ddlEquivalentCurrency.DataSource = objCurrencyBO.GetCurrencyList(false);
                ddlEquivalentCurrency.DataTextField = "ConvertTo";
                ddlEquivalentCurrency.DataValueField = "CIDRate";
                ddlEquivalentCurrency.DataBind();
                txtRate.Text = (Convert.ToDecimal(ddlSaleCurrency.SelectedValue.Split('-')[1]) / Convert.ToDecimal(ddlEquivalentCurrency.SelectedValue.Split('-')[1])).ToString();
            }
        }
        protected void txtCustomer_TextChanged(object sender, EventArgs e)
        {
            string GetCustomerId = txtCustomer.Text;
            string[] SplitGetCustomerId = GetCustomerId.Split('-');
            int i = 0;
            foreach (string word in SplitGetCustomerId)
            {
                i = i + 1;

                if (i == 1)
                {
                    SearchCustomerID = Convert.ToInt32(word);
                    BindCustomerDetail(SearchCustomerID);
                    BindCustomerDocumentDetail(SearchCustomerID);

                }
            }
        }

        private void BindCustomerDetail(int custid)
        {
            CustomerBO useradm = new CustomerBO();
            Customer objCustomer = new Customer();
            objCustomer.CustomerID = custid;
            Customer objRetCustomer = useradm.GetCustomerByID(objCustomer);
            if (objRetCustomer != null)
            {
                txtCustomer.Text = objRetCustomer.CustomerName.Trim();
                txtAddress.Text = objRetCustomer.CustomerAddress.Trim();
                txtStreet.Text = objRetCustomer.CustomerStreet.Trim();
                txtCity.Text = objRetCustomer.CityName.Trim();
                txtCountry.Text = objRetCustomer.CountryName.Trim();
                txtPhone.Text = objRetCustomer.CustomerPhone.Trim();
                txtCellPhone.Text = objRetCustomer.CustomerMobile.Trim();
                txtEmail.Text = objRetCustomer.CustomerEmail.Trim();
                txtWebsite.Text = objRetCustomer.CustomerWebsite.Trim();
                txtFax.Text = objRetCustomer.CustomerFax.Trim();
                hdnCustID.Value = Convert.ToString(objRetCustomer.CustomerID);
                hdnSalesTypeID.Value = Convert.ToString(objRetCustomer.SalesTypeID);
                //hdnStreetChargeID.Value = Convert.ToString(objRetCustomer.StreetChargeID);
                //lblMaxCreditLimit.Text = Convert.ToString(objRetCustomer.OpeningBalance);
                //lblMaxCreditLimitUSD.Text = Convert.ToString(objRetCustomer.OpeningBalanceUSD);
                //lblCreditLimit.Text = Convert.ToString(objRetCustomer.MaxCreditLimit);
                //lblCreditLimitUSD.Text = Convert.ToString(objRetCustomer.MaxCreditLimitUSD);
                //------------------refrence detail------
            }

        }

        private void BindCustomerDocumentDetail(int id)
        {
            CheckBox chk;
            CustomerBO objCust = new CustomerBO();
            List<CustomerDocument> lst = new List<CustomerDocument>();
            lst = objCust.SearchCustomerDocument(id);
           // t.Rows.Clear();
            addfiletable();

            Count = 1;
            foreach (CustomerDocument obj in lst)
            {

                HyperLink lnk = new HyperLink();
                lnk.EnableViewState = true;
                lnk.ID = "lnk" + Count.ToString();
                lnk.Text = obj.FriendlyName;
                lnk.NavigateUrl = "~/CustomerScanID/" + obj.CustomerID.ToString() + "/" + obj.CustomerScanID;
                lnk.Visible = true;
                lnk.Target = "_blank";

                tb = new TextBox();
                tb.EnableViewState = true;
                tb.ID = "txt" + Count.ToString();
                tb.MaxLength = 150;
                tb.Text = obj.CustomerDescription;
                tb.Enabled = false;


                chk = new CheckBox();
                chk.Checked = true;
                chk.ID = "chk" + Count.ToString();
                chk.Enabled = true;

                Label Uid = new Label();
                Uid.EnableViewState = true;
                Uid.ID = "label2" + Count.ToString();
                Uid.Text = Convert.ToString(obj.ScanID);
                Uid.Visible = false;


                Label uName = new Label();
                uName.EnableViewState = true;
                uName.ID = "label3" + Count.ToString();
                uName.Text = obj.CustomerScanID;
                uName.Visible = false;



                TableRow dr = new TableRow();
                TableCell c1 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();
                TableCell c5 = new TableCell();
                TableCell C6 = new TableCell();
                TableCell c7 = new TableCell();
                TableCell c8 = new TableCell();
                TableCell c9 = new TableCell();

                Label DocType = new Label();
                DocType.EnableViewState = true;
                DocType.ID = "lblDocType" + Count.ToString();
                DocType.Text = obj.DocumentType;
                DocType.Visible = true;


                Label DocID = new Label();
                DocID.EnableViewState = true;
                DocID.ID = "lblDocID" + Count.ToString();
                DocID.Text = obj.DocumentID;
                DocID.Visible = true;

                c8.Controls.Add(DocType);
                c9.Controls.Add(DocID);


                c7.Controls.Add(uName);
                //c8.Controls.Add(filePath);

                c3.Text = "File" + Count.ToString(); ;
                c3.Style.Add(HtmlTextWriterStyle.Width, "1%");
                //  c1.Style.Add(HtmlTextWriterStyle.Width, "30%");
                TableCell c2 = new TableCell();
                //   c2.Style.Add(HtmlTextWriterStyle.Width, "30%");
                //   c4.Style.Add(HtmlTextWriterStyle.Width, "4%");
                //   c5.Style.Add(HtmlTextWriterStyle.Width, "2%");
                c2.Controls.Add(tb);
                c1.Controls.Add(lnk);
                c5.Controls.Add(chk);
                C6.Controls.Add(Uid);

                c1.Style.Add(HtmlTextWriterStyle.Width, "25%");
                c2.Style.Add(HtmlTextWriterStyle.Width, "5%");

                //  c3.Style.Add(HtmlTextWriterStyle.Width, "3%");
                c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c8.Style.Add(HtmlTextWriterStyle.Width, "8%");
                c8.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c9.Style.Add(HtmlTextWriterStyle.Width, "20%");
                c9.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
                c5.Style.Add(HtmlTextWriterStyle.Width, "1%");
                c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");


                dr.Cells.Add(c3);
                dr.Cells.Add(c1);
                dr.Cells.Add(c8);
                dr.Cells.Add(c9);
                // dr.Cells.Add(c4);
                dr.Cells.Add(c2);
                dr.Cells.Add(c5);
                dr.Cells.Add(C6);
                dr.Cells.Add(c7);

                Style myStyle = new Style();
                myStyle.ForeColor = System.Drawing.Color.Black;
                myStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                myStyle.Font.Bold = false;


                c1.ApplyStyle(myStyle);
                c8.ApplyStyle(myStyle);
                c3.ApplyStyle(myStyle);
                c9.ApplyStyle(myStyle);
                c5.ApplyStyle(myStyle);
                c2.ApplyStyle(myStyle);

                t.Rows.Add(dr);
                phControls.Controls.Add(t);
                Count++;

            }
            phControls.Controls.Add(t);
            Session["Files"] = t;
            Session["Count"] = Count;

        }

        private void addfiletable()
        {
            t = new Table();
            t.Rows.Clear();
            t.BorderStyle = BorderStyle.Solid;

            TableHeaderRow th = new TableHeaderRow();
            th.BorderStyle = BorderStyle.Solid;
            TableCell c1 = new TableCell();
            c1.Text = "S.No.";
            c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

            TableCell c2 = new TableCell();
            c2.Text = "Uploaded Files";
            c2.Style.Add(HtmlTextWriterStyle.Width, "25%");

            TableCell c3 = new TableCell();
            c3.Text = "Document Type";
            c3.Style.Add(HtmlTextWriterStyle.Width, "8%");
            c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c4 = new TableCell();
            c4.Text = "Document ID";
            c4.Style.Add(HtmlTextWriterStyle.Width, "20%");
            c4.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            TableCell c5 = new TableCell();
            c5.Text = "Remarks";
            c5.Style.Add(HtmlTextWriterStyle.Width, "10%");
            c5.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");

            TableCell c6 = new TableCell();
            c6.Style.Add(HtmlTextWriterStyle.Width, "1%");
            c6.Text = "Checked";
            c6.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");



            th.Cells.Add(c1);
            th.Cells.Add(c2);
            th.Cells.Add(c3);
            th.Cells.Add(c4);
            th.Cells.Add(c5);
            th.Cells.Add(c6);



            Style myStyle = new Style();
            myStyle.ForeColor = System.Drawing.Color.Black;
            myStyle.BackColor = System.Drawing.Color.LightGray;
            myStyle.Font.Bold = true;
            myStyle.BorderStyle = BorderStyle.Solid;

            th.ApplyStyle(myStyle);
            // th.Font.Size =Unit.Percentage(12);
            th.BorderStyle = BorderStyle.Solid;
            th.BorderWidth = Unit.Pixel(1);

            t.Rows.Add(th);

        }

        protected void ddlEquivalentCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {

            lblError.Visible = false;
            txtRate.Text = (Convert.ToDecimal(ddlSaleCurrency.SelectedValue.Split('-')[1]) / Convert.ToDecimal(ddlEquivalentCurrency.SelectedValue.Split('-')[1])).ToString(".##");
            if (txtSaleAmount.Text != "")
                txtEquivalentAmount.Text = (Convert.ToDecimal(txtSaleAmount.Text) * Convert.ToDecimal(txtRate.Text)).ToString(".##");
        }

        protected void txtSaleAmount_TextChanged(object sender, EventArgs e)
        {
            txtEquivalentAmount.Text = (Convert.ToDecimal(txtSaleAmount.Text) * Convert.ToDecimal(txtRate.Text)).ToString(".##");
            lblError.Visible = false;
        }


        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {

                ExchangeCurrencyBO objExchangeCurrencyBO = new ExchangeCurrencyBO();
                ExchangeCurrency objExchangeCurrency = new ExchangeCurrency();
                objExchangeCurrency.CustomerID = Convert.ToInt32(hdnCustID.Value);
                objExchangeCurrency.PurchaseCurrencyID = Convert.ToInt32(ddlSaleCurrency.SelectedValue.Split('-')[0]);
                objExchangeCurrency.EquivalentCurrencyId = Convert.ToInt32(ddlEquivalentCurrency.SelectedValue.Split('-')[0]);
                objExchangeCurrency.Rate = Convert.ToDecimal(txtRate.Text);
                objExchangeCurrency.PurchaseCurrencyAmount = Convert.ToDecimal(txtSaleAmount.Text);
                objExchangeCurrency.EquiCurrencyAmount = Convert.ToDecimal(txtEquivalentAmount.Text);
                objExchangeCurrency.AddedBy = objLoginToken.UserLoginId;
                objExchangeCurrency.LastModBy = objLoginToken.UserLoginId;
                objExchangeCurrencyBO.SaveExchangeCurrency(objExchangeCurrency);
                
                lblError.Text = "Data saved successfully.";
                lblError.Visible = true;
            }
            catch (Exception ex)
            {
                lblError.Visible = true;
                lblError.Text = "Data not saved successfully.";
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                
            }

        }

        protected void ddlSaleCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Visible = false;
            txtRate.Text = (Convert.ToDecimal(ddlSaleCurrency.SelectedValue.Split('-')[1]) / Convert.ToDecimal(ddlEquivalentCurrency.SelectedValue.Split('-')[1])).ToString(".##");
            if(txtSaleAmount.Text!="")
                txtEquivalentAmount.Text = (Convert.ToDecimal(txtSaleAmount.Text) * Convert.ToDecimal(txtRate.Text)).ToString(".##");
        }       
    }
}