﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data.SqlClient;
using System.Configuration;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;
using System.Collections;
using MMIE.SAL.Report;
using MMIE.Web.Reports;

namespace MMIE.CUR.Report
{
    public partial class CurrencyReportViewer : BasePage
    {   ReportDocument rptDoc;
        protected void Page_Load(object sender, EventArgs e)
        {
            ReportUtil RU = new ReportUtil();
           
            // Hide show Report Export Button
            crSaleReport.HasExportButton = this.LoginToken.IsPrintExportOn;

            if (Request.QueryString["ReportType"] == "PurchaseCurrency")
            {
                try
                {

                    rptDoc = new PurchaseCurrency();
                    Hashtable htable = new Hashtable();
                    htable.Add("@PurchaseCurrencyID", Request.QueryString["PurchaseCurrencyID"].Trim());
                    htable.Add("@FromDate", Request.QueryString["FromDate"].Trim());
                    htable.Add("@ToDate", Request.QueryString["ToDate"].Trim());
                    htable.Add("@CustomerName", Request.QueryString["CustomerName"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "PurchaseCurrencyReport")
            {
                try
                {

                    rptDoc = new PurchaseCurrency();
                    Hashtable htable = new Hashtable();
                    htable.Add("@PurchaseCurrencyID", Request.QueryString["Currency"].Trim());
                   
                    htable.Add("@FromDate", Request.QueryString["FromDate"].Trim());
                    htable.Add("@ToDate", Request.QueryString["ToDate"].Trim());
                    htable.Add("@CustomerName", Request.QueryString["Customer"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "PurchaseCurrencyReciept")
            {
                try
                {

                    rptDoc = new rptPurchaseCurrencyReciept();
                    Hashtable htable = new Hashtable();
                    htable.Add("@PurchaseID", Request.QueryString["PurchaseId"].Trim());
                   
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "CompanyCurrencyStatus")
            {
                try
                {

                    rptDoc = new rptCompanyCurrencyStatus();
                    Hashtable htable = new Hashtable();
                    htable.Add("@CompanyCode", Request.QueryString["CompanyCode"].Trim());
                    htable.Add("@CompanyID", Request.QueryString["Branch"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }
        }
        protected void Page_UnLoad(object sender, EventArgs e)
        {

            rptDoc.Close();
            rptDoc.Dispose();

        }
    }
}