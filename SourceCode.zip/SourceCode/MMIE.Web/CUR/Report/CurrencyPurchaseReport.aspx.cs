﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.BusinessProcess.Common;
using MMIE.Data.Common;

namespace MMIE.CUR.Report
{
    public partial class CurrencyPurchaseReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtStartDate.Attributes.Add("ReadOnly", "True");
            txtEndDate.Attributes.Add("ReadOnly", "True");

            MasterLookupBO mstlookup = new MasterLookupBO();
            BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
            dllBranch.Items.Insert(0, "--Select--");
            txtStartDate.Text = System.DateTime.Now.ToShortDateString();
            txtEndDate.Text = System.DateTime.Now.ToShortDateString();
            
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }
    }
}