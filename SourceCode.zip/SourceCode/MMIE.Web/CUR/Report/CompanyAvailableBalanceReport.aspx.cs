﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.CUR.Report
{
    public partial class CompanyAvailableBalanceReport :BasePage
    {

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                dllBranch.SelectedValue = Convert.ToString(LoginToken.CompanyID);
                dllBranch.Enabled = LoginToken.IsChangeBranchOn;               
                btnPrint.Enabled = LoginToken.IsPrintOn;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            MasterLookupBO mstlookup = new MasterLookupBO();
            BindDropDownControl(dllBranch, mstlookup.GetLookupsList(LookupNames.Company));
            dllBranch.Items.Insert(0, "--Select--");

            PagePermission();
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }
    }
}