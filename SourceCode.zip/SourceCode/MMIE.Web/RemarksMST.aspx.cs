﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE
{
    public partial class RemarksMST : BasePage
    {

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsAddOn;

            }
        }

        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                ViewState["IsEdit"] = false;
            }
            PagePermission();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records Please contact to your System Administrator";
                return;

            }
            try
            {

                Remarks objRemarks = new Remarks();
                RemarksBO  objRemarksBO = new RemarksBO();

                objRemarks.RemarksDetails = txtRemarksDetails.Text;


                if (rbtStatus.SelectedIndex == 1)
                {
                    objRemarks.IsActive = false;


                }
                else
                {
                    objRemarks.IsActive = true;

                }


                if (ddlCustomerType.SelectedIndex >0)
                {

                    objRemarks.CustomerType = ddlCustomerType.SelectedItem.ToString();
                }

                if (ddlRemarksType.SelectedIndex > 0)
                {

                    objRemarks.RemarksType = ddlRemarksType.SelectedItem.ToString();
                }

                if (ViewState["RemarksID"] != null)
                {

                    objRemarks.RemarksID = Convert.ToInt32(ViewState["RemarksID"].ToString());
                    objRemarks.ActionType = 2;
                    objRemarks.LastModBy = LoginToken.LoginId;
                    objRemarks.CompanyID = LoginToken.CompanyID;
                    objRemarks.FinancialYearID = LoginToken.FinancialYearID;

                }
                else
                {

                    objRemarks.RemarksID = 0;
                    objRemarks.ActionType = 1;
                    objRemarks.AddedBy = LoginToken.LoginId;
                    objRemarks.CompanyID = LoginToken.CompanyID;
                    objRemarks.FinancialYearID = LoginToken.FinancialYearID;

                }


                if (objRemarksBO.SaveRemarks(objRemarks))
                {
                    if (ViewState["RemarksID"] != null)
                        lblError.Text = "Remarks Updated Successfully";
                    else
                        lblError.Text = "Remarks Added Successfully";

                    ViewState["RemarksID"] = null;

                    txtRemarksDetails.Text = "";
                    ddlCustomerType.SelectedIndex = 0;
                    ddlRemarksType.SelectedIndex = 0;
                    BindRemarksList();

                    ViewState["IsEdit"] = false;
                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While saving the remarks : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }


        }

        


        



        protected void btnReset_Click(object sender, EventArgs e)
        {
            lblError.Text="";
            txtRemarksDetails.Text = "";
            ddlCustomerType.SelectedIndex = 0;
            ddlRemarksType.SelectedIndex = 0;
            rbtStatus.SelectedIndex = 0;
            ViewState["RemarksID"] = null;
            grdRemarksList.DataSource = null;
            grdRemarksList.DataBind();
            grdRemarksList.Visible = false;

            ViewState["IsEdit"] = false;
        }


        private void BindRemarksList()
        {
            try
            {

                RemarksBO objTaxBO = new RemarksBO();
                List<Remarks> lstTax = new List<Remarks>();
                lstTax = objTaxBO.GetRemarksList(true);
                
                grdRemarksList.DataSource = lstTax;
                grdRemarksList.DataBind();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While fetching the remarks list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

        protected void grdRemarksList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

            grdRemarksList.PageIndex = e.NewPageIndex;
            BindSearchRemarksList();

        }

        protected void grdRemarksList_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            try
            {

                if (e.CommandName == "REdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());

                    GridViewRow gr = grdRemarksList.Rows[id];

                    TextBox lblTaxName = (TextBox)gr .Cells[4].FindControl("lblRemarkDetails");
                    Label lblRemarksType = (Label)gr.Cells[2].FindControl("lblRemarksType");
                    Label lblCustomerType = (Label)gr.Cells[3].FindControl("lblCustomerType");
                    CheckBox chkIsActive = (CheckBox)gr.Cells[5].FindControl("chkIsActive");
                    LinkButton lblTaxID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");
                    txtRemarksDetails.Text = lblTaxName.Text;
                    ddlCustomerType.SelectedValue = lblCustomerType.Text;
                    ddlRemarksType.SelectedValue = lblRemarksType.Text;
                    ViewState["RemarksID"] = lblTaxID.Text;
                    ViewState["IsEdit"] = true;
                    if (chkIsActive.Checked)
                    {
                        rbtStatus.SelectedIndex = 0;

                    }
                    else
                    {
                        rbtStatus.SelectedIndex = 1;

                    }

                    //Label lblID = (Label)grdUnit.Rows[e.RowIndex].FindControl("lblUnitID");
                    //TextBox txtBoxUnit = (TextBox)grdUnit.Rows[e.RowIndex].FindControl("txtUnitName");



                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While fetch the remarks record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }



        }

    
        protected void bntSearch_Click(object sender, EventArgs e)
        {
            BindSearchRemarksList();

        }


        private void BindSearchRemarksList()
        {
            try
            {
                Remarks objRemarks = new Remarks();

                if (ddlCustomerType.SelectedIndex > 0)
                {

                    objRemarks.CustomerType = ddlCustomerType.SelectedValue;
                }
                else
                    objRemarks.CustomerType = null;

                if (ddlRemarksType.SelectedIndex > 0)
                {

                    objRemarks.RemarksType = ddlRemarksType.SelectedValue;

                }
                else
                    objRemarks.RemarksType = null;

                if (txtRemarksDetails.Text != "")
                    objRemarks.RemarksDetails = txtRemarksDetails.Text;
                else
                    objRemarks.RemarksDetails = null;
                objRemarks.IsActive = rbtStatus.SelectedIndex == 0 ? true : false;
         
                RemarksBO objTaxBO = new RemarksBO();
                List<Remarks> lstTax = new List<Remarks>();

                lstTax = objTaxBO.GetSearchRemarksList(objRemarks);

                grdRemarksList.DataSource = lstTax;
                grdRemarksList.DataBind();
                grdRemarksList.Visible = true;
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While search the remarks record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

       
    }
}