﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.Common;
//using MMIE.Data.ADM;
using MMIE.Data.ACC;

using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;
using System.Text;


namespace MMIE.BNK
{
    public partial class DepositsEntry : BasePage
    {
        public int FinancialYearID = 0;
        public int CompanyID = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            DepositId.Attributes.Add("Visible", "false");
            txtDate.Attributes.Add("readonly", "true");
            FinancialYearID = (Int16)LoginToken.FinancialYearID;
            CompanyID = (Int16)LoginToken.CompanyID;
            lblError.Text = "";
            if (IsPostBack)
                return;
            BindAccountGroup();
            Session["JournalEntry"] = null;
            Session["JournalEntryDebitCredit"] = null;
            ViewState["TotalAmount"] = "0.00";
            calExtenderDate.SelectedDate = System.DateTime.Now;

        }

        /// <summary>
        /// To bind All Account Groups
        /// </summary>
        private void BindAccountGroup()
        {
            AccountGroup objAccountGroup = new AccountGroup();
            AccountGroupBO objBO = new AccountGroupBO();
            List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
            objAccountGroup.IsActive = true;

            lstAccountGroup = objBO.GetSearchAccountGroup(objAccountGroup);
            ddlLedgerGroup.DataSource = lstAccountGroup;
            ddlLedgerGroup.DataTextField = "GroupName";
            ddlLedgerGroup.DataValueField = "AccountGroupID";
            ddlLedgerGroup.DataBind();
            ddlLedgerGroup.Items.Insert(0, new ListItem("--Select--", "0"));

            ddlLedgerGroupFrom.DataSource = lstAccountGroup;
            ddlLedgerGroupFrom.DataTextField = "GroupName";
            ddlLedgerGroupFrom.DataValueField = "AccountGroupID";
            ddlLedgerGroupFrom.DataBind();
            ddlLedgerGroupFrom.Items.Insert(0, new ListItem("--Select--", "0"));

            ddlCashBackLedgerGroup.DataSource = lstAccountGroup;
            ddlCashBackLedgerGroup.DataTextField = "GroupName";
            ddlCashBackLedgerGroup.DataValueField = "AccountGroupID";
            ddlCashBackLedgerGroup.DataBind();
            ddlCashBackLedgerGroup.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void ddlLedgerGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDepositAccount.Text = "";
            AutoCompleteExtender1.ContextKey = ddlLedgerGroup.SelectedValue;
        }

        protected void grdDeposites_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //DropDownList ddlLedgerGroupList = (DropDownList)e.Row.FindControl("ddlAccountGroup");
                //AccountGroup objAccountGroup = new AccountGroup();
                //AccountGroupBO objBO = new AccountGroupBO();
                //List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
                //objAccountGroup.IsActive = true;


                //lstAccountGroup = objBO.GetSearchAccountGroup(objAccountGroup);
                //ddlLedgerGroupList.DataSource = lstAccountGroup;
                //ddlLedgerGroupList.DataTextField = "GroupName";
                //ddlLedgerGroupList.DataValueField = "AccountGroupID";
                //ddlLedgerGroupList.DataBind();
                //ddlLedgerGroupList.Items.Insert(0, new ListItem("--Select--", "0"));
                //ddlLedgerGroupList.SelectedValue = grdDeposites.DataKeys[e.Row.RowIndex].Values[0].ToString();
                //if (ddlLedgerGroupList.SelectedValue != "0")
                //{
                //    DropDownList ddlLedger = (DropDownList)e.Row.FindControl("ddlLedger");
                //    List<LedgerHeader> lstLedgerHeader = new List<LedgerHeader>();
                //    lstLedgerHeader = bindLedgerAccoount(e.Row.RowIndex, Convert.ToInt32(ddlLedgerGroupList.SelectedValue));
                //    ddlLedger.DataSource = lstLedgerHeader;
                //    ddlLedger.DataTextField = "AccountName";
                //    ddlLedger.DataValueField = "LedgerAccountID";
                //    ddlLedger.DataBind();
                //    ddlLedger.Items.Insert(0, new ListItem("--Select--", "0"));
                //    ddlLedger.SelectedValue = grdDeposites.DataKeys[e.Row.RowIndex].Values[1].ToString();
                //}
            }
        }

        protected void grdDeposites_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }
        private List<LedgerHeader> bindLedgerAccoount(int rownumber, int AccountGroupId)
        {

            try
            {
                LedgerHeader objLedger = new LedgerHeader();
                List<LedgerHeader> lstLedgerHeader = new List<LedgerHeader>();
                LedgerHeaderBO objBO = new LedgerHeaderBO();
                objLedger.CompanyID = (Int16)LoginToken.CompanyID;
                objLedger.FinancialYearID = (Int16)LoginToken.FinancialYearID;

                objLedger.AccountGroupID = AccountGroupId;

                objLedger.LedgerAccountID = 0;
                //objLedger.IsActive = (rbtStatus.SelectedIndex == 0) ? true : false;
                objLedger.IsActive = true;
                lstLedgerHeader = objBO.GetSearchLedgerHeader(objLedger);
                return lstLedgerHeader;

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
                return null;
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            ClearAll();


        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (Convert.ToDecimal(lblTotalAmount.Text) < 0)
            {
                lblError.Text = "Please correct cash back amount. It can not exceed from deposit amount.";
                return;
            }
            GetCashBackAmount();
            List<JournalDetails> lstJournalEntry = Session["JournalEntryDebitCredit"] == null ? new List<JournalDetails>() : (List<JournalDetails>)Session["JournalEntryDebitCredit"];
            JournalDetails objJournalDetails = new JournalDetails();
            JournalDetailsBO objJournalDetailsBO = new JournalDetailsBO();
            objJournalDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
            objJournalDetails.CompanyID = (Int16)LoginToken.CompanyID;
            objJournalDetails.ActionType = EnumActionType.Insert;
            objJournalDetails.IsActive = true;
            objJournalDetails.IsLocked = false;
            objJournalDetails.XMLData = XMLConverter.JournalDetailsListToXMLForMultiple((List<JournalDetails>)Session["JournalEntryDebitCredit"]).ToString();

            if (objJournalDetailsBO.SaveJournalEntryForMultiple(objJournalDetails, lstJournalEntry.Count / 2))
            {
                lblError.Text = "Record Added Successfully";
                ClearAll();
            }
            Session["JournalEntry"] = null;
            Session["JournalEntryDebitCredit"] = null;
        }
        protected void ClearAll()
        {
            lblNewAmont.Text = "0.00";
            lblTotalAmount.Text = "0.00";
            Session["JournalEntry"] = null;
            Session["JournalEntryDebitCredit"] = null;
            txtDate.Text = "";
            txtMemo.Text = "";
            txtDepositAccount.Text = "";
            txtFromAccount.Text = "";
            ddlLedgerGroup.SelectedValue = "0";
            ddlLedgerGroupFrom.SelectedValue = "0";
            txtAmount.Text = "";
            grdDeposites.Visible = false;
            trSave.Visible = false;
            ViewState["TotalAmount"] = null;
            trCashBack.Visible = false;
        }

        protected void btnAddEntry_Click(object sender, EventArgs e)
        {
            lblError.Text = "";

            if (Convert.ToInt32(ViewState["DepositLedgerAccountID"]) != Convert.ToInt32(ViewState["FromLedgerAccountID"]))
            {
                decimal amount = 0;
                if (ddlLedgerGroupFrom.SelectedValue == "0" || ddlLedgerGroup.SelectedValue == "0" || txtFromAccount.Text == "" || txtDepositAccount.Text == "" || txtDate.Text == "" && txtAmount.Text == "" || txtMemo.Text == "")
                {
                    lblError.Text = "Please provide all mandatory information to add entry.";
                    return;
                }
                if (!decimal.TryParse(txtAmount.Text, out amount))
                {
                    lblError.Text = "Please provide correct amount.";
                    return;
                }
                if (ViewState["FromLedgerAccountID"] == null)
                {
                    lblError.Text = "Please select correct recieve ldger account.";
                    return;
                }
                if (ViewState["DepositLedgerAccountID"] == null)
                {
                    lblError.Text = "Please select correct deposit ldger account.";
                    return;
                }
                List<JournalDetails> lstJournalEntry = Session["JournalEntry"] == null ? new List<JournalDetails>() : (List<JournalDetails>)Session["JournalEntry"];
                List<JournalDetails> lstJournalEntryDebitCredit = Session["JournalEntryDebitCredit"] == null ? new List<JournalDetails>() : (List<JournalDetails>)Session["JournalEntryDebitCredit"];
                JournalDetails objJournalDetailsCredit = new JournalDetails();
                JournalDetails objJournalDetailsDebit = new JournalDetails();
                objJournalDetailsDebit.TransactionID = lstJournalEntry.Count + 1;
                objJournalDetailsCredit.TransactionID = lstJournalEntry.Count + 1;
                objJournalDetailsCredit.ReferenceNo = "";
                objJournalDetailsDebit.ReferenceNo = "";
                objJournalDetailsCredit.EntryDate = txtDate.Text;
                objJournalDetailsCredit.Details = txtMemo.Text;
                objJournalDetailsDebit.EntryDate = txtDate.Text;
                objJournalDetailsDebit.Details = txtMemo.Text;
                if (txtAmount.Text != "")
                {
                    objJournalDetailsCredit.CreditAmount = Convert.ToDecimal(txtAmount.Text);
                    objJournalDetailsDebit.DebitAmount = Convert.ToDecimal(txtAmount.Text);
                    if (ViewState["TotalAmount"] != null)
                    {
                        ViewState["TotalAmount"] = Convert.ToDecimal(ViewState["TotalAmount"]) + Convert.ToDecimal(txtAmount.Text);
                        lblNewAmont.Text = ViewState["TotalAmount"].ToString();
                        lblTotalAmount.Text = ViewState["TotalAmount"].ToString();
                    }
                }
                objJournalDetailsCredit.AccountName = txtFromAccount.Text;
                objJournalDetailsCredit.TType = "CR";
                objJournalDetailsCredit.LedgerAccountID = Convert.ToInt32(ViewState["FromLedgerAccountID"]);
                objJournalDetailsCredit.IsLocked = false;
                objJournalDetailsCredit.IsActive = true;
                lstJournalEntry.Add(objJournalDetailsCredit);

                objJournalDetailsDebit.AccountName = txtDepositAccount.Text;
                objJournalDetailsDebit.TType = "DR";
                objJournalDetailsDebit.LedgerAccountID = Convert.ToInt32(ViewState["DepositLedgerAccountID"]);
                objJournalDetailsDebit.IsLocked = false;
                objJournalDetailsDebit.IsActive = true;

                lstJournalEntryDebitCredit.Add(objJournalDetailsCredit);
                lstJournalEntryDebitCredit.Add(objJournalDetailsDebit);
                Session["JournalEntryDebitCredit"] = lstJournalEntryDebitCredit;
                Session["JournalEntry"] = lstJournalEntry;
                grdDeposites.DataSource = lstJournalEntry;
                grdDeposites.DataBind();
                trSave.Visible = true;
                trCashBack.Visible = true;
                grdDeposites.Visible = true;
                txtAmount.Text = "";
                txtMemo.Text = "";
                txtDate.Text = "";
            }
            else
            {
                lblError.Text = "Account to Deposit can not be same as Account to Receive.";
            }
        }

        protected void ddlLedgerGroupFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtFromAccount.Text = "";
            AutoCompleteExtender2.ContextKey = ddlLedgerGroupFrom.SelectedValue;
        }

        protected void txtDepositAccount_TextChanged(object sender, EventArgs e)
        {
            if (ddlLedgerGroup.SelectedValue == "0")
            {
                lblError.Text = "Please select account group for deposit ledger account";
                return;
            }
            string GetCustomerId = txtDepositAccount.Text.TrimStart();
            string[] SplitGetCustomerId = GetCustomerId.TrimStart().Split('-');
            int i = 0;
            int countidLen = 0; //Convert.ToInt16(SplitGetCustomerId.Length) + 1;
            int SearchCustomerID = 0;
            if (SplitGetCustomerId.Count() > 1)
            {
                foreach (string word in SplitGetCustomerId)
                {
                    i = i + 1;
                    if (i == 1)
                    {
                        SearchCustomerID = Convert.ToInt32(word);
                        countidLen = word.Length + 1;
                        hdnDepositeLedgerACcpuntID.Value = SearchCustomerID.ToString();
                        ViewState["DepositLedgerAccountID"] = SearchCustomerID;
                        DepositId.Text = SearchCustomerID.ToString();
                        txtDepositAccount.Text = txtDepositAccount.Text.TrimStart().Remove(0, countidLen);
                    }
                    i = i + 1;
                }
            }
            if (SearchCustomerID == 0)
            {
                lblError.Text = "Deposit ledger account not exist. Please select anothor account.";
                txtDepositAccount.Focus();
                return;
            }
            LedgerHeader objACGroup = new LedgerHeader();
            LedgerHeader objRetACGroup = new LedgerHeader();
            LedgerHeaderBO objAcGroupBO = new LedgerHeaderBO();
            objACGroup.LedgerAccountID = Convert.ToInt32(ViewState["DepositLedgerAccountID"]);
            objRetACGroup = objAcGroupBO.GetAccountGroupByID(objACGroup);
        }

        protected void txtFromAccount_TextChanged(object sender, EventArgs e)
        {
            if (ddlLedgerGroupFrom.SelectedValue == "0")
            {
                lblError.Text = "Please select account group for recieve ledger account";
                return;
            }
            string GetCustomerId = txtFromAccount.Text.TrimStart();
            string[] SplitGetCustomerId = GetCustomerId.TrimStart().Split('-');
            int i = 0;
            int countidLen = 0; //Convert.ToInt16(SplitGetCustomerId.Length) + 1;
            int SearchCustomerID = 0;
            if (SplitGetCustomerId.Count() > 1)
            {
                foreach (string word in SplitGetCustomerId)
                {
                    i = i + 1;
                    if (i == 1)
                    {
                        SearchCustomerID = Convert.ToInt32(word);
                        countidLen = word.Length + 1;
                        ViewState["FromLedgerAccountID"] = SearchCustomerID;
                        txtFromAccount.Text = txtFromAccount.Text.TrimStart().Remove(0, countidLen);
                    }
                    i = i + 1;
                }
            }
            if (SearchCustomerID == 0)
            {
                lblError.Text = "Recieve ledger account not exist. Please select anothor account.";
                txtFromAccount.Focus();
                return;
            }
            LedgerHeader objACGroup = new LedgerHeader();
            LedgerHeader objRetACGroup = new LedgerHeader();
            LedgerHeaderBO objAcGroupBO = new LedgerHeaderBO();
            objACGroup.LedgerAccountID = Convert.ToInt32(ViewState["FromLedgerAccountID"]);
            objRetACGroup = objAcGroupBO.GetAccountGroupByID(objACGroup);
        }

        protected void ddlCashBackLedgerGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            AutoCompleteExtender3.ContextKey = ddlCashBackLedgerGroup.SelectedValue;
        }

        protected void txtCashBackAccount_TextChanged(object sender, EventArgs e)
        {
            if (ddlCashBackLedgerGroup.SelectedValue == "0")
            {
                lblError.Text = "Please select account group for deposit ledger account";
                return;
            }
            string GetCustomerId = txtCashBackAccount.Text.TrimStart();
            string[] SplitGetCustomerId = GetCustomerId.TrimStart().Split('-');
            int i = 0;
            int countidLen = 0; //Convert.ToInt16(SplitGetCustomerId.Length) + 1;
            int SearchCustomerID = 0;
            if (SplitGetCustomerId.Count() > 1)
            {
                foreach (string word in SplitGetCustomerId)
                {
                    i = i + 1;
                    if (i == 1)
                    {
                        SearchCustomerID = Convert.ToInt32(word);
                        countidLen = word.Length + 1;
                        ViewState["CashBackLedgerAccountID"] = SearchCustomerID;
                        txtCashBackAccount.Text = txtCashBackAccount.Text.TrimStart().Remove(0, countidLen);
                    }
                    i = i + 1;
                }
            }
            if (SearchCustomerID == 0)
            {
                lblError.Text = "Cash back ledger account not exist. Please select anothor account.";
                txtDepositAccount.Focus();
                return;
            }
        }

        protected void txtCashBackAmount_TextChanged(object sender, EventArgs e)
        {
            decimal amount = 0;
            if (!decimal.TryParse(txtCashBackAmount.Text, out amount))
            {
                lblError.Text = "Please enter correct cash back amount";
                return;
            }
            if (ViewState["TotalAmount"] != null)
            {
                amount = Convert.ToDecimal(ViewState["TotalAmount"].ToString()) - Convert.ToDecimal(txtCashBackAmount.Text);
                if (amount < 0)
                {
                    lblTotalAmount.Text = amount.ToString();
                    lblError.Text = "Please enter correct cash back amount.It can not be grater then New Deposits Total";
                    return;
                }
            }
            else
            {
                lblError.Text = "You must make sure that the New Deposits Total is greater than 0.";
            }
            lblTotalAmount.Text = amount.ToString();

        }
        private void GetCashBackAmount()
        {

            List<JournalDetails> lstJournalEntry = Session["JournalEntry"] == null ? new List<JournalDetails>() : (List<JournalDetails>)Session["JournalEntry"];
            List<JournalDetails> lstJournalEntryDebitCredit = Session["JournalEntryDebitCredit"] == null ? new List<JournalDetails>() : (List<JournalDetails>)Session["JournalEntryDebitCredit"];
            JournalDetails objJournalDetailsCredit = new JournalDetails();
            JournalDetails objJournalDetailsDebit = new JournalDetails();
            objJournalDetailsDebit.TransactionID = lstJournalEntry.Count + 1;
            objJournalDetailsCredit.TransactionID = lstJournalEntry.Count + 1;
            objJournalDetailsCredit.ReferenceNo = "";
            objJournalDetailsDebit.ReferenceNo = "";
            objJournalDetailsCredit.EntryDate = System.DateTime.Now.ToString();
            objJournalDetailsCredit.Details = txtCashBackMemo.Text;
            objJournalDetailsDebit.EntryDate = System.DateTime.Now.ToString();
            objJournalDetailsDebit.Details = txtCashBackMemo.Text;
            if (txtCashBackAmount.Text != "")
            {
                objJournalDetailsCredit.CreditAmount = Convert.ToDecimal(txtCashBackAmount.Text);
                objJournalDetailsDebit.DebitAmount = Convert.ToDecimal(txtCashBackAmount.Text);
            }
            objJournalDetailsCredit.AccountName = txtDepositAccount.Text;
            objJournalDetailsCredit.TType = "CR";
            objJournalDetailsCredit.LedgerAccountID = Convert.ToInt32(ViewState["FromLedgerAccountID"]);
            objJournalDetailsCredit.IsLocked = false;
            objJournalDetailsCredit.IsActive = true;

            objJournalDetailsDebit.AccountName = txtCashBackAccount.Text;
            objJournalDetailsDebit.TType = "DR";
            objJournalDetailsDebit.LedgerAccountID = Convert.ToInt32(ViewState["CashBackLedgerAccountID"]);
            objJournalDetailsDebit.IsLocked = false;
            objJournalDetailsDebit.IsActive = true;

            lstJournalEntryDebitCredit.Add(objJournalDetailsCredit);
            lstJournalEntryDebitCredit.Add(objJournalDetailsDebit);
            Session["JournalEntryDebitCredit"] = lstJournalEntryDebitCredit;
        }

        #region Grid Events
        /// <summary>
        /// To malnuplate grid row at the time of row creation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdDeposites_OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //Change row colour on mouseover and mouseout
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
            }
        }

        /// <summary>
        /// To delete row from grid 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdDeposites_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            if (Session["JournalEntryDebitCredit"] != null && Session["JournalEntry"] != null)
            {
                List<JournalDetails> lstJournalEntry = (List<JournalDetails>)Session["JournalEntry"];
                List<JournalDetails> lstJournalEntryDebitCredit = (List<JournalDetails>)Session["JournalEntryDebitCredit"];

                lstJournalEntry.RemoveAll(x => x.TransactionID == Convert.ToInt32(e.Keys["TransactionID"]));
                lstJournalEntryDebitCredit.RemoveAll(x => x.TransactionID == Convert.ToInt32(e.Keys["TransactionID"]));
                Session["JournalEntryDebitCredit"] = lstJournalEntryDebitCredit;
                Session["JournalEntry"] = lstJournalEntry;

                grdDeposites.DataSource = lstJournalEntry;
                grdDeposites.DataBind();

                trSave.Visible = trCashBack.Visible = lstJournalEntry.Count > 0;

            }
        }
        #endregion
    }
}