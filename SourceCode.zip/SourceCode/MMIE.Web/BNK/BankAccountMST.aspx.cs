﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.BANK;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO;
using MMIE.Data.BANK;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.BANK
{
    public partial class BankAccountMST : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
                return;

            BindBankList();
            ViewState["IsSearch"] = false;
            BindBankAccountList();
        }
        private void BindBankList()
        {
            BankBO objBankBO = new BankBO();

            List<Bank> lstBank = new List<Bank>();
            lstBank = objBankBO.GetBankList(true);
            ddlBankName.DataSource = lstBank;
            ddlBankName.DataValueField = "BankID";
            ddlBankName.DataTextField = "BankName";
            ddlBankName.DataBind();
            ddlBankName.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        private void BindBankAccountList()
        {
            try
            {
                BankAccount objBankAccount = new BankAccount();
                BankAccountBO objBankBO = new BankAccountBO();
                List<BankAccount> lstAccount = new List<BankAccount>();
                if (Convert.ToBoolean(ViewState["IsSearch"]))
                {
                    objBankAccount.BankID = Convert.ToInt32(ddlBankName.SelectedValue);
                    if (rbtStatus.SelectedValue != "Deactive")
                        objBankAccount.IsActive = true;
                    else
                        objBankAccount.IsActive = false;
                    objBankAccount.AccountNumber = txtAccountNumber.Text == "" ? null : txtAccountNumber.Text;
                    objBankAccount.AccountDetails = txtAccountDetails.Text == "" ? null : txtAccountDetails.Text;
                }
                objBankAccount.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                lstAccount = objBankBO.GetSearchBankAccount(objBankAccount, Convert.ToBoolean(ViewState["IsSearch"]));
                grdAccountList.DataSource = lstAccount;
                grdAccountList.DataBind();
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching Bank Account List : " + Ex.Message;
            }

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            ViewState["IsSearch"] = false;
            try
            {
                if (Page.IsValid)
                {

                    BankAccountBO objBankBO = new BankAccountBO();
                    BankAccount objBank = new BankAccount();

                    objBank.AccountNumber = txtAccountNumber.Text;
                    objBank.BankID = Convert.ToInt32(ddlBankName.SelectedValue);
                    objBank.AccountDetails = txtAccountDetails.Text;
                    objBank.AccountType = ddlAccountType.SelectedValue;
                    if (ViewState["BankAccountID"] != null)
                    {
                        objBank.BankAccountID = Convert.ToInt16(ViewState["BankAccountID"].ToString());
                        objBank.LastModBy = LoginToken.LoginId;
                        objBank.LastModDTM = System.DateTime.Now;
                        objBank.ActionType = EnumActionType.Update;

                    }
                    else
                    {
                        objBank.AddedBy = LoginToken.LoginId;
                        objBank.AddedDTM = System.DateTime.Now;
                        objBank.ActionType = EnumActionType.Insert;
                    }
                    objBank.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    objBank.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                   
                    objBank.IsActive = rbtStatus.SelectedIndex == 0 ? true : false;
                    if (objBankBO.SaveBankAccount(objBank))
                    {
                        if (ViewState["BankAccountID"] != null)
                        {
                            lblError.Visible = true;
                            lblError.Text = "Bank Account Update Successfully";

                        }
                        else
                        {
                            lblError.Visible = true;
                            lblError.Text = "Bank Account Added Successfully";

                        }
                        ddlBankName.SelectedValue = "0";
                        txtAccountDetails.Text = "";
                        txtAccountNumber.Text = "";
                        ViewState["BankAccountID"] = null;
                        ViewState["IsEdit"] = false;
                    }
                    else
                    {
                        lblError.Visible = true;
                        lblError.Text = "Bank Account Already Exist. Please Give Another Account Number";
                    }


                }
                BindBankAccountList();

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void bntSearch_Click(object sender, EventArgs e)
        {
            ViewState["IsSearch"] = true;
            BindBankAccountList();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ddlBankName.SelectedValue = "0";
            txtAccountDetails.Text = "";
            txtAccountNumber.Text = "";
            ViewState["BankAccountID"] = null;
            ViewState["IsEdit"] = false;
            ViewState["IsSearch"] = false;
            ddlAccountType.SelectedValue="0";
            BindBankAccountList();
        }

        protected void grdAccountList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "REdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    lblError.Text = "";
                    BankAccount objBankAccount = new BankAccount();
                    BankAccountBO objBankAccountBO = new BankAccountBO();

                    objBankAccount.BankAccountID = id;
                    objBankAccount = objBankAccountBO.GetBankAccountByID(objBankAccount);
                    ddlAccountType.SelectedValue=objBankAccount.AccountType;
                    txtAccountNumber.Text = objBankAccount.AccountNumber;
                    ddlBankName.SelectedValue = objBankAccount.BankID.ToString();
                    txtAccountDetails.Text = objBankAccount.AccountDetails;
                    ViewState["BankAccountID"] = objBankAccount.BankAccountID;
                    ViewState["IsEdit"] = true;

                    if (objBankAccount.IsActive)
                    {
                        rbtStatus.SelectedIndex = 0;

                    }
                    else
                    {
                        rbtStatus.SelectedIndex = 1;

                    }

                }
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching AccountGroup Record : " + Ex.Message;
            }



        }

        protected void grdAccountList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdAccountList.PageIndex = e.NewPageIndex;
            BindBankAccountList();

        }

        protected void grdAccountList_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            grdAccountList.PageIndex = e.NewSelectedIndex;
            BindBankAccountList();
        }

    }
}