﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.Data.ACC;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Web;
using MMIE.Data.Common;

namespace MMIE.BNK
{
    public partial class BankAccountCheck : BasePage
    {
        #region Private Variables 
        private DataTable dtEntries = new DataTable(); //instantiate a new DataTable
        public int companyId = 0;
        public int financialYearId = 0;
        #endregion

        #region Page Events
        protected void Page_Load(object sender, EventArgs e)
        {
            this.CreateTable();
            
            companyId = LoginToken.CompanyID;
            financialYearId = LoginToken.FinancialYearID;

            //To make date text box Read only
            txtDated.Attributes.Add("ReadOnly", "True");

            if (!IsPostBack)
            {
                Session["dtEntries"] = null;
                this.BindSearchAccountList();
                AutoCompleteExtender1.ContextKey = ddlLedgerGroup.SelectedValue;
                this.BindAccountGroup();
                txtDated.Text = DateTime.Now.ToShortDateString();
            }

            //Toshow hide Save button
            btnSave.Visible = dtEntries.Rows.Count > 0;   
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// To create a temp table which bind grid dynamcally at page
        /// </summary>
        private void CreateTable()
        {
            if (Session["dtEntries"] == null || Session["dtEntries"] == "")
            {
                DataColumn dcId = new DataColumn("Id", typeof(Int32));// create new DataColumn
                dtEntries.Columns.Add(dcId); // add DataColumn Id to DataTable

                DataColumn dcLedgerSuperGroup = new DataColumn("LedgerSuperGroup", typeof(string));// create new DataColumn
                dtEntries.Columns.Add(dcLedgerSuperGroup); // add DataColumn LedgerSuperGroup to DataTable

                DataColumn dcLedgerSuperGroupId = new DataColumn("LedgerSuperGroupId", typeof(Int32));// create new DataColumn
                dtEntries.Columns.Add(dcLedgerSuperGroupId); // add DataColumn LedgerSuperGroupId to DataTable

                DataColumn dcPayorder = new DataColumn("Payorder", typeof(string));// create new DataColumn
                dtEntries.Columns.Add(dcPayorder); // add DataColumn to DataTable

                DataColumn dcPayorderId = new DataColumn("PayorderId", typeof(Int32));// create new DataColumn
                dtEntries.Columns.Add(dcPayorderId); // add DataColumn to DataTable
                
                DataColumn dcDate = new DataColumn("Date", typeof(DateTime));// create new DataColumn
                dtEntries.Columns.Add(dcDate); // add DataColumn to DataTable

                DataColumn dcRefNo = new DataColumn("RefNo", typeof(Int32));// create new DataColumn
                dtEntries.Columns.Add(dcRefNo); // add DataColumn to DataTable

                DataColumn dcAmount = new DataColumn("Amount", typeof(Int32));// create new DataColumn
                dtEntries.Columns.Add(dcAmount); // add DataColumn to DataTable

                DataColumn dcAddress = new DataColumn("Address", typeof(string));// create new DataColumn
                dtEntries.Columns.Add(dcAddress); // add DataColumn to DataTable

                DataColumn dcMemo = new DataColumn("Memo", typeof(string));// create new DataColumn
                dtEntries.Columns.Add(dcMemo); // add DataColumn to DataTable}

                DataColumn dcBankLedgerId = new DataColumn("BankLedgerId", typeof(Int32));// create new DataColumn
                dtEntries.Columns.Add(dcBankLedgerId); // add DataColumn to DataTable}

                DataColumn dcBankLedgerName = new DataColumn("BankLedgerName", typeof(string));// create new DataColumn
                dtEntries.Columns.Add(dcBankLedgerName); // add DataColumn to DataTable}

                Session["dtEntries"] = dtEntries;
            }

            dtEntries = (DataTable)Session["dtEntries"];
        }

        /// <summary>
        /// To Bind Bank Accounts
        /// </summary>
        private void BindSearchAccountList()
        {
            try
            {
                LedgerHeader objLedger = new LedgerHeader();
                List<LedgerHeader> lstLedgerHeader = new List<LedgerHeader>();
                LedgerHeaderBO objBO = new LedgerHeaderBO();
                objLedger.CompanyID = (Int16)LoginToken.CompanyID;
                objLedger.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                objLedger.IsActive =true;
                objLedger.GroupName = "bank";
                lstLedgerHeader = objBO.GetSearchLedgerHeader(objLedger);

                ddlBankAccount.DataSource = lstLedgerHeader;
                ddlBankAccount.DataValueField = "LedgerAccountID";
                ddlBankAccount.DataTextField = "AccountName";
                ddlBankAccount.DataBind();
                ddlBankAccount.Items.Insert(0, "--Select--");

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

        /// <summary>
        /// To bind All Account Groups
        /// </summary>
        private void BindAccountGroup()
        {
            AccountGroup objAccountGroup = new AccountGroup();
            AccountGroupBO objBO = new AccountGroupBO();
            List<AccountGroup> lstAccountGroup = new List<AccountGroup>();
            objAccountGroup.IsActive = true;

            lstAccountGroup = objBO.GetSearchAccountGroup(objAccountGroup);
            ddlLedgerGroup.DataSource = lstAccountGroup;
            ddlLedgerGroup.DataTextField = "GroupName";
            ddlLedgerGroup.DataValueField = "AccountGroupID";
            ddlLedgerGroup.DataBind();
            ddlLedgerGroup.Items.Insert(0, "--Select--");
        }

        /// <summary>
        /// To get details of account bu groupId
        /// </summary>
        /// <param name="objACGroup"></param>
        /// <returns></returns>
        private LedgerHeader GetAccountDetailsByGroupId(LedgerHeader objACGroup)
        {
            LedgerHeaderBO objAcGroupBO = new LedgerHeaderBO();
            LedgerHeader objRetACGroup = new LedgerHeader();
            objRetACGroup = objAcGroupBO.GetAccountGroupByID(objACGroup);
            return objRetACGroup;
        }

        /// <summary>
        /// To rferesh all control values
        /// </summary>
        private void ClearAll()
        {
            txtDated.Text = DateTime.Now.ToShortDateString();
            txtAmount.Text = "";
            txtRefNo.Text = "";
            txtMemo.Text = "";
            txtDeatails.Text = "";
            txtPayOrder.Text = "";
            lblShowBalance.Text = "";
            ddlBankAccount.SelectedIndex = 0;
            ddlLedgerGroup.SelectedIndex = 0;
            ViewState["LedgerAccountID"] = null;
            Session["dtEntries"] = null;
            dtEntries = null;
            grdEntries.DataSource = null;
            grdEntries.DataBind();
            
            //Toshow hide Save button
            btnSave.Visible = false;   

        }
        #endregion

        #region Controls event
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void txtPayOrder_TextChanged(object sender, EventArgs e)
        {
            string GetCustomerId = txtPayOrder.Text.TrimStart();
            string[] SplitGetCustomerId = GetCustomerId.TrimStart().Split('-');
            int i = 0;
            int countidLen = 0; //Convert.ToInt16(SplitGetCustomerId.Length) + 1;

            if (SplitGetCustomerId.Count() > 1)
            {
                foreach (string word in SplitGetCustomerId)
                {
                    i = i + 1;
                    if (i == 1)
                    {
                        int SearchCustomerID = Convert.ToInt32(word);
                        countidLen = word.Length + 1;
                        
                        txtPayOrder.Text = txtPayOrder.Text.TrimStart().Remove(0, countidLen);
                    }
                    i = i + 1;
                }
            }

            LedgerHeader objACGroup = new LedgerHeader();
            
            int customerId = 0;
            
            int.TryParse(SplitGetCustomerId[0], out customerId);

            objACGroup.LedgerAccountID = Convert.ToInt32(customerId);
            
            ViewState["PayorderId"] = Convert.ToInt32(customerId);
            
            hdnPayorderId.Value = Convert.ToString(customerId);

            txtDeatails.Text = Convert.ToInt32(customerId) != 0 ? this.GetAccountDetailsByGroupId(objACGroup).Details.ToString() : "";

        }

        /// <summary>
        /// To get the balance amount of a account
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlBankAccount_SelectedIndexChanged(object sender, EventArgs e)
        {
            LedgerHeader objACGroup;
            
            objACGroup = new LedgerHeader();
            
            int ledgerAccountID = 0;
            
            int.TryParse(ddlBankAccount.SelectedValue, out ledgerAccountID);
            
            objACGroup.LedgerAccountID = Convert.ToInt32(ledgerAccountID);

            objACGroup = this.GetAccountDetailsByGroupId(objACGroup);

            lblShowBalance.Text = ledgerAccountID != 0 ? objACGroup.Balance.ToString() : "0";

            lblShowBalance.Attributes.Add("style", Convert.ToDecimal(lblShowBalance.Text) <= 0 ? "color:Red; font-weight:bold; font-size:14px;" : "color:Green; font-weight:bold; font-size:14px;");

            txtRefNo.Text = Convert.ToString(objACGroup.RefrenceNumber + 1);
        }

        /// <summary>
        /// To bind ledger account on select a ledger super account
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlLedgerGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            //this.SearchHeaderAccount();
            AutoCompleteExtender1.ContextKey = ddlLedgerGroup.SelectedValue;
        }

        /// <summary>
        /// To create a table and add row to it to display it in a Grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddEntry_Click(object sender, EventArgs e)
        {
            lblError.Text = "";

            if (Session["dtEntries"] != null)
                dtEntries = (DataTable)Session["dtEntries"];
            else
                this.CreateTable();
            
            if (Convert.ToInt16(ViewState["PayorderId"]) != Convert.ToInt32(ddlBankAccount.SelectedValue))
            {
                DataRow dr = dtEntries.NewRow();//create a new Row

                //Preapring a datarow to insert in table
                dr["Id"] = dtEntries.Rows.Count + 1;//Set Id
                dr["LedgerSuperGroup"] = ddlLedgerGroup.SelectedItem.Text.Trim(); //set value for column LedgerSuperGroup
                dr["LedgerSuperGroupId"] = Convert.ToInt32(ddlLedgerGroup.SelectedValue); //set value for column LedgerSuperGroupId
                dr["Payorder"] = txtPayOrder.Text.Trim(); //set value for column Payorder
                dr["PayorderId"] = Convert.ToInt32(ViewState["PayorderId"]);//set value for column PayorderId
                dr["Date"] = Convert.ToDateTime(txtDated.Text.Trim()); //set value for column Date
                dr["RefNo"] = txtRefNo.Text.Trim(); //set value for column RefNo
                dr["Amount"] = txtAmount.Text.Trim(); //set value for column Amount
                dr["Address"] = txtDeatails.Text.Trim(); //set value for column Details
                dr["Memo"] = txtMemo.Text.Trim(); //set value for column Memo
                dr["BankLedgerId"] = Convert.ToInt32(ddlBankAccount.SelectedValue); //set value for column Details
                dr["BankLedgerName"] = ddlBankAccount.SelectedItem.Text.Trim(); //set value for column Memo

                //Adding row to the datatable
                dtEntries.Rows.Add(dr);

                grdEntries.DataSource = dtEntries;
                grdEntries.DataBind();

                //Get table in seesion to use again
                Session["dtEntries"] = dtEntries;

                //Toshow hide Save button
                btnSave.Visible = dtEntries.Rows.Count > 0;

                txtDated.Text = DateTime.Now.ToShortDateString();
                txtAmount.Text = "";
                txtRefNo.Text = "";
                txtMemo.Text = "";
                txtPayOrder.Text = "";
                txtDeatails.Text = "";
                ddlLedgerGroup.SelectedIndex = 0;
            }
            else
            {
                lblError.Text = "Account and Pay of the order can not be same.";    
            }
        }

        /// <summary>
        /// To save entries in JournalDetails
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            JournalDetails objJournalDetails = new JournalDetails();
            JournalDetailsBO objJournalDetailsBO = new JournalDetailsBO();

            objJournalDetails.Details = txtMemo.Text;
            objJournalDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
            objJournalDetails.CompanyID = (Int16)LoginToken.CompanyID;
            objJournalDetails.ActionType = EnumActionType.Insert;
            objJournalDetails.EntryDate = txtDated.Text;
            objJournalDetails.AddedBy = LoginToken.LoginId;
            objJournalDetails.IsActive = true;
            objJournalDetails.IsLocked = false;
            objJournalDetails.ReferenceNo = txtRefNo.Text.Trim();

            List<JournalDetails> lstJournalDetails = new List<JournalDetails>();
            JournalDetails objJournalDetailsNew;
            
            //To prepare Debit entry collection 
            //Read values one by one from Grid
            foreach(GridViewRow gr in grdEntries.Rows)
            {
                #region To prepare debit entry details
                
                objJournalDetailsNew = new JournalDetails();
                objJournalDetailsNew.TransactionID = gr.RowIndex + 1;
                objJournalDetailsNew.JournalDetailsID = 0;
                //Get LedgerAccountID for pay order to From dataKeyValues
                objJournalDetailsNew.LedgerAccountID = Convert.ToInt32(grdEntries.DataKeys[gr.RowIndex].Values[2]);
                objJournalDetailsNew.TType = "DR";
                objJournalDetailsNew.LF = "";
                objJournalDetailsNew.DebitAmount = Convert.ToInt32(((TextBox)gr.FindControl("txtAmount")).Text);
                objJournalDetailsNew.CreditAmount = 0;
                //Get Memo From dataKeyValues
                objJournalDetailsNew.Details = grdEntries.DataKeys[gr.RowIndex].Values[7].ToString();
                //Get Date From dataKeyValues
                objJournalDetailsNew.EntryDate = grdEntries.DataKeys[gr.RowIndex].Values[6].ToString();
                //Get Refrenceno From dataKeyValues
                objJournalDetailsNew.ReferenceNo = grdEntries.DataKeys[gr.RowIndex].Values[3].ToString();
                
                //Adding the object to the JournalDetails collection
                lstJournalDetails.Add(objJournalDetailsNew);
                
                #endregion

                #region To prepare creadit entry details
                
                objJournalDetailsNew = new JournalDetails();
                objJournalDetailsNew.TransactionID = gr.RowIndex + 1;
                objJournalDetailsNew.JournalDetailsID = 0;
                objJournalDetailsNew.LedgerAccountID = Convert.ToInt32(grdEntries.DataKeys[gr.RowIndex].Values[5]);
                objJournalDetailsNew.TType = "CR";
                objJournalDetailsNew.LF = "";
                objJournalDetailsNew.DebitAmount = 0;
                objJournalDetailsNew.CreditAmount = Convert.ToInt32(((TextBox)gr.FindControl("txtAmount")).Text);
                //Get Memo From dataKeyValues
                objJournalDetailsNew.Details = grdEntries.DataKeys[gr.RowIndex].Values[7].ToString();
                //Get Date From dataKeyValues
                objJournalDetailsNew.EntryDate = grdEntries.DataKeys[gr.RowIndex].Values[6].ToString();
                //Get Refrenceno From dataKeyValues
                objJournalDetailsNew.ReferenceNo = grdEntries.DataKeys[gr.RowIndex].Values[3].ToString();

                //Adding the object to the JournalDetails collection
                lstJournalDetails.Add(objJournalDetailsNew);
                
                #endregion
            }

            //Creating XML for Credit/Debit transactions
            objJournalDetails.XMLData = XMLConverter.JournalDetailsListToXMLForMultiple(lstJournalDetails).ToString();

            //Inserting transaction to JournalDetails table
            if (objJournalDetailsBO.SaveJournalEntryForMultiple(objJournalDetails, (lstJournalDetails.Count) / 2))
            {
                lblError.Text = "Transaction added successfully.";

                //Updating Refrence number corresponding to each Ledger credited
                foreach (GridViewRow gr in grdEntries.Rows)
                {
                    LedgerHeader objACGroup = new LedgerHeader();
                    objACGroup.LedgerAccountID = Convert.ToInt32(grdEntries.DataKeys[gr.RowIndex].Values[5]);
                    objACGroup = this.GetAccountDetailsByGroupId(objACGroup);

                    LedgerHeaderBO objLedgerHeaderBO = new LedgerHeaderBO();
                    objACGroup.ActionType = EnumActionType.Update;
                    objACGroup.RefrenceNumber = Convert.ToInt32(grdEntries.DataKeys[gr.RowIndex].Values[3]);

                    if (objLedgerHeaderBO.SaveLedgerHeader(objACGroup))
                    {
                        lblError1.Text = "Ledger account update successfully.";
                    }
                    else
                    {
                        lblError1.Text = "Fail to update ledger account.";
                    }
                }

                this.ClearAll();
            }
            else 
            {
                lblError.Text = "Fail to add transaction.";
            }
        }

        /// <summary>
        /// To reset all the controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnReset_Click(object sender, EventArgs e)
        {
            this.ClearAll();
        }
        #endregion

        #region Grid Events
        /// <summary>
        /// To malnuplate grid row at the time of row creation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdEntries_OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //Change row colour on mouseover and mouseout
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
            }
        }

        /// <summary>
        /// To delete row from grid 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdEntries_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            if (Session["dtEntries"] != null)
            {
                dtEntries = (DataTable)Session["dtEntries"];
                dtEntries.Rows.RemoveAt(Convert.ToInt32(e.Keys["Id"]) - 1);

                grdEntries.DataSource = dtEntries;
                grdEntries.DataBind();

                Session["dtEntries"] = dtEntries;

                //Toshow hide Save button
                btnSave.Visible = dtEntries.Rows.Count > 0;   
            }
        }
        #endregion

        
    }
}