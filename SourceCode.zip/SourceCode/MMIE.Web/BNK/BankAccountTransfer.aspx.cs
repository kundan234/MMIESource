﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Web;
using MMIE.BusinessProcess.ACC;
using MMIE.Data.ACC;
using MMIE.Data.Common;

namespace MMIE.BNK
{
    public partial class BankAccountTransfer : BasePage
    {
        #region Page varibles
        protected int companyId = 0;
        protected int financialYearId = 0;
        #endregion

        #region Page Events
        protected void Page_Load(object sender, EventArgs e)
        {
            companyId = LoginToken.CompanyID;
            financialYearId = LoginToken.FinancialYearID;

            //To make date text box Read only
            txtDated.Attributes.Add("ReadOnly", "True");

            if (IsPostBack) return;
            txtDated.Text = DateTime.Now.ToShortDateString();
            this.BindSearchAccountList();
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// To Bind Bank Accounts
        /// </summary>
        private void BindSearchAccountList()
        {
            try
            {
                LedgerHeader objLedger = new LedgerHeader();
                List<LedgerHeader> lstLedgerHeader = new List<LedgerHeader>();
                LedgerHeaderBO objBO = new LedgerHeaderBO();
                objLedger.CompanyID = (Int16)LoginToken.CompanyID;
                objLedger.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                objLedger.IsActive = true;
                objLedger.GroupName = "bank";
                lstLedgerHeader = objBO.GetSearchLedgerHeader(objLedger);

                ddlBankAccountFundFrom.DataSource = lstLedgerHeader;
                ddlBankAccountFundFrom.DataValueField = "LedgerAccountID";
                ddlBankAccountFundFrom.DataTextField = "AccountName";
                ddlBankAccountFundFrom.DataBind();
                ddlBankAccountFundFrom.Items.Insert(0, "--Select--");

                ddlBankAccountFundTo.DataSource = lstLedgerHeader;
                ddlBankAccountFundTo.DataValueField = "LedgerAccountID";
                ddlBankAccountFundTo.DataTextField = "AccountName";
                ddlBankAccountFundTo.DataBind();
                ddlBankAccountFundTo.Items.Insert(0, "--Select--");

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

        /// <summary>
        /// To get details of account bu groupId
        /// </summary>
        /// <param name="objACGroup"></param>
        /// <returns></returns>
        private LedgerHeader GetAccountDetailsByGroupId(LedgerHeader objACGroup)
        {
            LedgerHeaderBO objAcGroupBO = new LedgerHeaderBO();
            LedgerHeader objRetACGroup = new LedgerHeader();
            objRetACGroup = objAcGroupBO.GetAccountGroupByID(objACGroup);
            return objRetACGroup;
        }

        /// <summary>
        /// To rferesh all control values
        /// </summary>
        private void ClearAll()
        {
            txtDated.Text = DateTime.Now.ToShortDateString();
            txtAmountTransfer.Text = "";
            txtMemo.Text = "";
            lblShowBalanceFundFrom.Text = "";
            lblShowBalanceFundTo.Text = "";
            ddlBankAccountFundFrom.SelectedIndex = 0;
            ddlBankAccountFundTo.SelectedIndex = 0;
        }
        #endregion

        #region Controls event
        /// <summary>
        /// To make a transaction (Transfer amount from a bank account to another)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            lblError.Text = "";

            if (Convert.ToInt32(ddlBankAccountFundTo.SelectedValue) != Convert.ToInt32(ddlBankAccountFundFrom.SelectedValue))
            {
                JournalDetails objJournalDetails = new JournalDetails();
                JournalDetailsBO objJournalDetailsBO = new JournalDetailsBO();

                objJournalDetails.Details = txtMemo.Text;
                objJournalDetails.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                objJournalDetails.CompanyID = (Int16)LoginToken.CompanyID;
                objJournalDetails.ActionType = EnumActionType.Insert;
                objJournalDetails.EntryDate = txtDated.Text;
                objJournalDetails.AddedBy = LoginToken.LoginId;
                objJournalDetails.IsActive = true;
                objJournalDetails.IsLocked = false;


                List<JournalDetails> lstJournalDetails = new List<JournalDetails>();
                JournalDetails objJournalDetailsNew;

                //To prepare Debit entry collection 
                //Read values one by one from Grid

                #region To prepare debit entry details

                objJournalDetailsNew = new JournalDetails();
                objJournalDetailsNew.JournalDetailsID = 0;
                //Get LedgerAccountID for pay order to From dataKeyValues
                objJournalDetailsNew.LedgerAccountID = Convert.ToInt32(ddlBankAccountFundTo.SelectedValue);
                objJournalDetailsNew.TType = "DR";
                objJournalDetailsNew.LF = "";
                objJournalDetailsNew.DebitAmount = Convert.ToInt32(txtAmountTransfer.Text);
                objJournalDetailsNew.CreditAmount = 0;
                //Adding the object to the JournalDetails collection
                lstJournalDetails.Add(objJournalDetailsNew);

                #endregion

                #region To prepare creadit entry details

                objJournalDetailsNew = new JournalDetails();
                objJournalDetailsNew.JournalDetailsID = 0;
                //Get LedgerAccountID for pay order to From dataKeyValues
                objJournalDetailsNew.LedgerAccountID = Convert.ToInt32(ddlBankAccountFundFrom.SelectedValue);
                objJournalDetailsNew.TType = "CR";
                objJournalDetailsNew.LF = "";
                objJournalDetailsNew.DebitAmount = 0;
                objJournalDetailsNew.CreditAmount = Convert.ToInt32(txtAmountTransfer.Text);
                //Adding the object to the JournalDetails collection
                lstJournalDetails.Add(objJournalDetailsNew);
                #endregion


                //Creating XML for Credit/Debit transactions
                objJournalDetails.XMLData = XMLConverter.JournalDetailsListToXML(lstJournalDetails).ToString();

                //Inserting transaction to JournalDetails table
                if (objJournalDetailsBO.SaveJournalEntry(objJournalDetails))
                {
                    lblError.Text = "Transaction added successfully.";

                    this.ClearAll();
                }
            }
            else
            {
                lblError.Text = "Transfer Fund From cna not be same as Transfer Fund To.";
            }
        }

        /// <summary>
        /// To Reset all controls value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnReset_Click(object sender, EventArgs e)
        {
            this.ClearAll();
        }

        /// <summary>
        /// To show balance of Bank Account Fund From
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlBankAccountFundFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            LedgerHeader objACGroup;

            objACGroup = new LedgerHeader();

            int ledgerAccountID = 0;

            int.TryParse(ddlBankAccountFundFrom.SelectedValue, out ledgerAccountID);

            objACGroup.LedgerAccountID = Convert.ToInt32(ledgerAccountID);
    
            objACGroup = this.GetAccountDetailsByGroupId(objACGroup);
            
            lblShowBalanceFundFrom.Text = ledgerAccountID != 0 ? objACGroup.Balance.ToString() : "0";

            lblShowBalanceFundFrom.Attributes.Add("style", Convert.ToDecimal(lblShowBalanceFundFrom.Text) <= 0 ? "color:Red; font-weight:bold; font-size:14px;" : "color:Green; font-weight:bold; font-size:14px;");
        }

        /// <summary>
        /// To show balance of Bank Account Fund To 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlBankAccountFundTo_SelectedIndexChanged(object sender, EventArgs e)
        {
            LedgerHeader objACGroup;

            objACGroup = new LedgerHeader();

            int ledgerAccountID = 0;

            int.TryParse(ddlBankAccountFundTo.SelectedValue, out ledgerAccountID);

            objACGroup.LedgerAccountID = Convert.ToInt32(ledgerAccountID);

            objACGroup = this.GetAccountDetailsByGroupId(objACGroup);
            
            lblShowBalanceFundTo.Text = ledgerAccountID != 0 ? objACGroup.Balance.ToString() : "0";

            lblShowBalanceFundTo.Attributes.Add("style", Convert.ToDecimal(lblShowBalanceFundTo.Text) <= 0 ? "color:Red; font-weight:bold; font-size:14px;" : "color:Green; font-weight:bold; font-size:14px;");
        }
        #endregion
    }
}