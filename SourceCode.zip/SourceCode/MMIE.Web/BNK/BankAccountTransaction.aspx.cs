﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using MMIE.Data.BANK;
using System.IO;
using MMIE.Data.Common;
//using MMIE.Data.ADM;
using MMIE.Data.ACC;
using MMIE.BusinessProcess.BANK;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;
using System.Text;

namespace MMIE.BANK
{
    public partial class BankAccountTransaction : BasePage
    {
        #region Private variables
        BankAccountBO objBankBO;
        #endregion

        #region Page events
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            this.BindBankAccountList();
            this.BindCurrencyDetails();
        }
        #endregion

        #region Private methods
        /// <summary>
        /// To bind bank account list
        /// </summary>
        private void BindBankAccountList()
        {
            try
            {
                BankAccount objBankAccount = new BankAccount();
                BankAccountBO objBankBO = new BankAccountBO();
                List<BankAccount> lstAccount = new List<BankAccount>();
                objBankAccount.IsActive = true;
                objBankAccount.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                lstAccount = objBankBO.GetSearchBankAccount(objBankAccount,true);

                ddlBankAccount.DataSource = lstAccount;
                ddlBankAccount.DataValueField = "BankAccountID";
                ddlBankAccount.DataTextField = "AccountNumber";
                ddlBankAccount.DataBind();
                ddlBankAccount.Items.Insert(0, new ListItem("--Select--", "--Select--"));
            }
            catch (Exception Ex)
            {
                lblError.Text = "Error While Fetching Bank Account List : " + Ex.Message;
            }
        }

        /// <summary>
        /// To bind Currency dropdown
        /// </summary>
        private void BindCurrencyDetails()
        {
            CurrencyBO objCurrencyBO = new CurrencyBO();
            List<Currency> lstCurrency = new List<Currency>();
            lstCurrency = objCurrencyBO.GetCurrencyList(false);

            ddlCurrency.DataSource = lstCurrency;
            ddlCurrency.DataValueField = "Rate";
            ddlCurrency.DataTextField = "ConvertTO";
            ddlCurrency.DataBind();
            ddlCurrency.Items.Insert(0, new ListItem("--Select--", "--Select--"));
            ddlCurrency.SelectedIndex = 1;
            txtCurrencyConverter.Text = ddlCurrency.SelectedValue.ToString();
        }

        /// <summary>
        /// To Reset all control values
        /// </summary>
        private void Resetvalues()
        {
            ddlBankAccount.SelectedValue = "0";
            ddlTransactionMode.SelectedValue = "--Select--";
            ddlTransactionType.SelectedValue = "--Select--";
            txtTransactionDetails.Text = "";
            txtReferenceNumnber.Text = "";
            txtTransactionAmount.Text = "";
            rblActive.SelectedValue = "0";
        }
        #endregion

        #region Controls event
        /// <summary>
        /// To save a transaction corresponding to a bank account
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            //Instantiating BO object of BankAccount
            if (objBankBO == null)
                objBankBO = new BankAccountBO();
            
            try
            {
                //Assignig BankAccountDetail value  to Data object
                var objBankAccountDetails = new BankAccountDetails
                {
                    BankAccountID = Convert.ToInt32(ddlBankAccount.SelectedValue),
                    TransactionMode = ddlTransactionMode.SelectedValue,
                    TransactionType = ddlTransactionType.SelectedValue,
                    TType = ddlTransactionType.SelectedValue,
                    TransactionAmount = Convert.ToInt32(txtTransactionAmount.Text),
                    IsActive = rblActive.SelectedValue == "0" ? true : false,
                    ActionType = EnumActionType.Insert,
                    AddedBy = LoginToken.LoginId,
                    CompanyID =Convert.ToInt16(LoginToken.CompanyID)
                };

                //Adding a transaction(calling BO funtion)
                objBankBO.SaveBankAccountDetails(objBankAccountDetails);

                lblError.Text = "Transaction added successfully.";
                
                this.Resetvalues();
            }
            catch (Exception Ex)
            {
                lblError.Text = "Error While Saving Record : " + Ex.Message;
            }
        }

        /// <summary>
        /// To rest controls values
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnReset_Click(object sender, EventArgs e)
        {
            //To reset all values of controls
            this.Resetvalues();
        }
        #endregion
    }
}