﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing.Imaging;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;
using System.IO; 
//using MMIE.Data.ADM;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE
{
    public partial class BankMST : BasePage
    {
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = GlobalConstant.PageSize;

        //string fName;      
        //string MyString;
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSubmit.Enabled = LoginToken.IsAddOn;

            }
        }


        List<Bank> lstProduct = null;
        DataSet ds = null;
        int iPageCount = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
        
            btnSubmit.Attributes.Add("onclick", "return validate()");
            lblError.Text = "";
            lblError.Visible = false;
            PagePermission();
            MasterLookupBO mstlookup = new MasterLookupBO();
            if (!IsPostBack)
            {

                grdBankDetail.PageSize = GRID_PAGESIZE;


                if (Request.QueryString["BankID"] != null)
                {
                    int BankID = Convert.ToInt32(Request.QueryString["BankID"].ToString());
                    ViewState["BankID"] = BankID;

                }

                ViewState["IsEdit"] = false;
            }
            else
            {

                string eventTarget = Request.Form["__EVENTTARGET"];
                if (eventTarget != null)
                {
                    if (eventTarget.IndexOf("nav") >= 0)
                    {

                        int pageIndexPos = eventTarget.LastIndexOf("_");
                        string strIndex = eventTarget.Substring(pageIndexPos + 1);
                        int iNewIndex = Convert.ToInt32(strIndex);
                        ViewState["SubmittedNewIndex"] = iNewIndex;



                    }

                }
            }
        }
        protected void TabContainerproductRegistration_ActiveTabChanged(object sender, EventArgs e)
        {

        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            try
            {
                objDD.DataSource = lstLookups;
                objDD.DataValueField = "ItemId";
                objDD.DataTextField = "ItemName";
                objDD.DataBind();
            }
            catch (Exception ex) //Exception in agent layer itself
            {               
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching the list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records contact to your System Administrator";
                return;

            }

            try
            {
                if (Page.IsValid)
                {

                    Bank objBank = new Bank();
                    BankBO objBankBO = new BankBO();

                    objBank.BankAddress = txtAddress.Text;
                    objBank.BankName = txtBankName.Text;
                    if (ViewState["BankID"] != null)
                    {
                        objBank.BankID = Convert.ToInt16(ViewState["BankID"].ToString());
                        objBank.ActionType = EnumActionType.Update;

                    }
                    else
                    {
                        objBank.ActionType = EnumActionType.Insert;
                    }
                    objBank.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    objBank.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                    objBank.IsActive = rbtStatus.SelectedIndex == 0 ? true : false;
                    if (objBankBO.SaveBank(objBank))
                    {
                        if (ViewState["BankID"] != null)
                        {
                            lblError.Visible = true;
                            lblError.Text = "Bank Update Successfully";
                            
                        }
                        else
                        {
                            lblError.Visible = true;
                            lblError.Text = "Bank Added Successfully";
                            
                        }

                        txtAddress.Text = "";
                        txtBankName.Text = "";
                        ViewState["BankID"] = null;


                        ViewState["IsEdit"] = false;
                    }


                }


            }          

            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While save the bank record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                txtAddress.Text = "";
                txtBankName.Text = "";
                ViewState["BankID"] = null;
                rbtStatus.SelectedIndex = 0;

                ViewState["IsEdit"] = false;
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While reset the bank record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                CallSearch();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While search the bank record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        public void CallSearch()
        {

            try
            {
               

                Bank objBank = new Bank();
                BankBO objBankBO = new BankBO();
                objBank.BankAddress = txtAddress.Text;
                objBank.BankName = txtBankName.Text;
                objBank.IsActive = rbtStatus.SelectedIndex > 0 ? false : true;
                List<Bank> lstBank = new List<Bank>();

                lstBank = objBankBO.GetBankListSearch(objBank);


                grdBankDetail.DataSource = lstBank;
                grdBankDetail.DataBind();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While search the bank record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }




        public string MakeBankIDLink(int BankId, string BankName)
        {
            string ret;
            string str;
            string pageName;
            pageName = "BankMST.aspx";
            str = pageName + "?Bankid=" + BankId.ToString().Trim();
            ret = "<a href=\"" + str + "\">" + BankName + "</a>";
            return ret;
        }


      


        protected void grdBankDetail_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            try
            {
                if (e.CommandName == "REdit")
                {
                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    lblError.Text = "";
                    GridViewRow gr = grdBankDetail.Rows[id];
                    Bank objACGroup = new Bank();
                    Bank objRetACGroup = new Bank();
                    BankBO objAcGroupBO = new BankBO();
                    LinkButton lnkBankID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");

                    objRetACGroup = objAcGroupBO.GetBankByID(Convert.ToInt32(lnkBankID.Text));

                    txtAddress.Text = objRetACGroup.BankAddress;
                    txtBankName.Text = objRetACGroup.BankName;
                    ViewState["BankID"] = objRetACGroup.BankID;
                    ViewState["IsEdit"] = true;
                    if (objRetACGroup.IsActive)
                    {
                        rbtStatus.SelectedIndex = 0;

                    }
                    else
                        rbtStatus.SelectedIndex = 1;


                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While fetch the bank record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }



        }

        protected void grdBankDetail_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdBankDetail.PageIndex = e.NewPageIndex;
            CallSearch();
        }
    }
}