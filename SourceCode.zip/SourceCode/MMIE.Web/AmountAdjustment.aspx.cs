﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.SAL;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;

namespace MMIE
{
        

    public partial class AmountAdjustment : BasePage
    {
        DataSet ds = null;
        List<Order> lstOrder = null;
        DataSet dsOrderdetails = null;
        List<Customer> lstStore = null;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

          private DataSet SearchOrder(Order objOrder)
        {
            //Call service operation to get data from database source
            OrderBO odr = new OrderBO();
            lstOrder = odr.SearchOrder(objOrder);
            //    lstCustomer  = UserAdminServiceAgent.SearchCustomer(objCustomer);
            DataTable dt = ORHelper<Order>.GenericListToDataTable(lstOrder);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        protected void  GetSearchOrder()
        {
            


                 
                   
                    
                  
                    Customer objCustomer = new Customer();
                  
                    
                  
                    
                    
                    //-----------------get customer id------------------
                    Order  objOrder = new Order ();
                    objOrder.OrderNumber = txtOrderNo.Text;
                    dsOrderdetails = SearchOrder(objOrder);



                    ViewState["custid"] = dsOrderdetails.Tables[0].Rows[0]["CustomerID"].ToString();


                     lblOpeningBalance.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalance"].ToString();
                     lblOpeningBalanceUSD.Text = dsOrderdetails.Tables[0].Rows[0]["OpeningBalanceUSD"].ToString();
                     lblCreditLimit.Text = dsOrderdetails.Tables[0].Rows[0]["MaxCreditLimit"].ToString();
                     lblCreditLimitUSD.Text = dsOrderdetails.Tables[0].Rows[0]["MaxCreditLimitUSD"].ToString();
                     //lblDebtAmountInGourdes.Text = dsOrderdetails.Tables[0].Rows[0]["DebtAmountGourdes"].ToString();
                     //lblDebtAmtInUSD.Text = dsOrderdetails.Tables[0].Rows[0]["DebtAmountUSD"].ToString();

                     //ViewState["DueAmountGourdes"] = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                     //txtUSDPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidUSDAmt"].ToString();
                     // txtGourdesPaidAmount.Text = dsOrderdetails.Tables[0].Rows[0]["PaidGourdesAmt"].ToString();

                     //txtTotalDueAmountUSD.Text = dsOrderdetails.Tables[0].Rows[0]["DueUSDAmt"].ToString();
                     //txtTotalDueAmount.Text = dsOrderdetails.Tables[0].Rows[0]["DueGourdesAmt"].ToString();
                    // ddlPaymentMode.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["PaymentMode"].ToString();
                   
                           ddlCurrency.SelectedValue = dsOrderdetails.Tables[0].Rows[0]["CurrencyID"].ToString();
                   //   txtGourdesConverter.Text= dsOrderdetails.Tables[0].Rows[0]["CurrencyRate"].ToString();



        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            GetSearchOrder();  
        }


        private void ClearAll()
        {

            ViewState["CustomerID"] = 0;
            ViewState["OpeningBalance"] = 0;
            ViewState["OpeningBalanceUSD"] = 0;
            txtPhone.Text = "";
            txtAddress.Text = "";
            txtAmount.Text = "";
            
            lblCreditLimit.Text = "";
            lblCreditLimitUSD.Text = "";
            txtCustomer.Text = "";
            lblOpeningBalance.Text = "";
            lblOpeningBalanceUSD.Text = "";

        }


        protected void BindCurrencyDropDown()
        {
            Currency objCurrency = new Currency();
            CurrencyBO objCurrencyBO = new CurrencyBO();
            try
            {
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("----Select----", "0"));


            }
            catch (Exception ex)
            {

                lblError.Text = "Error while fetching Currency Details : " + ex.Message;
            }

        }

    }
}