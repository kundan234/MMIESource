﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace MMIE
{
    /// <summary>
    /// Summary description for City
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class City : System.Web.Services.WebService
    {
        System.Configuration.ConnectionStringSettings conStr = System.Configuration.ConfigurationManager.ConnectionStrings["SqlConnectionString"];
        public City()
        {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
        }
       
        [WebMethod]
        public string[] GetCityList(string prefixText, int count)
        {

            
            SqlConnection cn = new SqlConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(conStr.ConnectionString);            
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text ;           
            cmd.CommandText = "SELECT Top(20) dbo.CountryMST.CountryId, dbo.CountryMST.CountryName, dbo.CityMST.CityId, dbo.CityMST.CityName,dbo.CityMST.Zip_Code fROM dbo.CityMST INNER JOIN  dbo.CountryMST ON dbo.CityMST.CountryId = dbo.CountryMST.CountryId and CityMST.cityname like @myParameter ";            

            cmd.Parameters.AddWithValue("@myParameter", prefixText + "%");
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
            }
            finally
            {
                cn.Close();
            }
            dt = ds.Tables[0];

            //Then return List of string(txtItems) as result
            List<string> txtItems = new List<string>();
            String dbValues;
            foreach (DataRow row in dt.Rows)
            {
                string cname = row["cityname"].ToString() + "-" + row["zip_code"].ToString();
                dbValues = cname.ToLower();
                txtItems.Add(dbValues);

            }

            return txtItems.ToArray();

        }
        [WebMethod]
        public string[] GetCustomerList(string prefixText, int count)
        {


            SqlConnection cn = new SqlConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(conStr.ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sqlQuery = "SELECT dbo.CustomerMST.CustomerID,dbo.CustomerMST.Customername FROM    dbo.CityMST,dbo.CountryMST, dbo.CustomerMST where dbo.CityMST.CountryId = dbo.CountryMST.CountryId and "
                          + " dbo.CountryMST.CountryId = dbo.CustomerMST.CustomerCountryId AND dbo.CityMST.CityId = dbo.CustomerMST.CustomerCityID and dbo.CustomerMST.CustomerName like @myParameter ";
            cmd.CommandText = sqlQuery;
            cmd.Parameters.AddWithValue("@myParameter", "%" + prefixText + "%");
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
            }
            finally
            {
                cn.Close();
            }
           if(ds.Tables[0]!=null)
            dt = ds.Tables[0];

            //Then return List of string(txtItems) as result
            List<string> txtItems = new List<string>();
            String dbValues;
            foreach (DataRow row in dt.Rows)
            {
                string cname = row["CustomerID"].ToString() + "-" + row["CustomerName"].ToString();
                dbValues = cname.ToLower();
                txtItems.Add(dbValues);

            }

            return txtItems.ToArray();

        }
        //-------------------------get street charges---------------------------------
        [WebMethod]
        public string[] GetStreetCharges(string prefixText, int count)
        {


            SqlConnection cn = new SqlConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(conStr.ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sqlQuery = "SELECT StreetName from StreetMST where StreetName like @myParameter ";
            cmd.CommandText = sqlQuery;
            cmd.Parameters.AddWithValue("@myParameter", "%" + prefixText + "%");
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
            }
            finally
            {
                cn.Close();
            }
            dt = ds.Tables[0];

            //Then return List of string(txtItems) as result
            List<string> txtItems = new List<string>();
            String dbValues;
            foreach (DataRow row in dt.Rows)
            {
                string cname = row["Streetname"].ToString();
                dbValues = cname.ToLower();
                txtItems.Add(dbValues);

            }

            return txtItems.ToArray();

        }
        //-------------------------close


        //-------------------------get street name---------------------------------
        [WebMethod]
        public string[] GetStreetName(string prefixText, int count)
        {


            SqlConnection cn = new SqlConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(conStr.ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sqlQuery = "SELECT StreetName from StreetMST where StreetName like @myParameter ";
            cmd.CommandText = sqlQuery;
            cmd.Parameters.AddWithValue("@myParameter", "%" + prefixText + "%");
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
            }
            finally
            {
                cn.Close();
            }
            dt = ds.Tables[0];

            //Then return List of string(txtItems) as result
            List<string> txtItems = new List<string>();
            String dbValues;
            foreach (DataRow row in dt.Rows)
            {
                string cname = row["StreetName"].ToString();
                dbValues = cname.ToLower();
                txtItems.Add(dbValues);

            }

            return txtItems.ToArray();

        }
        //-------------------------close
        //-------------------------get street name---------------------------------
        [WebMethod]
        public string[] GetProductName(string prefixText, int count)
        {


            SqlConnection cn = new SqlConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(conStr.ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sqlQuery = "SELECT ProductName from ProductMST where ProductName like @myParameter ";
            cmd.CommandText = sqlQuery;
            cmd.Parameters.AddWithValue("@myParameter", "%" + prefixText + "%");
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
            }
            finally
            {
                cn.Close();
            }
            dt = ds.Tables[0];

            //Then return List of string(txtItems) as result
            List<string> txtItems = new List<string>();
            String dbValues;
            foreach (DataRow row in dt.Rows)
            {
                string cname = row["ProductName"].ToString();
                dbValues = cname.ToLower();
                txtItems.Add(dbValues);

            }

            return txtItems.ToArray();

        }
        //-------------------------close

        //------------------------------CityID Search-----------------///
        [WebMethod]
        public string[] GetCityNameList(string prefixText, int count)
        {


            SqlConnection cn = new SqlConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(conStr.ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sqlQuery = "SELECT top(20) (convert(varchar(10),CityID,0)+'#'+CityName) as CityName from CityMST where Cityname like @myParameter ";
            cmd.CommandText = sqlQuery;
            cmd.Parameters.AddWithValue("@myParameter", "%" + prefixText + "%");
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
            }
            finally
            {
                cn.Close();
            }
            dt = ds.Tables[0];

            //Then return List of string(txtItems) as result
            List<string> txtItems = new List<string>();
            String dbValues;
            foreach (DataRow row in dt.Rows)
            {
                string cname = row["CityName"].ToString();
                dbValues = cname.ToLower();
                txtItems.Add(dbValues);

            }

            return txtItems.ToArray();

        }
        [WebMethod(Description="Getting the Ledger Account for current company & financial year",EnableSession=true)]
        public string[] GetLedgerHeader(string prefixText, int count, string contextKey)
        {
            SqlConnection cn = new SqlConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(conStr.ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("usp_ACC_GetSearchLedgerAccountMAP",conn);
            LoginToken objLoginToken = new LoginToken();

                objLoginToken = (LoginToken)Session["LoginToken"];

            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;

        
            cmd.Parameters.AddWithValue("@VoucherGroupID", Convert.ToInt32(contextKey));
            cmd.Parameters.AddWithValue("@AccountName", prefixText);
            cmd.Parameters.AddWithValue("@CompanyID", objLoginToken.CompanyID);
            cmd.Parameters.AddWithValue("@FinancialYearID", objLoginToken.FinancialYearID);
            
            



            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
            }
            finally
            {
                cn.Close();
            }
            dt = ds.Tables[0];

            //Then return List of string(txtItems) as result
            List<string> txtItems = new List<string>();
            String dbValues;
            foreach (DataRow row in dt.Rows)
            {
                string cname = row["LedgerAccountID"].ToString() + "-" + row["AccountName"].ToString();
                dbValues = cname.TrimStart().ToLower();
                txtItems.Add(dbValues);

            }

            return txtItems.ToArray();

        }
        [WebMethod(Description = "Getting the Ledger Account for current company & financial year", EnableSession = true)]
        public string[] GetLedgerHeaderByAccountGroupID(string prefixText, int count, string contextKey)
        {
            SqlConnection cn = new SqlConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(conStr.ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("usp_ACC_GetSearchLedgerHeaderListMapping", conn);
            LoginToken objLoginToken = new LoginToken();

            objLoginToken = (LoginToken)Session["LoginToken"];

            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AccountGroupID", Convert.ToInt32(contextKey));
            cmd.Parameters.AddWithValue("@AccountName", prefixText);
            cmd.Parameters.AddWithValue("@CompanyID", objLoginToken.CompanyID);
            cmd.Parameters.AddWithValue("@IsActive", true);
            cmd.Parameters.AddWithValue("@FinancialYearID", objLoginToken.FinancialYearID);





            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
            }
            finally
            {
                cn.Close();
            }
            dt = ds.Tables[0];

            //Then return List of string(txtItems) as result
            List<string> txtItems = new List<string>();
            String dbValues;
            foreach (DataRow row in dt.Rows)
            {
                string cname = row["LedgerAccountID"].ToString() + "-" + row["AccountName"].ToString();
                dbValues = cname.TrimStart().ToLower();
                txtItems.Add(dbValues);

            }

            return txtItems.ToArray();

        }
        //-------------------------close
        #region Get Employe List

        [WebMethod]
      
        public string[] GetEmployeeList(string prefixText, int count)
        {


            SqlConnection cn = new SqlConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(conStr.ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sqlQuery = @"SELECT   PRL_EmployeeMST.EmployeeID, (PRL_EmployeeMST.FirstName + ''+ PRL_EmployeeMST.LastName) as Name FROM PRL_EmployeeMST where PRL_EmployeeMST.IsActive=1 ";

            cmd.CommandText = sqlQuery;
            cmd.Parameters.AddWithValue("@myParameter", "%" + prefixText + "%");
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
            }
            finally
            {
                cn.Close();
            }
           if(ds.Tables[0]!=null)
            dt = ds.Tables[0];

            //Then return List of string(txtItems) as result
            List<string> txtItems = new List<string>();
            String dbValues;
            foreach (DataRow row in dt.Rows)
            {
                string cname = row["EmployeeID"].ToString() + "-" + row["Name"].ToString();
                dbValues = cname.ToLower();
                txtItems.Add(dbValues);

            }

            return txtItems.ToArray();

        }


        #endregion

    }
}
