﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE
{
    public partial class OtherChargesMST : BasePage
    {
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsAddOn;
                btnSave.Enabled = LoginToken.IsModify;
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
              
                ViewState["IsEdit"] = false;
            }

            PagePermission();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if ((bool)ViewState["IsEdit"] == true && !LoginToken.IsModify)
            {
                lblError.Text = "You can not modify the records Please contact to your System Administrator";
                return;

            }
            try
            {
                OtherCharges objothercharge = new OtherCharges();
                OtherChargesBO objotherchargeBO = new OtherChargesBO();

                objothercharge.ChargeName = txtChargeName.Text;
                objothercharge.ChargeRate = Convert.ToDecimal(txtChargeRate.Text);
                if (rbtIsActive.SelectedIndex > 0)
                    objothercharge.IsActive = false;
                else
                    objothercharge.IsActive = true;


                List<OtherCharges> lstothercharge = new List<OtherCharges>();
                if (ViewState["ChargeID"] != null)
                {

                    objothercharge.ChargeID = Convert.ToInt32(ViewState["ChargeID"].ToString());
                    objothercharge.ActionType = EnumActionType.Update;
                    objothercharge.LastModBy = LoginToken.LoginId;
                    objothercharge.CompanyID = LoginToken.CompanyID;
                    objothercharge.FinancialYearID = (Int16)LoginToken.FinancialYearID;

                }
                else
                {
                    objothercharge.ChargeID = 0;
                    objothercharge.ActionType = EnumActionType.Insert;
                    objothercharge.AddedBy = LoginToken.LoginId;
                    objothercharge.CompanyID = LoginToken.CompanyID;
                    objothercharge.FinancialYearID = (Int16)LoginToken.FinancialYearID;
                }
                if (objotherchargeBO.SaveOtherCharges(objothercharge))
                {
                    if (ViewState["ChargeID"] != null)
                        lblError.Text = "Charge updated Successfully";
                    else
                        lblError.Text = "Charge Added Successfully";

                    ViewState["ChargeID"] = null;
                    ViewState["IsEdit"] = false;

                    txtChargeName.Text = "";
                    txtChargeRate.Text = "";
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While save the other charge record : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }


        private void BindOtherChargeList()
        {
            try
            {
                OtherCharges objothercharge = new OtherCharges();
                OtherChargesBO objotherchargeBO = new OtherChargesBO();
                List<OtherCharges> lstothercharge = new List<OtherCharges>();

                if (txtChargeName.Text != "")
                    objothercharge.ChargeName = txtChargeName.Text;
                else
                    objothercharge.ChargeName = null;
                if (txtChargeRate.Text != "")
                    objothercharge.ChargeRate = Convert.ToDecimal(txtChargeRate.Text);
                else
                    objothercharge.ChargeRate = Convert.ToDecimal(null);
                if (rbtIsActive.SelectedIndex > 0)
                    objothercharge.IsActive = false;
                else
                    objothercharge.IsActive = true;
                lstothercharge = objotherchargeBO.GetSearchOtherCharges(objothercharge);
                grdOtherChargesMST.DataSource = lstothercharge;
                grdOtherChargesMST.DataBind();
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While fetch the other charge list : " + ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        protected void bntSearch_Click(object sender, EventArgs e)
        {
            this.BindOtherChargeList();
        }


        private void Reset()
        {
           
            txtChargeName.Text = "";
            txtChargeRate.Text = "";
            lblError.Text = "";
            ViewState["ChargeID"] = null;
            ViewState["IsEdit"] = false;
            rbtIsActive.SelectedIndex = 0;
            grdOtherChargesMST.DataSource = null;
            grdOtherChargesMST.DataBind();
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            this.Reset();
        }

        protected void grdOtherChargesMST_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {   //Ankit:-change search functionality.
                if (e.CommandName == "REdit")
                {
                    OtherCharges objotherchargeMST = new OtherCharges();
                    OtherCharges objothercharge = new OtherCharges();
                    OtherChargesBO objotherchargeBO = new OtherChargesBO();
                    List<OtherCharges> lstothercharge = new List<OtherCharges>();

                    int id = Convert.ToInt32(e.CommandArgument.ToString());
                    GridViewRow gr = grdOtherChargesMST.Rows[id];
                    LinkButton lblChargeID = (LinkButton)gr.Cells[1].FindControl("lnkEdit");
                    Label lblName = (Label)gr.Cells[2].FindControl("lblName");
                    Label lblRate = (Label)gr.Cells[3].FindControl("lblRate");
                    CheckBox ChkActive = (CheckBox)gr.Cells[4].FindControl("chkIsActive");
                    //objotherchargeMST.ChargeID =Convert.ToInt32(lblChargeID.Text);

                    txtChargeName.Text = lblName.Text;
                    txtChargeRate.Text = lblRate.Text;
                    ViewState["ChargeID"] = lblChargeID.Text;
                    ViewState["IsEdit"] = true;

                    if (ChkActive.Checked==false)
                    {
                        rbtIsActive.SelectedIndex = 1;

                    }
                    else
                    {
                        rbtIsActive.SelectedIndex = 0;

                    }

                }
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching the other charge Record : " + Ex.Message;
            }
        }

        protected void grdOtherChargesMST_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdOtherChargesMST.PageIndex = e.NewPageIndex;
            BindOtherChargeList();
        }
    }
}