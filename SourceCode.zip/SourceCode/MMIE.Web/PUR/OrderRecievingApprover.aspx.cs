﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Data.PUR;
using MMIE.Common.Util;
using MMIE.Web;

namespace MMIE.PUR
{
    public partial class OrderRecievingApprover : BasePage
    {

        protected void PagePermission()
        {
            if (LoginToken != null)
            {


                //txtEndDate.Enabled = LoginToken.IsChangeDateOn;
                //txtStartDate.Enabled = LoginToken.IsChangeDateOn;
                btnSubmit.Enabled = LoginToken.IsApproverRecievedOn;
            }
        }


        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //txtStartDate.Attributes.Add("ReadOnly", "True");
            //txtEndDate.Attributes.Add("ReadOnly", "True");
            //grdVehicalOrder.HeaderRow.Cells[5].Text
            PagePermission();

            if (!IsPostBack)
            {

                MasterLookupBO mstlookup = new MasterLookupBO();
                BindDropDownControl(ddlProductGroup, mstlookup.GetLookupsList(LookupNames.Group));
                ddlProductGroup.Items.Insert(0, "--Select--");
                BindDropDownControl(ddlStoreType, mstlookup.GetLookupsList(LookupNames.StoreName));
                ddlStoreType.Items.Insert(0, "--Select--");
                    
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtInvoiceNumber.Text = "";
            txtOrderNo.Text = "";
            grdVehicalDetails.DataSource = null;
            grdVehicalDetails.DataBind();
            ddlProductGroup.SelectedIndex = 0;
            rbtStatus.SelectedIndex = 1;
            ddlProductGroup.Enabled=true;
            
           
        }

        protected void btnSearchOrder_Click(object sender, EventArgs e)
        {
            try
            {
                grdVehicalDetails.DataSource = null;
                grdVehicalDetails.DataBind();

                Product objproduct = new Product();
                objproduct.PONumber = Convert.ToInt32(txtOrderNo.Text);
                PartBO objPartBO = new PartBO();

                List<Product> lstProduct = new List<Product>();
                objproduct.IsApproved = rbtStatus.SelectedIndex == 1 ? false : true;
                objproduct.InvoiceNo = txtInvoiceNumber.Text;
                objproduct.GroupType = Convert.ToInt32(ddlProductGroup.SelectedValue.ToString());
                objproduct.StoreID = Convert.ToInt32(ddlStoreType.SelectedValue.ToString());
                lstProduct = objPartBO.SearchPurchaseOrderApproverRate(objproduct);
                if (lstProduct.Count > 0)
                {
                    grdVehicalDetails.DataSource = lstProduct;
                    grdVehicalDetails.DataBind();
                    ddlProductGroup.Enabled = false;
                }
                //if (1 == 1)
                //{
                //    grdVehicalDetails.Columns[1].Visible = false;
                //}
            }

            catch (Exception ex)
            {

                lblError.Text = "Error While Searching Purchase Order Details :" + ex.Message;  
            }


        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            PartBO objPartBO = new PartBO();
            Product objProduct = new Product();

            objProduct.LastModBy = LoginToken.LoginId;
            objProduct.CompanyID =(Int16) LoginToken.CompanyID;
            objProduct.XMLData = CreateGridToXML();
            objProduct.GroupType =Convert.ToInt32 (ddlProductGroup.SelectedValue.ToString());
            objProduct.StoreID = Convert.ToInt32(ddlStoreType.SelectedValue.ToString());
            if (objPartBO.UpdatePurchaseOrderSalesPrice(objProduct))
            {
             lblError.Text="Product Price Updated Successfully"   ;
             ddlProductGroup.Enabled = true;

             grdVehicalDetails.DataSource = null;

             grdVehicalDetails.DataBind();

             txtInvoiceNumber.Text = "";
             txtOrderNo.Text = "";
                
            }


           



        }


        protected string CreateGridToXML()
        {
            StringBuilder objBuilder = new StringBuilder();
            CheckBox IsChecked = new CheckBox();
            TextBox txtApproverRemarks = new TextBox();
            TextBox Retailer1 = new TextBox();
            TextBox Retailer2 = new TextBox();
            TextBox Dealer = new TextBox();
            TextBox CreditRate = new TextBox();
            Label lblInvoiceItemID = new Label();
            Label lblUnitID = new Label();
            Label lblStoreID = new Label();
            foreach (GridViewRow gr in grdVehicalDetails.Rows)
            {

                IsChecked = (CheckBox)gr.Cells[1].FindControl("IsChecked");

                if (IsChecked.Checked && IsChecked.Enabled )
                {
                    Retailer1 = (TextBox)gr.Cells[12].FindControl("Retailer1");
                    Retailer2 = (TextBox)gr.Cells[13].FindControl("Retailer2");
                    Dealer = (TextBox)gr.Cells[14].FindControl("Dealer");
                    CreditRate = (TextBox)gr.Cells[15].FindControl("CreditRate");
                    txtApproverRemarks = (TextBox)gr.FindControl("txtApproverRemarks");
                    lblInvoiceItemID = (Label)gr.FindControl("lblInvoiceItemID");
                    lblUnitID = (Label)gr.FindControl("lblUnitID");
                    lblStoreID = (Label)gr.FindControl("lblStoreID");

                    objBuilder.Append("<PurchaseOrderDetails InvoiceNo= \"" + txtInvoiceNumber.Text + "\" ");
                    objBuilder.Append(" ProductID  = \"" + gr.Cells[2].Text.ToString() + "\" ");
                //    objBuilder.Append(" UnitPriceUSD  = \"" + gr.Cells[8].Text.ToString() + "\" ");
                    objBuilder.Append(" ModelNo  = \"" + gr.Cells[3].Text.ToString() + "\" ");
                    objBuilder.Append(" Retailer1  = \"" + Retailer1.Text + "\" ");
                    objBuilder.Append(" Retailer2  = \"" + Retailer2.Text + "\" ");
                    objBuilder.Append(" Dealer  = \"" + Dealer.Text + "\" ");
                    objBuilder.Append(" CreditRate  = \"" + CreditRate.Text + "\" ");
                    objBuilder.Append(" ApproverRemarks  = \"" + txtApproverRemarks.Text + "\" ");
                    objBuilder.Append(" Ischecked = \"" + (IsChecked.Checked?1:0).ToString() + "\" ");
                    objBuilder.Append(" ProductPriceID  = \"" + lblUnitID.Text + "\" ");
                   // objBuilder.Append(" CostPrice = \"" + gr.Cells[10].Text.ToString() + "\" ");
                    objBuilder.Append(" RecievedQty = \"" + gr.Cells[6].Text.ToString() + "\" ");
                    objBuilder.Append(" InvoiceItemID= \"" + lblInvoiceItemID.Text + "\" ");
                    objBuilder.Append(" PONumber= \"" + gr.Cells[16].Text.ToString() + "\" ");
                    objBuilder.Append(" StoreID= \"" + gr.Cells[16].Text.ToString() + "\" ");

                    objBuilder.Append("/>");

                }
            }

            return objBuilder.ToString();
        }

        protected void btnResetAll_Click(object sender, EventArgs e)
        {
            grdVehicalDetails.DataSource = null;

            grdVehicalDetails.DataBind();

            txtInvoiceNumber.Text = "";
            txtOrderNo.Text = "";
            lblError.Text = "";
        }

        protected void grdVehicalDetails_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

    }
}