﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Data.PUR;

namespace MMIE.PUR
{
    public partial class ProductVehicleReceiveNote : BasePage
    {
        int SearchCustomerID = 0;
        DataSet ds = null;
        List<Product> lstOrder = null;
       const string VS_SEARCH = "VS_SEARCH";
       protected void PagePermission()
       {
           if (LoginToken != null)
           {
               btnsave.Enabled = LoginToken.IsAddOn;
               btnNewOrder.Enabled = LoginToken.IsAddOn;
              
           }
       }
        protected void Page_Load(object sender, EventArgs e)
        {
            txtQuantity.Attributes.Add("ReadOnly", "True");
            txtMaxQuantity.Attributes.Add("ReadOnly", "True");
            txtProductID.Attributes.Add("ReadOnly", "True");
            txtModeNumber.Attributes.Add("ReadOnly", "True");
            txtProductName.Attributes.Add("ReadOnly", "True");
            txtPONUmber.Attributes.Add("ReadOnly", "True");
            txtColor.Attributes.Add("ReadOnly", "True");

            PagePermission();
             try
            {
            if (!IsPostBack)
            {
                MasterLookupBO mstlookup = new MasterLookupBO();

                BindDropDownControl(ddlPurchaseNumber, mstlookup.GetLookupsList(LookupNames.PONumber));
                ddlPurchaseNumber.Items.Insert(0, "Select Purchase Number");
                BindStoreDropDownControl(ddlStoreType, mstlookup.GetLookupsList(LookupNames.StoreName));
                ddlStoreType.Items.Insert(0, "Select Store/Depot");
                Session["IssuedProductList"] = null;
                BindOtherCharges();
                AddNewTable();
            }
            txtReceiveDate.Text = System.DateTime.Now.ToString("MM-dd-yyyy");
            txtReceiveTime.Text = System.DateTime.Now.ToString("hh:mm:ss");
            }
             catch (Exception ex) //Exception in agent layer itself
             {
                 PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                 LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                 lblError.Text = ExceptionMessage.GetMessage(ex);
                 lblError.Visible = true;
             }
        }

        protected void BindOtherCharges()
        {
            List<OtherCharges> lstOtherCharges = new List<OtherCharges>();
            OtherChargesBO objOChargesBO = new OtherChargesBO();
            OtherCharges objOCharges = new OtherCharges();

            objOCharges.IsActive = true;

            lstOtherCharges = objOChargesBO.GetSearchOtherCharges(objOCharges);
            ddlOtherChargeID.DataSource = lstOtherCharges;
            ddlOtherChargeID.DataTextField = "ChargeName";
            ddlOtherChargeID.DataValueField = "ChargeID";
            ddlOtherChargeID.DataBind();


        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemname";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
        }
        private void BindStoreDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemid";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
        }

        protected void gvProductSearch_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                for (int count = 0; count < e.Row.Cells.Count; count++)
                    e.Row.Cells[count].ToolTip = e.Row.Cells[count].Text;
                HyperLink hy = (e.Row.Cells[0].Controls[0]) as HyperLink;
                if (hy != null)
                {
                    hy.NavigateUrl = "javascript:" + hy.NavigateUrl;
                    hy.ToolTip = hy.Text;
                }
            }
        }
        protected void txtSearchModel_TextChanged(object sender, EventArgs e)
        {
            SearchVehicle();

        }
        protected void txtSearchName_TextChanged(object sender, EventArgs e)
        {
            if (txtSearchName.Text.Trim().Length > 2)
            {
                SearchVehicle();
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SearchVehicle();
        }

        protected void txtSearchColor_TextChanged(object sender, EventArgs e)
        {
            SearchVehicle();
        }
        public void SearchVehicle()
        {

            String SearchParam = txtSearchModel.Text.Trim() == "" ? "" : "Model like '" + txtSearchModel.Text.Trim() + "%'";
            if (SearchParam == "" && rdProductName.Checked)
            {
                SearchParam = txtSearchName.Text.Trim() == "" ? "" : "ProductName like '" + txtSearchName.Text.Trim() + "%'";
            }
            else if (rdProductName.Checked)
            {
                SearchParam = SearchParam + (txtSearchName.Text.Trim() == "" ? "" : " and ProductName like '" + txtSearchName.Text.Trim() + "%'") + (txtSearchColor.Text.Trim() == "" ? "" : " and Color like '" + txtSearchColor.Text.Trim() + "%'");
            }

            if (SearchParam == "" && rdReferenceName.Checked)
            {
                SearchParam = txtSearchName.Text.Trim() == "" ? "" : "ReferenceName like '" + txtSearchName.Text.Trim() + "%'";
            }
            else if (rdReferenceName.Checked)
            {
                SearchParam = SearchParam + (txtSearchName.Text.Trim() == "" ? "" : " and ReferenceName like '" + txtSearchName.Text.Trim() + "%'") + (txtSearchColor.Text.Trim() == "" ? "" : " and Color like '" + txtSearchColor.Text.Trim() + "%'");
            }

            SearchParam = SearchParam == "" ? "" : " and " + SearchParam;

            if (Session["dsMaterialDetail"] == null)
            {
                //Session["dsMaterialDetail"] = PartBO.GetPURProductDetail(Request["isunique"] != null ? Product.IsUniqueMaterial.IsUnique : Product.IsUniqueMaterial.IsUnique,1);
              //  Session["dsMaterialDetail"] = PartBO.GetMaterialDetailNew(Request["isunique"] != null ? Product.IsUniqueMaterial.IsUnique : Product.IsUniqueMaterial.IsUnique, 0, 0, 0, 0, txtProductName.Text, txtModeNumber.Text, 1);
            }

            DataTable dtProductDetail = (DataTable)Session["dsMaterialDetail"];
            DataView dv = new DataView(dtProductDetail, "GroupType = 1" + SearchParam, "Model", DataViewRowState.CurrentRows);
            gvProductSearch.DataSource = dv;
            gvProductSearch.DataBind();
            gvProductSearch.Visible = true;
        }

        protected void btnAddMaterial_Click(object sender, EventArgs e)
        {
            if (grdPartreturn.Rows.Count <= 0) return;
            
            IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
            Product objProduct = new Product();
            objProduct.ProductID = Convert.ToInt32(txtProductID.Text.Trim() == "" ? "0" : txtProductID.Text.Trim());
            objProduct.Model = txtModeNumber.Text;
            objProduct.ProductName = txtProductName.Text;
            objProduct.IssuedQty = Convert.ToInt32(txtQuantity.Text.Trim() == "" ? "0" : txtQuantity.Text.Trim());
            objProduct.UnitName = txtUnit.Text.Trim();
            objProduct.Color = txtColor.Text.Trim();
            objProduct.VINNO = txtVINNo.Text.Trim();
            objProduct.EngineNo = txtEngineNo.Text.Trim();
            objProduct.CostPrice = Convert.ToDecimal(txtCostPrice.Text.Trim());
            objProduct.InvoiceNo = txtInvoiceNumber.Text.Trim();
            objProduct.ModifiedBy = LoginToken.LoginId;
            objProduct.AddedBy = LoginToken.LoginId;
            objProduct.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
            objProduct.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
            objProduct.IsApproved = false;
            objProduct.ApproverRemarks = "";
            if (ddlPurchaseNumber.SelectedIndex > 0)
            { objProduct.PONumber = Convert.ToInt32(ddlPurchaseNumber.SelectedValue.ToString()); }
            listProduct.Add(objProduct);

            if (gvProductDetail.Rows.Count < Convert.ToInt16(txtMaxQuantity.Text))
            {
                if (listProduct.Count > 0) gvProductDetail.DataSource = listProduct;
                else gvProductDetail.DataSource = null;
                gvProductDetail.DataBind();
                // save the list to the
                if (listProduct.Count > 0) Session["IssuedProductList"] = listProduct;
                
                lblMsg.Text = "";
            }
            else
            {
                lblMsg.Text = "You can not insert items more than the max quantity.";
            }
               

            // update material detail DataTable
            //DataTable dtProductDetail = InitMaterialList();
            // modify certain values into the DataTable
            //dtProductDetail.AcceptChanges();
            // reset all textboxes
            //btnAddMaterial.Enabled = false;
            btnsave.Enabled = true;
            gvProductSearch.DataSource = null;
            gvProductSearch.DataBind();
            gvProductSearch.Visible = false;
            ddlPurchaseNumber.Enabled = false;
            btnSearchPONO.Enabled = false;
            // ddlProductType.SelectedIndex = 0;
        }
        public DataTable InitMaterialList()
        {
            DataTable dtProductDetail = (DataTable)Session["dsMaterialDetail"];
            //Set Primary key
            DataColumn[] dcPK = new DataColumn[1];
            dcPK[0] = dtProductDetail.Columns["ProductID"];
            dtProductDetail.PrimaryKey = dcPK;
            return dtProductDetail;
        }

        protected void rdProductName_CheckedChanged(object sender, EventArgs e)
        {
            if (rdReferenceName.Checked)
            {
                rdReferenceName.Checked = false;
            }
        }

        protected void rdReferenceName_CheckedChanged(object sender, EventArgs e)
        {
            if (rdProductName.Checked)
            {
                rdProductName.Checked = false;
            }
        }
        protected void btnNewOrder_Click(object sender, EventArgs e)
        {
            lblMsg.Text = "";
            Session["ProductDetail"] = null;
            Session["IssuedProductList"] = null;
            Session["dsMaterialDetail"] = null;
            Response.Redirect("~/PUR/ProductVehicleReceiveNote.aspx");
        }

        private Product GetProductIssuesDetail()
        {
            Product objProductCommon = new Product();
            try
            {
                if (Session["IssuedProductList"] != null)
                {
                    IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
                    objProductCommon.xmlSalesTransactionDetail = XMLConverter.VehicleReceivingListToXML((List<Product>)Session["IssuedProductList"]).ToString();
                }

            }
            catch (Exception ex)
            {
                objProductCommon = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objProductCommon;
        }

        protected void btnSearchPONO_Click(object sender, EventArgs e)
        {
            lblMsg.Text = "";
            this.BindPurchaseOrderDetail();

             Session[VS_SEARCH] = null;
             Product objOrder = new Product();
            objOrder.SaleOrderNumber = ddlPurchaseNumber.SelectedValue;
            objOrder.GroupType = 1;
            //ds = SearchOrder(objOrder);
            //if (ds.Tables[0].Rows.Count > 0)
            //{
                //int SupplierID = Convert.ToInt32(ds.Tables[0].Rows[0]["CustomerID"].ToString());
                //BindCustomerDetail(SupplierID);
                //gvProductDetail.DataSource = ds.Tables[0].DefaultView;
                //gvProductDetail.DataBind();
                //gvProductDetail.Visible = true;
                //btnsave.Enabled = true;
                txtSearchModel.Enabled = false;
                txtSearchName.Enabled = false;
                txtSearchColor.Enabled = false;
                btnSearch.Enabled = false;
            //}
            //else
            //{
            //    gvProductDetail.DataSource = ds.Tables[0].DefaultView;
            //    gvProductDetail.DataBind();
            //    gvProductDetail.Visible = true;
            //}
        }

        private DataSet SearchOrder(Product objOrder)
        {
            //Call service operation to get data from database source
            PartBO odr = new PartBO();
            lstOrder = odr.SearchOrder(objOrder);
            //    lstCustomer  = UserAdminServiceAgent.SearchCustomer(objCustomer);
            DataTable dt = ORHelper<Order>.GenericListToDataTable(lstOrder);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            lblMsg.Text = "";
            string strAmountValue = string.Empty;
            string strDescValue = string.Empty;
            string strID = string.Empty;
            try
            {
                if (Page.IsValid)
                {
                    Table tempTable = Session["OtherCharges"] == null ? new Table() : (Table)Session["OtherCharges"];

                    for (int i = 1; i < tempTable.Rows.Count; i++)
                    {

                        TableRow tr = tempTable.Rows[i];
                        TextBox txtChargeName;// = new TextBox();
                        TextBox txtChargeRate; //= new TextBox();
                        Label lblChargeID;// = new Label();
                        lblChargeID = (Label)tr.Cells[3].Controls[0];
                        txtChargeName = (TextBox)tr.Cells[1].Controls[0];
                        txtChargeRate = (TextBox)tr.Cells[2].Controls[0];
                        strAmountValue += txtChargeRate.Text + ",";
                        strDescValue += txtChargeName.Text + ",";
                        strID += lblChargeID.Text + ",";

                    }
                    Product ProductSales = GetProductIssuesDetail();
                    ProductSales.StoreID = Convert.ToInt16(ddlStoreType.SelectedValue);
                    ProductSales.InvoiceNo = txtInvoiceNumber.Text.Trim();
                    decimal decId = 0;
                    decimal.TryParse(txtTotalReceiptAmount.Text.Trim(), out decId);
                    ProductSales.Othercharges = strAmountValue;
                    ProductSales.OtherDesc = strDescValue;
                    ProductSales.OtherChargeID =strID;
                    ProductSales.TotalUSDAmount = Convert.ToDecimal(decId);
                    ProductSales.ModifiedBy = LoginToken.LoginId;
                    ProductSales.AddedBy = LoginToken.LoginId;
                    ProductSales.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                    ProductSales.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                    ProductSales.GroupType = 1;
                    ProductSales.CustomerID = Convert.ToInt32(hdnCustID.Value);
                    ProductSales.TotalCostPrice  = Convert.ToInt32(txtTotalReceiptAmount.Text.Trim());
                    ProductSales.TotalFrieght = Convert.ToInt32(txtFrieghtAmount.Text.Trim());
                    ProductSales.TotalInsurance = Convert.ToInt32(txtInsuranceAmount.Text.Trim());
                    ProductSales.TotalOtherCharges = Convert.ToInt32(txtOtherCharges.Text.Trim());
                    PartBO PurBO = new PartBO();
                    string result = PurBO.UpdateVehicleReceivingOrderDetails(ProductSales);
                    if (result != "")
                    {
                        lblError.Text = ExceptionMessage.GetMessage("OP7000001");
                        lblError.Visible = true;
                        txtReceiveDate.Text = System.DateTime.Now.ToString("yyyy-MM-dd");
                        txtReceiveTime.Text = System.DateTime.Now.ToShortTimeString();
                        if (Session["IssuedProductList"] != null) Session["IssuedProductList"] = null;
                        btnsave.Enabled = false;
                        ddlPurchaseNumber.Enabled = true;
                        btnSearchPONO.Enabled = true;
                        txtSearchModel.Enabled = true;
                        txtSearchName.Enabled = true;
                        txtSearchColor.Enabled = true;
                        btnSearch.Enabled = true;
                    }
                    else
                    {
                        lblError.Visible = true;
                        lblError.Text = ExceptionMessage.GetMessage("OP700000");
                    }
                }
            }
            
             catch (Exception ex) //Exception in agent layer itself
             {
                 PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                 LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                 lblError.Text = ExceptionMessage.GetMessage(ex);
                 lblError.Visible = true;
             }
               
        }

        protected void txtCustomer_TextChanged(object sender, EventArgs e)
        {
            string GetCustomerId = txtCustomer.Text;
            string[] SplitGetCustomerId = GetCustomerId.Split('-');
            int i = 0;
            foreach (string word in SplitGetCustomerId)
            {
                i = i + 1;

                if (i == 1)
                {
                    SearchCustomerID = Convert.ToInt32(word);
                    BindCustomerDetail(SearchCustomerID);
                }
            }
        }
        private void BindCustomerDetail(int custid)
        {
            CustomerBO useradm = new CustomerBO();
            Customer objCustomer = new Customer();
            objCustomer.CustomerID = custid;
            Customer objRetCustomer = useradm.GetCustomerByID(objCustomer);
            if (objRetCustomer != null)
            {
                txtCustomer.Text = objRetCustomer.CustomerName.Trim();
                txtAddress.Text = objRetCustomer.CustomerAddress.Trim();
                txtStreet.Text = objRetCustomer.CustomerStreet.Trim();
                txtCity.Text = objRetCustomer.CityName.Trim();
                txtCountry.Text = objRetCustomer.CountryName.Trim();
                txtPhone.Text = objRetCustomer.CustomerPhone.Trim();
                txtCellPhone.Text = objRetCustomer.CustomerMobile.Trim();
                txtEmail.Text = objRetCustomer.CustomerEmail.Trim();
                txtWebsite.Text = objRetCustomer.CustomerWebsite.Trim();
                txtFax.Text = objRetCustomer.CustomerFax.Trim();
                hdnCustID.Value = Convert.ToString(objRetCustomer.CustomerID);
                hdnSalesTypeID.Value = Convert.ToString(objRetCustomer.SalesTypeID);

            }

        }

        /// <summary>
        /// To bind Order Detail by Order Number
        /// </summary>
        private void BindPurchaseOrderDetail()
        {
            try
            {
                ProductPurchaseOrderBO objPODetailBO = new ProductPurchaseOrderBO();
                List<ProductPurchaseOrder> lstDetails = new List<ProductPurchaseOrder>();
                lstDetails = objPODetailBO.SearchProductPurchageOrderDetail(ddlPurchaseNumber.SelectedValue + " and ProductType=1");

                grdPartreturn.DataSource = lstDetails;
                grdPartreturn.DataBind();

                divOrderDetail.Visible = lstDetails.Count > 0;//Show order grid if there is order
            }
            catch (Exception Ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, Ex, "1000001");
                LogManager.WriteErrorLogInDB(Ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Order Records : " + Ex.Message;
                lblError.Visible = true;
            }
        }

        protected void grdPartreturn_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "FillOrderData")
            {
                
                int rowIndex = int.Parse(e.CommandArgument.ToString());

                txtPONUmber.Text = Convert.ToString(grdPartreturn.DataKeys[rowIndex]["PONumber"]);
                txtProductName.Text = Convert.ToString(grdPartreturn.DataKeys[rowIndex]["ENName"]);
                txtProductID.Text = Convert.ToString(grdPartreturn.DataKeys[rowIndex]["ProductId"]);
                txtModeNumber.Text = Convert.ToString(grdPartreturn.DataKeys[rowIndex]["Model"]);
                txtColor.Text = Convert.ToString(grdPartreturn.DataKeys[rowIndex]["Color"]);
                txtUnit.Text = Convert.ToString(grdPartreturn.DataKeys[rowIndex]["Unit"]);
                txtMaxQuantity.Text = Convert.ToString(grdPartreturn.DataKeys[rowIndex]["ApprovedQty"]);
                txtQuantity.Text = "1";
            }
        }

        protected void gvProductDetail_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "RDelete")
            {
                int id = Convert.ToInt32(e.CommandArgument.ToString());
                List<Product> lstJournalEntry = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
                lstJournalEntry.RemoveAt(id); ;

                Session["IssuedProductList"] = lstJournalEntry;
                gvProductDetail.DataSource = lstJournalEntry;
                gvProductDetail.DataBind();
            }
        }

        private int ExpBoxID
        {
            get
            {
                var count = ViewState["txtExpBoxID"];
                return (count == null) ? 0 : (int)count;
            }
            set { ViewState["txtExpBoxID"] = value; }
        }

        private void AddNewTable()
        {
            Session["OtherCharges"] = null;
            Table t = new Table();
            t.Style.Add(HtmlTextWriterStyle.Width, "100%");
            t.Rows.Clear();
            t.BorderStyle = BorderStyle.Solid;

            TableHeaderRow th = new TableHeaderRow();
            th.BorderStyle = BorderStyle.Solid;
            TableCell c1 = new TableCell();
            c1.Text = "S.No.";
            c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

            TableCell c2 = new TableCell();
            c2.Text = "Other Charges";
            c2.Style.Add(HtmlTextWriterStyle.Width, "15%");

            TableCell c3 = new TableCell();
            c3.Text = "Charges Amount";
            c3.Style.Add(HtmlTextWriterStyle.Width, "5%");
            c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");


            th.Cells.Add(c1);
            th.Cells.Add(c2);
            th.Cells.Add(c3);




            Style myStyle = new Style();
            myStyle.ForeColor = System.Drawing.Color.Black;
            myStyle.BackColor = System.Drawing.Color.LightGray;
            myStyle.Font.Bold = true;
            myStyle.BorderStyle = BorderStyle.Solid;

            th.ApplyStyle(myStyle);
            // th.Font.Size =Unit.Percentage(12);
            th.BorderStyle = BorderStyle.Solid;
            th.BorderWidth = Unit.Pixel(1);

            t.Rows.Add(th);

            Session["OtherCharges"] = t;
        }
        void AddOtherCharges()
        {

            OtherChargesBO objBO = new OtherChargesBO();
            OtherCharges objCharges = new OtherCharges();
            objCharges.ChargeID = Convert.ToInt32(ddlOtherChargeID.SelectedValue.ToString());
            OtherCharges objChargesRet = new OtherCharges();

            objChargesRet = objBO.GetOtherChargeByID(objCharges);
            if (objChargesRet != null)
            {
                Table tempTable = Session["OtherCharges"] == null ? new Table() : (Table)Session["OtherCharges"];
                HyperLink lnk = new HyperLink();

                ExpBoxID++;

                TextBox txtChargeName = new TextBox();
                txtChargeName.EnableViewState = true;
                txtChargeName.ID = "txt" + ExpBoxID.ToString();
                txtChargeName.MaxLength = 100;
                txtChargeName.Text = ddlOtherChargeID.SelectedItem.ToString();

                TextBox txtChargeAmount = new TextBox();
                txtChargeAmount.ID = "chk" + ExpBoxID.ToString();
                txtChargeAmount.Text = objChargesRet.ChargeRate.ToString();




                Label lblID = new Label();
                lblID.EnableViewState = true;
                lblID.ID = "label4" + ExpBoxID.ToString();
                lblID.Text = ExpBoxID.ToString();
                lblID.Visible = true;

                Label lblChID = new Label();
                lblChID.EnableViewState = true;
                lblChID.ID = "label5" + ExpBoxID.ToString();
                lblChID.Text = ddlOtherChargeID.SelectedValue.ToString();
                lblChID.Visible = false;

                TableRow dr = new TableRow();

                TableCell c1 = new TableCell();
                TableCell c2 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();

                c1.Controls.Add(lblID);
                c2.Controls.Add(txtChargeName);
                c3.Controls.Add(txtChargeAmount);
                c4.Controls.Add(lblChID);
                dr.Cells.Add(c1);
                dr.Cells.Add(c2);
                dr.Cells.Add(c3);
                dr.Cells.Add(c4);

                tempTable.Rows.Add(dr);

                phControls1.Controls.Add(tempTable);

                Session["OtherCharges"] = tempTable;
            }
        }
        protected void btnAddAuto_Click(object sender, EventArgs e)
        {
            

            AddOtherCharges();
        
        }
    }
}