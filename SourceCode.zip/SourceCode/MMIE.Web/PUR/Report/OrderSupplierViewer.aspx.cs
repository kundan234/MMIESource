﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data.SqlClient;
using System.Configuration;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;
using System.Collections;
using MMIE.PRL.Report;
using MMIE.Web.Reports;

namespace MMIE.PUR.Report
{
    public partial class OrderSupplierViewer : BasePage
    {

        //System.Configuration.ConnectionStringSettings conStr = System.Configuration.ConfigurationManager.ConnectionStrings["SqlConnectionString"];

        ReportDocument rptDoc;
        protected void Page_Load(object sender, EventArgs e)
        {
            ReportUtil RU = new ReportUtil();

            // This command is using to hide show the export button
            crSaleReport.HasExportButton = this.LoginToken.IsPrintExportOn;

            if (Request.QueryString["ReportType"] == "OrderSupplierRpt")
            {
                try
                {
                    //Product ProductSales = new Product();
                    // PartBO PurBO = new PartBO();
                    // ProductSales.CustomerID = Convert.ToInt32(Request.QueryString["SupplierID"].ToString().Trim());
                    // ProductSales.SaleOrderNumber = Request.QueryString["PONumber"].ToString().Trim();
                    // PurBO.UpdateOrderToSupplier(ProductSales);

                    rptDoc = new rptPurchaseOrderSupplier();
                    Hashtable htable = new Hashtable();

                    htable.Add("@PONumber", Request.QueryString["PONumber"].Trim());

                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }



            }


            //if (Request.QueryString["ReportType"] == "Return")
            //{

            //    try
            //    {
            //        rptDoc = new rptProductReturn();
            //        Hashtable htable = new Hashtable();
            //        htable.Add("@OrderNumber", Request.QueryString["OrderNumber"].Trim());
            //        crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
            //        crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
            //        ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
            //        crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
            //        htable.Clear();
            //    }
            //    catch (Exception ex) //Exception of the layer(itself)/unhandle
            //    {
            //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
            //        LogManager.WriteErrorLogInDB(ex);
            //        throw new DataAccessException("5000001", ex);
            //    }

            //}


            if (Request.QueryString["ReportType"] == "ProductReceivingRpt" && Request.QueryString["GroupID"] == "1")
            {

                try
                {
                    rptDoc = new VehicleReceivingReport();
                    Hashtable htable = new Hashtable();
                    htable.Add("@GroupType", Request.QueryString["GroupID"].Trim());
                    htable.Add("@BranchID", Request.QueryString["BranchID"].Trim());
                    htable.Add("@StoreID", Request.QueryString["StoreID"].Trim());
                    htable.Add("@Fromdate", Request.QueryString["Fromdate"].Trim());
                    htable.Add("@Todate", Request.QueryString["Todate"].Trim());
                    htable.Add("@ArticleName", Request.QueryString["ArticleName"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }


            if (Request.QueryString["ReportType"] == "ProductReceivingRpt" && Request.QueryString["GroupID"] == "2")
            {

                try
                {
                    rptDoc = new PartReceivingReport();
                    Hashtable htable = new Hashtable();
                    htable.Add("@GroupType", Request.QueryString["GroupID"].Trim());
                    htable.Add("@BranchID", Request.QueryString["BranchID"].Trim());
                    htable.Add("@StoreID", Request.QueryString["StoreID"].Trim());
                    htable.Add("@Fromdate", Request.QueryString["Fromdate"].Trim());
                    htable.Add("@Todate", Request.QueryString["Todate"].Trim());
                    htable.Add("@ArticleName", Request.QueryString["ArticleName"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "VehicalReceivingInvoice")
            {

                try
                {
                    rptDoc = new rptVehicalRecievingInvoice();
                    Hashtable htable = new Hashtable();
                    htable.Add("@InvoiceNo", Request.QueryString["InvoiceNo"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "PartReceivingInvoice")
            {

                try
                {
                    rptDoc = new rptPartRecievingInovice();
                    Hashtable htable = new Hashtable();
                    htable.Add("@InvoiceNo", Request.QueryString["InvoiceNo"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }


            if (Request.QueryString["ReportType"] == "PaymentDetails")
            {

                try
                {
                    rptDoc = new rptSupplierPaymentStatement();
                    Hashtable htable = new Hashtable();
                    htable.Add("@FromDate", Request.QueryString["DateFrom"].Trim());
                    htable.Add("@ToDate", Request.QueryString["DateTo"].Trim());
                    htable.Add("@PaymentMode", Request.QueryString["Mode"].Trim());
                    htable.Add("@CompanyID", Request.QueryString["Branch"].Trim());
                    htable.Add("@CustomerName", Request.QueryString["CustomerName"].Trim());
                    htable.Add("@OrderNo", Request.QueryString["OrderNo"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "SupplierDebtReport")
            {

                try
                {
                    string DateFrom = Request.QueryString["DateFrom"].Trim();
                    string DateTo = Request.QueryString["DateTo"].Trim();

                    rptDoc = new rptPUR_SupplierDebReport();
                    Hashtable htable = new Hashtable();
                    htable.Add("@FromDate", Request.QueryString["DateFrom"].Trim());
                    htable.Add("@ToDate", Request.QueryString["DateTo"].Trim());                  
                    htable.Add("@CustomerName", Request.QueryString["CustomerName"].Trim());
                    htable.Add("@InvoiceNo", Request.QueryString["InvoiceNo"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "OrderPending")
            {

                try
                {
                    rptDoc = new rptOrderPending();
                    Hashtable htable = new Hashtable();

                    htable.Add("@PONumber", Request.QueryString["OrderNo"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "UnitAndCostPrice")
            {

                try
                {
                    rptDoc = new rptUnitAndCostPrice();
                    Hashtable htable = new Hashtable();
                    htable.Add("@PONumber", Request.QueryString["OrderNo"].Trim());
                    htable.Add("@SupplierName", Request.QueryString["Name"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "OtherCharges")
            {

                try
                {
                    rptDoc = new rptVehicleProductOtherCharges();
                    Hashtable htable = new Hashtable();
                    htable.Add("@InvoiceID", Request.QueryString["OrderNo"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }

            if (Request.QueryString["ReportType"] == "ProductReturnQty")
            {

                try
                {
                    rptDoc = new rptProductReturnQty();
                    Hashtable htable = new Hashtable();
                    htable.Add("@ProductID", Request.QueryString["ProductId"].Trim());
                    htable.Add("@ProductName", Request.QueryString["ProductName"].Trim());
                    htable.Add("@PONumber", Request.QueryString["PoNumber"].Trim());
                    crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
                    crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
                    ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
                    crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
                    htable.Clear();
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                    LogManager.WriteErrorLogInDB(ex);
                    throw new DataAccessException("5000001", ex);
                }

            }          



            //if (Request.QueryString["ReportType"] == "PurchasePaymentDebtReport")
            //{

            //    try
            //    {
            //        rptDoc = new rptBalanceAmount();
            //        Hashtable htable = new Hashtable();
            //        htable.Add("@FromDate", Request.QueryString["DateFrom"].Trim());
            //        htable.Add("@ToDate", Request.QueryString["DateTo"].Trim());
            //        htable.Add("@InvoiceNo", Request.QueryString["InvoiceNo"].Trim());
            //        htable.Add("@CustomerName", Request.QueryString["CustomerName"].Trim());
            //        crSaleReport.ReportSource = RU.SetDatabaseInfo(rptDoc);
            //        crSaleReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None;
            //        ParameterFields crParameterFields = crSaleReport.ParameterFieldInfo;
            //        crSaleReport.ParameterFieldInfo = RU.SetParameterFields(crParameterFields, htable);
            //        htable.Clear();
            //    }
            //    catch (Exception ex) //Exception of the layer(itself)/unhandle
            //    {
            //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
            //        LogManager.WriteErrorLogInDB(ex);
            //        throw new DataAccessException("5000001", ex);
            //    }

            //}
        }
        protected void Page_UnLoad(object sender, EventArgs e)
        {
            if (rptDoc != null)
            {
                rptDoc.Close();
                rptDoc.Dispose();
            }
        }
    }
}