﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Data.PUR;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.PUR
{
    public partial class PurchaseVehicalUpdate : BasePage
    {
        int num = 0;
      

        #region GridView Event Handler
        int iPageCount = 0;
        const string VS_MAXROWS = "VS_MAXROWS";
        const string VS_CURRENTINDEX = "VS_CURRENTINDEX";
        const string VS_PAGESIZE = "VS_PAGESIZE";
        const string VS_SEARCH = "VS_SEARCH";
        const int GRID_PAGESIZE = 100;

       
        private void CreateNavigation(int currentPageIndex, int a_iPageSize, int a_iRowCount)
        {
            //Save the arguments in ViewState
            ViewState[VS_CURRENTINDEX] = currentPageIndex;
            ViewState[VS_PAGESIZE] = a_iPageSize;
            ViewState[VS_MAXROWS] = a_iRowCount;
            pnlNavigation.Controls.Clear();
            if (a_iPageSize == 0)
            {
                return;
            }

            //Get the TotalNumber of Pages
            //int iPageCount = 0;
            iPageCount = 0;
            if (a_iRowCount % a_iPageSize == 0)
            {
                iPageCount = a_iRowCount / a_iPageSize;
            }
            else
            {
                iPageCount = (a_iRowCount / a_iPageSize) + 1;
            }

            if (iPageCount <= 1)
            {
                return;
            }

            //Check if LeftDots are to be displayed
            if ((currentPageIndex + 1) - 5 > 1)
            {
                //Start when left dots are visible then show << button also
                LinkButton linkFirst = new LinkButton();
                linkFirst.Text = " FIRST ";
                linkFirst.CssClass = "lftmenu";
                linkFirst.ID = "linkFirst";
                linkFirst.Click += new EventHandler(linkFirst_Click);
                pnlNavigation.Controls.Add(linkFirst);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
                //End when left dots are visible then show << button also

                int iLIndex = (currentPageIndex + 1) - 5 - 1;
                //Add LeftDots
                LinkButton btnLeftDots = new LinkButton();
                btnLeftDots.Text = " PREVIOUS ";
                btnLeftDots.CssClass = "lftmenu";
                btnLeftDots.ID = "nav_" + iLIndex.ToString();
                btnLeftDots.Attributes.Add("onclick", "__doPostBack('" + btnLeftDots.ClientID + "',' " + iLIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            int iLeftIndex = 1;

            if (currentPageIndex + 1 - 5 > 1)
            {
                iLeftIndex = currentPageIndex + 1 - 5;
            }

            //Create the Number buttons on the left side of the index
            for (int i = iLeftIndex; i <= currentPageIndex; i++)
            {
                LinkButton btnLeftNumbers = new LinkButton();
                btnLeftNumbers.Text = i.ToString();
                btnLeftNumbers.CssClass = "lftmenu";
                btnLeftNumbers.ID = "nav_" + i.ToString();
                btnLeftNumbers.Attributes.Add("onclick", "__doPostBack('" + btnLeftNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnLeftNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Display the Current Page Number
            Label lblCurrent = new Label();
            lblCurrent.Text = Convert.ToString(currentPageIndex + 1);
            lblCurrent.CssClass = "textNormal";
            pnlNavigation.Controls.Add(lblCurrent);
            pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

            //Create Right Number buttons
            int iRightIndex = iPageCount;

            if (currentPageIndex + 1 + 5 < iRightIndex)
            {
                iRightIndex = 5;//currentPageIndex + 1 + 5;
            }

            for (int i = currentPageIndex + 2; i <= iRightIndex; i++)
            {
                LinkButton btnRightNumbers = new LinkButton();
                btnRightNumbers.Text = i.ToString();
                btnRightNumbers.CssClass = "lftmenu";
                btnRightNumbers.ID = "nav_" + i.ToString();
                btnRightNumbers.Attributes.Add("onclick", "__doPostBack('" + btnRightNumbers.ClientID + "',' " + i.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightNumbers);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));
            }

            //Check if RightDots are to be displayed
            if ((currentPageIndex + 1) + 5 < iPageCount)
            {
                int iRIndex = ((currentPageIndex + 1) + 5) + 1;
                //Add RightDots
                LinkButton btnRightDots = new LinkButton();
                btnRightDots.Text = " NEXT ";
                btnRightDots.CssClass = "lftmenu";
                btnRightDots.ID = "nav_" + iRIndex.ToString();
                btnRightDots.Attributes.Add("onclick", "__doPostBack('" + btnRightDots.ClientID + "',' " + iRIndex.ToString() + "'); return false;");
                pnlNavigation.Controls.Add(btnRightDots);
                pnlNavigation.Controls.Add(new LiteralControl("&nbsp;"));

                //Start when right dots are visible then show >> button also
                LinkButton linkLast = new LinkButton();
                linkLast.Text = " LAST ";
                linkLast.CssClass = "lftmenu";
                linkLast.ID = "linkLast";
                linkLast.Click += new EventHandler(linkLast_Click);
                pnlNavigation.Controls.Add(linkLast);
                //End when left dots are visible then show << button also

                if (pnlNavigation.Controls.Count > 0)
                {
                    pnlNavigation.Visible = true;
                }
                else
                    pnlNavigation.Visible = false;
            }
        }

        private void CreateNavigation()
        {
            if (ViewState[VS_CURRENTINDEX] == null || ViewState[VS_PAGESIZE] == null || ViewState[VS_MAXROWS] == null)
            {
                return;
            }
            else
            {
                CreateNavigation((int)ViewState[VS_CURRENTINDEX], (int)ViewState[VS_PAGESIZE], (int)ViewState[VS_MAXROWS]);
            }
        }


        protected void linkFirst_Click(object sender, EventArgs e)
        {
            BindData(0);
        }

        protected void linkLast_Click(object sender, EventArgs e)
        {
            BindData(iPageCount - 1);
        }

      


        #endregion




        protected void BindData(int currentPageIndex)
        {

            lblError.Text = "";
            Product objProduct = new Product();
            //  objInvoice.InvoiceHeaderID = InvoiceHeaderID;
            objProduct.PONumber = Convert.ToInt32(ViewState["PONumber"]);
            List<Product> lstInvoice = new List<Product>();
            ProductPurchaseOrderBO objInvoiceBO = new ProductPurchaseOrderBO();

            objProduct.CurrentIndex = currentPageIndex;
            objProduct.PageSize = GRID_PAGESIZE;
            lstInvoice = objInvoiceBO.SearchRecievedVehicalList(objProduct);
          
            grdVehicalList.PageIndex = 0;


            PagedDataSource objPagedDataSource = new PagedDataSource();
            objPagedDataSource.AllowCustomPaging = true;
            objPagedDataSource.PageSize = GRID_PAGESIZE;
            objPagedDataSource.CurrentPageIndex = currentPageIndex;

            //Get search option from viewstate
        

            //Call service operation to get data from database source
            //ds = SearchCustomer(objCustomer);

            if (lstInvoice.Count> 0)
            {
                
                //Bind data in ViewGrid.
                objPagedDataSource.VirtualCount = lstInvoice[0].MaximumRows;
                //Save Virtual Count in ViewState
                ViewState[VS_MAXROWS] = objPagedDataSource.VirtualCount;
                CreateNavigation(currentPageIndex, objPagedDataSource.PageSize, objPagedDataSource.VirtualCount);

                objPagedDataSource.DataSource = lstInvoice;
                grdVehicalList.DataSource = objPagedDataSource;
                grdVehicalList.DataBind();
            }
            else
            {
                lblError.Text = "No Records Found";
                grdVehicalList.DataSource = null;
                grdVehicalList.DataBind();
                pnlNavigation.Visible = false;
            }
        
        }

        protected void PagePermission()
        {
            if (LoginToken != null)
            {

               btnSave.Enabled = LoginToken.IsAddOn;



            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

            }
            else
            {
                string eventTarget = Request.Form["__EVENTTARGET"];
                if (eventTarget != null)
                {
                    if (eventTarget.IndexOf("nav") >= 0)
                    {

                        int pageIndexPos = eventTarget.LastIndexOf("_");
                        string strIndex = eventTarget.Substring(pageIndexPos + 1);
                        int iNewIndex = Convert.ToInt32(strIndex);
                        ViewState["SubmittedNewIndex"] = iNewIndex;
                        if (iNewIndex > 0)
                            BindData(iNewIndex - 1);
                        else
                            BindData(iNewIndex);
                    }

                }
                //Recreate Buttons for Paging
                CreateNavigation();


            }
        }

        protected void btnSearchPO_Click(object sender, EventArgs e)
        {
            BindInvoiceHeaderList();
        }


        protected void BindInvoiceHeaderList()
        {
            try
            {

                InvoiceHeaderDetails objInvoice = new InvoiceHeaderDetails();

                //objInvoice.InvoiceHeaderID = InvoiceHeaderID;
                grdVehicalList.DataSource = null;
                grdVehicalList.DataBind();
                pnlNavigation.Controls.Clear();
                objInvoice.IsActive = true;
                objInvoice.InvoiceNo = txtInvoiceNo.Text;
                objInvoice.PONumber = int.TryParse(txtPurchaseOrderNo.Text, out num) ? num : 0;
                objInvoice.InvoiceHeaderID = 0;
                objInvoice.CustomerName = txtSupplierName.Text;

                List<InvoiceHeaderDetails> lstInvoice = new List<InvoiceHeaderDetails>();

                InvoiceHeaderDetailsBO objInvoiceBO = new InvoiceHeaderDetailsBO();
                lstInvoice = objInvoiceBO.GetSearchInvoiceHeaderDetails(objInvoice);
                grdInvoiceList.DataSource = lstInvoice;
                grdInvoiceList.DataBind();


            }
            catch
            {
                lblError.Text = "Error while fecthing  Invoice Details";

            }
            }

     

        protected void grdVehicalList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdInvoiceList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdInvoiceList_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "ShowDetails")
            {
                int Index = Convert.ToInt32(e.CommandArgument.ToString());

                LinkButton lnk = (LinkButton)grdInvoiceList.Rows[Index].FindControl("lnkOrderNo");

                
                ViewState["PONumber"] = Convert.ToInt32(lnk.Text);
             
                ViewState[VS_CURRENTINDEX] = 0;
                ViewState[VS_PAGESIZE] = GRID_PAGESIZE;
                pnlNavigation.Controls.Clear();
                pnlNavigation.Visible = true;
                CreateNavigation();

                BindData(0);
               // BindVehicalList(Index);


            }

        }


        protected void BindVehicalList(int index)
        {
            //try
            //{

                Product objProduct = new Product();

                //  objInvoice.InvoiceHeaderID = InvoiceHeaderID;

                objProduct.IsActive = true;
                objProduct.InvoiceNo = txtInvoiceNo.Text;
                LinkButton lnk =(LinkButton)grdInvoiceList.Rows[index].FindControl("lnkOrderNo");

                objProduct.PONumber = Convert.ToInt32(lnk.Text);
                ViewState["PONumber"] = Convert.ToInt32(lnk.Text);
          
                objProduct.CustomerName = txtSupplierName.Text;

                List<Product> lstInvoice = new List<Product>();

                ProductPurchaseOrderBO objInvoiceBO = new ProductPurchaseOrderBO();
                lstInvoice = objInvoiceBO.SearchRecievedVehicalList(objProduct);
                grdVehicalList.DataSource = lstInvoice;
                grdVehicalList.DataBind();


            //}

            //catch { 
            
            
            //}
        
        }


        protected string CreateGridToXML()
        {
            StringBuilder objBuilder = new StringBuilder();
            CheckBox IsChecked = new CheckBox();
            TextBox VinNo = new TextBox();
            TextBox EngineNo = new TextBox();
            TextBox ModelNo = new TextBox();
            TextBox ContainerNo = new TextBox();


            CheckBox IsReturn = new CheckBox();
            CheckBox IsApprove = new CheckBox();
     
            foreach (GridViewRow gr in grdVehicalList.Rows)
            {

                IsChecked = (CheckBox)gr.Cells[1].FindControl("IsChecked");

                if (IsChecked.Checked && IsChecked.Enabled)
                {
                    ModelNo = (TextBox)gr.Cells[5].FindControl("txtModelNo");
                    ContainerNo = (TextBox)gr.Cells[6].FindControl("txtConatainerNo");
                    VinNo = (TextBox)gr.Cells[7].FindControl("txtVinNo");
                    EngineNo = (TextBox)gr.Cells[8].FindControl("txtEngineNo");

                    IsReturn = (CheckBox)gr.FindControl("chkIsReturn");
                    IsApprove = (CheckBox)gr.FindControl("chkIsApproved");

                    objBuilder.Append("<VehicalUpdateList VehiclePOID= \"" + gr.Cells[2].Text.ToString() + "\" ");
                   
                    //    objBuilder.Append(" UnitPriceUSD  = \"" + gr.Cells[8].Text.ToString() + "\" ");
                    objBuilder.Append(" VinNo  = \"" + VinNo.Text + "\" ");
                    objBuilder.Append(" EngineNo  = \"" + EngineNo.Text + "\" ");
                    objBuilder.Append(" ModelNo  = \"" + ModelNo.Text + "\" ");
                    objBuilder.Append(" ContainerNo = \"" + ContainerNo.Text + "\" ");
                    objBuilder.Append(" IsReturn = \"" + (IsReturn.Checked ? 1 : 0).ToString() + "\" ");
                    objBuilder.Append(" IsApprove  = \"" + (IsApprove.Checked ? 1 : 0).ToString() + "\" ");

                    objBuilder.Append("/>");

                }
            }

            return objBuilder.ToString();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Product objProduct = new Product();
            ProductPurchaseOrderBO objInvoiceBO = new ProductPurchaseOrderBO();
            lblError.Text = "";
            if (ViewState["PONumber"] != null)
            {
                objProduct.LastModBy = LoginToken.LoginId;
                objProduct.XMLData = CreateGridToXML();
                objProduct.ActionType = EnumActionType.Update;
                if (objProduct.XMLData == null)
                {
                    lblError.Text = "Not Vehical Selected To Update";
                    return;
                
                }

                if (objProduct.XMLData.Length <4)
                {
                    lblError.Text = "Not Vehical Selected To Update";
                    return;

                }


                if (objInvoiceBO.SaveVehicalRecievedList(objProduct))
                {
                    lblError.Text = "Vehical List Updated Successfully";
                    ViewState["PONumber"] = null;
                }
                else
                {
                    lblError.Text = "No Changes made please try again later..!";
                }



            }


        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            grdVehicalList.DataSource = null;
            grdVehicalList.DataBind();

            grdInvoiceList.DataSource = null;
            grdInvoiceList.DataBind();

            txtInvoiceNo.Text = "";
            txtPurchaseOrderNo.Text = "";
            txtSupplierName.Text = "";
            ViewState[VS_CURRENTINDEX] = 0;
            ViewState[VS_PAGESIZE] = 0;
            ViewState[VS_MAXROWS] = 0;

            pnlNavigation.Controls.Clear();



        }


    }
}