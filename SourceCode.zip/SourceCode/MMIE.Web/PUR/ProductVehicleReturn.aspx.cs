﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using System.Configuration;
using MMIE.Common.Util;
using System.Web.UI.HtmlControls;
using MMIE.Data.Common;
using MMIE.Common;
using MMIE.Data.PUR;
using System.Text;

namespace MMIE.PUR
{
    public partial class ProductVehicleReturn : BasePage
    {
        #region Private member variables
        DataSet dsOrderdetails = null;
        DataSet ds = null;
        List<Customer> lstStore = null;
        private Currency objCurrency = new Currency();
        private CurrencyBO objCurrencyBO = new CurrencyBO();
        const string VS_SEARCH = "VS_SEARCH";
        #endregion

        #region Page Events
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    MasterLookupBO mstlookup = new MasterLookupBO();
                    BindDropDownControl(ddlStoreType, mstlookup.GetLookupsList(LookupNames.StoreName));
                    ddlStoreType.Items.Insert(0, "--Select--");
                    //this.BindDropDownControl(ddlPurchaseNumber, mstlookup.GetLookupsList(LookupNames.PONumber));
                }
            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        #endregion

        #region Bind Events
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemid";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
           
        }

        /// <summary>
        /// To bind Order Detail by Order Number
        /// </summary>
        private void BindPurchaseOrderDetail()
        {
            try
            {
                 PartBO objPartBO = new PartBO();
                   Product objproduct = new Product();
             List<Product> lstProduct = new List<Product>();
             objproduct.PONumber = Convert.ToInt32(txtOrderNo.Text);
             objproduct.GroupType = 0;
             objproduct.StoreID = int.Parse(ddlStoreType.SelectedValue);
             objproduct.IsApproved = true;
             lstProduct = objPartBO.SearchPurchaseOrderApproverRate(objproduct);
             if (lstProduct.Count > 0)
             {
                 grdPartreturn.DataSource = lstProduct;
                 grdPartreturn.DataBind();
             }
                divOrderDetail.Visible = lstProduct.Count > 0;//Show order grid if there is order
                divVehicalDetails.Visible = false;
                divPartDetails.Visible = false;
            }
            catch (Exception Ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, Ex, "1000001");
                LogManager.WriteErrorLogInDB(Ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Fetching Order Records : " + Ex.Message;
                lblError.Visible = true;
            }
        }

        /// <summary>
        /// To bind vehicle receiving details Grid
        /// </summary>
        /// <param name="PONumber"></param>
        private void BindVehicleGrid(int PONumber,int ProductType,int ProductID)
        {
            Product objproduct = new Product();
            objproduct.PONumber = PONumber;
            objproduct.GroupType = ProductType;
            objproduct.ProductID = ProductID;
            objproduct.StoreID =Convert.ToInt32(ddlStoreType.SelectedValue);
            PartBO objPartBO = new PartBO();

            List<Product> lstProduct = new List<Product>();

            lstProduct = objPartBO.SearchPurchaseOderDetails(objproduct);
            grdVehicalDetails.DataSource = lstProduct;
            grdVehicalDetails.DataBind();

            tr_Submit.Visible = btnSubmit.Enabled = btnPrint.Enabled = lstProduct.Count > 0;

            grdVehicalDetails.Visible = true;
        }

        /// <summary>
        /// To bind part receiving details Grid
        /// </summary>
        /// <param name="PONumber"></param>
        private void BindPartGrid(int PONumber, int ProductType, int ProductID)
        {
            Product objproduct = new Product();
            objproduct.PONumber = PONumber;
            objproduct.GroupType = ProductType;
            objproduct.ProductID = ProductID;
            objproduct.StoreID = Convert.ToInt32(ddlStoreType.SelectedValue);
            
            PartBO objPartBO = new PartBO();

            List<Product> lstProduct = new List<Product>();

            lstProduct = objPartBO.SearchPurchaseOderDetails(objproduct);
            grdPartDetails.DataSource = lstProduct;
            grdPartDetails.DataBind();

            tr_Submit.Visible = btnSubmit.Enabled = btnPrint.Enabled = lstProduct.Count > 0;

            grdPartDetails.Visible = true;
        }
        #endregion

        #region Grid Events
        /// <summary>
        /// To manuplate grid row at the time of row creation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdPartreturn_OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        /// <summary>
        /// For Binding Vehicle/Part Item Grid on Row Command of order
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdPartreturn_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ShowDetails")
            {
                GridViewRow grArtist = ((Control)
                   (e.CommandSource)).NamingContainer as GridViewRow;
                Label lblproductID = (Label)(grArtist.Cells[2].FindControl("lblProductID"));
                if (Convert.ToInt32(grdPartreturn.DataKeys[grArtist.RowIndex]["ProductType"]) == 1)
                {
                    //To bind Vehicle grid
                    this.BindVehicleGrid(Convert.ToInt32(grdPartreturn.DataKeys[grArtist.RowIndex]["PONumber"]), Convert.ToInt32(grdPartreturn.DataKeys[grArtist.RowIndex]["ProductType"]), Convert.ToInt32(lblproductID.Text));
                    divVehicalDetails.Visible = true;
                    divPartDetails.Visible = false;
                }
                else if (Convert.ToInt32(grdPartreturn.DataKeys[grArtist.RowIndex]["ProductType"]) == 2)
                {
                    //To bind Part grid
                    this.BindPartGrid(Convert.ToInt32(grdPartreturn.DataKeys[grArtist.RowIndex]["PONumber"]), Convert.ToInt32(grdPartreturn.DataKeys[grArtist.RowIndex]["ProductType"]), Convert.ToInt32(lblproductID.Text));
                    divVehicalDetails.Visible = false;
                    divPartDetails.Visible = true;
                }

                //ViewState["PONumber"] = Convert.ToInt32(grdPartreturn.DataKeys[grArtist.RowIndex]["ProductType"]) == 1 ? grdPartreturn.DataKeys[grArtist.RowIndex]["PONumber"] : grdPartreturn.DataKeys[grArtist.RowIndex]["VehiclePOID"];
                ViewState["PONumber"] = grdPartreturn.DataKeys[grArtist.RowIndex]["PONumber"];
                ViewState["ProductType"] = grdPartreturn.DataKeys[grArtist.RowIndex]["ProductType"];
                ViewState["ProductID"] = lblproductID.Text;
            }

            int PO= Convert.ToInt32(e.CommandArgument.ToString());
            ViewState["ProductFlag"] = PO;
        }

        /// <summary>
        /// To manuplate grid row at the time of row creation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdVehicalDetails_OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        /// <summary>
        /// To manuplate grid row at the time of row creation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdPartDetails_OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }
        #endregion

        #region Create XML
        /// <summary>
        /// To create XML for updating in Vehicle Reciving Detail for updating Return
        /// </summary>
        /// <returns></returns>
        protected string CreateVechicleGridToXML()
        {
            StringBuilder objBuilder = new StringBuilder();
            
            foreach (GridViewRow gr in grdVehicalDetails.Rows)
            {
                CheckBox chk = (CheckBox)gr.Cells[9].FindControl("chkIsCheckin");
                TextBox txtRemarksCheck = (TextBox)gr.Cells[10].FindControl("txtRemarksCheck");
                Label lblStoreID = (Label)gr.Cells[10].FindControl("lblStoreID");
                Label lblVin = (Label)gr.Cells[7].FindControl("lblVinNo");
                Label lblEngine = (Label)gr.Cells[8].FindControl("lblEngineNo");
                if (chk.Checked)
                {
                    objBuilder.Append("<BulkVehicleReturn  VehiclePOID= \"" + Convert.ToString(grdVehicalDetails.DataKeys[gr.RowIndex]["VehiclePOID"]) + "\" ");
                    objBuilder.Append(" RemarksCheck  = \"" + txtRemarksCheck.Text.Trim() + "\" ");
                    objBuilder.Append(" ProductId  = \"" + Convert.ToString(grdVehicalDetails.DataKeys[gr.RowIndex]["ProductId"]) + "\" ");
                    objBuilder.Append(" Ischecked = \"true\" ");
                    objBuilder.Append(" StoreID  = \"" + lblStoreID.Text + "\" ");
                    objBuilder.Append("VinNo  = \"" + lblVin.Text + "\" ");
                    objBuilder.Append(" EngineNo  = \"" +lblEngine.Text + "\" ");
                    objBuilder.Append("/>");

                }
            }
            return objBuilder.ToString();
        }

        /// <summary>
        /// To create XML for updating in Part Reciving Detail for updating Return
        /// </summary>
        /// <returns></returns>
        protected string CreatePratGridToXML()
        {
            StringBuilder objBuilder = new StringBuilder();

            foreach (GridViewRow gr in grdPartDetails.Rows)
            {
              
                TextBox txtReturnQty = (TextBox)gr.Cells[7].FindControl("txtReturnQty");
                Label lblEquivalentUnit = (Label)gr.Cells[6].FindControl("lblEquivalentUnit");
                Label lblStoreID = (Label)gr.Cells[10].FindControl("lblStoreID");
                CheckBox chk = (CheckBox)gr.Cells[8].FindControl("chkIsCheckin");

                if (chk.Checked)
                {
                
                decimal qty =Convert.ToDecimal(txtReturnQty.Text) *Convert.ToDecimal(lblEquivalentUnit.Text);

                
                TextBox txtRemarksCheck = (TextBox)gr.Cells[9].FindControl("txtRemarksCheck");
                Label lblunitid= (Label)gr.Cells[10].FindControl("lblUnitID");
                Label lblunitPrice = (Label)gr.Cells[10].FindControl("lblUnitPrice");
                Label lblunitName = (Label)gr.Cells[6].FindControl("lblUnitName");
                Label lblunitExpence = (Label)gr.Cells[11].FindControl("lblUnitExpences");
               
                    objBuilder.Append("<BulkPartReturn PartRecevingID= \"" + Convert.ToString(grdPartDetails.DataKeys[gr.RowIndex]["PartRecevingID"]) + "\" ");
                    objBuilder.Append(" ReturnQuantity  = \"" + qty.ToString() + "\" ");
                    objBuilder.Append(" Qty  = \"" + txtReturnQty.Text + "\" ");
                    objBuilder.Append(" RemarksCheck  = \"" + txtRemarksCheck.Text.Trim() + "\" ");
                    objBuilder.Append(" ProductID = \"" + Convert.ToString(grdPartDetails.DataKeys[gr.RowIndex]["ProductId"]) + "\" ");
                    objBuilder.Append(" Ischecked = \"true\" ");                 
                    objBuilder.Append(" StoreID  = \"" + lblStoreID.Text + "\" ");
                    objBuilder.Append(" UnitID  = \"" +lblunitid.Text.Trim() + "\" ");
                    objBuilder.Append(" UnitPrice  = \"" + lblunitPrice.Text.Trim() + "\" ");
                    objBuilder.Append(" UnitName  = \"" +lblunitName.Text.Trim() + "\" ");
                    objBuilder.Append(" PerUnitExpense  = \"" + lblunitExpence.Text.Trim() + "\" ");
                    objBuilder.Append("/>");
                }
            }
            return objBuilder.ToString();
        }
        #endregion

        #region Control Events
        /// <summary>
        /// To search orders by ther Order Numbers
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            tr_Submit.Visible = btnSubmit.Enabled = btnPrint.Enabled = false;
            this.BindPurchaseOrderDetail();
            lblError.Text = "";
        }

        /// <summary>
        /// To Refund Vehicle/Parts
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                lblError.Text = "";
                int gridIndex = Convert.ToInt32(ViewState["ProductFlag"]);
                GridViewRow gr = grdPartreturn.Rows[gridIndex];
               

                if (divVehicalDetails.Visible)
                {

                    PartBO ObjBO = new PartBO();
                    Product objproduct = new Product();
                    LinkButton ponumber = (LinkButton)(gr.Cells[1].FindControl("lnkOrderNo"));
                    objproduct.PONumber =Convert.ToInt32(ponumber.Text);
                    objproduct.XMLData = CreateVechicleGridToXML();
                    objproduct.UnitPrice =Convert.ToDecimal(gr.Cells[8].Text);


                    objproduct.UnitId = Convert.ToInt32( ((Label)gr.FindControl("lblUnitID")).Text);
                    objproduct.PerUnitExpense =Convert.ToDecimal(gr.Cells[9].Text);
                    objproduct.UnitName = gr.Cells[7].Text;
                    
                    objproduct.GroupType = 1;
                    objproduct.IsActive = true;
                    objproduct.FinancialYearID =Convert.ToInt16(LoginToken.FinancialYearID);
                    objproduct.CompanyID =Convert.ToInt16(LoginToken.CompanyID);
                    objproduct.AddedBy = LoginToken.LoginId;
                    objproduct.LastModBy = LoginToken.LoginId;
                    objproduct.InvoiceHeaderID =Convert.ToInt32(gr.Cells[10].Text);
                    bool status = ObjBO.UpdateVehicleRecivingForReturn(objproduct);
                   // lblError.Text = "";
                    lblError.Visible = true;
                  

                    if (status)
                    {
                        lblError.Text = "Vehicle return successfully.";
                        lblError.Visible = true;
                        grdPartDetails.DataSource = null;
                        grdPartDetails.DataBind();
                        grdPartreturn.DataSource = null;
                        grdPartreturn.DataBind();
                        grdVehicalDetails.DataSource = null;
                        grdVehicalDetails.DataBind();
                        
                    }
                }
                else if (divPartDetails.Visible)
                {
                    PartBO ObjBO = new PartBO();
                    Product objproduct = new Product();
                    LinkButton ponumber = (LinkButton)(gr.Cells[1].FindControl("lnkOrderNo"));
                    objproduct.XMLData=CreatePratGridToXML();
                    objproduct.PONumber = Convert.ToInt32(ponumber.Text);
                    objproduct.FinancialYearID =Convert.ToInt16(LoginToken.FinancialYearID);
                    objproduct.CompanyID =Convert.ToInt16(LoginToken.CompanyID);                   
                    objproduct.LastModBy = LoginToken.LoginId;
                    objproduct.GroupType = 2;
                    objproduct.InvoiceHeaderID =Convert.ToInt32(gr.Cells[10].Text);
                    bool status = ObjBO.UpdatePartRecivingForReturn(objproduct);

                   
                  
                    if (status)
                    {
                        lblError.Text = "Part return successfully.";
                        lblError.Visible = true;

                        if (ViewState["PONumber"] != null)
                            this.BindPartGrid(Convert.ToInt32(ViewState["PONumber"]), Convert.ToInt32(ViewState["ProductType"]), Convert.ToInt32(ViewState["ProductID"]));
                    }
                }

            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
                lblError.Text = "Error while preparing Part List : " + ex.Message;
            }
        }
        #endregion  
    }
}