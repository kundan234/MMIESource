﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Data.PUR;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.PUR
{
  

    public partial class InvoicePaymentCheckout : BasePage
    {
        int num = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                try
                {

                    BindBankDetails();
                    BindCurrencyDropDown();
                    ViewState["InvoiceHeaderID"] = null;
                     
                }
                catch (Exception ex)
                {
                    lblError.Text = "Error While Loading Master Data :" + ex.Message;  

                }
                ClearAll();
            }
        }

        protected void ClearAll()
        {
            txtAddress.Text = "";
            txtCellNo.Text = "";
            txtCustomer.Text = "";
            txtStreet.Text = "";
            ddlCurrency.SelectedIndex = 0;
            ddlPaymentMode.SelectedIndex = 0;
            ddlBank.SelectedIndex = 0;
            txtPaymentModeNo.Text = "";
            txtPaymentExpirationDate.Text = "";
            txtCurrencyRate.Text = "";
            txtPhone.Text = "";
            txtTotalInvoiceAmount.Text = "";
            txtTotalPaidAmount.Text = "";
            txtTotalBalanceAmount.Text = "";

            grdTransaction.DataSource = null;
            grdTransaction.DataBind();
            grdInvoiceList.DataSource = null;
            grdInvoiceList.DataBind();
            txtInvoiceNoSave.Text = "";
            txtPONumber.Text = "";

            txtPayingAmount.Text = "";
            txtAmountRemaining.Text = "";


            ViewState["InvoiceHeaderID"] = null;
ViewState["SupplierID"]=null;
       


    }
        protected void PagePermission()
        {
            if (LoginToken != null)
            {

              
              
              
              
              
              
              
               btnSave.Enabled = LoginToken.IsAddOn;



            }
        }
        protected void btnSearchPO_Click(object sender, EventArgs e)
        {
            ClearAll(); 
            BindInvoiceHeaderList();

        }

        protected void BindInvoiceHeaderList()
        {
            try
            {

                InvoiceHeaderDetails objInvoice = new InvoiceHeaderDetails();

              //  objInvoice.InvoiceHeaderID = InvoiceHeaderID;

                objInvoice.IsActive = true;
                objInvoice.InvoiceNo = txtInvoiceNo.Text;
                objInvoice.PONumber = int.TryParse(txtPurchaseOrderNo.Text,out num)?num:0;
                objInvoice.InvoiceHeaderID = 0;
                objInvoice.CustomerName = txtSupplierName.Text;

                List<InvoiceHeaderDetails> lstInvoice = new List<InvoiceHeaderDetails>();

                InvoiceHeaderDetailsBO objInvoiceBO = new InvoiceHeaderDetailsBO();
                lstInvoice = objInvoiceBO.GetSearchInvoiceHeaderDetails(objInvoice);
                grdInvoiceList.DataSource = lstInvoice;
                grdInvoiceList.DataBind();


            }
            catch
            {
                lblError.Text = "Error while fecthing Error Invoice Details";

            }








        }

        /// <summary>
        /// Bind Masters
        /// </summary>
        /// <param name="invoiceHeaderID"></param>
        #region Binding Masters

        private void BindBankDetails()
        {
            BankBO objPaymentDetailsBO = new BankBO();
            List<Bank> lstPaymentHistory = new List<Bank>();
            lstPaymentHistory = objPaymentDetailsBO.GetBankList(false);
            if (lstPaymentHistory != null)
            {
                ddlBank.DataSource = lstPaymentHistory;
                ddlBank.DataBind();

                ddlBank.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }

        protected void BindCurrencyDropDown()
        {
            try
            {
                CurrencyBO objCurrencyBO = new CurrencyBO();

                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
                //ddlCurrency.SelectedIndex = 1;
                

            }
            catch (Exception ex)
            {

                lblError.Text = "Error : " + ex.Message;
            }

        }
       




        #endregion



        protected void BindInvoiceDetails(int invoiceHeaderID)
        {
            try
            {


                InvoiceHeaderDetails objInvoice = new InvoiceHeaderDetails();
                objInvoice.InvoiceHeaderID = num;

                InvoiceHeaderDetails objInvoiceRet = new InvoiceHeaderDetails();

                InvoiceHeaderDetailsBO objInvoiceBO = new InvoiceHeaderDetailsBO();
                objInvoiceRet = objInvoiceBO.GetSearchInvoiceHeaderDetailsByID(objInvoice);
                if(objInvoiceRet !=null)
                {
                txtAddress.Text = objInvoiceRet.CustomerAddress;
                txtCellNo.Text = objInvoiceRet.CustomerMobile;
                txtCustomer.Text = objInvoiceRet.CustomerName;
                txtStreet.Text = objInvoiceRet.CustomerStreet;
                ddlCurrency.SelectedValue = objInvoiceRet.CurrencyID.ToString();
                txtCurrencyRate.Text = objInvoiceRet.CurrencyRate.ToString();
                txtPhone.Text = objInvoiceRet.CustomerPhone;
                txtTotalInvoiceAmount.Text=objInvoiceRet.TotalInvoiceAmount.ToString();
                txtTotalPaidAmount.Text= objInvoiceRet.PaidAmount.ToString();
                txtTotalBalanceAmount.Text= (objInvoiceRet.TotalInvoiceAmount- objInvoiceRet.PaidAmount).ToString();

                txtPayingAmount.Text = txtTotalBalanceAmount.Text;
                txtAmountRemaining.Text="";
                txtPONumber.Text = objInvoiceRet.PONumber.ToString();
                txtInvoiceNoSave.Text = objInvoiceRet.InvoiceNo;


                ViewState["SupplierID"] = objInvoiceRet.SupplierID;
                ViewState["InvoiceHeaderID"] = objInvoiceRet.InvoiceHeaderID;

                PaymentDetails objPaymentDetails = new PaymentDetails();
                List<PaymentDetails> lstPayment = new List<PaymentDetails>();
                PaymentDetailsBO objPaymentDetailsBO = new PaymentDetailsBO();

                lstPayment = objPaymentDetailsBO.GetPaymentDetailsListByInvoiceID(objInvoiceRet.InvoiceHeaderID);

                grdTransaction.DataSource = lstPayment;
                grdTransaction.DataBind();



                }
            }

            catch (Exception ex)
            {
                lblError.Text = "Error while fetching invoice Details :  " + ex.Message;
                
            }

        }

        #region Grid Events
        /// <summary>
        /// To manuplate grid row at the time of row creation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //protected void grdInvoiceList_OnRowCreated(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
        //        if (e.Row.RowIndex % 2 == 0)
        //        {
        //            //Change row colour on mouseover and mouseout
        //            e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
        //        }
        //        else
        //        {
        //            //Change row colour on mouseover and mouseout
        //            e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
        //        }
        //    }
        //}

        /// <summary>
        /// For Binding Vehicle/Part Item Grid on Row Command of order
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdInvoiceList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ShowDetails")
            {
                GridViewRow grArtist = ((Control)
                   (e.CommandSource)).NamingContainer as GridViewRow;

                int.TryParse(grdInvoiceList.DataKeys[grArtist.RowIndex]["InvoiceHeaderID"].ToString(), out num);
                BindInvoiceDetails(num);

                num = 0;

               

                
                
            }
        }

      
        /// <summary>
        /// To manuplate grid row at the time of row creation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdInvoiceList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }
        #endregion

        #region Page Events

        

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {


                PaymentDetails objPaymentDetails = new PaymentDetails();
                PaymentDetailsBO objPaymentDetailsBO = new PaymentDetailsBO();


                objPaymentDetails.PaymentAmount = Convert.ToDecimal(txtPayingAmount.Text);
                objPaymentDetails.PaymentSourceID = Convert.ToInt32(ddlPaymentMode.SelectedValue.ToString());
                objPaymentDetails.PaymentMode = ddlPaymentMode.SelectedItem.ToString();
                objPaymentDetails.PaymentModeNo = txtPaymentModeNo.Text;
                objPaymentDetails.BankID = ddlBank.SelectedIndex > 0 ? Convert.ToInt32(ddlBank.SelectedValue.ToString()) : 0;
                if (ddlPaymentMode.SelectedValue == "2" || ddlPaymentMode.SelectedValue == "3") { objPaymentDetails.Expirationdate = Convert.ToDateTime(txtPaymentExpirationDate.Text); }
                objPaymentDetails.AuthorizationNo = 0;
                objPaymentDetails.CurrencyID = ddlCurrency.SelectedIndex > 0 ? Convert.ToInt32(ddlCurrency.SelectedValue.ToString()) : 0;
                objPaymentDetails.CurrencyRate = Convert.ToDecimal(txtCurrencyRate.Text != "" ? txtCurrencyRate.Text : "0");

  
                objPaymentDetails.CustomerID = ViewState["SupplierID"] != null ? (int)ViewState["SupplierID"] : 0;
                objPaymentDetails.FinancialYearID = LoginToken.FinancialYearID;
                objPaymentDetails.CompanyID = LoginToken.CompanyID;
                objPaymentDetails.AddedBy = LoginToken.LoginId;

                objPaymentDetails.PaidGourdesAmt = Convert.ToDecimal(txtTotalPaidAmount.Text) + objPaymentDetails.PaymentAmount;


                objPaymentDetails.TType = "DR";
                objPaymentDetails.TransactionType = "PurchasePayment";
                objPaymentDetails.Remarks = txtRemarks.Text;

                objPaymentDetails.PurchaseOrderID = ViewState["InvoiceHeaderID"] != null ? (int)ViewState["InvoiceHeaderID"] : 0;
                objPaymentDetails.PONumber = txtPONumber.Text != "" ? Convert.ToInt32(txtPONumber.Text) : 0;
                objPaymentDetails.InvoiceNo = txtInvoiceNoSave.Text;
                objPaymentDetails.IsActive = true;
                objPaymentDetails.IsPurchase = true;

                if (objPaymentDetailsBO.SaveInvoicePaymentDetails(objPaymentDetails))
                {

                    lblError.Text = "Purchase Payment Details Saved Successfully";
                    ClearAll();

                }
            }

            catch (Exception ex) //Exception in agent layer itself
            {
             //  PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Saving Purhcase Payment: "+ex.Message ;
                lblError.Visible = true;
            }






        }

        #endregion

        protected void grdTransaction_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdTransaction.PageIndex = e.NewPageIndex;
            grdTransaction.DataBind();  
        }

        protected void grdTransaction_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }
    }





}