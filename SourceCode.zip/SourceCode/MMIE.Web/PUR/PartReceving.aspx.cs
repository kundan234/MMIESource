﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.Web;
using System.Data;
using System.Data.SqlClient;
using MMIE.BusinessProcess.Common;
using MMIE.Data.Common;
using MMIE.BusinessProcess.PUR;
using System.Configuration;
using MMIE.Common.Util;
using System.Web.UI.HtmlControls;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
namespace MMIE.PUR
{
    public partial class PartReceving : BasePage
    {
        DataSet dsImportReceivingData = new DataSet();
        DataSet ds = null;
        DataSet dsExpenseDetails = null;
        DataSet dsOrderparts = null;
        List<Customer> lstStore = null;
        public int SupplierID = 0;
        bool Flag;

        protected void PagePermission()
        {
            if (LoginToken != null)
            {

                btnSubmit.Enabled = LoginToken.IsAddOn;
                btnPrint.Enabled = LoginToken.IsPrintOn;
            }
        }

        protected void BindOtherCharges()
        {
            List<OtherCharges> lstOtherCharges = new List<OtherCharges>();
            OtherChargesBO objOChargesBO = new OtherChargesBO();
            OtherCharges objOCharges = new OtherCharges();

            objOCharges.IsActive = true;

            lstOtherCharges = objOChargesBO.GetSearchOtherCharges(objOCharges);
            ddlOtherChargeID.DataSource = lstOtherCharges;
            ddlOtherChargeID.DataTextField = "ChargeName";
            ddlOtherChargeID.DataValueField = "ChargeID";
            ddlOtherChargeID.DataBind();


        }
        protected void Page_Load(object sender, EventArgs e)
        {
            PagePermission();
       
            try
            {
                if (!IsPostBack)
                {
                    TabContainerVehicleReceving_ActiveTabChanged(TabContainerVehicleReceving, null);
                    MasterLookupBO mstlookup = new MasterLookupBO();
                    //BindDropDownControl(ddlCity, mstlookup.GetLookupsList(LookupNames.City));
                    //ddlCity.Items.Insert(0, "Select City");
                    BindDropDownControl(drCompanyBranch, mstlookup.GetLookupsList(LookupNames.Company));

                    BindDropDownControl(ddlStoreType, mstlookup.GetLookupsList(LookupNames.StoreName));
                    ddlStoreType.Items.Insert(0, "Select Store/Depot");

                    BindDropDownControl(ddlStoreDepot, mstlookup.GetLookupsList(LookupNames.StoreName));
                    ddlStoreDepot.Items.Insert(0, "Select Store/Depot");

                    BindDropDownControl(ddlCountry, mstlookup.GetLookupsList(LookupNames.Country));
                    ddlCountry.Items.Insert(0, "Select Country");

                    BindDropDownControl(ddlPurchaseNumber, mstlookup.GetLookupsList(LookupNames.PONumber));
                    ddlPurchaseNumber.Items.Insert(0, "Select Order No");
                    BindOtherCharges();
                    //AddExpenseBox(ExpenseBoxCount);
                    //ExpenseBoxCount++;
                    //AddDescriptionBox(DescBoxCount);
                    //DescBoxCount++;
                    AddNewTable();
                }
                else
                {

                    Table tempTable = Session["OtherCharges"] == null ? new Table() : (Table)Session["OtherCharges"];

                    phControls1.Controls.Add(tempTable);
                    //for (var i = 0; i < ExpenseBoxCount; i++)
                    //    AddExpenseBox(i);
                    //for (var i = 0; i < DescBoxCount; i++)
                    //    AddDescriptionBox(i);

                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        //private int ExpenseBoxCount
        //{
        //    get
        //    {
        //        var count1 = ViewState["ExpenseBoxCount"];
        //        return (count1 == null) ? 0 : (int)count1;
        //    }
        //    set { ViewState["ExpenseBoxCount"] = value; }
        //}
        //private int DescBoxCount
        //{
        //    get
        //    {
        //        var count = ViewState["txtBoxCount"];
        //        return (count == null) ? 0 : (int)count;
        //    }
        //    set { ViewState["txtBoxCount"] = value; }
        //}
        //private void AddExpenseBox(int index)
        //{
        //    var txtexp = new TextBox { ID = string.Concat("txtExp", index) };
        //    txtexp.Style.Add("display", "block");
        //    phControls1.Controls.Add(txtexp);

        //}
        //private void AddDescriptionBox(int index)
        //{

        //    var txtDesc = new TextBox { ID = string.Concat("txtDesc", index) };
        //    txtDesc.Style.Add("display", "block");
        //    panel1.Controls.Add(txtDesc);

        //}

        private int ExpBoxID
        {
            get
            {
                var count = ViewState["txtExpBoxID"];
                return (count == null) ? 0 : (int)count;
            }
            set { ViewState["txtExpBoxID"] = value; }
        }

        protected void TabContainerVehicleReceving_ActiveTabChanged(object sender, EventArgs e)
        {

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtInvoiceNo.Text != "" && ddlSupplier.SelectedValue != "")
                {
                    string strAmountValue = string.Empty;
                    string strDescValue = string.Empty;
                    string strID = string.Empty;
                    //foreach (var control in phControls1.Controls)
                    //{
                    //    var textBox = control as TextBox;
                    //    if (textBox == null) continue;
                    //    strAmountValue += textBox.Text + ",";
                    //}
                    //foreach (var control in panel1.Controls)
                    //{
                    //    var textBox1 = control as TextBox;
                    //    if (textBox1 == null) continue;
                    //    strDescValue += textBox1.Text + ",";
                    //}

                    Table tempTable = Session["OtherCharges"] == null ? new Table() : (Table)Session["OtherCharges"];
                    for (int i = 1; i < tempTable.Rows.Count; i++)
                    {

                        TableRow tr = tempTable.Rows[i];
                        TextBox txtChargeName;// = new TextBox();
                        TextBox txtChargeRate; //= new TextBox();
                        Label lblChargeID;// = new Label();
                        lblChargeID = (Label)tr.Cells[3].Controls[0];
                        txtChargeName = (TextBox)tr.Cells[1].Controls[0];
                        txtChargeRate = (TextBox)tr.Cells[2].Controls[0];
                        strAmountValue += txtChargeRate.Text + ",";
                        strDescValue += txtChargeName.Text + ",";
                        strID += lblChargeID.Text + ",";

                    }

                    PartBO useradm = new PartBO();
                    Customer objCustomer = new Customer();
                    LoginToken objLoginToken = new LoginToken();
                    objCustomer.InvoiceNo = txtInvoiceNo.Text.Trim();
                    objLoginToken.LoginId = LoginToken.LoginId;
                    objCustomer.LastModBy = LoginToken.LoginId;
                    objCustomer.CompanyID = Convert.ToInt16(drCompanyBranch.SelectedValue);//Convert.ToInt16(LoginToken.CompanyID);
                    objCustomer.ActionType = EnumActionType.Insert;
                    objCustomer.Amount = strAmountValue; //txtAddGourdes.Text.Trim();
                    objCustomer.Descr = strDescValue; //txtDesc.Text.Trim();
                    objCustomer.CustomerID = Convert.ToInt32(ddlSupplier.SelectedValue);
                    objCustomer.TotalAmount = Convert.ToDouble(lblTotalAmount.Text.Substring(3).Replace(",", ""));
                    objCustomer.GroupType = 2;
                    objCustomer.TotalInsurance = Convert.ToDecimal(txtInsrance.Text);
                    objCustomer.TotalFrieght = Convert.ToDecimal(txtFright.Text);
                    objCustomer.TotalCostPrice = Convert.ToDecimal(txtCostPrice.Text);

                    PartBO Cust = new PartBO();
                    bool status = Cust.SavePurOtherCharges(objCustomer);
                    if (status == true)
                    {
                        Customer objRetCustomer = useradm.GetPURTotalExpenses(objCustomer);
                        if (objRetCustomer != null)
                        {
                            decimal expense = objRetCustomer.TotalGourdesAmt;
                            //decimal prevexpense = Convert.ToDecimal(lblExpenses.Text.Substring(3));
                            //lblExpenses.Text = "US$" + Convert.ToString(prevexpense + expense);
                            lblExpenses.Text = "US$" + Convert.ToString(expense);
                            decimal Prevtotalamount = objRetCustomer.TotalUSDAmt; //Convert.ToDecimal(lblTotalAmount.Text.Substring(3).Replace(",", ""));
                            lblTotalAmount.Text = "US$" + Convert.ToString(Prevtotalamount + expense);
                        }
                        lblError.Text = ExceptionMessage.GetMessage("STR7000001");
                        lblError.Visible = true;
                        TabContainerVehicleReceving.ActiveTabIndex = 0;
                    }
                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemid";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
        }


        protected void UploadFile_Click(object sender, EventArgs e)
        {
            try
            {
                if (PartListExceUpload.HasFile)
                {
                    //reading excel information and assigned to dataset
                    DataTable objdt = null;
                    string AccessFilename = PartListExceUpload.FileName.ToString();
                    string UploadFilestring = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "\\UploadedExcelFiles\\" + AccessFilename;

                    lblError.Text = "Please Wait! Updating Data....";
                    lblError.Visible = true;
                    //Retriving Invoice Details
                    PartListExceUpload.SaveAs(UploadFilestring);
                    objdt = ExcelConverter.ReadFromExcel(UploadFilestring, "invoice", "Invoice");

                    if (objdt != null)
                    {
                        int icreament = 0;
                        foreach (DataColumn colums in objdt.Columns)
                        {
                            Flag = false;
                            PartBO useradm = new PartBO();
                            Customer objcustomer = new Customer();
                            objcustomer.CustomerName = colums.ColumnName.Replace("#", ".");
                            Customer objRetCustomer = useradm.GetCustomerNameByName(objcustomer);
                            if (objRetCustomer != null)
                            {
                                MasterLookupBO mstlookup = new MasterLookupBO();
                                Flag = true;
                                txtPhone.Text = objRetCustomer.CustomerPhone;
                                txtAddress.Text = objRetCustomer.CustomerAddress;
                                txtCellNo.Text = objRetCustomer.CustomerMobile;
                                txtStreet.Text = objRetCustomer.CustomerStreet;
                                txtFaxNo.Text = objRetCustomer.CustomerFax;
                                string TotalCostPrice = objdt.Rows[22].ItemArray[4].ToString().Substring(3).Replace(",", "");
                                string Insuranc = objdt.Rows[24].ItemArray[4].ToString().Substring(3).Replace(",", "");
                                string Freight = objdt.Rows[23].ItemArray[4].ToString().Substring(3).Replace(",", "");
                                double CostPriceFinal = Convert.ToDouble(TotalCostPrice);
                                double Insurancfinal = Convert.ToDouble(Insuranc);
                                double Freightfinal = Convert.ToDouble(Freight);
                                txtFright.Text = Freightfinal.ToString();
                                txtInsrance.Text = Insurancfinal.ToString();
                                txtCostPrice.Text = CostPriceFinal.ToString();
                                // lblExpenses.Text ="US$"+Convert.ToString(Insurancfinal + Freightfinal);
                                lblTotalAmount.Text = objdt.Rows[25].ItemArray[4].ToString();
                                BindDropDownControl(ddlSupplier, mstlookup.GetLookupsList(LookupNames.Supplier));
                                ddlSupplier.Items.Insert(0, "Select Supplier");
                                (ddlSupplier.SelectedValue) = objRetCustomer.CustomerID.ToString();
                                //  (ddlCity.SelectedValue) = objRetCustomer.CustomerCityID.ToString();
                                txtCity.Text = objRetCustomer.CityName;
                                txtEmail.Text = objRetCustomer.CustomerEmail;
                                (ddlCountry.SelectedValue) = objRetCustomer.CustomerCountryID.ToString();
                                txtWebsite.Text = objRetCustomer.CustomerWebsite;

                            }

                            break;
                        }
                        foreach (DataRow row in objdt.Rows) // Loop over the rows.
                        {
                            //objdt.Rows.Remove();
                            foreach (var item in row.ItemArray) // Loop over the items.
                            {

                                if (icreament == 31)
                                {

                                    // txtInvoiceNo.Text = item.ToString().Substring(12, 17);
                                    txtInvoiceNo.Text = item.ToString().Trim().Remove(0, 12).Trim();
                                }

                                string abc = item.ToString();
                                icreament++;
                            }
                        }
                        //Deleting extra rows in the datatable
                        int Increment = 3;
                        for (int i = 0; i < Increment; i++)
                        {
                            DataRow rowDel;
                            rowDel = objdt.Rows[i];
                            objdt.Rows.Remove(rowDel);
                        }
                        //Deleting extra rows in the datatable
                        Increment = 2;
                        for (int i = 0; i < Increment; i++)
                        {
                            DataRow rowDel;
                            rowDel = objdt.Rows[i];
                            objdt.Rows.Remove(rowDel);
                        }
                        //Deleting extra rows in the datatable
                        Increment = 1;
                        for (int i = 0; i < Increment; i++)
                        {
                            DataRow rowDel;
                            rowDel = objdt.Rows[i];
                            objdt.Rows.Remove(rowDel);
                        }
                        //Deleting extra rows in the datatable
                        Increment = 1;
                        for (int i = 0; i < Increment; i++)
                        {
                            DataRow rowDel;
                            rowDel = objdt.Rows[i];
                            objdt.Rows.Remove(rowDel);
                        }
                        //Deleting extra rows in the datatable
                        Increment = 1;
                        for (int i = 0; i < Increment; i++)
                        {
                            DataRow rowDel;
                            rowDel = objdt.Rows[i];
                            objdt.Rows.Remove(rowDel);
                        }
                        //Deleting extra rows in the datatable
                        Increment = 20;
                        for (int i = 18; i < Increment; i++)
                        {
                            DataRow rowDel;
                            rowDel = objdt.Rows[i];
                            objdt.Rows.Remove(rowDel);
                        }

                        DataColumn POnumber = new DataColumn();
                        POnumber.DataType = System.Type.GetType("System.Int32");
                        POnumber.ColumnName = "PONumber";
                        if (ddlPurchaseNumber.SelectedIndex > 0)
                            POnumber.DefaultValue = ddlPurchaseNumber.SelectedItem.ToString();
                        else
                        {
                            POnumber.DefaultValue = "0";
                        }
                        objdt.Columns.Add(POnumber);

                        if (Flag == true)
                        {
                            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString))
                            {
                                cn.Open();
                                using (SqlBulkCopy copy = new SqlBulkCopy(cn))
                                {
                                    copy.ColumnMappings.Add(0, 2);
                                    copy.ColumnMappings.Add(1, 10);
                                    copy.ColumnMappings.Add(2, 4);
                                    copy.ColumnMappings.Add(3, 6);
                                    copy.ColumnMappings.Add(4, 8);
                                    copy.ColumnMappings.Add(7, 16);
                                    copy.DestinationTableName = "PUR_InvoiceDetail";
                                    copy.WriteToServer(objdt);
                                    //Calling Save operation of IUserAdmin Service
                                    Customer objCustomer = new Customer();
                                    LoginToken objLoginToken = new LoginToken();
                                    objCustomer.InvoiceNo = txtInvoiceNo.Text.Trim();
                                    objLoginToken.LoginId = LoginToken.LoginId;
                                    objCustomer.LastModBy = LoginToken.LoginId;
                                    objCustomer.AddedBy = LoginToken.LoginId;
                                    // objCustomer.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                                    objCustomer.StoreID = Convert.ToInt16(ddlStoreType.SelectedValue);
                                    objCustomer.CompanyID = Convert.ToInt16(drCompanyBranch.SelectedValue);
                                    objCustomer.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);

                                    objCustomer.ActionType = EnumActionType.Update;
                                    PartBO Cust = new PartBO();
                                    bool status = Cust.SavePurInvoiceNumber(objCustomer);
                                    if (status == true)
                                    {

                                    }
                                    ds = SearchStore(objCustomer);
                                    grdPartReceving.DataSource = ds.Tables[0].DefaultView;
                                    grdPartReceving.DataBind();
                                }
                            }
                        }
                    }
                    else
                    {
                        lblError.Text = ExceptionMessage.GetMessage("1000020");
                        lblError.Visible = true;
                    }

                    //Retriving Order Parts Details   
                    DataTable objdtorderPart = null;
                    objdtorderPart = ExcelConverter.ReadFromExcel(UploadFilestring, "ORDER PARTS", "PartOrder");
                    if (objdtorderPart != null)
                    {
                        //Deleting extra rows in the datatable
                        int Increments = 3;
                        for (int i = 0; i < Increments; i++)
                        {
                            DataRow rowDel;
                            rowDel = objdtorderPart.Rows[i];
                            objdtorderPart.Rows.Remove(rowDel);
                        }
                        //Deleting extra rows in the datatable
                        Increments = 1;
                        for (int i = 0; i < Increments; i++)
                        {
                            DataRow rowDel;
                            rowDel = objdtorderPart.Rows[i];
                            objdtorderPart.Rows.Remove(rowDel);
                        }
                        //Deleting extra rows in the datatable
                        Increments = 193;
                        if (objdtorderPart.Rows.Count >= 192)
                        {
                            for (int i = 192; i < Increments; i++)
                            {
                                DataRow rowDel;
                                rowDel = objdtorderPart.Rows[i];
                                objdtorderPart.Rows.Remove(rowDel);
                            }
                        }

                        DataColumn POnumber = new DataColumn();
                        POnumber.DataType = System.Type.GetType("System.Int32");
                        POnumber.ColumnName = "PONumber";
                        if (ddlPurchaseNumber.SelectedIndex > 0)
                            POnumber.DefaultValue = ddlPurchaseNumber.SelectedItem.ToString();
                        else
                        {
                            POnumber.DefaultValue = "0";
                        }
                        objdtorderPart.Columns.Add(POnumber);

                        if (Flag == true)
                        {
                            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString))
                            {
                                cn.Open();
                                using (SqlBulkCopy copy = new SqlBulkCopy(cn))
                                {

                                    copy.ColumnMappings.Add(0, 2);
                                    copy.ColumnMappings.Add(4, 3);
                                    copy.ColumnMappings.Add(5, 4);
                                    copy.ColumnMappings.Add(6, 5);
                                    copy.ColumnMappings.Add(9, 1);
                                    copy.ColumnMappings.Add(10, 8);
                                    copy.ColumnMappings.Add(11, 9);
                                    copy.ColumnMappings.Add(12, 10);
                                    copy.ColumnMappings.Add(13, 11);
                                    copy.ColumnMappings.Add(14, 19);
                                    copy.ColumnMappings.Add(1, 20);

                                    copy.DestinationTableName = "PUR_PartRecevingDetail";
                                    copy.WriteToServer(objdtorderPart);

                                    //Calling Save operation of IUserAdmin Service

                                    Customer objCustomer = new Customer();
                                    LoginToken objLoginToken = new LoginToken();
                                    objCustomer.InvoiceNo = txtInvoiceNo.Text.Trim();
                                    objLoginToken.LoginId = LoginToken.LoginId;
                                    objCustomer.LastModBy = LoginToken.LoginId;
                                    objCustomer.CompanyID = Convert.ToInt16(drCompanyBranch.SelectedValue); //Convert.ToInt16(LoginToken.CompanyID);
                                    objCustomer.AddedBy = LoginToken.LoginId;
                                    objCustomer.StoreID = Convert.ToInt16(ddlStoreType.SelectedValue);
                                    objCustomer.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                                    objCustomer.ActionType = EnumActionType.Insert;
                                    objCustomer.GroupType = 2;


                                    PartBO Cust = new PartBO();
                                    bool status = Cust.SavePurInvoiceNumber(objCustomer);
                                    if (status == true)
                                    {

                                    }

                                    dsOrderparts = GetOrderPartsDetails(objCustomer);
                                    grdPartReceivedtemlist.DataSource = dsOrderparts.Tables[0].DefaultView;
                                    grdPartReceivedtemlist.DataBind();

                                }
                            }
                        }
                    }
                    else
                    {
                        lblError.Text = ExceptionMessage.GetMessage("1000020");
                        lblError.Visible = true;
                    }

                }

                lblError.Text = "";
                lblError.Visible = false;
            }

            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }


        private DataSet SearchStore(Customer objStore)
        {
            //Call service operation to get data from database source
            PartBO st = new PartBO();
            lstStore = st.SearchStore(objStore);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        private DataSet GetOrderPartsDetails(Customer objStore)
        {
            //Call service operation to get data from database source
            PartBO st = new PartBO();
            lstStore = st.GetOrderPartsDetails(objStore);
            DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
            ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }


        protected void txtInvoiceNo_TextChanged(object sender, EventArgs e)
        {

        }


        protected void btnAddAuto_Click(object sender, EventArgs e)
        {
            //AddExpenseBox(ExpenseBoxCount);
            //ExpenseBoxCount++;
            //AddDescriptionBox(DescBoxCount);
            //DescBoxCount++;
            AddOtherCharges();

        }



        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Customer objCustomer = new Customer();
                PartBO useradm = new PartBO();
                objCustomer.InvoiceNo = txtInvoiceNo.Text.Trim();
                objCustomer.ContainerNumber = txtContainerNo.Text.Trim();
                ds = SearchStore(objCustomer);
                grdPartReceving.DataSource = ds.Tables[0].DefaultView;
                grdPartReceving.DataBind();
                dsOrderparts = GetOrderPartsDetails(objCustomer);
                grdPartReceivedtemlist.DataSource = dsOrderparts.Tables[0].DefaultView;
                grdPartReceivedtemlist.DataBind();

                Customer objRetCustomer = useradm.GetCustomerNameByName(objCustomer);
                if (objRetCustomer != null)
                {
                    MasterLookupBO mstlookup = new MasterLookupBO();
                    txtPhone.Text = objRetCustomer.CustomerPhone;
                    txtAddress.Text = objRetCustomer.CustomerAddress;
                    txtCellNo.Text = objRetCustomer.CustomerMobile;
                    txtStreet.Text = objRetCustomer.CustomerStreet;
                    txtFaxNo.Text = objRetCustomer.CustomerFax;
                    BindDropDownControl(ddlSupplier, mstlookup.GetLookupsList(LookupNames.Supplier));
                    ddlSupplier.Items.Insert(0, "Select Supplier");
                    (ddlSupplier.SelectedValue) = objRetCustomer.CustomerID.ToString();
                    //  (ddlCity.SelectedValue) = objRetCustomer.CustomerCityID.ToString();
                    txtCity.Text = objRetCustomer.CityName;
                    txtEmail.Text = objRetCustomer.CustomerEmail;
                    (ddlCountry.SelectedValue) = objRetCustomer.CustomerCountryID.ToString();
                    txtWebsite.Text = objRetCustomer.CustomerWebsite;
                }

                objCustomer.ActionType = EnumActionType.Insert;
                Customer objCust = useradm.GetPURTotalExpenses(objCustomer);
                if (objCust != null)
                {
                    decimal expense = objCust.TotalGourdesAmt;
                    lblExpenses.Text = "US$" + Convert.ToString(expense);
                    decimal Prevtotalamount = objCust.TotalUSDAmt;
                    lblTotalAmount.Text = "US$" + Convert.ToString(Prevtotalamount + expense);
                }


            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }

        }

        private void AddNewTable()
        {
            Session["OtherCharges"] = null;
            Table t = new Table();
            t.Style.Add(HtmlTextWriterStyle.Width, "100%");
            t.Rows.Clear();
            t.BorderStyle = BorderStyle.Solid;

            TableHeaderRow th = new TableHeaderRow();
            th.BorderStyle = BorderStyle.Solid;
            TableCell c1 = new TableCell();
            c1.Text = "S.No.";
            c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

            TableCell c2 = new TableCell();
            c2.Text = "Other Charges";
            c2.Style.Add(HtmlTextWriterStyle.Width, "15%");

            TableCell c3 = new TableCell();
            c3.Text = "Charges Amount";
            c3.Style.Add(HtmlTextWriterStyle.Width, "5%");
            c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");


            th.Cells.Add(c1);
            th.Cells.Add(c2);
            th.Cells.Add(c3);




            Style myStyle = new Style();
            myStyle.ForeColor = System.Drawing.Color.Black;
            myStyle.BackColor = System.Drawing.Color.LightGray;
            myStyle.Font.Bold = true;
            myStyle.BorderStyle = BorderStyle.Solid;

            th.ApplyStyle(myStyle);
            // th.Font.Size =Unit.Percentage(12);
            th.BorderStyle = BorderStyle.Solid;
            th.BorderWidth = Unit.Pixel(1);

            t.Rows.Add(th);

            Session["OtherCharges"] = t;
        }
        void AddOtherCharges()
        {

            OtherChargesBO objBO = new OtherChargesBO();
            OtherCharges objCharges = new OtherCharges();
            objCharges.ChargeID = Convert.ToInt32(ddlOtherChargeID.SelectedValue.ToString());
            OtherCharges objChargesRet = new OtherCharges();

            objChargesRet = objBO.GetOtherChargeByID(objCharges);
            if (objChargesRet != null)
            {
                Table tempTable = Session["OtherCharges"] == null ? new Table() : (Table)Session["OtherCharges"];
                HyperLink lnk = new HyperLink();

                ExpBoxID++;

                TextBox txtChargeName = new TextBox();
                txtChargeName.EnableViewState = true;
                txtChargeName.ID = "txt" + ExpBoxID.ToString();
                txtChargeName.MaxLength = 100;
                txtChargeName.Text = ddlOtherChargeID.SelectedItem.ToString();

                TextBox txtChargeAmount = new TextBox();
                txtChargeAmount.ID = "chk" + ExpBoxID.ToString();
                txtChargeAmount.Text = objChargesRet.ChargeRate.ToString();




                Label lblID = new Label();
                lblID.EnableViewState = true;
                lblID.ID = "label4" + ExpBoxID.ToString();
                lblID.Text = ExpBoxID.ToString();
                lblID.Visible = true;

                Label lblChID = new Label();
                lblChID.EnableViewState = true;
                lblChID.ID = "label5" + ExpBoxID.ToString();
                lblChID.Text = ddlOtherChargeID.SelectedValue.ToString();
                lblChID.Visible = false;

                TableRow dr = new TableRow();

                TableCell c1 = new TableCell();
                TableCell c2 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();

                c1.Controls.Add(lblID);
                c2.Controls.Add(txtChargeName);
                c3.Controls.Add(txtChargeAmount);
                c4.Controls.Add(lblChID);
                dr.Cells.Add(c1);
                dr.Cells.Add(c2);
                dr.Cells.Add(c3);
                dr.Cells.Add(c4);

                tempTable.Rows.Add(dr);

                phControls1.Controls.Add(tempTable);

                Session["OtherCharges"] = tempTable;
            }
        }

        //private DataSet GetPartsExpenseDetails(Customer objStore)
        //{
        //    PartBO st = new PartBO();
        //    lstStore = st.GetPartsExpenseDetails(objStore);
        //    DataTable dt = ORHelper<Customer>.GenericListToDataTable(lstStore);
        //    ds = new DataSet();
        //    ds.Tables.Add(dt);
        //    return ds;
        //}

        protected void ddlPurchaseNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtPONo.Text = ddlPurchaseNumber.SelectedItem.ToString();

        }
    }

}

