﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Data.PUR;
using MMIE.Common.Util;
using MMIE.Web;
 

public partial class PartReturnDetail :BasePage
{

  
        
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}