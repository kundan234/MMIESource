﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MMIE.Web;
using MMIE.BusinessProcess.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.Common;


namespace MMIE.PUR
{
    public partial class PurchaseOrder : BasePage
    {
        DataSet ds = null;
      //  int SearchCustomerID = 0;
        List<Order> lstOrder = null;
      //  DataSet dsOrderdetails = null;
        const string VS_SEARCH = "VS_SEARCH";
        protected void Page_UnLoad(object sender, EventArgs e)
        {
            if (Session["ProductDetail"] == null) Session["ProductDetail"] = null;
         
        }

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnsave.Enabled = LoginToken.IsAddOn;
                //btnNewOrder.Enabled = LoginToken.IsAddOn;
             
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                PagePermission();
                if (!IsPostBack)
                {
                    MasterLookupBO mstlookup = new MasterLookupBO();

                    BindDropDownControl(ddlProductType, mstlookup.GetLookupsList(LookupNames.Group));
                    ddlProductType.Items.Insert(0, "Select Product Type");
                    Session["IssuedProductList"] = null;
                    Session["ProductDetail"] = null;
                    Session["dsMaterialDetail"] = null;

                }
                txtPUROrderDate.Text = System.DateTime.Now.ToString("MM/dd/yyyy");
                txtOrderTime.Text = System.DateTime.Now.ToString("hh:mm:ss");
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemid";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
        }

        protected void gvProductSearch_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    for (int count = 0; count < e.Row.Cells.Count; count++)
            //        e.Row.Cells[count].ToolTip = e.Row.Cells[count].Text;
            //    HyperLink hy = (e.Row.Cells[0].Controls[0]) as HyperLink;
            //    if (hy != null)
            //    {
            //        hy.NavigateUrl = "javascript:" + hy.NavigateUrl;
            //        hy.ToolTip = hy.Text;
            //    }
            //}
        }

        protected void txtSearchModel_TextChanged(object sender, EventArgs e)
        {
          SearchVehicle();
            
        }
        protected void txtSearchName_TextChanged(object sender, EventArgs e)
        {
            if (txtSearchName.Text.Trim().Length > 2)
            {
                SearchVehicle();
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SearchVehicle();
        }

        protected void txtSearchColor_TextChanged(object sender, EventArgs e)
        {
            SearchVehicle();
        }
        public void SearchVehicle()
        {
            try
            {

                Session["ProductDetail"] = null;
                Session["dsMaterialDetail"] = null;
                String SearchParam = txtSearchModel.Text.Trim() == "" ? "" : "Model like '" + txtSearchModel.Text.Trim() + "%'";
                if (SearchParam == "" && rdProductName.Checked)
                {
                    SearchParam = txtSearchName.Text.Trim() == "" ? "" : "ProductName like '" + txtSearchName.Text.Trim() + "%'";
                }
                else if (rdProductName.Checked)
                {
                    SearchParam = SearchParam + (txtSearchName.Text.Trim() == "" ? "" : " and ProductName like '" + txtSearchName.Text.Trim() + "%'") + (txtSearchColor.Text.Trim() == "" ? "" : " and Color like '" + txtSearchColor.Text.Trim() + "%'");
                }

                if (SearchParam == "" && rdReferenceName.Checked)
                {
                    SearchParam = txtSearchName.Text.Trim() == "" ? "" : "ReferenceName like '" + txtSearchName.Text.Trim() + "%'";
                }
                else if (rdReferenceName.Checked)
                {
                    SearchParam = SearchParam + (txtSearchName.Text.Trim() == "" ? "" : " and ReferenceName like '" + txtSearchName.Text.Trim() + "%'") + (txtSearchColor.Text.Trim() == "" ? "" : " and Color like '" + txtSearchColor.Text.Trim() + "%'");
                }

                SearchParam = SearchParam == "" ? "" : " and " + SearchParam;

                if (Session["dsMaterialDetail"] == null)
                {
                    //   Session["dsMaterialDetail"] = PartBO.GetPURProductDetail(Request["isunique"] != null ? Product.IsUniqueMaterial.IsUnique : Product.IsUniqueMaterial.IsUnique, Convert.ToInt32(ddlProductType.SelectedValue.Trim()));
                    Session["dsMaterialDetail"] = PartBO.GetMaterialDetailNew(txtSearchName.Text, 
                        txtSearchModel.Text,
                        (ddlProductType.SelectedIndex > 0 ? Convert.ToInt32(ddlProductType.SelectedValue.ToString()) : 0));

                }

                DataTable dtProductDetail = (DataTable)Session["dsMaterialDetail"];
                // DataView dv = new DataView(dtProductDetail, "GroupType =" + ddlProductType.SelectedValue + SearchParam, "Model", DataViewRowState.CurrentRows);
                gvProductSearch.DataSource = dtProductDetail;
                gvProductSearch.DataBind();
                gvProductSearch.Visible = true;
            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = "Error While Searching Product : " + ex.Message;  

            }

        }

        protected void btnAddMaterial_Click(object sender, EventArgs e)
        {
            try
            {

                IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
                List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
                Product objProduct = new Product();
                lblGridError.Text = "";
                foreach (Product pd in listProduct)
                {
                    if (Convert.ToInt32(txtProductID.Text.Trim()) == pd.ProductID && Convert.ToInt32(ddlUnit.SelectedValue.ToString()) == pd.UnitId)
                    {
                        lblGridError.Text = "Product Already Exist ..!";
                        return;
                    }
                
                }
                objProduct.ProductID = Convert.ToInt32(txtProductID.Text.Trim());
                objProduct.Model = txtModeNumber.Text;
                objProduct.ProductName = txtProductName.Text;
                objProduct.IssuedQty = Convert.ToInt32(txtQuantity.Text.Trim() == "" ? "0" : txtQuantity.Text.Trim());
                objProduct.UnitName = ddlUnit.SelectedItem.Text.ToString();
                objProduct.UnitId = Convert.ToInt32( ddlUnit.SelectedValue.ToString());
                objProduct.Color = txtColor.Text.Trim();
                objProduct.GroupType = Convert.ToInt32(ddlProductType.SelectedValue);
                objProduct.strDate = txtPUROrderDate.Text.Trim();
                objProduct.ModifiedBy = LoginToken.LoginId;
                objProduct.AddedBy = LoginToken.LoginId;
                objProduct.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
                objProduct.CompanyID = Convert.ToInt16(LoginToken.CompanyID);
                objProduct.IsActive = true;
                listProduct.Add(objProduct);
                if (listProduct.Count > 0)
                {
                    gvProductDetail.DataSource = listProduct;
                    ddlProductType.Enabled = false;
                }
                else
                {
                    gvProductDetail.DataSource = null;
                    ddlProductType.Enabled = true;
            
                }
                gvProductDetail.DataBind();
                PagePermission();
                // save the list to the
                if (listProduct.Count > 0) Session["IssuedProductList"] = listProduct;

                // update material detail DataTable
                //DataTable dtProductDetail = InitMaterialList();
                //// modify certain values into the DataTable
                //dtProductDetail.AcceptChanges();
                // reset all textboxes
                txtModeNumber.Text = "";
                txtProductName.Text = "";
                txtQuantity.Text = "";
               // txtUnit.Text = "";
                ddlUnit.Items.Clear();
                txtColor.Text = "";
                btnAddMaterial.Enabled = false;
                // btnsave.Enabled = true;
           
                gvProductSearch.Visible = false;
                txtProductID.Text = "";
                // ddlProductType.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
               
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
               

                lblError.Text = "Error While Adding Product :" + ex.Message;  
            
            }

        }
        public DataTable InitMaterialList()
        {
            DataTable dtProductDetail = (DataTable)Session["dsMaterialDetail"];
            //Set Primary key
            DataColumn[] dcPK = new DataColumn[1];
            dcPK[0] = dtProductDetail.Columns["ProductID"];
            dtProductDetail.PrimaryKey = dcPK;
            return dtProductDetail;
        }

        protected void rdProductName_CheckedChanged(object sender, EventArgs e)
        {
            if (rdReferenceName.Checked)
            {
                rdReferenceName.Checked = false;
            }
        }

        protected void rdReferenceName_CheckedChanged(object sender, EventArgs e)
        {
            if (rdProductName.Checked)
            {
                rdProductName.Checked = false;
            }
        }

        protected void btnNewOrder_Click(object sender, EventArgs e)
        {
            NewOrderSet();
        }


        protected void NewOrderSet()
        {
            Session["ProductDetail"] = null;
            Session["IssuedProductList"] = null;
            Session["dsMaterialDetail"] = null;
            Response.Redirect("~/PUR/PurchaseOrder.aspx");
        }
        protected void gvProductDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            // add javascript, delete confirmation
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // add javascript, delete confirmation
                foreach (DataControlFieldCell cell in e.Row.Cells)
                {
                    // check all cells in one row
                    foreach (Control control in cell.Controls)
                    {
                        // Must use LinkButton here instead of ImageButton
                        // if you are having Links (not images) as the command button.
                        ImageButton button = control as ImageButton;
                        if (button != null && button.CommandName == "Delete")
                            // Add delete confirmation
                            button.OnClientClick = "if (!confirm('Are you sure " +
                                   "you want to delete this record?')) return;";
                    }
                }
            }
        }

        protected void gvProductDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
            // get the values for delete operation

            GridView gvTemp = (GridView)sender;
            int index = e.RowIndex;
            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];

            if (listProduct != null && index >= 0)
            {
                // get IssuedQty
                int IssuedQty = listProduct[index].IssuedQty;

                // get MaterialTransID
                long TransID = listProduct[index].ProductID;

                // restore the quantity in the datatable
                DataTable dtProductDetail = InitMaterialList();

                // Finds the row specified in txtUnit
                DataRow dr = dtProductDetail.Rows.Find(TransID);
                int intRowIndex = dtProductDetail.Rows.IndexOf(dr);
                // decimal BalcQty = Convert.ToDecimal(dtProductDetail.Rows[intRowIndex]["BalancedQty"].ToString() == "" ? "0" : dtProductDetail.Rows[intRowIndex]["BalancedQty"].ToString());

                // modify certain values into the DataTable
                // dtProductDetail.Rows[intRowIndex]["BalancedQty"] = BalcQty + Convert.ToDecimal(IssuedQty);
                dtProductDetail.AcceptChanges();

                // remove row for the index
                listProduct.RemoveAt(index);

                if (listProduct.Count > 0)
                    ddlProductType.Enabled = false;
                else
                    ddlProductType.Enabled = true;
                Session["IssuedProductList"] = listProduct;
                gvProductDetail.DataSource = listProduct;
                gvProductDetail.DataBind();
                if (listProduct.Count == 0)
                    Session["IssuedProductList"] = null;

                //ClientScript.RegisterClientScriptBlock(GetType(), "Javascript","<script>alert('Record Added Successfully')</script>");
                //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertUser", "UpdateFooter(" + IssuedQty + ", " + TransID + ");", true);

            }

            }
                catch (Exception  ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);

                lblError.Text="Error While Delete Product : " +ex.Message ;  
                

            }
        }

        private Product GetProductIssuesDetail()
        {
            Product objProductCommon = new Product();
            try
            {
                if (Session["IssuedProductList"] != null) 
                {
                    IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
                    objProductCommon.xmlSalesTransactionDetail = XMLConverter.PurchaseOrderListToXML((List<Product>)Session["IssuedProductList"]).ToString();
                   

                }
                
            }
            catch (Exception ex)
            {
                objProductCommon = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objProductCommon;
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    if (Session["IssuedProductList"] != null)
                    {
                        Product ProductSales = GetProductIssuesDetail();
                        //Random random = new Random();
                        //ProductSales.SaleOrderNumber = random.Next(10000000, 100000000).ToString();// Next(13287, 21439); 
                        PartBO PurBO = new PartBO();

                            ProductSales.IsActive = true;


                        ProductSales.AddedBy = LoginToken.LoginId;
                        ProductSales.CompanyID = (Int16)LoginToken.CompanyID;
                        ProductSales.FinancialYearID = (Int16)LoginToken.FinancialYearID;

                        ProductSales.ActionType = EnumActionType.Insert;
                        ProductSales.Remark = txtRemarks.Text;
                        ProductSales.GroupType = Convert.ToInt32((ddlProductType.SelectedIndex > 0 ? ddlProductType.SelectedValue.ToString() : "0"));

                        string result = PurBO.UpdatePurchaseOrderDetail(ProductSales);
                        if (result != "")
                        {
                            lblError.Text = ExceptionMessage.GetMessage("OP7000001");
                            txtPUROrderDate.Text = System.DateTime.Now.ToString("yyyy-MM-dd");
                            txtOrderTime.Text = System.DateTime.Now.ToShortTimeString();
                            txtPUROrderNumber.Text = result;
                            Session["IssuedProductList"] = null;
                            Session["dsMaterialDetail"] = null;
                            Session["ProductDetail"] = null;
                            btnsave.Enabled = false;
                            lblError.Text = "Data saved successfully.";
                            ClearAll();
                        }
                        else
                        {
                            lblError.Text = ExceptionMessage.GetMessage("OP700000");
                        }
                    }
                    else
                    {
                        lblError.Text = "There are nothing to save, so please add the Information first.";
                    }
                }

                lblError.Visible = true;
            }
            catch (Exception ex)
            {
                Session["IssuedProductList"] = null;
                Session["dsMaterialDetail"] = null;
                Session["ProductDetail"] = null;

                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "@message");
                LogManager.WriteErrorLogInDB(ex);                
                lblError.Visible = true;
                lblError.Text = ExceptionMessage.GetMessage("OP700000");
            }
        }

        protected void ClearAll()
        {
            Session["IssuedProductList"] = null;
            Session["dsMaterialDetail"] = null;
            Session["ProductDetail"] = null;
            gvProductDetail.DataSource = null;
            gvProductDetail.DataBind();
            ddlProductType.Enabled = true;

            txtModeNumber.Text = "";
            txtProductName.Text = "";
            txtQuantity.Text = "";
            txtAvailable.Text = "";
          //  txtUnit.Text = "";
            txtColor.Text = "";
            btnAddMaterial.Enabled = false;
          
            gvProductSearch.DataSource = null;
            gvProductSearch.DataBind();
            gvProductSearch.Visible = false;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ClearAll();
            ddlProductType.SelectedIndex = 0;
            btnsave.Enabled = true;
            txtProductID.Text = "";
            lblError.Text = "";
            txtRemarks.Text = "";
        }

        protected void gvProductSearch_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "ShowProductDetails")
            {

                int id = Convert.ToInt32(e.CommandArgument.ToString());
                //btnAddMaterial.Enabled = true;
                GridViewRow gr = gvProductSearch.Rows[id];

                LinkButton lnk = (LinkButton)gr.Cells[1].FindControl("lnkProductID");
                //txtRate.Text = "";
                //txtEquivalentUnit.Text = "";

                txtProductID.Text = lnk.Text;
                txtProductName.Text = gr.Cells[4].Text.ToString();
                txtColor.Text = gr.Cells[3].Text;
                txtModeNumber.Text = gr.Cells[2].Text;
                
                Product objUnitProduct = new Product();

                objUnitProduct.ProductID = Convert.ToInt32(lnk.Text);
             
             
             
                List<Product> lstUnitProduct = new List<Product>();
                ProductUnitPriceBO objUnitPriceBO = new ProductUnitPriceBO();
                btnAddMaterial.Enabled = true;
                objUnitProduct.IsActive = true;
                lstUnitProduct = objUnitPriceBO.SearchProductUnitList(objUnitProduct);
                ddlUnit.Items.Clear();

                ddlUnit.DataSource = lstUnitProduct;

                ddlUnit.DataTextField = "UnitName";
                ddlUnit.DataValueField = "ProductPriceID";

                ddlUnit.DataBind();
                ddlUnit.Items.Insert(0, new ListItem("--Select--", "0"));


                txtAvailable.Text = gr.Cells[5].Text;
               
            }

        }

        protected void gvProductSearch_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }


        }

        protected void gvProductDetail_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

      

        

    }
}