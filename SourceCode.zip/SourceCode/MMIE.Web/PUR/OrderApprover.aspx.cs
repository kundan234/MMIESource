﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Data.PUR;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.PUR
{
    public partial class OrderApprover : BasePage
    {
        protected void PagePermission()
        {
            if (LoginToken != null)
            {


                txtEndDate.Enabled = LoginToken.IsChangeDateOn;
                txtStartDate.Enabled = LoginToken.IsChangeDateOn;
                btnSubmit.Enabled = LoginToken.IsApproverRecievedOn;
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            txtStartDate.Attributes.Add("ReadOnly", "True");
            txtEndDate.Attributes.Add("ReadOnly", "True");
            //grdVehicalOrder.HeaderRow.Cells[5].Text
            PagePermission();

            if (!IsPostBack)
            {

                MasterLookupBO mstlookup = new MasterLookupBO();
                BindDropDownControl(ddlOrderType, mstlookup.GetLookupsList(LookupNames.Group));
                ddlOrderType.Items.Insert(0, "--Select--");
            }
        }



        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "ItemId";
            objDD.DataTextField = "ItemName";
            objDD.DataBind();
        }
        protected void btnSearchOrder_Click(object sender, EventArgs e)
        {

            BindPurchaseOrderDetail();


        }

        private void BindPurchaseOrderDetail()
        {
            try
            {


                ProductPurchaseOrderBO objPODetailBO = new ProductPurchaseOrderBO();
                List<ProductPurchaseOrder> lstDetails = new List<ProductPurchaseOrder>();
                if (txtOrderNo.Text == "")
                {
                    int ordertype = int.Parse(ddlOrderType.SelectedValue.ToString());
                    DateTime FromDate = Convert.ToDateTime(txtStartDate.Text);
                    DateTime ToDate = Convert.ToDateTime(txtEndDate.Text);
                    string Status = ddlStatusType.SelectedValue.ToString();
                    lstDetails = objPODetailBO.SearchProductPurchageOrderDetail(ordertype, txtStartDate.Text, txtEndDate.Text, LoginToken.CompanyID, Status);
                    ViewState["Saved"] = null;
                }
                else
                {
                    lstDetails = objPODetailBO.SearchProductPurchageOrderDetail(txtOrderNo.Text);
                }
                grdVehicalOrder.DataSource = lstDetails;
                grdVehicalOrder.DataBind();


            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching Order Records : " + Ex.Message;
            }


        }



        protected void chkIsPending_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow row = (sender as CheckBox).Parent.Parent as GridViewRow;
            CheckBox IsActive = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[9].FindControl("chkIsApproved");
            CheckBox IsPending = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[8].FindControl("chkIsPending");
            CheckBox IsRejected = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[10].FindControl("chkIsRejected");
            IsActive.Checked = false;
            IsPending.Checked = true;
            IsRejected.Checked = false;






        }

        protected void chkIsApproved_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow row = (sender as CheckBox).Parent.Parent as GridViewRow;
            CheckBox IsApproved = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[9].FindControl("chkIsApproved");
            CheckBox IsPending = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[8].FindControl("chkIsPending");
            CheckBox IsRejected = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[10].FindControl("chkIsRejected");
            IsApproved.Checked = true;
            IsPending.Checked = false;
            IsRejected.Checked = false;






        }
        protected void chkIsRejected_CheckedChanged(object sender, EventArgs e)
        {

            GridViewRow row = (sender as CheckBox).Parent.Parent as GridViewRow;
            CheckBox IsActive = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[9].FindControl("chkIsApproved");
            CheckBox IsPending = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[8].FindControl("chkIsPending");
            CheckBox IsRejected = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[10].FindControl("chkIsRejected");
            IsActive.Checked = false;
            IsPending.Checked = false;
            IsRejected.Checked = true;






        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SaveData();
        }

        private void SaveData()
        {
            try
            {
                int i;
                List<ProductPurchaseOrder> lstOrder = new List<ProductPurchaseOrder>();

                for (i = 0; i < grdVehicalOrder.Rows.Count; i++)
                {
                    GridViewRow row = grdVehicalOrder.Rows[i];
                    CheckBox IsApproved = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[8].FindControl("chkIsApproved");
                    CheckBox IsPending = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[7].FindControl("chkIsPending");
                    CheckBox IsRejected = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[9].FindControl("chkIsRejected");
                    TextBox Details = (TextBox)grdVehicalOrder.Rows[row.RowIndex].Cells[10].FindControl("txtDetails");
                    TextBox ApprovedQty = (TextBox)grdVehicalOrder.Rows[row.RowIndex].Cells[11].FindControl("txtApprovedQty");
                    Label ID = (Label)grdVehicalOrder.Rows[row.RowIndex].Cells[12].FindControl("lblID");
                    CheckBox IsActive = (CheckBox)grdVehicalOrder.Rows[row.RowIndex].Cells[8].FindControl("IsActive");
                    ProductPurchaseOrder order = new ProductPurchaseOrder();
                    order.IsActive = IsActive.Checked;
                    
                    order.ID = Convert.ToInt32(ID.Text);
                    order.IsApproved = IsApproved.Checked;
                    order.IsPending = IsPending.Checked;
                    order.IsRejected = IsRejected.Checked;
                    order.CompanyID = LoginToken.CompanyID;
                    order.FinancialYearID = LoginToken.FinancialYearID;
                    order.LastModBy = LoginToken.LoginId;
                    if (ApprovedQty.Text != "")
                        order.ApprovedQty = Convert.ToInt32(ApprovedQty.Text);
                    else
                        order.ApprovedQty = 0;
                    order.Details = Details.Text;
                    lstOrder.Add(order);

                }

                ProductPurchaseOrderBO objOrderDetailsBO = new ProductPurchaseOrderBO();
                if (objOrderDetailsBO.SaveOrderDetailUpdate(lstOrder))
                {
                    lblError.Text = "Updated Successfully";
                    ViewState["Saved"] = true;
                    grdVehicalOrder.DataSource = null;
                    grdVehicalOrder.DataBind();


                }
            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Updating Error " + Ex.Message;
            }


        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtEndDate.Text = "";
            txtStartDate.Text = "";
            ddlOrderType.SelectedIndex = 0;
            lblError.Text = "";
            txtOrderNo.Text = "";
            grdVehicalOrder.DataSource = null;

            lblGridMessage.Text = "";
            grdVehicalOrder.DataBind();
        }

        protected void grdVehicalOrder_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            //string msg = "All Changes Made will be saved";
            //string script = "<script language=\"javascript\">";
            //script += "alert('" + msg + "');";
            //script += "</script>";
            //this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "grdVehicalOrder", script);
            //if (ViewState["Saved"]==null)
            //{
            //    if (!(bool)ViewState["Saved"])
            //    {
            //        e.Cancel = true;
            SaveData();
            lblGridMessage.Text = "Your Previous Changes Saved";
            lblGridMessage.Visible = true;
            //    }

            //}
            //else
            //{
            lblError.Text = "";
            grdVehicalOrder.PageIndex = e.NewPageIndex;
            BindPurchaseOrderDetail();

            //}

            //  SaveData();



        }

        protected void grdVehicalOrder_PageIndexChanged(object sender, EventArgs e)
        {

        }
    }
}