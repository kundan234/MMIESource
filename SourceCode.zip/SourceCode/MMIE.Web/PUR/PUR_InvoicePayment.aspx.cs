﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.ACC;
using MMIE.Data.ACC;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Web;
using MMIE.Data.Common;

namespace MMIE.PUR
{
    public partial class PUR_InvoicePayment : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}