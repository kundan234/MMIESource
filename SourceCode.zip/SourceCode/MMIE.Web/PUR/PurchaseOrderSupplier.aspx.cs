﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.BusinessProcess.ADM;
using MMIE.BusinessProcess.Common;
using MMIE.Data;

using MMIE.Data.Common;
using MMIE.BusinessProcess.PUR;
using MMIE.Data.PUR;
using MMIE.Common.Util;
using MMIE.Web;


namespace MMIE.PUR
{
    public partial class PurchaseOrderSupplier : BasePage
    {
        int num = 0;

        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                 
                btnPrint.Enabled = LoginToken.IsPrintOn;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            PagePermission();
           
            try
            {
                if (!IsPostBack)
                {    

                }
               

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemname";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
        }

        //protected void txtCustomer_TextChanged(object sender, EventArgs e)
        //{
        //    string GetCustomerId = txtCustomer.Text;

        //    try
        //    {

        //        string[] SplitGetCustomerId = GetCustomerId.Split('-');
        //        int i = 0;
        //        foreach (string word in SplitGetCustomerId)
        //        {
        //            i = i + 1;

        //            if (i == 1)
        //            {
        //                SearchCustomerID = Convert.ToInt32(word);
        //                BindCustomerDetail(SearchCustomerID);


        //            }
        //        }
        //    }
        //    catch
        //    {
        //        txtCustomer.Text = "";
        //    }

        //}

        //private void BindCustomerDetail(int custid)
        //{
        //    CustomerBO useradm = new CustomerBO();
        //    Customer objCustomer = new Customer();
        //    objCustomer.CustomerID = custid;
        //    hdnSupplierID.Value = Convert.ToString(custid);
        //    Customer objRetCustomer = useradm.GetCustomerByID(objCustomer);
        //    if (objRetCustomer != null)
        //    {
        //        txtCustomer.Text = objRetCustomer.CustomerName.Trim();
        //        //hdnCustID.Value = Convert.ToString(objRetCustomer.CustomerID);
               
             
        //    }

        //}

        protected void btnSearchOrder_Click(object sender, EventArgs e)
        {
            ProductPurchaseOrderBO objPurchaseOrder = new ProductPurchaseOrderBO();
            InvoiceHeaderDetails objOrder = new InvoiceHeaderDetails();
            objOrder = objPurchaseOrder.GetProductPurchaseOrderDetailByID((int.TryParse(txtPoSearch.Text, out num) ? num : 0));
            if (objOrder != null)
            {
                BindCustomerDetail(objOrder.SupplierID);
            }
            BindPurchaseOrderDetail();
            if (txtCustomer.Text != "")
            {
                btnPrint.Enabled = true;
            }
            else
            {
                btnPrint.Enabled = false;
            }
        }

        private void BindPurchaseOrderDetail()
        {
            try
            {


                ProductPurchaseOrderBO objPODetailBO = new ProductPurchaseOrderBO();
                List<ProductPurchaseOrder> lstDetails = new List<ProductPurchaseOrder>();
                if (txtPoSearch.Text!="")
                {

                    lstDetails = objPODetailBO.SearchProductPurchageOrderDetail(txtPoSearch.Text);
                    grdVehicalOrder.DataSource = lstDetails;
                    grdVehicalOrder.DataBind();
                }
               


            }
            catch (Exception Ex)
            {

                lblError.Text = "Error While Fetching Order Records : " + Ex.Message;
            }


        }

        protected void txtCustomer_TextChanged(object sender, EventArgs e)
        {

            int SearchCustomerID = 0;

            try
            {
                string GetCustomerId = txtCustomer.Text;
                string[] SplitGetCustomerId = GetCustomerId.Split('-');

                int i = 0;

                foreach (string word in SplitGetCustomerId)
                {
                    i = i + 1;

                    if (i == 1)
                    {
                        SearchCustomerID = Convert.ToInt32(word);
                        BindCustomerDetail(SearchCustomerID);
                       

                    }
                }
            }

            catch
            {
                txtCustomer.Text = "";
            }
        }

        private void BindCustomerDetail(int custid)
        {
            CustomerBO useradm = new CustomerBO();
            Customer objCustomer = new Customer();
            objCustomer.CustomerID = custid;
            ViewState["CustomerID"] = custid;
            Customer objRetCustomer = useradm.GetCustomerByID(objCustomer);
            if (objRetCustomer != null)
            {
                txtCustomer.Text = objRetCustomer.CustomerName;
                txtAddress.Text = objRetCustomer.CustomerAddress;
                txtStreet.Text = objRetCustomer.CustomerStreet;
                txtCity.Text = objRetCustomer.CityName;
              
                txtCountry.Text = objRetCustomer.CountryName;
                txtCellNo.Text = objRetCustomer.CustomerMobile;
                txtPhone.Text = objRetCustomer.CustomerPhone;
                txtFaxNo.Text = objRetCustomer.CustomerFax;
                txtEmail.Text = objRetCustomer.CustomerEmail;
                txtWebsite.Text = objRetCustomer.CustomerWebsite;
                ViewState["CustomerName"] = objRetCustomer.CustomerName;
               
            }

        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {
            Product ProductSales = new Product();
            PartBO PurBO = new PartBO();
           
         
           if (ViewState["CustomerName"] != null && txtCustomer.Text!="")
           {
               ProductSales.CustomerID = Convert.ToInt32(ViewState["CustomerID"]);
               ProductSales.SaleOrderNumber = txtPoSearch.Text;
               string msg = PurBO.UpdateOrderToSupplier(ProductSales);
               if (msg != "")
               {
                   lblError.Text = "Supplier Updated Successfully.";
                   lblError.Visible = true;                 
               }
           }
           else
           {
               lblError.Text = "Please Select A valid Customer";
               lblError.Visible = true;    
               return;
           }


        }

    }
}