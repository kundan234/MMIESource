﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MMIE.Web;
using System.Data;
using System.Data.SqlClient;
using MMIE.BusinessProcess.Common;
using MMIE.Data.Common;
using MMIE.BusinessProcess.PUR;
using System.Configuration;
using MMIE.Common.Util;
using System.Web.UI.HtmlControls;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.Data.PUR;
using System.Text;
namespace MMIE.PUR
{
    public partial class PurchaseOrderRecieving : BasePage
    {
        bool Flag;
        bool status;
        int num = 0;        
        StringBuilder XMLPartList = new StringBuilder();
        protected void PagePermission()
        {
            if (LoginToken != null)
            {
                btnSave.Enabled = LoginToken.IsAddOn;
                btnAddOtherCharges.Enabled = LoginToken.IsAddOn;
                btnAddMaterial.Enabled = LoginToken.IsAddOn;
            }
        }

        #region Bind Masters
        protected void BindOtherCharges()
        {
            List<OtherCharges> lstOtherCharges = new List<OtherCharges>();
            OtherChargesBO objOChargesBO = new OtherChargesBO();
            OtherCharges objOCharges = new OtherCharges();
            objOCharges.IsActive = true;
            lstOtherCharges = objOChargesBO.GetSearchOtherCharges(objOCharges);
            ddlOtherChargeID.DataSource = lstOtherCharges;
            ddlOtherChargeID.DataTextField = "ChargeName";
            ddlOtherChargeID.DataValueField = "ChargeID";
            ddlOtherChargeID.DataBind();
            ddlOtherChargeID.Items.Insert(0, new ListItem("--Select Charges--", "0"));
            ddlOtherChargeID.SelectedIndex = 0;
        }
        private void BindDropDownControl(DropDownList objDD, List<LookupItem> lstLookups)
        {
            objDD.DataSource = lstLookups;
            objDD.DataValueField = "itemid";
            objDD.DataTextField = "itemname";
            objDD.DataBind();
        }
        protected void BindCurrencyDropDown()
        {
            try
            {
                CurrencyBO objCurrencyBO = new CurrencyBO();
                List<Currency> lstCurrency = new List<Currency>();
                lstCurrency = objCurrencyBO.GetCurrencyList(false);
                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataTextField = "ConvertTO";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select Currency--", "0"));
                ddlCurrency.SelectedIndex = 0;
            }
            catch (Exception ex)
            {

                lblError.Text = "Error : " + ex.Message;
            }

        }
        #endregion

        #region Run time Other Charges
        private void AddNewTable()
        {
            Session["OtherCharges"] = null;
            Table t = new Table();
            t.Style.Add(HtmlTextWriterStyle.Width, "100%");
            t.Rows.Clear();
            t.BorderStyle = BorderStyle.Solid;

            TableHeaderRow th = new TableHeaderRow();
            th.BorderStyle = BorderStyle.Solid;
            TableCell c1 = new TableCell();
            c1.Text = "S.No.";
            c1.Style.Add(HtmlTextWriterStyle.Width, "1%");

            TableCell c2 = new TableCell();
            c2.Text = "Other Charges";
            c2.Style.Add(HtmlTextWriterStyle.Width, "15%");

            TableCell c3 = new TableCell();
            c3.Text = "Charges Amount";
            c3.Style.Add(HtmlTextWriterStyle.Width, "5%");
            c3.Style.Add(HtmlTextWriterStyle.TextAlign, "Center");
            th.Cells.Add(c1);
            th.Cells.Add(c2);
            th.Cells.Add(c3);
            Style myStyle = new Style();
            myStyle.ForeColor = System.Drawing.Color.Black;
            myStyle.BackColor = System.Drawing.Color.LightGray;
            myStyle.Font.Bold = true;
            myStyle.BorderStyle = BorderStyle.Solid;
            th.ApplyStyle(myStyle);
            // th.Font.Size =Unit.Percentage(12);
            th.BorderStyle = BorderStyle.Solid;
            th.BorderWidth = Unit.Pixel(1);

            t.Rows.Add(th);

            Session["OtherCharges"] = t;
        }
        private int ExpBoxID
        {
            get
            {
                var count = ViewState["txtExpBoxID"];
                return (count == null) ? 0 : (int)count;
            }
            set { ViewState["txtExpBoxID"] = value; }
        }


        void AddOtherCharges()
        {

            OtherChargesBO objBO = new OtherChargesBO();
            OtherCharges objCharges = new OtherCharges();
            objCharges.ChargeID = Convert.ToInt32(ddlOtherChargeID.SelectedValue.ToString());
            OtherCharges objChargesRet = new OtherCharges();
            objChargesRet = objBO.GetOtherChargeByID(objCharges);
            if (objChargesRet != null)
            {
                List<OtherCharges> lstOtherCharges = Session["lstOtherCharges"] == null ? new List<OtherCharges>() : (List<OtherCharges>)Session["lstOtherCharges"];
                decimal Amount = (objChargesRet.ChargeRate / Convert.ToDecimal(txtInvoiceCurrency.Text != "" ? txtInvoiceCurrency.Text : "1"));
                objChargesRet.CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());
                objChargesRet.CurrencyRate = Convert.ToDecimal(txtInvoiceCurrency.Text);
                objChargesRet.ChargeRate = Amount;
                txtTotalOtherCharges.Text = (Convert.ToDecimal(txtTotalOtherCharges.Text == "" ? "0" : txtTotalOtherCharges.Text) + Amount).ToString("0.00");
                lstOtherCharges.Add(objChargesRet);
                grdTotalCharges.DataSource = lstOtherCharges;
                grdTotalCharges.DataBind();
                Session["lstOtherCharges"] = lstOtherCharges;
                if (lstOtherCharges.Count > 0)
                    ddlCurrency.Enabled = false;
                else ddlCurrency.Enabled = true;


            }
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    ClearAll();
                    txtPurchaseNumber.Text = "";
                    MasterLookupBO mstlookup = new MasterLookupBO();
                    BindDropDownControl(drCompanyBranch, mstlookup.GetLookupsList(LookupNames.Company));
                    BindDropDownControl(ddlStoreType, mstlookup.GetLookupsList(LookupNames.StoreName));
                    ddlStoreType.Items.Insert(0, "Select Store/Depot");
                    BindDropDownControl(ddlOrderGroup, mstlookup.GetLookupsList(LookupNames.Group));
                    ddlOrderGroup.Items.Insert(0, "Select Group");
                    BindCurrencyDropDown();
                    BindOtherCharges();
                    AddNewTable();
                    PagePermission();
                    ddlStoreType.SelectedIndex = 0;
                    txtPurchaseNumber.Text = "";
                    ddlCurrency.SelectedIndex = 0;
                    Session["lstOtherCharges"] = null;
                    ViewState["CustomerID"] = null;
                    ViewState["InvoiceHeaderID"] = null;
                    Session["IssuedProductList"] = null;

                }

            }
            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtInvoiceNo.Text != "" && ViewState["CustomerID"] != null)
                {
                    PartBO useradm = new PartBO();
                    Customer objCustomer = new Customer();
                    StringBuilder XMLVehicalList = new StringBuilder();

                    if (grdOrderDetails.Rows.Count < 1)
                    {
                        lblError.Text = "No Product is added to receive";
                        return;
                    }

                    #region Upload ExcelSheet

                    if (ddlOrderGroup.SelectedValue == "1")
                    {
                        if (PartListExceUpload.HasFile)
                        {

                            string AccessFilename = PartListExceUpload.FileName.ToString();
                            string UploadFilestring = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "UploadedExcelFiles\\" + AccessFilename;
                            PartListExceUpload.SaveAs(UploadFilestring);
                            #region Retriving Invoice Details
                            //// This below function used to get all the sheet name from the excel sheet....
                            //// and insert all sheet record into the database table...
                            #endregion
                            string[] excelSheetsName = ExcelConverter.GetExcelSheetNames(UploadFilestring);
                            // Loop through all of the sheets if you want too...
                            try
                            {
                                #region Retrieving Vechical List Working Fine hidden for testing


                                // Loop through all of the sheets if you want too...
                                if (excelSheetsName != null)
                                {
                                    for (int j = 0; j < excelSheetsName.Length; j++)
                                    {
                                        if (excelSheetsName[j].Length <= 5)
                                        {
                                            //Retriving Order Parts Details   
                                            DataTable objdtorderPart = null;
                                            objdtorderPart = ExcelConverter.ReadFromExcel(UploadFilestring, excelSheetsName[j].Replace("'", "").Replace("$", "").ToString(), "VehicleOrder");
                                            if (objdtorderPart != null)
                                            {

                                                //Deleting extra rows in the datatable
                                                int Increments = 3;
                                                for (int i = 0; i < Increments; i++)
                                                {
                                                    DataRow rowDel;
                                                    rowDel = objdtorderPart.Rows[i];
                                                    objdtorderPart.Rows.Remove(rowDel);
                                                }
                                                //Deleting extra rows in the datatable
                                                Increments = 1;
                                                for (int i = 0; i < Increments; i++)
                                                {
                                                    DataRow rowDel;
                                                    rowDel = objdtorderPart.Rows[i];
                                                    objdtorderPart.Rows.Remove(rowDel);
                                                }
                                                //Deleting extra rows in the datatable
                                                Increments = 1;
                                                for (int i = 0; i < Increments; i++)
                                                {
                                                    DataRow rowDel;
                                                    rowDel = objdtorderPart.Rows[i];
                                                    objdtorderPart.Rows.Remove(rowDel);
                                                }

                                                #region Creating Vehical List XML


                                                if (objdtorderPart.Columns.Count < 9)
                                                {
                                                    lblError.Text = "Sheet : " + excelSheetsName[j].ToString() + " Containing invalid data format please check and try again...!";
                                                    return;
                                                }

                                                foreach (DataRow grRow in objdtorderPart.Rows)
                                                {
                                                    int ProductId;
                                                    if (int.TryParse(grRow.ItemArray[1].ToString(), out ProductId))
                                                    {

                                                        XMLVehicalList.Append("<ItemList ProductID = \"" + grRow.ItemArray[1].ToString() + "\"");
                                                        XMLVehicalList.Append(" ModelNo = \" " + grRow.ItemArray[3].ToString() + "\"");
                                                        XMLVehicalList.Append(" VinNo = \" " + grRow.ItemArray[4].ToString() + "\"");
                                                        XMLVehicalList.Append(" EngineNo = \" " + grRow.ItemArray[5].ToString() + grRow.ItemArray[6].ToString() + "\"");
                                                        XMLVehicalList.Append(" ContainerNo = \" " + grRow.ItemArray[8].ToString() + "\"");
                                                        XMLVehicalList.Append(" />");
                                                        Flag = true;
                                                    }
                                                    else
                                                    {
                                                        Flag = false;
                                                        lblError.Text = "Sheet : " + excelSheetsName[j].ToString() + " Containing invalid data format please check and try again...!";
                                                        return;
                                                    }

                                                }
                                                #endregion

                                            }




                                        }

                                    }

                                }

                                #endregion
                            }
                            catch
                            {
                                lblError.Text = "Please Select A a valid Upload Sheet and Try Again...! ";
                                Flag = false;
                            }
                        }
                        else
                        {
                            lblError.Text = "Please Select A a valid Upload Sheet and Try Again...! ";
                        }

                    }
                    else if (ddlOrderGroup.SelectedValue == "2")
                    {
                        // Part/ Product Vehical Uploading form sheet

                        try
                        {

                            Flag = true;
                        }
                        catch
                        {
                            lblError.Text = "Error While Uploading the Part excel sheet";
                            Flag = false;
                        }

                    }


                    #endregion

                    if (!Flag)
                    {
                        lblError.Text = "Please Select A a valid Upload Sheet and Try Again...! ";
                        return;
                    }

                    if (Flag == true)
                    {

                        #region Calulate Other charges
                        StringBuilder XMLCharges = new StringBuilder("");
                        string strAmountValue = string.Empty;
                        string strDescValue = string.Empty;
                        string strID = string.Empty;
                        decimal totalothercharges = 0;
                        List<OtherCharges> lstOtherCharges = Session["lstOtherCharges"] == null ? new List<OtherCharges>() : (List<OtherCharges>)Session["lstOtherCharges"];
                        foreach (OtherCharges objOT in lstOtherCharges)
                        {
                            //strDescValue += objOT.ChargeName + ",";
                            //strID += objOT.ChargeID.ToString() + ",";
                            totalothercharges = totalothercharges + objOT.ChargeRate;
                            XMLCharges.Append("<OtherCharges ChargeID = \"" + objOT.ChargeID.ToString() + "\"");
                            XMLCharges.Append(" ChargeRate = \"" + objOT.ChargeRate.ToString() + "\"");
                            XMLCharges.Append(" ChargeName = \"" + objOT.ChargeName.ToString() + "\"");
                            XMLCharges.Append(" CurrencyID = \"" + objOT.CurrencyID.ToString() + "\"");
                            XMLCharges.Append(" CurrencyRate = \"" + objOT.CurrencyRate.ToString() + "\"");
                            XMLCharges.Append(" />");
                        }

                        #endregion

                        status = false;
                        #region Save invoice Header data
                        InvoiceHeaderDetails objInvoiceHeader = new InvoiceHeaderDetails();
                        objInvoiceHeader.InvoiceNo = txtInvoiceNo.Text.Trim();
                        objInvoiceHeader.XMLCharges = XMLCharges.ToString();
                        objInvoiceHeader.XMLData = CreateVehicalRecievingXML();
                        objInvoiceHeader.XMLItems = XMLVehicalList.ToString();

                        //   objLoginToken.LoginId = LoginToken.LoginId;
                        objInvoiceHeader.CompanyID = Convert.ToInt16(drCompanyBranch.SelectedValue);//Convert.ToInt16(LoginToken.CompanyID);
                        if (ViewState["InvoiceHeaderID"] != null)
                        {
                            objInvoiceHeader.ActionType = EnumActionType.Update;
                            objInvoiceHeader.LastModBy = LoginToken.LoginId;
                            objInvoiceHeader.InvoiceHeaderID = (int)ViewState["InvoiceHeaderID"];
                        }
                        else
                        {
                            objInvoiceHeader.ActionType = EnumActionType.Insert;
                            objInvoiceHeader.AddedBy = LoginToken.LoginId;
                            objInvoiceHeader.InvoiceHeaderID = 0;
                        }
                        //  objInvoiceHeader.Amount = 0; //txtAddGourdes.Text.Trim();
                        objInvoiceHeader.Remarks = strDescValue; //txtDesc.Text.Trim();
                        objInvoiceHeader.SupplierID = Convert.ToInt32(ViewState["CustomerID"] == null ? 0 : ViewState["CustomerID"]);
                        objInvoiceHeader.TotalInvoiceAmount = Convert.ToDecimal(lblTotalAmount.Text);
                        objInvoiceHeader.GroupType = Convert.ToInt32(ddlOrderGroup.SelectedValue.ToString());
                        objInvoiceHeader.TotalOtherCharges = totalothercharges;
                        objInvoiceHeader.TotalInsurance = Convert.ToDecimal(txtInsrance.Text);
                        objInvoiceHeader.TotalFrieght = Convert.ToDecimal(txtFright.Text);
                        objInvoiceHeader.TotalCostPrice = Convert.ToDecimal(txtCostPrice.Text);
                        decimal TotalExpenses = (totalothercharges + objInvoiceHeader.TotalInsurance + objInvoiceHeader.TotalFrieght);
                        objInvoiceHeader.OtherChargeID = strID;
                        objInvoiceHeader.OtherChargeDesc = strDescValue;
                        objInvoiceHeader.StoreID = Convert.ToInt32(ddlStoreType.SelectedValue.ToString());
                        objInvoiceHeader.ShipmentNumber = txtShipment.Text + "," + lblShipmentNo.Text;
                        objInvoiceHeader.ContainerNumber = txtContainerNo.Text + "," + lblContainerNo.Text;
                        objInvoiceHeader.CurrencyID = Convert.ToInt32(ddlCurrency.SelectedIndex > 0 ? ddlCurrency.SelectedValue.ToString() : "0");
                        objInvoiceHeader.CurrencyRate = Convert.ToDecimal(txtInvoiceCurrency.Text);
                        objInvoiceHeader.InvoiceDueDate = Convert.ToDateTime(txtDuedate.Text);
                        objInvoiceHeader.TotalQty = ViewState["TotalRecievedQty"] == null ? 1 : Convert.ToInt32(ViewState["TotalRecievedQty"]);
                        objInvoiceHeader.FinancialYearID = LoginToken.FinancialYearID;
                        objInvoiceHeader.PerUnitCharges = Convert.ToDecimal(txtChargeRate.Text != "" ? txtChargeRate.Text : "0"); //TotalExpenses / (ViewState["TotalRecievedQty"] == null ? 1 : Convert.ToInt32(ViewState["TotalRecievedQty"]));
                        objInvoiceHeader.PONumber = (int.TryParse(txtPurchaseNumber.Text, out num) ? num : 0);
                        InvoiceHeaderDetailsBO objInvoiceBO = new InvoiceHeaderDetailsBO();
                        status = objInvoiceBO.UpdateInvoiceHeaderDetails(objInvoiceHeader);
                        //   bool status = useradm.SavePurVehicleOtherCharges(objCustomer);
                        if (status == true)
                        {
                            lblError.Text = "Invoice Details updated successfully for Purchase Order No " + objInvoiceHeader.PONumber.ToString();
                            //COMITT
                            ClearAll();
                            txtPurchaseNumber.Text = "";
                            Session["lstOtherCharges"] = null;
                            ViewState["CustomerID"] = null;
                            ViewState["InvoiceHeaderID"] = null;
                            Session["IssuedProductList"] = null;

                        }

                        #endregion

                    }

                }


            }


            catch (Exception ex) //Exception in agent layer itself
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
                lblError.Text = ExceptionMessage.GetMessage(ex);
                lblError.Visible = true;
                Flag = false;
            }
        }

        protected void ClearAll()
        {

            AddNewTable();
            lblProductError.Text = "";
            ViewState["txtExpBoxID"] = 0;
            ViewState["TotalRecievedQty"] = null;
            ViewState["CustomerID"] = null;
            Session["IssuedProductList"] = null;
            Session["lstOtherCharges"] = null;
            txtCustomer.ReadOnly = false;
            txtInvoiceNo.Enabled = true;
            lblShipmentNo.Text = "";
            lblContainerNo.Text = "";
            txtTotalCharges.Text = "";
            txtChargeRate.Text = "";

            ddlCurrency.SelectedIndex = 0;
            ddlOrderGroup.SelectedIndex = 0;
            ddlStoreType.SelectedIndex = 0;
            txtAddress.Text = "";
            txtCellNo.Text = "";
            txtCity.Text = "";
            txtContainerNo.Text = "";
            txtCostPrice.Text = "";
            //    txtDate.Text = "";
            txtEmail.Text = "";
            txtFaxNo.Text = "";
            txtFright.Text = "";
            txtInsrance.Text = "";
            txtInvoiceNo.Text = "";
            txtPhone.Text = "";
            //  txtPONo.Text = "";
            txtStreet.Text = "";
            txtWebsite.Text = "";
            txtInvoiceCurrency.Text = "";
            grdOrderDetails.DataSource = null;
            grdOrderDetails.DataBind();
            grdPurchaseOrderDetails.DataSource = null;
            grdPurchaseOrderDetails.DataBind();
            grdTotalCharges.DataSource = null;
            grdTotalCharges.DataBind();
            txtFright.Text = "";
            txtCostPrice.Text = "";
            txtDuedate.Text = "";
            txtCustomer.Text = "";
            txtCountry.Text = "";
            txtPONumber.Text = "";
            txtShipment.Text = "";
            lblTotalAmount.Text = "";
            txtRemarks.Text = "";
            drCompanyBranch.SelectedIndex = 0;
            btnSave.Enabled = true;
            txtInvoiceNo.Enabled = true;
            ddlCurrency.Enabled = true;
            ddlOrderGroup.Enabled = true;
            btnAddOtherCharges.Enabled = true;
            txtTotalOtherCharges.Text = "";


            // reset all textboxes material List
            txtModeNumber.Text = "";
            txtProductName.Text = "";
            txtQuantity.Text = "";
            txtUnit.Text = "";
            txtColor.Text = "";
            txtPreviousAmount.Text = "";
            txtUnitPriceUSD.Text = "";
            txtTotalAmount.Text = "";

            RecievedQuantity.Text = "";
            txtProductID.Text = "";
            btnAddMaterial.Enabled = false;

            btnSave.Enabled = true;
            ddlUnit.Items.Clear();
            txtPONumber.Text = "";


        }


        protected string CreateVehicalRecievingXML()
        {
            StringBuilder objBuilder = new StringBuilder();

            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
            Product objProduct = new Product();

            int total = 0;

            try
            {
                if (listProduct != null)
                {

                    foreach (Product obj in listProduct)
                    {

                        objBuilder.Append("<PurchaseOrderRecievedlst InvoiceNo= \"" + txtInvoiceNo.Text + "\" ");
                        objBuilder.Append(" ProductID  = \"" + obj.ProductID.ToString() + "\" ");
                        objBuilder.Append(" Model = \"" + obj.Model.ToString() + "\" ");
                        objBuilder.Append(" Color = \"" + obj.Color.ToString() + "\" ");

                        objBuilder.Append(" UnitID = \"" + obj.UnitId.ToString() + "\" ");
                        objBuilder.Append(" UnitName = \"" + obj.UnitName.ToString() + "\" ");
                        objBuilder.Append(" Qty  = \"" + obj.IssuedQty.ToString() + "\" ");
                        objBuilder.Append(" RecievedQty  = \"" + obj.EquivalentUnit.ToString() + "\" ");
                        objBuilder.Append(" UnitPrice  = \"" + obj.UnitPriceUSD + "\" ");
                        objBuilder.Append(" TotalAmount  = \"" + obj.TotalAmount + "\" ");
                        objBuilder.Append(" PONumberID  = \"" + obj.PONumber + "\" ");

                        objBuilder.Append(" CostPrice  = \"" + (obj.UnitPriceUSD + (obj.UnitPriceUSD * Convert.ToDecimal(txtChargeRate.Text)) / 100).ToString() + "\" ");
                        objBuilder.Append(" PerUnitExpense  = \"" + txtChargeRate.Text + "\" ");
                        objBuilder.Append(" ContainerNo  = \"" + obj.ContainerNo + "\" ");

                        objBuilder.Append("/>");

                        total = total + Convert.ToInt32(obj.EquivalentUnit);

                    }

                }
                else
                {
                    objBuilder = null;

                }

                ViewState["TotalRecievedQty"] = total;

            }
            catch (Exception ex)
            {
                listProduct = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);

                lblError.Text = "Error While Creating XML :" + ex.Message;
            }

            //        total = total + txtRecievedQty.Text !=""?Convert.ToInt32(txtRecievedQty.Text):0; 
            //    }
            //}
            return objBuilder.ToString();

        }

        protected void btnAddOtherCharges_Click(object sender, EventArgs e)
        {
            //AddOtherCharges();
            OtherCharges objChargesRet = new OtherCharges();
            List<OtherCharges> lstOtherCharges = Session["lstOtherCharges"] == null ? new List<OtherCharges>() : (List<OtherCharges>)Session["lstOtherCharges"];
            //decimal Amount =(Convert.ToDecimal(txtTempOther.Text)*(Convert.ToDecimal(txtCostPrice.Text))/100) ;
            decimal Amount = Convert.ToDecimal(txtTempOther.Text);
            objChargesRet.CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue.ToString());
            objChargesRet.ChargeID = Convert.ToInt32(ddlOtherChargeID.SelectedValue.ToString());
            objChargesRet.ChargeName = ddlOtherChargeID.SelectedItem.Text;
            objChargesRet.CurrencyRate = Convert.ToDecimal(txtInvoiceCurrency.Text);
            objChargesRet.ChargeRate = Amount;
            txtTotalOtherCharges.Text = (Convert.ToDecimal(txtTotalOtherCharges.Text == "" ? "0" : txtTotalOtherCharges.Text) + Amount).ToString("0.00");
            txtTotalCharges.Text = (Convert.ToDecimal(txtTotalCharges.Text == "" ? "0" : txtTotalCharges.Text) + Amount).ToString("0.00");
            txtChargeRate.Text = ((Convert.ToDecimal(txtTotalCharges.Text == "" ? "0" : txtTotalCharges.Text) * 100) / (Convert.ToDecimal(txtCostPrice.Text.Trim() != "" ? txtCostPrice.Text : "1"))).ToString("0.00");

            lblTotalAmount.Text = (Convert.ToDecimal(txtCostPrice.Text == "" ? "0" : txtCostPrice.Text) + Convert.ToDecimal(txtFright.Text == "" ? "0" : txtFright.Text) + Convert.ToDecimal(txtInsrance.Text == "" ? "0" : txtInsrance.Text) + Convert.ToDecimal(txtPreviousAmount.Text == "" ? "0" : txtPreviousAmount.Text)).ToString();


            lstOtherCharges.Add(objChargesRet);

            grdTotalCharges.DataSource = lstOtherCharges;
            grdTotalCharges.DataBind();

            Session["lstOtherCharges"] = lstOtherCharges;
            if (lstOtherCharges.Count > 0)
                ddlCurrency.Enabled = false;
            else ddlCurrency.Enabled = true;
            ddlOtherChargeID.SelectedIndex = 0;
            txtTempOther.Text = "";
        }

        //protected void ddlPurchaseNumber_SelectedIndexChanged(object sender, EventArgs e)
        //{



        //}

        protected void ddlOrderGroup_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        #region Customer Details Binding
        protected void txtCustomer_TextChanged(object sender, EventArgs e)
        {

            int SearchCustomerID = 0;

            try
            {
                string GetCustomerId = txtCustomer.Text;
                string[] SplitGetCustomerId = GetCustomerId.Split('-');

                int i = 0;

                foreach (string word in SplitGetCustomerId)
                {
                    i = i + 1;

                    if (i == 1)
                    {
                        SearchCustomerID = Convert.ToInt32(word);
                        BindCustomerDetail(SearchCustomerID);
                        //BindCustomerDocumentDetail(SearchCustomerID);

                    }
                }
            }

            catch
            {
                txtCustomer.Text = "";
            }
        }

        private void BindCustomerDetail(int custid)
        {
            CustomerBO useradm = new CustomerBO();
            Customer objCustomer = new Customer();
            objCustomer.CustomerID = custid;
            ViewState["CustomerID"] = custid;
            Customer objRetCustomer = useradm.GetCustomerByID(objCustomer);
            if (objRetCustomer != null)
            {
                txtCustomer.Text = objRetCustomer.CustomerName;
                txtAddress.Text = objRetCustomer.CustomerAddress;
                txtStreet.Text = objRetCustomer.CustomerStreet;
                txtCity.Text = objRetCustomer.CityName;
                txtDuedate.Text = DateTime.Today.AddDays(objRetCustomer.MaximumDueDays).ToShortDateString();
                txtCountry.Text = objRetCustomer.CountryName;
                txtPhone.Text = objRetCustomer.CustomerPhone;
                txtEmail.Text = objRetCustomer.CustomerEmail;
                txtWebsite.Text = objRetCustomer.CustomerWebsite;
                txtCellNo.Text = objCustomer.CustomerMobile;
                txtFaxNo.Text = objCustomer.CustomerFax;

            }

        }




        #endregion

        #region Page Control Events


        protected void ddllCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                CurrencyBO objCurrencyBO = new CurrencyBO();
                Currency objCur = new Currency();

                if (ddlCurrency.SelectedIndex > 0)
                {
                    objCur = objCurrencyBO.GetCurrencyByID(Convert.ToInt32(ddlCurrency.SelectedValue.ToString()));

                    txtInvoiceCurrency.Text = objCur.Rate.ToString();
                }
                else
                {
                    lblError.Text = "Invalid Currency Selected";

                }
            }

            catch
            {
                lblError.Text = "Error While getting currency details";


            }
        }



        protected void grdPurchaseOrderDetails_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void grdPurchaseOrderDetails_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ShowDetails")
            {
                int id = Convert.ToInt32(e.CommandArgument.ToString());
                btnAddMaterial.Enabled = true;
                GridViewRow gr = grdPurchaseOrderDetails.Rows[id];
                LinkButton lnk = (LinkButton)gr.Cells[1].FindControl("lnkOrderNo");
                txtPONumber.Text = txtPurchaseNumber.Text;
                txtProductID.Text = gr.Cells[2].Text;
                txtProductName.Text = gr.Cells[3].Text.Replace("&#39;", "'");
                txtModeNumber.Text = gr.Cells[4].Text;
                txtColor.Text = gr.Cells[5].Text;
                //txtUnit.Text = gr.Cells[6].Text;
                txtQuantity.Text = gr.Cells[9].Text;
                //btnAddMaterial.Enabled = true;                   
                Product objUnitProduct = new Product();
                objUnitProduct.ProductID = Convert.ToInt32(gr.Cells[2].Text);
                List<Product> lstUnitProduct = new List<Product>();
                ProductUnitPriceBO objUnitPriceBO = new ProductUnitPriceBO();
                objUnitProduct.IsActive = true;
                lstUnitProduct = objUnitPriceBO.SearchProductUnitList(objUnitProduct);


                ddlUnit.DataSource = lstUnitProduct;

                ddlUnit.DataTextField = "UnitName";
                ddlUnit.DataValueField = "ProductPriceID";

                ddlUnit.DataBind();
                ddlUnit.Items.Insert(0, new ListItem("--Select--", "0"));



            }






        }

        protected void btnResetDetails_Click(object sender, EventArgs e)
        {
            txtPONumber.Text = "";
            txtProductID.Text = "";
            txtProductName.Text = "";
            txtModeNumber.Text = "";
            txtColor.Text = "";
            txtUnit.Text = "";
            txtQuantity.Text = "";
            //  txtInvoiceNumber.Text = "";
            RecievedQuantity.Text = "";

            // txtInovoiceNo.Text = "";
            //txtCosPrice.Text = "";
            lblProductError.Text = "";
            txtPONumber.Text = "";
            ddlUnit.Items.Clear();
        }

        protected void btnAddMaterial_Click(object sender, EventArgs e)
        {

            lblProductError.Text = "";
            IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
            List<Product> listProduct = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
            Product objProduct = new Product();
            foreach (Product mypr in listProduct)
            {
                if (mypr.ProductID == (Convert.ToInt32(txtProductID.Text.Trim() == "" ? "0" : txtProductID.Text.Trim())) && mypr.UnitId == (Convert.ToInt32(ddlUnit.SelectedValue.ToString())))
                {
                    lblProductError.Text = "Product Already exist in the list";
                    return;
                }
            }


            objProduct.ProductID = Convert.ToInt32(txtProductID.Text.Trim() == "" ? "0" : txtProductID.Text.Trim());
            objProduct.Model = txtModeNumber.Text;
            objProduct.ProductName = txtProductName.Text;
            objProduct.IssuedQty = Convert.ToInt32(RecievedQuantity.Text);
            objProduct.EquivalentUnit = Convert.ToDecimal(RecievedQuantity.Text.Trim()) * Convert.ToInt32(txtUnit.Text);  // == "" ? "0" : RecievedQuantity.Text.Trim()) * Convert.ToInt32(txtUnit.Text != "" ? txtUnit.Text : "0");
            objProduct.UnitName = ddlUnit.SelectedItem.ToString();
            objProduct.UnitId = Convert.ToInt32(ddlUnit.SelectedValue.ToString());

            objProduct.Color = txtColor.Text.Trim();
            objProduct.UnitPriceUSD = Convert.ToDecimal(txtUnitPriceUSD.Text.Trim() == "" ? "0" : txtUnitPriceUSD.Text.Trim());
            objProduct.InvoiceNo = txtInvoiceNo.Text.Trim();
            objProduct.ContainerNo = txtContainerNo.Text.Trim();
            objProduct.TotalAmount = Convert.ToDecimal(txtTotalAmount.Text.Trim() == "" ? "0" : txtTotalAmount.Text.Trim());
            objProduct.ModifiedBy = LoginToken.LoginId;
            objProduct.AddedBy = LoginToken.LoginId;
            objProduct.FinancialYearID = Convert.ToInt16(LoginToken.FinancialYearID);
            objProduct.CompanyID = Convert.ToInt16(LoginToken.CompanyID);

            if (txtPurchaseNumber.Text != "")
            {
                objProduct.PONumber = int.TryParse(txtPurchaseNumber.Text, out num) ? num : 0;  // Convert.ToInt32(txtPurchaseNumber.Text ); }
                listProduct.Add(objProduct);
            }
            if (listProduct.Count > 0)
            {
                grdOrderDetails.DataSource = listProduct;
                ddlOrderGroup.Enabled = false;
            }
            else
            {
                grdOrderDetails.DataSource = null;
                ddlOrderGroup.Enabled = true;
            }
            grdOrderDetails.DataBind();
            // save the list to the
            if (listProduct.Count > 0) Session["IssuedProductList"] = listProduct;
            txtModeNumber.Text = "";
            txtProductName.Text = "";
            txtQuantity.Text = "";
            txtUnit.Text = "";
            txtColor.Text = "";
            txtUnitPriceUSD.Text = "";
            txtTotalAmount.Text = "";
            RecievedQuantity.Text = "";
            txtProductID.Text = "";
            btnAddMaterial.Enabled = false;
            btnSave.Enabled = true;
            ddlUnit.Items.Clear();
            txtPONumber.Text = "";
            btnAddOtherCharges.Enabled = false;

        }

        protected void grdOrderDetails_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "RDelete")
            {
                int id = Convert.ToInt32(e.CommandArgument.ToString());
                List<Product> lstJournalEntry = Session["IssuedProductList"] == null ? new List<Product>() : (List<Product>)Session["IssuedProductList"];
                lstJournalEntry.RemoveAt(id - 1); ;

                Session["IssuedProductList"] = lstJournalEntry;
                grdOrderDetails.DataSource = lstJournalEntry;
                grdOrderDetails.DataBind();
                if (lstJournalEntry.Count > 0)
                {
                    btnAddOtherCharges.Enabled = false;
                }
                else
                    btnAddOtherCharges.Enabled = true;
            }
        }

        #endregion

        protected void btnSearch_Click(object sender, EventArgs e)
        {


        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ClearAll();
            txtPurchaseNumber.Text = "";
            lblProductError.Text = "";
            txtPONumber.Text = "";

        }

        protected void btnSearchPO_Click(object sender, EventArgs e)
        {

            try
            {

                ProductPurchaseOrderBO objPurchaseOrder = new ProductPurchaseOrderBO();
                InvoiceHeaderDetails objOrder = new InvoiceHeaderDetails();
                ProductPurchaseOrder objPO = new ProductPurchaseOrder();
                int.TryParse(txtPurchaseNumber.Text, out num);
                objOrder = objPurchaseOrder.GetProductPurchaseOrderDetailByID(num);
                //objproduct.PONumber = Convert.ToInt32(ddlPurchaseNumber.SelectedValue.ToString());
                lblError.Text = "";
                ClearAll();



                if (objOrder != null)
                {
                    txtRemarks.Text = objOrder.Remarks;
                    ddlOrderGroup.SelectedValue = Convert.ToString(objOrder.GroupType);
                    BindCustomerDetail(objOrder.SupplierID);

                    if (objOrder.GroupType == 1)
                    {

                        lblFilemsg.Visible = true;
                        PartListExceUpload.Visible = true;
                    }
                    else
                    {

                        lblFilemsg.Visible = false;
                        PartListExceUpload.Visible = false;
                    }

                    ddlOrderGroup.SelectedValue = objOrder.GroupType.ToString();
                    ddlOrderGroup.Enabled = false;
                    if (objOrder.InvoiceHeaderID == 0)
                    {
                        ViewState["InvoiceHeaderID"] = null;


                        txtInvoiceNo.Enabled = true;
                        ddlCurrency.Enabled = true;
                        txtCustomer.ReadOnly = false;

                    }

                    else
                    {

                        txtInvoiceNo.Text = objOrder.InvoiceNo;
                        txtInvoiceNo.Enabled = false;
                        ddlCurrency.SelectedValue = Convert.ToString(objOrder.CurrencyID);
                        txtInvoiceCurrency.Text = Convert.ToString(objOrder.CurrencyRate);
                        ddlCurrency.Enabled = false;
                        txtCustomer.ReadOnly = true;
                        ddlOrderGroup.Enabled = false;
                        BindInvoiceHeaderDetails(objOrder.InvoiceHeaderID);
                    }


                    PurchageOrderDetails();


                }
                else
                {

                    lblError.Text = "No Record found, please try with another purchase order number!";
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);

                lblError.Text = "Error While Fetching Order Records : " + ex.Message;
            }



        }
        int PageIndex = 0;

        private void PurchageOrderDetails()
        {
            ProductPurchaseOrderBO objPurchaseOrder = new ProductPurchaseOrderBO();
            ProductPurchaseOrder objPO = new ProductPurchaseOrder();
            int.TryParse(txtPurchaseNumber.Text, out num);

            List<ProductPurchaseOrder> lstPurchaseOrder = new List<ProductPurchaseOrder>();

            objPO.IsActive = true;
            objPO.IsApproved = true;
            objPO.PONumber = num.ToString();
            lstPurchaseOrder = objPurchaseOrder.SearchProductPurchaseOrderDetail_New(objPO);
            grdPurchaseOrderDetails.DataSource = lstPurchaseOrder;
            grdPurchaseOrderDetails.PageIndex = PageIndex;
            grdPurchaseOrderDetails.DataBind();
        }


        protected void BindInvoiceHeaderDetails(int Id)
        {
            ProductPurchaseOrder objPO = new ProductPurchaseOrder();
            InvoiceHeaderDetails objInvoiceHeader = new InvoiceHeaderDetails();
            InvoiceHeaderDetails objInvoiceHeaderRet = new InvoiceHeaderDetails();
            InvoiceHeaderDetailsBO objInvoiceBO = new InvoiceHeaderDetailsBO();
            ProductPurchaseOrderBO objPurchaseOrder = new ProductPurchaseOrderBO();
            try
            {
                objInvoiceHeader.InvoiceHeaderID = Id;
                objInvoiceHeaderRet = objInvoiceBO.GetSearchInvoiceHeaderDetailsByID(objInvoiceHeader);
                if (objInvoiceHeaderRet != null)
                {
                    ViewState["InvoiceHeaderID"] = objInvoiceHeaderRet.InvoiceHeaderID;

                    lblShipmentNo.Text = objInvoiceHeaderRet.ShipmentNumber;
                    lblContainerNo.Text = objInvoiceHeaderRet.ShipmentNumber;
                    txtPreviousAmount.Text = objInvoiceHeaderRet.TotalInvoiceAmount.ToString("0.00");
                }
                else
                {
                    lblError.Text = "No record found, please try with another purchase order number!";
                }

            }
            catch (Exception ex)
            {
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);

                lblError.Text = "Error While Fetching Order Records : " + ex.Message;
            }



        }

        protected void grdPurchaseOrderDetails_RowCreated(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdOrderDetails_RowCreated(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdTotalCharges_RowCreated(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#FFFFE1';");
                if (e.Row.RowIndex % 2 == 0)
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF';");
                }
                else
                {
                    //Change row colour on mouseover and mouseout
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F0F0F0';");
                }
            }
        }

        protected void grdTotalCharges_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "RDelete")
            {
                int id = Convert.ToInt32(e.CommandArgument.ToString());
                List<OtherCharges> lstOtherCharges = Session["lstOtherCharges"] == null ? new List<OtherCharges>() : (List<OtherCharges>)Session["lstOtherCharges"];

                decimal Amount = Convert.ToDecimal(txtTotalOtherCharges.Text == "" ? "0" : txtTotalOtherCharges.Text);
                decimal TotalCharge = Convert.ToDecimal(txtTotalCharges.Text == "" ? "0" : txtTotalCharges.Text);
                decimal TotalAmount = Convert.ToDecimal(lblTotalAmount.Text == "" ? "0" : lblTotalAmount.Text);

                txtTotalOtherCharges.Text = (Amount - lstOtherCharges[id - 1].ChargeRate).ToString("0.00");
                txtTotalAmount.Text = "";
                txtTotalCharges.Text = (TotalCharge - lstOtherCharges[id - 1].ChargeRate).ToString("0.00");
                txtChargeRate.Text = ((Convert.ToDecimal(txtTotalCharges.Text) * 100) / Convert.ToDecimal(txtCostPrice.Text != "" ? txtCostPrice.Text : "1")).ToString("0.00");
                lblTotalAmount.Text = (TotalAmount).ToString("0.00");

                lstOtherCharges.RemoveAt(id - 1);



                Session["lstOtherCharges"] = lstOtherCharges;
                grdTotalCharges.DataSource = lstOtherCharges;
                grdTotalCharges.DataBind();
            }

        }

        protected void ddUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                if (ddlUnit.SelectedIndex > 0)
                {
                    //  txtUnit.Text = ddlUnit.SelectedItem.Text;

                    Product objProduct = new Product();
                    Product objProductRET = new Product();
                    ProductUnitPriceBO objBO = new ProductUnitPriceBO();
                    objProduct.ProductPriceID = Convert.ToInt32(ddlUnit.SelectedValue.ToString());
                    objProduct.CustomerID = Convert.ToInt32(ViewState["CustomerID"]);
                    objProductRET = objBO.GetProductUnitByID(objProduct);

                    //VehicleBO objVehicle = new VehicleBO();
                    //objProduct.UnitId = Convert.ToInt32(ddlUnit.SelectedValue);
                    //  Product objRetUnit = objVehicle.GetUnitDetailsByID(objProduct);
                    if (objProductRET != null)
                    {
                        int EquivalentUnit = Convert.ToInt32(objProductRET.EquivalentUnit);
                        txtUnit.Text = EquivalentUnit.ToString();
                        //txtTotalAmount.Text = (Convert.ToDecimal(String.Format("{0:0.00}", txtTotalAmount.Text != "" ? Convert.ToDecimal(txtTotalAmount.Text) : 0)) * EquivalentUnit).ToString();

                        //btnAddMaterial.Enabled = true;
                    }
                    else txtUnit.Text = "";

                }
            }
            catch (Exception ex) //Exception in agent layer itself
            {
                lblError.Text = "Error while Rate loading for the product : " + ex.Message;
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.Web);
            }
        }

        protected void grdTotalCharges_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdTotalCharges.PageIndex = e.NewPageIndex;
            List<OtherCharges> lstOtherCharges = Session["lstOtherCharges"] == null ? new List<OtherCharges>() : (List<OtherCharges>)Session["lstOtherCharges"];
            if (lstOtherCharges.Count > 0)
                ddlCurrency.Enabled = false;
            else ddlCurrency.Enabled = true;
            grdTotalCharges.DataSource = lstOtherCharges;
            grdTotalCharges.DataBind();

        }

        protected void ddlOtherChargeID_SelectedIndexChanged(object sender, EventArgs e)
        {
            OtherChargesBO objBO = new OtherChargesBO();
            OtherCharges objCharges = new OtherCharges();
            objCharges.ChargeID = Convert.ToInt32(ddlOtherChargeID.SelectedValue.ToString());
            OtherCharges objChargesRet = new OtherCharges();

            objChargesRet = objBO.GetOtherChargeByID(objCharges);
            if (objChargesRet != null)
            {
                List<OtherCharges> lstOtherCharges = Session["lstOtherCharges"] == null ? new List<OtherCharges>() : (List<OtherCharges>)Session["lstOtherCharges"];
                decimal Amount = objChargesRet.ChargeRate;
                txtTempOther.Text = Amount.ToString();
                objChargesRet.ChargeRate = Amount;
                // txtTotalOtherCharges.Text = Amount.ToString("0.00");

            }
            else
            {
                txtTempOther.Text = "";
            }
        }

        protected void grdPurchaseOrderDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            PageIndex = e.NewPageIndex;
            PurchageOrderDetails();
        }


    }




}