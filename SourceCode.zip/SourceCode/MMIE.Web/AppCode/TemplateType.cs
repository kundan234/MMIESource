﻿namespace MMIE.Web
{
    public enum TemplateType
    {
        ItemTemplate = 0,

        EditItemTemplate = 1,

        InsertItemTemplate = 2
    }
}