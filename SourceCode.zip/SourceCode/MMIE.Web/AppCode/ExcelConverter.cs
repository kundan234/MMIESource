﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;

/*************************************************************************************************  
  
  Name of the Class			    : ExcelConverter                      
  
  Description of the class	    : 
  
  Created Date					: 24 Oct 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.Web
{
    public static class ExcelConverter
    {
        public static DataTable ReadFromExcel(string path, string sheetName, string tableName )
        {
            //Connection for Excel sheet
            string xlsConnectionString = ConfigurationManager.ConnectionStrings["xlsConnectionString"].ConnectionString;
            String strConn = xlsConnectionString + path;
            //You must use the $ after the object you reference in the spreadsheet
            DataTable xlsDatatable = null;
            try
            {
                OleDbDataAdapter objCommand = new OleDbDataAdapter("SELECT * FROM [" + sheetName + "$]", strConn);
                DataSet objDataSet = new DataSet();
                objCommand.Fill(objDataSet, tableName);
                xlsDatatable = objDataSet.Tables[tableName];
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
     
            return xlsDatatable;
        }

        public static DataTable ReadFromExcelPO(string path, string sheetName, string tableName, string PO)
        {
            //Connection for Excel sheet
            string xlsConnectionString = ConfigurationManager.ConnectionStrings["xlsConnectionString"].ConnectionString;
            String strConn = xlsConnectionString + path;
            //You must use the $ after the object you reference in the spreadsheet
            DataTable xlsDatatable = null;
            try
            {
                OleDbDataAdapter objCommand = new OleDbDataAdapter("SELECT * FROM [" + sheetName + "$]", strConn);
                DataSet objDataSet = new DataSet();
                objCommand.Fill(objDataSet, tableName);
                xlsDatatable = objDataSet.Tables[tableName];
                
            }
            catch (Exception ex)
            {
                ex.ToString();
            }

            return xlsDatatable;
        }


        public static String[] GetExcelSheetNames(string excelFile)
        {
            OleDbConnection objConn = null;
            System.Data.DataTable dt = null;
            try
            {
                // Connection String. Change the excel file to the file you
                // will search.
                string xlsConnectionString = ConfigurationManager.ConnectionStrings["xlsConnectionString"].ConnectionString;
                String connString = xlsConnectionString + excelFile;
                // Create connection object by using the preceding connection string.
                objConn = new OleDbConnection(connString);
                // Open connection with the database.
                objConn.Open();
                // Get the data table containg the schema guid.
                dt = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                if (dt == null)
                {
                    return null;
                }

                String[] excelSheets = new String[dt.Rows.Count];
                int i = 0;

                // Add the sheet name to the string array.
                foreach (DataRow row in dt.Rows)
                {
                    excelSheets[i] = row["TABLE_NAME"].ToString();
                    i++;
                }

                return excelSheets;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                // Clean up.
                if (objConn != null)
                {
                    objConn.Close();
                    objConn.Dispose();
                }
                if (dt != null)
                {
                    dt.Dispose();
                }
            }
        }

    }

}