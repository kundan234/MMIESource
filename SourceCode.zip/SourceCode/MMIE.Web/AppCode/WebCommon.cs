﻿using System;
using System.Collections.Generic;
using System.Linq;
//using System;
using System.Web;
using System.Web.UI.WebControls;
using System.Data;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Configuration;
//using System.Collections.Generic;
//using System.Linq;
using System.Web.UI;
using System.Web.Security;
//using System.Xml.Serialization;
using System.Xml.Linq;
using System.Security.Cryptography;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data;

using MMIE.Common;
using MMIE.Data.Common;
using MMIE.Common.Util;
using System.Text;

namespace MMIE.Web
{
    public static class WebCommon    
    {
        // Description: This method returns groups Names by comma separated 
        //related to current user such as : Tier1,Tier2,Tier3,Tier4         
        public static string GetRolesNamesFromToken()
        {
            string RolesAssigntoUser = "";
            // Get Roles Ids
            LoginToken objLoginToken = (LoginToken)HttpContext.Current.Session["LoginToken"];
            if (objLoginToken != null)
            {
                foreach (string objUGrp in objLoginToken.RoleNames)
                {
                    if (RolesAssigntoUser.Trim() != "")
                    {
                        RolesAssigntoUser = RolesAssigntoUser + "," + objUGrp;
                    }
                    else
                    {
                        RolesAssigntoUser = objUGrp;
                    }
                }

            }
            return RolesAssigntoUser;
        }

        // Description: This method returns groups ids by comma separated 
        //related to current user such as : 1,2,3,4         
        public static string GetRolesIdFromToken()
        {
            string RolesAssigntoUser = "";
            // Get Roles Ids
            LoginToken objLoginToken = (LoginToken)HttpContext.Current.Session["LoginToken"];
            if (objLoginToken != null)
            {
                foreach (int objUGrp in objLoginToken.RoleIds)
                {
                    if (RolesAssigntoUser.Trim() != "")
                    {
                        RolesAssigntoUser = RolesAssigntoUser + "," + objUGrp.ToString();
                    }
                    else
                    {
                        RolesAssigntoUser = objUGrp.ToString();
                    }
                }
            }
            return RolesAssigntoUser;
        }

        public static string GetLoginIdFromToken()
        {
            LoginToken objLoginToken = (LoginToken)HttpContext.Current.Session["LoginToken"];
            if (objLoginToken != null)
            {
                return objLoginToken.LoginId;
            }
            else
                return string.Empty;
        }

        public static string GetMenuData()
        {
            string xmlData = "";
            LoginToken objLoginToken = (LoginToken)HttpContext.Current.Session["LoginToken"];
            xmlData = objLoginToken.NavigationXmlData;
            return xmlData;
        }

        //// Get XMLData for Master      
        //public static XmlDataSource GetXMLDataSource(string type)
        //{
        //    XmlDataSource xmlData = new XmlDataSource();
        //    String serverPath = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "..\\Master\\";
        //    switch (type)
        //    {
        //        case "ServicesType":
        //            xmlData.DataFile = serverPath + "Services\\ServicesType.xml";
        //            xmlData.XPath = "ServicesType/Service";
        //            break;
        //        case "BillTypes":
        //            xmlData.DataFile = serverPath + "Services\\BillTypes.xml";
        //            xmlData.XPath = "BillTypes/BillType";
        //            break;
        //        default: break;

        //    }
        //    return xmlData;
        //}

        // convert xxx.xxxxxx string to xxx.xx format with round up
        public static String GetMoney(String str) // in xxx.xxxxx
        {
            try
            {
                decimal number;
                Decimal.TryParse(str, out number);
                return Decimal.Round(number, 2).ToString(); // in xxx.xx format
            }
            catch
            {
                return "0.00"; // in 0.00 format if invalid number is passed
            }
        }

        // get current date time in yyyy-MM-dd HH:mm:ss format
        public static String GetDateTime()
        {
            return System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ".000";
        }

        // convert date time from DD/MM/YYYY to yyyy-MM-dd HH:mm:ss format
        public static String GetDateTime(String strDDMMYYYY) // in DD/MM/YYYY
        {
            try
            {
                DateTime MyDateTime = new DateTime();
                MyDateTime = DateTime.ParseExact(strDDMMYYYY, "dd/MM/yyyy", null);
                return MyDateTime.ToString("yyyy-MM-dd") + " " + System.DateTime.Now.ToString("HH:mm:ss") + ".000";
            }
            catch
            {
                return GetDateTime();
            }
        }

        public static void PopulateDdl(DropDownList drpDownList, List<LookupItem> lstLookups)
        {
            if (drpDownList != null && lstLookups != null)
            {
                drpDownList.DataSource = lstLookups;
                drpDownList.DataValueField = "ItemId";
                drpDownList.DataTextField = "ItemName";
                drpDownList.DataBind();
                drpDownList.Items.Insert(0, "-- Select --");
                drpDownList.Items[0].Value = "0";
                drpDownList.ClearSelection();
            }
        }

        public static void PopulateDdlAll(DropDownList drpDownList, List<LookupItem> lstLookups)
        {
            if (drpDownList != null && lstLookups != null)
            {
                drpDownList.DataSource = lstLookups;
                drpDownList.DataValueField = "ItemId";
                drpDownList.DataTextField = "ItemName";
                drpDownList.DataBind();
                drpDownList.Items.Insert(0, "-- All --");
                drpDownList.Items[0].Value = "0";
                drpDownList.ClearSelection();
            }
        }

        public static void ShowNoResultFound<T>(List<T> source, GridView gv) where T : new()
        {
            if (source == null) return;
            source.Add(new T());
            gv.DataSource = source;
            gv.DataBind();

            // Get the total number of columns in the GridView to know what the Column Span should be
            int columnsCount = gv.Columns.Count;
            gv.Rows[0].Cells.Clear();// clear all the cells in the row
            gv.Rows[0].Cells.Add(new TableCell()); //add a new blank cell
            gv.Rows[0].Cells[0].ColumnSpan = columnsCount; //set the column span to the new added cell

            //You can set the styles here
            ////gv.Rows[0].Cells[0].HorizontalAlign = HorizontalAlign.Center;
            ////gv.Rows[0].Cells[0].ForeColor = System.Drawing.Color.Red;
            ////gv.Rows[0].Cells[0].Font.Bold = true;
            // or you can pass a css class name 
            //gv.Rows[0].Cells[0].CssClass = "";
            //set No Results found to the new added cell
            gv.Rows[0].Cells[0].Text = ".....there is no result found....";//gv.EmptyDataText; // Use GridView's Empty Row message
        }

       

        public static string ReportServerName = ConfigurationManager.ConnectionStrings["ReportServerName"].ConnectionString;
        public static string ReportDatabase = ConfigurationManager.ConnectionStrings["ReportDatabase"].ConnectionString;
        public static string ReportUserId = ConfigurationManager.ConnectionStrings["ReportUserId"].ConnectionString;
        public static string ReportPassword = ConfigurationManager.ConnectionStrings["ReportPassword"].ConnectionString;
        public static void ResetAllSession()
        {
           
        }

        // get unique key by RNGCharacterMasking
        public static string GetUniqueKey(int MaxLengthOfKey)
        {
            //int maxSize = 8;
            //int minSize = 5;
            char[] chars = new char[62];
            string a;
            a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            chars = a.ToCharArray();
            int size = MaxLengthOfKey;
            byte[] data = new byte[1];
            RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
            crypto.GetNonZeroBytes(data);
            size = MaxLengthOfKey;
            data = new byte[size];
            crypto.GetNonZeroBytes(data);
            StringBuilder result = new StringBuilder(size);
            foreach (byte b in data)
            { result.Append(chars[b % (chars.Length - 1)]); }
            return result.ToString();
        }

        static IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
        public static DateTime SQL_DateTimeMininum = DateTime.Parse("01/01/1753", provider, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
        public static DateTime SQL_DateTimeMaximum = DateTime.Parse("31/12/9999", provider, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
    }
}
