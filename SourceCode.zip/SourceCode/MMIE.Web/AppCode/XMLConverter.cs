﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using MMIE.Data.Common;
using MMIE.Data.ACC;
using MMIE.Data.CUR;
using MMIE.Data.PUR;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;




namespace MMIE.Web
{
    public static class XMLConverter
    {

        public static StringBuilder SalesProductListToXML(List<Product> listStore)
        {
            StringBuilder objBuilder = new StringBuilder();
            if (listStore != null)
            {
                foreach (Product obj in listStore)
                {
                    objBuilder.Append("<ProductlIssue ProductID = \"" + obj.ProductID.ToString() + "\" ");
                    objBuilder.Append(" IssuedQty = \"" + obj.IssuedQty.ToString() + "\" ");
                    objBuilder.Append(" Amount = \"" + obj.Amount.ToString() + "\" ");
                    objBuilder.Append(" Remarks = \"" + obj.Remark + "\" ");
                    objBuilder.Append(" FinancialYearID = \"" + obj.FinancialYearID.ToString() + "\" ");
                    objBuilder.Append(" CompanyID = \"" + obj.CompanyID.ToString() + "\" ");
                    objBuilder.Append(" AddedBy = \"" + obj.AddedBy + "\" ");
                    objBuilder.Append(" StockProductReceivedTransID = \"" + obj.StockProductReceivedTransID + "\" ");
                    objBuilder.Append(" />");
                }
                return objBuilder;
            }
            else return null;
        }

        public static StringBuilder PurchaseCurrencyListToXML(List<ExchangeCurrency> listItems)
        {
            StringBuilder objBuilder = new StringBuilder();
            if (listItems != null)
            {
                foreach (ExchangeCurrency obj in listItems)
                {
                    objBuilder.Append("<PurchaseCurrency PurchaseCurrencyId = \"" + obj.PurchaseCurrencyID + "\" ");
                    objBuilder.Append(" EquivalentCurrencyId = \"" + obj.EquivalentCurrencyId.ToString() + "\" ");
                    objBuilder.Append(" Rate = \"" + obj.Rate.ToString() + "\" ");
                    objBuilder.Append(" PurchaseCurrencyAmount = \"" + obj.PurchaseCurrencyAmount + "\" ");
                    objBuilder.Append(" EquiCurrencyAmount = \"" + obj.EquiCurrencyAmount.ToString() + "\" ");
                    objBuilder.Append(" CustomerID = \"" + obj.CustomerID.ToString() + "\" ");
                    objBuilder.Append(" AddedBy = \"" + obj.AddedBy + "\" ");
                    objBuilder.Append(" LastModBy = \"" + obj.LastModBy + "\" ");

                    //objBuilder.Append(" PurchaseID = \"" + obj.CustomerID.ToString() + "\" ");
                    //objBuilder.Append(" InvoiceNo = \"" + obj.AddedBy + "\" ");
                    //objBuilder.Append(" PurchaseDate = \"" + obj.LastModBy + "\" ");

                    objBuilder.Append(" />");


                }
                return objBuilder;
            }
            else return null;
        }


        public static StringBuilder SalesVehicleListToXML(List<Product> listStore)
        {
            StringBuilder objBuilder = new StringBuilder();
            try
            {
                if (listStore != null)
                {

                    foreach (Product obj in listStore)
                    {
                        objBuilder.Append("<VehicleIssue ProductID = \"" + obj.ProductID.ToString() + "\" ");
                        objBuilder.Append(" IssuedQty = \"" + obj.IssuedQty.ToString() + "\" ");
                        objBuilder.Append(" UnitPriceUSD = \"" + obj.UnitPriceUSD.ToString() + "\" ");
                        objBuilder.Append(" UnitPriceGourdes = \"" + obj.UnitPriceGourdes.ToString() + "\" ");

                        // objBuilder.Append(" VinNo = \"" + obj.VINNO == null ?  " a " : obj.VINNO.ToString() + "\" ");
                        // objBuilder.Append(" EngineNo = \"" + obj.EngineNo == null ? "" : obj.EngineNo.ToString() + "\" ");
                        objBuilder.Append(" UnitID = \"" + obj.UnitId.ToString() + "\" ");
                        objBuilder.Append(" FinancialYearID = \"" + obj.FinancialYearID.ToString() + "\" ");
                        objBuilder.Append(" CompanyID = \"" + obj.CompanyID.ToString() + "\" ");
                        objBuilder.Append(" AddedBy = \"" + obj.AddedBy + "\" ");
                        objBuilder.Append(" ProductReceivedTransID = \"" + obj.StockProductReceivedTransID + "\" ");
                        objBuilder.Append(" DeliveryChargeUSD = \"" + obj.DeliveryChargeUSD + "\" ");
                        objBuilder.Append(" DeliveryChargeGourdes = \"" + obj.DeliveryChargeGourdes + "\" ");
                        objBuilder.Append(" SalesTaxUSD = \"" + obj.SaleTaxUSD + "\" ");
                        objBuilder.Append(" SalesTaxGourdes = \"" + obj.SaleTaxGourdes + "\" ");
                        objBuilder.Append(" TaxRate = \"" + obj.TaxRate + "\" ");
                        objBuilder.Append(" UnitName = \"" + obj.UnitName + "\" ");
                        objBuilder.Append(" CurrencyID = \"" + obj.CurrencyID + "\" ");
                        objBuilder.Append(" CurrencyRate = \"" + obj.CurrencyRate + "\" ");
                        objBuilder.Append(" />");
                    }
                    return objBuilder;
                }
                else
                    objBuilder = null;

            }
            catch (Exception ex)
            {
                listStore = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objBuilder;

        }




        public static StringBuilder DeliveryVehicleListToXML(List<Product> listStore)
        {
            StringBuilder objBuilder = new StringBuilder();
            try
            {
                if (listStore != null)
                {
                    foreach (Product obj in listStore)
                    {
                        objBuilder.Append("<VehicleDelivery ProductID = \"" + obj.ProductID.ToString() + "\"");
                        objBuilder.Append(" DeliveryQty = \"" + obj.IssuedQty.ToString() + "\"");
                        objBuilder.Append(" DeliveryUnitPriceUSD = \"" + obj.UnitPriceUSD.ToString() + "\"");
                        objBuilder.Append(" DeliveryUnitPriceGourdes = \"" + obj.UnitPriceGourdes.ToString() + "\"");
                        objBuilder.Append(" ProductSaleID = \"" + obj.ProductSaleID.ToString() + "\"");
                        objBuilder.Append(" OrderNumber = \"" + obj.SaleOrderNumber.ToString() + "\"");
                        objBuilder.Append(" DeliveryTotalUSDAmount = \"" + obj.DeliveryAmount.ToString() + "\"");
                        objBuilder.Append(" DeliveryTotalGourdesAmount = \"" + obj.DeliveryGourdesAmount.ToString() + "\"");
                        objBuilder.Append(" FinancialYearID = \"" + obj.FinancialYearID.ToString() + "\"");
                        objBuilder.Append(" CompanyID = \"" + obj.CompanyID.ToString() + "\" ");
                        objBuilder.Append(" AddedBy = \"" + obj.AddedBy + "\"");
                        objBuilder.Append(" VinNo = \"" + obj.VINNO + "\" ");
                        objBuilder.Append(" EngineNo = \"" + obj.EngineNo + "\"");
                        objBuilder.Append(" VehiclePOID = \"" + obj.VehiclePOID + "\"");
                        objBuilder.Append(" UnitName = \"" + obj.UnitName + "\"");
                        objBuilder.Append(" UnitId = \"" + obj.UnitId + "\"");
                        objBuilder.Append(" EquivalentUnit = \"" + obj.EquivalentUnit + "\"");
                  
                        

                        objBuilder.Append(" />");
                    }


                    return objBuilder;
                }
                else
                    objBuilder = null;

            }
            catch (Exception ex)
            {
                listStore = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objBuilder;

        }


        public static StringBuilder PurchaseOrderListToXML(List<Product> listStore)
        {
            StringBuilder objBuilder = new StringBuilder();
            try
            {
                if (listStore != null)
                {

                    foreach (Product obj in listStore)
                    {
                        objBuilder.Append("<PurchaseOrderlst Model = \"" + obj.Model.ToString() + "\" ");
                        objBuilder.Append(" Color = \"" + obj.Color.ToString() + "\" ");
                        objBuilder.Append(" IssuedQty = \"" + obj.IssuedQty.ToString() + "\" ");
                        objBuilder.Append(" Unit = \"" + obj.UnitName.ToString() + "\" ");
                        objBuilder.Append(" ENName = \"" + obj.ProductName.ToString() + "\" ");
                        objBuilder.Append(" ProductType = \"" + obj.GroupType.ToString() + "\" ");
                        objBuilder.Append(" OrderDate = \"" + obj.strDate.ToString() + "\" ");
                        objBuilder.Append(" CompanyID = \"" + obj.CompanyID.ToString() + "\" ");
                        objBuilder.Append(" FinancialYearID = \"" + obj.FinancialYearID.ToString() + "\" ");
                        objBuilder.Append(" AddedBy = \"" + obj.AddedBy + "\" ");
                        objBuilder.Append(" LastModBy = \"" + obj.ModifiedBy + "\" ");
                        objBuilder.Append(" ProductID = \"" + obj.ProductID.ToString() + "\" ");
                        objBuilder.Append(" IsActve = \"" + (obj.IsActive?1:0).ToString() + "\" ");
                        objBuilder.Append(" />");
                    }
                    return objBuilder;
                }
                else
                    objBuilder = null;

            }
            catch (Exception ex)
            {
                listStore = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objBuilder;

        }



        public static StringBuilder VehicleReceivingListToXML(List<Product> listStore)
        {
            StringBuilder objBuilder = new StringBuilder();
            try
            {
                if (listStore != null)
                {

                    foreach (Product obj in listStore)
                    {
                        objBuilder.Append("<VehicleReceivinglst ProductID = \"" + obj.ProductID.ToString() + "\" ");
                        objBuilder.Append(" Model = \"" + obj.Model.ToString() + "\" ");
                        objBuilder.Append(" Color = \"" + obj.Color.ToString() + "\" ");
                        objBuilder.Append(" ProductName = \"" + obj.ProductName.ToString() + "\" ");
                        objBuilder.Append(" IssuedQty = \"" + obj.IssuedQty.ToString() + "\" ");
                        objBuilder.Append(" Unit = \"" + obj.UnitName.ToString() + "\" ");
                        objBuilder.Append(" VINNO = \"" + obj.VINNO.ToString() + "\" ");
                        objBuilder.Append(" EngineNo = \"" + obj.EngineNo.ToString() + "\" ");
                        //objBuilder.Append(" InvoiceNo = \"" + obj.InvoiceNo.ToString() + "\" ");
                        //objBuilder.Append(" ContainerNo = \"" + obj.ContainerNo.ToString() + "\" ");
                        //objBuilder.Append(" Retailer1 = \"" + obj.Retailer1.ToString() + "\" ");
                        //objBuilder.Append(" Retailer2 = \"" + obj.Retailer2.ToString() + "\" ");
                        //objBuilder.Append(" Dealer = \"" + obj.Dealer.ToString() + "\" ");
                        //objBuilder.Append(" CreditRate = \"" + obj.CreditRate.ToString() + "\" ");
                        objBuilder.Append(" CompanyID = \"" + obj.CompanyID.ToString() + "\" ");
                        objBuilder.Append(" FinancialYearID = \"" + obj.FinancialYearID.ToString() + "\" ");
                        objBuilder.Append(" AddedBy = \"" + obj.AddedBy + "\" ");
                        objBuilder.Append(" LastModBy = \"" + obj.ModifiedBy + "\" ");
                        objBuilder.Append(" PONumber = \"" + Convert.ToString(obj.PONumber) + "\" ");
                        objBuilder.Append(" IsApproved = \"" + obj.IsApproved + "\" ");
                        objBuilder.Append(" ApproverRemarks = \"" + obj.ApproverRemarks.ToString() + "\" ");
                        objBuilder.Append(" />");
                    }
                    return objBuilder;
                }
                else
                    objBuilder = null;

            }
            catch (Exception ex)
            {
                listStore = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objBuilder;

        }


        public static StringBuilder Vehicle_Part_ReceivingListToXML(List<ProductPurchaseOrder> listStore)
        {
            StringBuilder objBuilder = new StringBuilder();
            try
            {
                if (listStore != null)
                {

                    foreach (ProductPurchaseOrder obj in listStore)
                    {
                        objBuilder.Append("<VehicleReceivinglst ProductID = \"" + obj.ProductID.ToString() + "\" ");
                        objBuilder.Append(" Model = \"" + obj.Model.ToString() + "\" ");
                        objBuilder.Append(" Color = \"" + obj.Color.ToString() + "\" ");
                        objBuilder.Append(" ProductName = \"" + obj.ProductName.ToString() + "\" ");
                        objBuilder.Append(" IssuedQty = \"" + obj.RecievedQty.ToString() + "\" ");
                        objBuilder.Append(" Unit = \"" + obj.UnitName.ToString() + "\" ");
                                       
                        
                        objBuilder.Append(" />");
                    }
                    return objBuilder;
                }
                else
                    objBuilder = null;

            }
            catch (Exception ex)
            {
                listStore = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objBuilder;

        }




        public static StringBuilder PartReceivingListToXML(List<Product> listStore)
        {
            StringBuilder objBuilder = new StringBuilder();
            try
            {
                if (listStore != null)
                {

                    foreach (Product obj in listStore)
                    {
                        objBuilder.Append("<PartReceivinglst ProductID = \"" + obj.ProductID.ToString() + "\" ");
                        objBuilder.Append(" Model = \"" + obj.Model.ToString() + "\" ");
                        objBuilder.Append(" Color = \"" + obj.Color.ToString() + "\" ");
                        objBuilder.Append(" ProductName = \"" + obj.ProductName.ToString() + "\" ");
                        objBuilder.Append(" IssuedQty = \"" + obj.IssuedQty.ToString() + "\" ");
                        objBuilder.Append(" Unit = \"" + obj.UnitName.ToString() + "\" ");
                        objBuilder.Append(" UnitPriceUSD = \"" + obj.UnitPriceUSD.ToString() + "\" ");
                        objBuilder.Append(" UnitPriceGourdes = \"" + obj.UnitPriceGourdes.ToString() + "\" ");
                        //  objBuilder.Append(" InvoiceNo = \"" + obj.InvoiceNo.ToString() + "\" ");
                        objBuilder.Append(" ContainerNo = \"" + obj.ContainerNo.ToString() + "\" ");
                        objBuilder.Append(" Retailer1 = \"" + obj.Retailer1.ToString() + "\" ");
                        objBuilder.Append(" Retailer2 = \"" + obj.Retailer2.ToString() + "\" ");
                        objBuilder.Append(" Dealer = \"" + obj.Dealer.ToString() + "\" ");
                        objBuilder.Append(" CreditRate = \"" + obj.CreditRate.ToString() + "\" ");
                        objBuilder.Append(" CompanyID = \"" + obj.CompanyID.ToString() + "\" ");
                        objBuilder.Append(" FinancialYearID = \"" + obj.FinancialYearID.ToString() + "\" ");
                        objBuilder.Append(" AddedBy = \"" + obj.AddedBy + "\" ");
                        objBuilder.Append(" LastModBy = \"" + obj.ModifiedBy + "\" ");
                        objBuilder.Append(" PONumber = \"" + Convert.ToString(obj.PONumber) + "\" ");


            
                        objBuilder.Append(" CostPrice = \"" + Convert.ToString(obj.CostPrice) + "\" ");

                        

                        objBuilder.Append(" />");
                    }
                    return objBuilder;
                }
                else
                    objBuilder = null;

            }
            catch (Exception ex)
            {
                listStore = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objBuilder;

        }



        public static StringBuilder JournalDetailsListToXML(List<JournalDetails> listJounalEntry)
        {
            StringBuilder objBuilder = new StringBuilder();
            try
            {
                if (listJounalEntry != null)
                {

                    foreach (JournalDetails obj in listJounalEntry)
                    {
                        objBuilder.Append("<JournalEntry TransactionID=\"" + "1" + "\" JournalDetailsID = \"" + obj.JournalDetailsID.ToString() + "\" ");
                        objBuilder.Append(" LedgerAccountID = \"" + obj.LedgerAccountID.ToString() + "\" ");

                        objBuilder.Append(" TType = \"" + obj.TType + "\" ");
                        objBuilder.Append(" LF = \"" + obj.LF + "\" ");
                        objBuilder.Append(" DebitAmount = \"" + obj.DebitAmount.ToString() + "\" ");
                        objBuilder.Append(" CreditAmount = \"" + obj.CreditAmount.ToString() + "\" ");

                        objBuilder.Append(" />");
                    }
                    return objBuilder;
                }
                else
                    objBuilder = null;

            }
            catch (Exception ex)
            {
                listJounalEntry = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objBuilder;

        }
        public static StringBuilder JournalDetailsListToXMLForMultiple(List<JournalDetails> listJounalEntry)
        {
            StringBuilder objBuilder = new StringBuilder();
            try
            {
                if (listJounalEntry != null)
                {

                    foreach (JournalDetails obj in listJounalEntry)
                    {
                        objBuilder.Append("<JournalEntry TransactionID=\"" + obj.TransactionID.ToString() + "\" JournalDetailsID = \"" + obj.JournalDetailsID.ToString() + "\" ");
                        objBuilder.Append(" LedgerAccountID = \"" + obj.LedgerAccountID.ToString() + "\" ");
                        objBuilder.Append(" TType = \"" + obj.TType + "\" ");
                        objBuilder.Append(" LF = \"" + obj.LF + "\" ");
                        objBuilder.Append(" DebitAmount = \"" + obj.DebitAmount.ToString() + "\" ");
                        objBuilder.Append(" CreditAmount = \"" + obj.CreditAmount.ToString() + "\" ");
                        objBuilder.Append(" Details = \"" + obj.Details.ToString() + "\" ");
                        objBuilder.Append(" EntryDate = \"" + obj.EntryDate.ToString() + "\" ");
                        objBuilder.Append(" ReferenceNo = \"" + obj.ReferenceNo.ToString() + "\" ");
                        objBuilder.Append(" />");
                    }
                    return objBuilder;
                }
                else
                    objBuilder = null;

            }
            catch (Exception ex)
            {
                listJounalEntry = null;
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, ex, "1000001");
                LogManager.WriteErrorLogInDB(ex);
            }
            return objBuilder;

        }


    }
}