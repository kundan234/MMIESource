﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MMIE.Data.Common;


/// <summary>
/// Summary description for LookupEditEventArgs
/// </summary>
public class LookupEditEventArgs : EventArgs
{
    private LookupItem item = null;
	public LookupEditEventArgs(LookupItem item)
	{
        this.item = item;
	}
    #region Event properties

    public LookupItem LookupItem
    {
        get { return this.item; }
        set { this.item = value; }
    }

    #endregion
}