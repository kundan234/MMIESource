﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Collections;


namespace MMIE.Web.UI.Controls
{
    
    using MMIE.Common.ExceptionHandler;
    public class RequiredFieldValidator : System.Web.UI.WebControls.RequiredFieldValidator
    {
        private string _errorMessageID;
        [Description("The message id will identify which message to show")]
        public string ErrorMessageID
        {
            get { return _errorMessageID; }
            set { _errorMessageID = value; }
        }
        
        protected override void OnLoad(System.EventArgs e)
        {
            base.OnLoad(e);
            if(ErrorMessageID !=null)
                base.ErrorMessage = ExceptionMessage.GetMessage(ErrorMessageID);
        }
        
    }

    public class RegularExpressionValidator : System.Web.UI.WebControls.RegularExpressionValidator
    {
        private string _errorMessageID;
        [Description("The message id will identify which message to show")]
        public string ErrorMessageID
        {
            get { return _errorMessageID; }
            set { _errorMessageID = value; }
        }

        protected override void OnLoad(System.EventArgs e)
        {
            base.OnLoad(e);
            if (ErrorMessageID != null)
                base.ErrorMessage = ExceptionMessage.GetMessage(ErrorMessageID);
        }

    }

    public class CustomValidator : System.Web.UI.WebControls.CustomValidator
    {
        private string _errorMessageID;
        [Description("The message id will identify which message to show")]
        public string ErrorMessageID
        {
            get { return _errorMessageID; }
            set { _errorMessageID = value; }
        }

        protected override void OnLoad(System.EventArgs e)
        {
            base.OnLoad(e);
            if (ErrorMessageID != null)
                base.ErrorMessage = ExceptionMessage.GetMessage(ErrorMessageID);
        }
    }
}