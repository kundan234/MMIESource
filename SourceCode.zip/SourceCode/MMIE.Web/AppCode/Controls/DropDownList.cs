﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Collections;
using MMIE.Data.Common;


namespace MMIE.Web.UI.Controls
{
        
    public class DropDownList : System.Web.UI.WebControls.DropDownList
    {
        private LookupNames? _lookupName;
        [Description("The lookup Name for which control will display.")]
        public LookupNames? LookupName
        {
            get { return _lookupName; }
            set { _lookupName = value; }
        }
        public string FirstItemText
        {
            get;
            set;
        }
        protected override void OnLoad(System.EventArgs e)
        {
            base.OnLoad(e);
            if (!this.Page.IsPostBack)
            {
                GetLookupMaster();    
            }
        }
        //public override string SelectedValue
        //{
        //    get
        //    {
        //        if (base.SelectedValue == "0")
        //            return null;
        //        else
        //            return base.SelectedValue;
        //    }
        //    set
        //    {
        //        base.SelectedValue = value;
        //    }
        //}
        public void BindDataWithSource()
        {
            GetLookupMaster();
        }

        private int _itemID;
        public int ItemID
        {
            get {
                return _itemID;
            }
        }
        public void EditDataBind(Int32 itemID)
        {
            _itemID = itemID;
            BindDataWithSource();
        }

        private void GetLookupMaster()
        {
            if (LookupName != null)
            {
               // base.DataSource = MasterLookupServiceAgent.GetLookupsList((LookupNames)LookupName);
                this.DataValueField = "ItemId";
                this.DataTextField = "ItemName";
                base.DataBind();
           }

            ListItem li = null;
            if (FirstItemText != null)
                li = new ListItem("--" + FirstItemText + "--", "0");
            else
                li = new ListItem("--Select--", "0");
            this.Items.Insert(0, li);
        }
    }
}