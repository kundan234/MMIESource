﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SiteUrls
/// </summary>
public static class SiteUrls
{

    public static readonly string MasterLookup = GetUrl("common/common.aspx");
    public static readonly string Default = GetUrl("HomePage.aspx");

    private static string GetUrl(string page)
    {
        return VirtualPathUtility.ToAbsolute("~/"+ page);
    }
}
