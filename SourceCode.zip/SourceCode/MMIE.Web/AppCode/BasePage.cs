﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Serialization;
using System.IO;
//using System.ServiceModel;
using System.Data;
using System.ComponentModel;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.Data;
//////using MMIE.Data.ADM;


using System.Web.SessionState;

namespace MMIE.Web
{
    public class BasePage : System.Web.UI.Page
    {

        #region RESET PATIENT PICKER SESSIONS

        HttpSessionState session = HttpContext.Current.Session;

        //session.
        //session
        //Session["UpdateParentWindowByRegdID"]=null;
        //    if (objUpdateParentWindowByMRNo != null && objUpdateParentWindowByMRNo != undefined && objUpdateParentWindowByMRNo != "") {
        //        objPPRegistrationID = document.getElementById('<%= hdnRegistrationID.ClientID %>');
        //        href = window.opener.location.href;
        //        var mySplitResult = href.split("?");
        //        href = mySplitResult[0] + "?ID=" + objPPRegistrationID.value;
        //        window.opener.location.href = href;
        //        window.close();
        //    }

        //    // get Session ClientIDs to update
        //    objIPNo = window.opener.document.getElementById('<%= (String)Session["txtIPNo"] %>');
        //    objMRNumber = window.opener.document.getElementById('<%= (String)Session["txtMRNumber"] %>');
        //    objDepartment = window.opener.document.getElementById('<%= (String)Session["txtDepartment"] %>');
        //    objDepartmentDDl = window.opener.document.getElementById('<%= (String)Session["ddlDepartment"] %>');
        //    objPatientName = window.opener.document.getElementById('<%= (String)Session["txtPatientName"] %>');
        //    objPatientFirstName = window.opener.document.getElementById('<%= (String)Session["txtPatientFirstName"] %>');
        //    objPatientMiddleName = window.opener.document.getElementById('<%= (String)Session["txtPatientMiddleName"] %>');
        //    objPatientAddress = window.opener.document.getElementById('<%= (String)Session["txtPatientAddress"] %>');
        //    objSalutationDdl = window.opener.document.getElementById('<%= (String)Session["ddlSalutation"] %>');
        //    objTariffcategoryDdl = window.opener.document.getElementById('<%= (String)Session["ddlTariffcategory"] %>');
        //    objAge = window.opener.document.getElementById('<%= (String)Session["txtAge"] %>');
        //    objSex = window.opener.document.getElementById('<%= (String)Session["txtSex"] %>');
        //    objPatientSexDdl = window.opener.document.getElementById('<%= (String)Session["ddlSex"] %>');
        //    objPatientcategoryDdl = window.opener.document.getElementById('<%= (String)Session["ddlPatientcategorylist"] %>');
        //    objAdmissiondate = window.opener.document.getElementById('<%= (String)Session["txtAdmissiondate"] %>');
        //    objAdmissionTime = window.opener.document.getElementById('<%= (String)Session["txtPAdmissionTime"] %>');
        //    objAdmissiondoctor = window.opener.document.getElementById('<%= (String)Session["txtAdmissiondoctor"] %>');
        //    objPhoneNo = window.opener.document.getElementById('<%= (String)Session["txtPhoneNo"] %>');
        //    objMobileNo = window.opener.document.getElementById('<%= (String)Session["txtMobileNo"] %>');
            
        //    objFloor = window.opener.document.getElementById('<%= (String)Session["txtFloor"] %>');
        //    objFloorID = window.opener.document.getElementById('<%= (String)Session["txtFloorID"] %>');
        //    objWard = window.opener.document.getElementById('<%= (String)Session["txtWard"] %>');
        //    objWardID = window.opener.document.getElementById('<%= (String)Session["txtWardID"] %>');
        //    objRoom = window.opener.document.getElementById('<%= (String)Session["txtRoom"] %>');
        //    objRoomID = window.opener.document.getElementById('<%= (String)Session["txtRoomID"] %>');
        //    objBed = window.opener.document.getElementById('<%= (String)Session["txtBed"] %>');
        //    objBedID = window.opener.document.getElementById('<%= (String)Session["txtBedID"] %>');

        //    objBillingTotal = window.opener.document.getElementById('<%= (String)Session["txtBillingTotal"] %>');
        //    objBillingDiscount = window.opener.document.getElementById('<%= (String)Session["txtBillingDiscount"] %>');
        //    objBillingPaid = window.opener.document.getElementById('<%= (String)Session["txtBillingPaid"] %>');
        //    objBillingBalance = window.opener.document.getElementById('<%= (String)Session["txtBillingBalance"] %>');
            
        //    objBedCategoryIDDdl = window.opener.document.getElementById('<%= (String)Session["BedCategoryID"] %>');
        //    objBedCategoryName = window.opener.document.getElementById('<%= (String)Session["BedCategoryName"] %>');
        //    objBLBedCategoryIDDdl = window.opener.document.getElementById('<%= (String)Session["BLBedCategoryID"] %>');
        //    objBLBedCategoryName = window.opener.document.getElementById('<%= (String)Session["BLBedCategoryName"] %>');

        //    objDepositAmount = window.opener.document.getElementById('<%= (String)Session["txtDepositAmount"] %>');
        //    objRefundAmount = window.opener.document.getElementById('<%= (String)Session["txtRefundAmount"] %>');
        //    objRefundStatusNote = window.opener.document.getElementById('<%= (String)Session["lblRefundStatusNote"] %>');
        //    objRefundStatusNoteTxt = window.opener.document.getElementById('<%= (String)Session["txtRefundStatusNote"] %>');
        //    objIsRefundVerifiedNote = window.opener.document.getElementById('<%= (String)Session["txtIsRefundVerifiedNote"] %>');
        //    objToRefundAmount = window.opener.document.getElementById('<%= (String)Session["txtToRefundAmount"] %>');

        //    objbtn1 = window.opener.document.getElementById('<%= (String)Session["btn1"] %>');
        //    objbtn2 = window.opener.document.getElementById('<%= (String)Session["btn2"] %>');
        //    objbtn3 = window.opener.document.getElementById('<%= (String)Session["btn3"] %>');
        //    objbtn4 = window.opener.document.getElementById('<%= (String)Session["btn4"] %>');
        //    objbtn5 = window.opener.document.getElementById('<%= (String)Session["btn5"] %>');
        #endregion

        #region Private Variables Declaration


        string m_CurrentPage = String.Empty;
        bool isValid = false;
        private static int intCounter = 0;       

        #endregion

        #region Public Properties

        protected LoginToken LoginToken
        {
            get;
            set;
        }

        #endregion

        #region Constructor
        public BasePage()
        {
            this.PreInit += new EventHandler(BasePage_PreInit);
            this.Load += new EventHandler(BasePage_Load);
            this.Init += new EventHandler(BasePage_Init);
        }

        #endregion

        #region Page level event

        protected void BasePage_PreInit(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["LoginToken"] != null)
            {
                LoginToken = (LoginToken)HttpContext.Current.Session["LoginToken"];
            }
        }

        protected void BasePage_Init(object sender, EventArgs e)
        {

        }

        protected void BasePage_Load(object sender, EventArgs e)
        {
            //get the login token        
            if (LoginToken != null)
            {
                #region Check Authorization -- TODO ondated: 12/09/2010 by Shubhakaran

                //try
                //{
                //    if (Request.Url.AbsolutePath != null)
                //    {
                //        m_CurrentPage = Request.Url.AbsolutePath.ToString().Trim();
                //        if (m_CurrentPage.IndexOf("/") == 0)
                //        {
                //            m_CurrentPage = m_CurrentPage.Substring(1, (m_CurrentPage.Length - 1));
                //        }

                //        if (!String.IsNullOrEmpty(m_CurrentPage))
                //        {
                //            if (Session["Token"] != null)
                //            {
                //                isValid = IsAuthroize(m_CurrentPage);
                //                if (!isValid)
                //                {
                //                    Response.Redirect("~/InvalidRequest.aspx", true);
                //                }
                //            }
                //            else
                //            {
                //                if (m_CurrentPage != "Default.aspx")
                //                {
                //                    Response.Redirect("~/Default.aspx", true);
                //                }
                //            }
                //        }
                //    }
                //}
                //catch (Exception exm)
                //{
                //    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.UIExceptionPolicy, exm, "110001");
                //  LogManager.WriteErrorLogInDB(ex);
                //    DisplayClientMessage(ExceptionMessage.GetMessage("110001"));
                //}

                #endregion
            }
            else
            {
                Response.Redirect("~/Default.aspx", false);
            }
        }

        #endregion

        #region Protected Methods
        /// <summary>
        /// This is used to Display Client Message
        /// </summary>
        /// <param name="Message"></param>
        protected void DisplayClientMessage(string Message)
        {
            if ((Message != null) && Message.Length > 0)
            {
                string script = "<script language=\"javascript\">";
                script += "alert(\"" + Message + "\");";
                script += "</script>";
                intCounter += 1;
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "msg" + this.ID + intCounter.ToString(), script);
            }
        }

        /// <summary>
        /// This is used to Set Page Title
        /// </summary>
        /// <param name="titleText"></param>
        protected void SetPageTitle(string titleText)
        {
            //set page title            
            string script = "<script language='javascript'> ";
            script += " document.title = ('" + titleText + "');";
            script += " </script> ";
            this.Page.ClientScript.RegisterStartupScript(this.GetType(), "setPageTitle", script);
        }

        /// <summary>
        /// Finds a Control recursively. Note finds the first match and exists
        /// </summary>
        /// <param name="Root"></param>
        /// <param name="Id"></param>
        /// <returns></returns>
        protected Control FindControlRecursive(Control Root, string Id)
        {
            if (Root.ID == Id)
                return Root;
            foreach (Control Ctl in Root.Controls)
            {
                Control FoundCtl = FindControlRecursive(Ctl, Id);
                if (FoundCtl != null)
                    return FoundCtl;
            }
            return null;
        }

        #endregion

        #region Private Methods

        private bool IsAuthroize(string PagePath)
        {
            bool isValid = false;
            UserCE objUserCE = null;

            LoginToken objLoginToken = (LoginToken)HttpContext.Current.Session["LoginToken"];
            if (objLoginToken != null)
            {
                // Verify Sitemap files
                foreach (MMIE.Data.Common.SiteMap objSiteMap in objUserCE.SiteMapList)
                {
                    if (String.Compare(PagePath, objSiteMap.Url, true) == 0)
                    {
                        isValid = true;
                        break;
                    }
                }
            }
            return (isValid);
        }

        #endregion
    }

}
