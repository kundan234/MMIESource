using System;
using System.Collections;
using System.Web;
using CrystalDecisions.Shared;
using CrystalDecisions.ReportSource;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;

namespace MMIE.Web.Reports
{

	public enum FormatTypeEnum
	{
		PDF=0,
		MSWord=1,
		MSExcel=2,			
		RichText=3,
		HTML32=4,
		HTML40=5,
		CrystalReport=6
	}

	public class ReportUtil
	{
		public ReportUtil()
		{

		}

		public static Hashtable GetExportFormatType()
		{
			Hashtable htable = new Hashtable();
			
			htable.Add("Portable Document (PDF)",FormatTypeEnum.PDF.ToString().ToLower());
			htable.Add("MS Word (DOC)",FormatTypeEnum.MSWord.ToString().ToLower());
			htable.Add("MS Excel (XLS)",FormatTypeEnum.MSExcel.ToString().ToLower());
			htable.Add("Rich Text (RTF)",FormatTypeEnum.RichText.ToString().ToLower());			
			htable.Add("Crystal Report (RPT)",FormatTypeEnum.CrystalReport.ToString().ToLower());			
			htable.Add("HTML 4.0 (HTML)",FormatTypeEnum.HTML40.ToString().ToLower());
			//htable.Add("HTML 3.2 (HTML)",FormatTypeEnum.HTML32.ToString().ToLower());			
			return htable;
		}		
		

		public ReportDocument SetDatabaseInfo(ReportDocument crReportDocument)
		{		
			
			try
			{
				// CR variables		
				Database crDatabase;
				Tables crTables;
				TableLogOnInfo crTableLogOnInfo;
				ConnectionInfo crConnectionInfo;						
				crConnectionInfo = new ConnectionInfo();

                ReportObjects crReportObjects; 
                Sections crSections;
                ReportDocument crSubreportDocument;
                SubreportObject crSubreportObject;


                //string strServerName = System.Configuration.ConfigurationManager.AppSettings["strServerName"];
                //string strDatabaseName = System.Configuration.ConfigurationManager.AppSettings["strDatabaseName"];
                //string strUid = System.Configuration.ConfigurationManager.AppSettings["strUid"];
                //string strPassword = System.Configuration.ConfigurationManager.AppSettings["strPassword"];



                crConnectionInfo.ServerName = System.Configuration.ConfigurationManager.AppSettings["strServerName"]; ;
                crConnectionInfo.DatabaseName = System.Configuration.ConfigurationManager.AppSettings["strDatabaseName"];
                crConnectionInfo.UserID = System.Configuration.ConfigurationManager.AppSettings["strUid"];
                crConnectionInfo.Password = System.Configuration.ConfigurationManager.AppSettings["strPassword"];
				//Get the tables collection from the report object
				crDatabase = crReportDocument.Database;
				crTables = crDatabase.Tables;
				//Apply the logon information to each table in the collection
				foreach (CrystalDecisions.CrystalReports.Engine.Table crTable in crTables)
				{		
					crTableLogOnInfo = crTable.LogOnInfo;
					crTableLogOnInfo.ConnectionInfo = crConnectionInfo;
					crTable.ApplyLogOnInfo(crTableLogOnInfo);
				}


                crSections = crReportDocument.ReportDefinition.Sections;
                // loop through all the sections to find all the report objects 
                foreach (Section crSection in crSections)
                {
                    crReportObjects = crSection.ReportObjects;
                    //loop through all the report objects in there to find all subreports 
                    foreach (ReportObject crReportObject in crReportObjects)
                    {
                        if (crReportObject.Kind == ReportObjectKind.SubreportObject)
                        {
                            crSubreportObject = (SubreportObject)crReportObject;
                            //open the subreport object and logon as for the general report 
                            crSubreportDocument = crSubreportObject.OpenSubreport(crSubreportObject.SubreportName);
                            crDatabase = crSubreportDocument.Database;
                            crTables = crDatabase.Tables;
                            foreach (CrystalDecisions.CrystalReports.Engine.Table aTable in crTables)
                            {
                                crTableLogOnInfo = aTable.LogOnInfo;
                                crTableLogOnInfo.ConnectionInfo = crConnectionInfo;
                                aTable.ApplyLogOnInfo(crTableLogOnInfo);
                            }
                        }
                    }
                }
                
			}
			catch
			{
				throw;
			}			
			
			return crReportDocument;			
		}

		public ParameterFields SetParameterFields(ParameterFields crParameterFields, Hashtable htable)
		{
          

            ParameterField crParameterField;
			ParameterValues crParameterValues;
			ParameterDiscreteValue crParameterDiscreteValue;			

			try
			{
				//for setting parameter values to main report
				foreach(DictionaryEntry dicEntry in htable)
				{
					crParameterField = crParameterFields[(string)dicEntry.Key];
					crParameterValues = crParameterField.CurrentValues;
					crParameterDiscreteValue = new ParameterDiscreteValue();
					crParameterDiscreteValue.Value = (string)dicEntry.Value;
					crParameterValues.Add(crParameterDiscreteValue);
				}
			}
			catch
			{
				throw;
			}						
			return crParameterFields;
		}

		public ParameterFields SetParameterFields(ParameterFields crParameterFields, Hashtable htable,string subReportName,Hashtable shtable)
		{			
			ParameterField crParameterField;
			ParameterValues crParameterValues;
			ParameterDiscreteValue crParameterDiscreteValue;			

			try
			{
				//for setting parameter values to main report
				foreach(DictionaryEntry dicEntry in htable)
				{
					crParameterField = crParameterFields[(string)dicEntry.Key];
					crParameterValues = crParameterField.CurrentValues;
					crParameterDiscreteValue = new ParameterDiscreteValue();
					crParameterDiscreteValue.Value = (string)dicEntry.Value;
					crParameterValues.Add(crParameterDiscreteValue);
				}

				//for setting parameter values to sub report
				foreach(DictionaryEntry dicEntry in shtable)
				{	
					crParameterField = crParameterFields[(string)dicEntry.Key, subReportName];	
					crParameterValues = crParameterField.CurrentValues;
					crParameterDiscreteValue = new ParameterDiscreteValue();
					crParameterDiscreteValue.Value = (string)dicEntry.Value;
					crParameterValues.Add(crParameterDiscreteValue);
				}

			}
			catch
			{
				throw;
			}						
			return crParameterFields;
		}
		
		public ArrayList ExportReport(ReportDocument crReportDocument,string formatType,Hashtable htable)
		{
			// This subroutine uses a case statement to determine the selected export format from the dropdownlist
			// menu and then sets the appropriate export options for the selected export format.  The report is 
			// exported to a subdirectory called "Exported".

			// ********************************
			//Check to see if the application directory has a subdirectory called "Exported".
			//If not, create the directory since exported files will be placed here.
			//This uses the Directory class of the System.IO namespace.			
			//string fileName = "BilledDemurrageByCustomer";
			//folder name where report file will be saved after exporting
			
			ExportOptions crExportOptions;
			DiskFileDestinationOptions crDiskFileDestinationOptions;

            string reportFolder = HttpContext.Current.Request.PhysicalApplicationPath; //Apmt.Config.ConstantVariable.REPORTFOLDER;
			string fileName = HttpContext.Current.Session.SessionID;
			string tempDir;
			string contentType=null;
			tempDir = HttpContext.Current.Request.PhysicalApplicationPath + reportFolder + "\\";
			if (Directory.Exists(tempDir) == false) Directory.CreateDirectory(HttpContext.Current.Request.PhysicalApplicationPath + reportFolder+ "\\");					
			
			// First we must create a new instance of the diskfiledestinationoptions class and
			// set variable called crExportOptions to the exportoptions class of the reportdocument.
			crDiskFileDestinationOptions = new DiskFileDestinationOptions();
			crExportOptions = crReportDocument.ExportOptions;


			//Find the export type specified in the dropdownlist and export the report. The possible export format
			//types are Rich Text(RTF), Portable Document (PDF), MS Word (DOC), MS Excel (XLS), Crystal Report (RPT),
			//HTML 3.2 (HTML) and HTML 4.0 (HTML)
			//
			//Though not used in this sample application, there are options that can be specified for various format types.
			//When exporting to Rich Text, Word, or PDF, you can use the PdfRtfWordFormatOptions class to specify the
			//first page, last page or page range to be exported.
			//When exporting to Excel, you can use the ExcelFormatOptions class to specify export properties such as
			//the column width etc.

			if (formatType.ToLower() == FormatTypeEnum.RichText.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to RTF. 

				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".rtf";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/msword";

				//set the required report ExportOptions properties
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.RichText;
				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.PDF.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to PDF


				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".pdf";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/pdf";

				//set the required report ExportOptions properties
				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;

				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.MSWord.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to Word


				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".doc";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/msword";

				//set the required report ExportOptions properties
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.WordForWindows;
				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;			
																												
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.MSExcel.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to Excel

				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".xls";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/vnd.ms-excel";

				//set the required report ExportOptions properties
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.Excel;
				ExcelFormatOptions objExcelOptions=new ExcelFormatOptions();
				objExcelOptions.ExcelUseConstantColumnWidth = true;
				objExcelOptions.ExcelConstantColumnWidth = 1500;				
				//crReportDocument.ExportOptions.FormatOptions = objExcelOptions;
				crExportOptions.FormatOptions=objExcelOptions;

				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;
																												
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.CrystalReport.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to Crystal reports:

				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".rpt";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/octet-stream";

				//set the required report ExportOptions properties
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.CrystalReport;
				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;
																												
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.HTML32.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to HTML32:

				fileName+=".htm";
				HTMLFormatOptions HTML32Formatopts = new HTMLFormatOptions();

				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.HTML32;

				HTML32Formatopts.HTMLBaseFolderName = tempDir; //Foldername to place HTML files
				HTML32Formatopts.HTMLFileName = fileName;				
				HTML32Formatopts.HTMLEnableSeparatedPages = false;
				HTML32Formatopts.HTMLHasPageNavigator = false;

				crExportOptions.FormatOptions = HTML32Formatopts;
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.HTML40.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to Html 4.0:
				fileName+=".htm";
				HTMLFormatOptions HTML40Formatopts = new HTMLFormatOptions();

				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.HTML40;

				HTML40Formatopts.HTMLBaseFolderName = tempDir; // Foldername to place HTML files
				HTML40Formatopts.HTMLFileName = fileName;				
				HTML40Formatopts.HTMLEnableSeparatedPages = true;
				HTML40Formatopts.HTMLHasPageNavigator = true;
				HTML40Formatopts.FirstPageNumber = 1;
				HTML40Formatopts.LastPageNumber = 3;

				crExportOptions.FormatOptions = HTML40Formatopts;
				
			} //export format

			//Once the export options have been set for the report, the report can be exported. The Export command
			//does not take any arguments
			string tempFileNameUsed=null;
			try
			{
				//set the Parameter value to crystal report				
				foreach(DictionaryEntry dicEntry in htable)
				{
					crReportDocument.SetParameterValue((string)dicEntry.Key,(string)dicEntry.Value);									
				}				
				//Export the report				
				crReportDocument.Export();
				crReportDocument.Close();							
				
				if (formatType.ToLower() == FormatTypeEnum.HTML32.ToString().ToLower() || formatType.ToLower() == FormatTypeEnum.HTML40.ToString().ToLower())
				{	
					string[] fp = crReportDocument.FilePath.Split("\\".ToCharArray());
					string leafDir = fp[fp.Length-1];
					// strip .rpt extension
					leafDir = leafDir.Substring(0, leafDir.Length - 4);
					tempFileNameUsed = string.Format("{0}{1}\\{2}", tempDir, leafDir, fileName);
				}
				else
					tempFileNameUsed = tempDir + fileName;						
			}
			catch
			{
				throw;
			}
			
			ArrayList al = new ArrayList();
			al.Add(contentType);
			al.Add(tempFileNameUsed);
			return al;
		}	

		public ArrayList ExportReport(ReportDocument crReportDocument,string formatType,Hashtable htable,string subReportName,Hashtable shtable)
		{
			// This subroutine uses a case statement to determine the selected export format from the dropdownlist
			// menu and then sets the appropriate export options for the selected export format.  The report is 
			// exported to a subdirectory called "Exported".

			// ********************************
			//Check to see if the application directory has a subdirectory called "Exported".
			//If not, create the directory since exported files will be placed here.
			//This uses the Directory class of the System.IO namespace.			
			//string fileName = "BilledDemurrageByCustomer";
			//folder name where report file will be saved after exporting
			
			ExportOptions crExportOptions;
			DiskFileDestinationOptions crDiskFileDestinationOptions;

            string reportFolder = HttpContext.Current.Request.PhysicalApplicationPath; // Apmt.Config.ConstantVariable.REPORTFOLDER;
			string fileName = HttpContext.Current.Session.SessionID;
			string tempDir;
			string contentType=null;
			tempDir = HttpContext.Current.Request.PhysicalApplicationPath + reportFolder + "\\";
			if (Directory.Exists(tempDir) == false) Directory.CreateDirectory(HttpContext.Current.Request.PhysicalApplicationPath + reportFolder+ "\\");					
			
			// First we must create a new instance of the diskfiledestinationoptions class and
			// set variable called crExportOptions to the exportoptions class of the reportdocument.
			crDiskFileDestinationOptions = new DiskFileDestinationOptions();
			crExportOptions = crReportDocument.ExportOptions;


			//Find the export type specified in the dropdownlist and export the report. The possible export format
			//types are Rich Text(RTF), Portable Document (PDF), MS Word (DOC), MS Excel (XLS), Crystal Report (RPT),
			//HTML 3.2 (HTML) and HTML 4.0 (HTML)
			//
			//Though not used in this sample application, there are options that can be specified for various format types.
			//When exporting to Rich Text, Word, or PDF, you can use the PdfRtfWordFormatOptions class to specify the
			//first page, last page or page range to be exported.
			//When exporting to Excel, you can use the ExcelFormatOptions class to specify export properties such as
			//the column width etc.

			if (formatType.ToLower() == FormatTypeEnum.RichText.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to RTF. 

				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".rtf";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/msword";

				//set the required report ExportOptions properties
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.RichText;
				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.PDF.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to PDF


				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".pdf";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/pdf";

				//set the required report ExportOptions properties
				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;

				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.MSWord.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to Word


				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".doc";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/msword";

				//set the required report ExportOptions properties
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.WordForWindows;
				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;			
																												
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.MSExcel.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to Excel

				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".xls";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/vnd.ms-excel";

				//set the required report ExportOptions properties
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.Excel;
				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;
																												
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.CrystalReport.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to Crystal reports:

				//append a filename to the export path and set this file as the filename property for
				//the DestinationOptions class
				fileName+=".rpt";
				crDiskFileDestinationOptions.DiskFileName = tempDir + fileName;				
				contentType = "application/octet-stream";

				//set the required report ExportOptions properties
				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.CrystalReport;
				crExportOptions.DestinationOptions = crDiskFileDestinationOptions;
																												
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.HTML32.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to HTML32:

				fileName+=".htm";
				HTMLFormatOptions HTML32Formatopts = new HTMLFormatOptions();

				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.HTML32;

				HTML32Formatopts.HTMLBaseFolderName = tempDir; //Foldername to place HTML files
				HTML32Formatopts.HTMLFileName = fileName;				
				HTML32Formatopts.HTMLEnableSeparatedPages = false;
				HTML32Formatopts.HTMLHasPageNavigator = false;

				crExportOptions.FormatOptions = HTML32Formatopts;
				//--------------------------------------------------------------------
			}
			else if (formatType.ToLower() == FormatTypeEnum.HTML40.ToString().ToLower())
			{
				//--------------------------------------------------------------------
				//Export to Html 4.0:
				fileName+=".htm";
				HTMLFormatOptions HTML40Formatopts = new HTMLFormatOptions();

				crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				crExportOptions.ExportFormatType = ExportFormatType.HTML40;

				HTML40Formatopts.HTMLBaseFolderName = tempDir; // Foldername to place HTML files
				HTML40Formatopts.HTMLFileName = fileName;				
				HTML40Formatopts.HTMLEnableSeparatedPages = true;
				HTML40Formatopts.HTMLHasPageNavigator = true;
				HTML40Formatopts.FirstPageNumber = 1;
				HTML40Formatopts.LastPageNumber = 3;

				crExportOptions.FormatOptions = HTML40Formatopts;
				
			} //export format

			//Once the export options have been set for the report, the report can be exported. The Export command
			//does not take any arguments
			string tempFileNameUsed=null;
			try
			{
				//set the Parameter value to crystal main report				
				foreach(DictionaryEntry dicEntry in htable)
				{
					crReportDocument.SetParameterValue((string)dicEntry.Key,(string)dicEntry.Value);									
				}
				//set the Parameter value to crystal sub report				
				foreach(DictionaryEntry dicEntry in shtable)
				{
					crReportDocument.SetParameterValue((string)dicEntry.Key,(string)dicEntry.Value,subReportName);									
				}

				//Export the report				
				crReportDocument.Export();
				crReportDocument.Close();							
				
				if (formatType.ToLower() == FormatTypeEnum.HTML32.ToString().ToLower() || formatType.ToLower() == FormatTypeEnum.HTML40.ToString().ToLower())
				{	
					string[] fp = crReportDocument.FilePath.Split("\\".ToCharArray());
					string leafDir = fp[fp.Length-1];
					// strip .rpt extension
					leafDir = leafDir.Substring(0, leafDir.Length - 4);
					tempFileNameUsed = string.Format("{0}{1}\\{2}", tempDir, leafDir, fileName);
				}
				else
					tempFileNameUsed = tempDir + fileName;						
			}
			catch
			{
				throw;
			}
			
			ArrayList al = new ArrayList();
			al.Add(contentType);
			al.Add(tempFileNameUsed);
			return al;
		}

	}
	
}
