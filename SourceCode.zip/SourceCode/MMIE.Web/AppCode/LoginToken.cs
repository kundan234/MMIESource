﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Hold login credential (User Detail/Role/Navigation data) as token
/// </summary>

[Serializable]

public class LoginToken
{
    public LoginToken()
    {

    }

    //User Login detail
    public int UserLoginId { get; set; }

    public int UserTypeID { get; set; }
    public string UserTypeCode { get; set; }
    public string UserTypeName { get; set; }

    public string LoginId { get; set; }
    public Guid LoginUniqueId { get; set; }
    public string Password { get; set; }
    public int Status { get; set; }       

    public int FinancialYearID { get; set; }
    public string FinancialYearCode { get; set; }   
    public string FinancialYearName { get; set; }
    public int CompanyID { get; set; }
    public string CompanyCode { get; set; }
    public string CompanyName { get; set; }
    public string CompanyAddress { get; set; }
    public string CompanyPhoneSTDCode { get; set; }
    public string CompanyPhoneNo { get; set; }
    public string CompanyPhoneAltNo { get; set; }
    public string CompanyMobileNo { get; set; }
    public string CompanyFaxNo { get; set; }
    public string CompanyEmailID { get; set; }
    public string CompanyWebsite { get; set; }
    //Role Detail
    public string[] RoleNames { get; set; }
    public int[] RoleIds { get; set; }

    //Navigation Data
    public string NavigationXmlData { get; set; }

    //User Detail (It could be Employee, Customer, Suppilier etc)   
    public int UserDetailID { get; set; }   
    public string FirstName { get; set; }    
    public string LastName { get; set; }    
    public string UserCode { get; set; }    
    public int DesignationID { get; set; }    
    public int DepartmentID { get; set; }    
    public int MaritalStatusID { get; set; }
   
    // Access Role for Buttons such as Delete, Add, Print etc.

    public Boolean IsAddOn { get; set; }
    public Boolean IsModify { get; set; }
    public Boolean IsCancelOn { get; set; }
    public Boolean IsDeleteOn { get; set; }
    public Boolean IsPrintOn { get; set; }
    public Boolean IsPrintExportOn { get; set; }

    public Boolean IsChangeDateOn { get; set; }
    public Boolean IsChangeBranchOn { get; set; }
    public Boolean IsApproverReturnOn { get; set; }
    public Boolean IsApproverReimbursementOn { get; set; }
    public Boolean IsApproverRecievedOn { get; set; }
    public Boolean IsCheckOut { get; set; }
    public Boolean IsRateChangeOn { get; set; }
    public Boolean IsPartialCancellationOn { get; set; }
    public Boolean IsCreditLimitChangeAllowed { get; set; }
    public Boolean IsPartialOrderCancelAllowed { get; set; } 
    




}
