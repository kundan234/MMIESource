
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SAL_UpdateBulkInvoicePayment]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SAL_UpdateBulkInvoicePayment]
GO

Create Proc [dbo].[usp_SAL_UpdateBulkInvoicePayment]      
(      
  @PaymentMode varchar(15)=null      
 ,@PaymentModeNo varchar(25)      
 ,@PaymentSourceID int        
 ,@PaymentAmount money=0.00      
 ,@DepositAmount money=0.00      
 ,@BankID int      
 ,@Expirationdate date =null      
 ,@CustomerID int      
 ,@IsActive bit=1      
 ,@AddedBy varchar(50)      
 ,@LastModBy varchar(50)      
 ,@FinancialYearID smallint      
 ,@CompanyID smallint      
 ,@BillHeaderID int      
 ,@OrderNumber varchar(15)      
 ,@TType varchar(5)      
 ,@Remarks varchar(100)=null      
 ,@TransactionType varchar(100)=null      
 ,@IsSales bit=1      
 ,@CurrencyID int =0      
 ,@CurrencyRate money=0      
       
 ,@InvoiceNumber varchar(500)=null      
 ,@XMLData xml=null      
 ,@PaymentID int output      
)      
      
As      
Begin      
      
/*************************************************************************************************          
          
  Name of the Procedure   : [usp_UpdatePaymentDetails]                         
          
  Created Date     : 20th Sept 2012          
          
  Developer      : Kundan Singh        
          
  Description of the procedure :       
          
  Input Parameters    :       
            
  Output Parameters    : ()         
          
  Result set     : report information        
          
  Assumptions     :         
          
  Modify Date     :         
          
  Modified By Developer   :         
    select * from PaymentDetails      
  Comments      : ()        
  *************************************************************************************************/          
        
Declare @AmountUSD money=0.00      
Declare @Amount money=0.00      
declare @Result int=0       
DECLARE @RC int      
      
BEGIN TRAN SalesInvoicePayment      
BEGIN TRY        
      
      
INSERT INTO [PaymentDetails]      
           ([PaymentMode]      
           ,[PaymentModeNo]      
           ,[PaymentAmount]      
           ,[BankID]      
           ,[Expirationdate]      
           ,[CompanyID]      
           ,[CustomerID]      
           ,[BillHeaderID]      
           ,[ParentID]      
           ,[OrderNumber]      
           ,[Remarks]      
           ,[TransactionType]      
           ,[TType]      
           ,[IsActive]      
           ,[IsSales]      
           ,[AddedBy]      
           ,[AddedDTM]      
           ,[LastModBy]      
           ,[LastModDTM]      
           ,[FinancialYearID]      
           ,[CurrencyID]      
           ,[CurrencyRate]      
           ,[PaymentSourceID]      
           ,[InvoiceNo]      
           )      
     VALUES      
           (      
           @PaymentMode      
           ,@PaymentModeNo      
           ,@PaymentAmount      
           ,@BankID      
           ,@Expirationdate      
           ,@CompanyID      
           ,@CustomerID      
           ,@BillHeaderID      
           ,0      
           ,@OrderNumber      
           ,@Remarks      
           ,@TransactionType      
           ,@TType      
           ,@IsActive      
           ,@IsSales      
           ,@AddedBy      
           ,GETDATE()      
           ,@LastModBy      
           ,GETDATE()      
           ,@FinancialYearID      
           ,@CurrencyID      
           ,@CurrencyRate      
           ,@PaymentSourceID      
           ,@InvoiceNumber      
                
          )      
set @PaymentID=SCOPE_IDENTITY()          
                
update PMT      
set PMT.PaidAmount=PMT.PaidAmount+ISNULL(item.value('@PaidAmount', 'money'),0)       
 ,PMT.DueAmount=ISNULL(item.value('@DueAmount', 'money'),0)       
 ,PMT.LastModBy=@LastModBy      
 ,PMT.LastModDTM=GETDATE()       
FROM SAL_InvoiceHeaderDetails PMT inner join @XMlData.nodes('InvoicePayment') r(item)      
on PMT.InvoiceID = item.value('@InvoiceID', 'Int')      
update CompanyBalanceMST      
set CompanyBalanceAmount=CompanyBalanceAmount + ISNULL(@PaymentAmount,0)      
where CompanyBalanceMST.BranchID=@CompanyID and CompanyBalanceMST.CurrencyID=@CurrencyID and CompanyBalanceMST.PaymentSourceID=@PaymentSourceID      
      
      
if(@CurrencyID=1)      
set @Amount=@PaymentAmount      
else      
set @AmountUSD=@PaymentAmount      
update SAL_BillHeaderDetail       
set PaidGourdesAmount=PaidGourdesAmount+@Amount,PaidUSDAmount=PaidUSDAmount+@AmountUSD,DueGrourdesAmount=DueGrourdesAmount-@Amount,DueUSDAmount=DueUSDAmount-@AmountUSD where BillHeaderID=@BillHeaderID      
  
update CustomerMST        
set DebtAmountGourdes=DebtAmountGourdes-@Amount,DebtAmountUSD=DebtAmountUSD-@AmountUSD where CustomerID=@CustomerID  
  
      
      
if(@PaymentSourceID=4)      
BEGIN      
     
     DECLARE @DTType varchar(2)='DR'           
     DECLARE @adjustRemarks varchar(50)='Amount Adjusted To '+@InvoiceNumber       
     DECLARE @OrderNo varchar(50)=''      
     Declare @Modee int=4      
     set @OrderNo=@OrderNumber      
     -- TODO: Set parameter values here.      
          
     EXECUTE @RC = [usp_UpdateDepositTransactionBalance]       
      @CustomerID      
     ,@DTType      
     ,@CurrencyRate      
     ,@AmountUSD      
     ,@Amount      
     ,@FinancialYearID      
     ,@CompanyID      
     ,@IsActive      
     ,@AddedBy      
     ,@LastModBy      
     ,@adjustRemarks      
     ,1      
     ,@Result OUTPUT      
     ,@OrderNo      
     ,@CurrencyID      
     ,@Modee      
     ,'Deposit'      
      
     update CompanyBalanceMST      
     set CompanyBalanceAmount=CompanyBalanceAmount - ISNULL(@PaymentAmount,0)      
     where CompanyBalanceMST.BranchID=@CompanyID and CompanyBalanceMST.CurrencyID=@CurrencyID and CompanyBalanceMST.PaymentSourceID=4      
      
     --update CompanyBalanceMST      
     --set CompanyBalanceAmount=CompanyBalanceAmount - ISNULL(@PaymentAmount,0)      
     --where CompanyBalanceMST.BranchID=@CompanyID and CompanyBalanceMST.CurrencyID=@CurrencyID and CompanyBalanceMST.PaymentSourceID=4      
         
     --update CompanyBalanceMST      
     --set CompanyBalanceAmount=CompanyBalanceAmount + ISNULL(@PaymentAmount,0)      
     --where CompanyBalanceMST.BranchID=@CompanyID and CompanyBalanceMST.CurrencyID=@CurrencyID and CompanyBalanceMST.PaymentSourceID=1      
      
END      
      
if(@DepositAmount>0)      
BEGIN      
if(@CurrencyID=1)      
set @Amount=@DepositAmount      
else      
set @AmountUSD=@DepositAmount      
Declare @Rem varchar(500)='Balance Amount Transfer From ' +@PaymentMode +' Payment'      
EXECUTE  [dbo].[usp_UpdateDepositTransactionBalance]       
   @CustomerID      
  ,@TType      
  ,@CurrencyRate      
  ,@AmountUSD      
  ,@Amount      
  ,@FinancialYearID      
  ,@CompanyID      
  ,@IsActive      
  ,@AddedBy      
  ,@LastModBy      
  ,@Rem      
  ,1      
  ,@Result OUTPUT      
  ,''      
  ,@CurrencyID      
  ,1      
  ,@PaymentMode    
      
      
      
      
END      
      
      
COMMIT TRAN SalesInvoicePayment      
END TRY         
BEGIN CATCH          
ROLLBACK TRAN SalesInvoicePayment          
PRINT 'Exception Occured'          
END CATCH         
      
END

Go



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SAL_GetBillInvoiceList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SAL_GetBillInvoiceList]
GO

Create PROCEDURE [dbo].[usp_SAL_GetBillInvoiceList]         
(      
@BillHeaderID int=0,      
@ShipmentNumber varchar(50)=null,      
@InvoiceNumber varchar(50)=null,      
@OrderNo varchar(50)=null,      
@CustomerID int=0      
,@CurrencyID int=0      
      
)      
        
/*************************************************************************************************          
          
  Name of the Procedure   : [usp_GetCompanyMST]                              
          
  Created Date     : 19 Oct 2011         
          
  Developer      : Budha        
          
  Description of the procedure : Get Company List         
          
  Input Parameters    : (none)         
  Output Parameters    : (none)         
          
  Result set     : Get Company List          
          
  Assumptions     : --          
          
  Modify Date     : --19 Oct 2011          
          
  Modified By Developer   : -- Budha        
          
  Comments      : ()        
  *************************************************************************************************/          
  as      
        
BEGIN      
if(@BillHeaderID=0) set @BillHeaderID=null      
if(@CustomerID=0) set @CustomerID=null      
if(@CurrencyID=0) set @CurrencyID=null      
      
SELECT     SAL_InvoiceHeaderDetails.BillHeaderID, SAL_BillHeaderDetail.OrderNumber, SAL_InvoiceHeaderDetails.InvoiceID, SAL_InvoiceHeaderDetails.InvoiceNumber,       
                      SAL_InvoiceHeaderDetails.ShipmentNumber, SAL_InvoiceHeaderDetails.TotalAmount, SAL_InvoiceHeaderDetails.PaidAmount, SAL_InvoiceHeaderDetails.DueAmount,       
                      CONVERT(Varchar(20), SAL_InvoiceHeaderDetails.AddedDTM, 101) AS InvoiceDate, SAL_BillHeaderDetail.GroupType, CustomerMST.IsPriceVisible      
                      ,SAL_BillHeaderDetail.CurrencyID,SAL_BillHeaderDetail.CurrencyRate      
FROM         SAL_BillHeaderDetail INNER JOIN      
                      SAL_InvoiceHeaderDetails ON SAL_BillHeaderDetail.BillHeaderID = SAL_InvoiceHeaderDetails.BillHeaderID INNER JOIN      
                      CustomerMST ON SAL_BillHeaderDetail.CustomerID = CustomerMST.CustomerID      
where  SAL_BillHeaderDetail.IsActive=1     
and SAL_InvoiceHeaderDetails.BillHeaderID= ISNULL(@BillHeaderID,SAL_InvoiceHeaderDetails.BillHeaderID)      
and SAL_BillHeaderDetail.CustomerID= ISNULL(@CustomerID,SAL_BillHeaderDetail.CustomerID)      
and SAL_BillHeaderDetail.CurrencyID= ISNULL(@CurrencyID,SAL_BillHeaderDetail.CurrencyID)      
and SAL_InvoiceHeaderDetails.InvoiceNumber like +'%'+ISNULL(@InvoiceNumber,'')+'%'      
and SAL_InvoiceHeaderDetails.ShipmentNumber like +'%'+ISNULL(@ShipmentNumber,'')+'%'      
and SAL_InvoiceHeaderDetails.OrderNumber like +'%'+ISNULL(@OrderNo,'')+'%'      
      
order by  SAL_InvoiceHeaderDetails.BillHeaderID,SAL_InvoiceHeaderDetails.InvoiceID      
END

Go



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SAL_GetOrderPartialDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SAL_GetOrderPartialDetails]
GO

CREATE PROCEDURE [dbo].[usp_SAL_GetOrderPartialDetails]    
(                
  @OrderNumber   VARCHAR(15) =NULL,              
  @CustomerName VARCHAR(100) = NULL,              
  @PhoneNumber VARCHAR(15)=NULL              
)                
AS                
BEGIN                
DECLARE @QUERY VARCHAR(MAX)        
SET @QUERY=''        
SET @QUERY= 'SELECT             
SAL_BillHeaderDetail.OrderNumber AS OrderNo,SAL_BillHeaderDetail.GroupType AS GroupType,CustomerMST.CustomerID,         
CustomerMST.CustomerName AS CustomerName,CustomerMST.CustomerAddress AS CustomerAddress,         
CustomerMST.CustomerPhone AS CustomerPhone,CustomerMST.CustomerEmail AS CustomerEmail,        
CustomerMST.CustomerStreet AS CustomerStreet,CustomerMST.IsPriceVisible,SAL_BillHeaderDetail.CurrencyID, SAL_BillHeaderDetail.BillHeaderID       
        
FROM       SAL_BillHeaderDetail INNER JOIN CustomerMST         
           ON SAL_BillHeaderDetail.CustomerID = CustomerMST.CustomerID     
           INNER JOIN (Select BillHeaderID,SUM(Qty-DeliveryQty-CancelQty) Qty from SAL_ProductSaleDetail group by BillHeaderID) P    
           ON  SAL_BillHeaderDetail.BillHeaderID=P.BillHeaderID           
WHERE      SAL_BillHeaderDetail.IsActive=1'        
                   
  + case when (@OrderNumber ='') then '' else ' AND SAL_BillHeaderDetail.OrderNumber=' + ''''+@OrderNumber +''' ' end        
  + case when (@CustomerName ='') then '' else ' AND CustomerMST.CustomerName like ' + ''''+'%'+@CustomerName +'%'+''''  end        
  + case when (@PhoneNumber ='') then '' else ' AND CustomerMST.CustomerPhone='+ ''''+@PhoneNumber +'''' end        
          
  EXEC(@QUERY)        
        
 --print @QUERY      
               
 END 
 
 GO
 
 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_PUR_UpdateInvoiceHeaderDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_PUR_UpdateInvoiceHeaderDetails]
GO

 Create procedure [dbo].[usp_PUR_UpdateInvoiceHeaderDetails]     
(  
@InvoiceHeaderID int=0,     
@InvoiceNo varchar(100),           
@AddedBy varchar(50),          
@LastModBy varchar(50),         
@CompanyID  int,         
--@AmountGourdes varchar(1000)=null,  
--@GourdesDesc  varchar(1000),        
--@OtherChargeID varchar(1000)=null,  
@CustomerID int,        
@GroupType   int,       
@ActionType int   -- 1 is used for parts 2 is used for vehicle   
,@TotalCostPrice Money=0  
,@TotalInsurance Money=0  
,@TotalFrieght Money=0  
,@TotalOtherCharges money=0  
,@TotalInvoiceAmount money=0  
,@PONumber int =0    
  
,@TotalQty int =0  
,@FinancialYearID int=0  
,@CurrencyID int=0  
,@CurrencyRate money=0  
,@InvoiceDueDate date=null  
,@ShipmentNumber varchar(50)=null  
,@ContainerNumber varchar(50)=null  
,@XMLData xml=null  
,@Remarks varchar(100)=null  
,@XMLCharges xml=null  
,@StoreID int=0  
,@Result varchar(50) output  
,@XMLItems xml=null  
,@PerUnitCharges money=0  
 )        
AS                
    
  /*************************************************************************************************      
      
  Name of the Procedure   : usp_PUR_UpdateInvoiceHeaderDetails                   
      
  Created Date     : 4 aprril 2011      
      
  Developer      : Kundan singh  
      
  Description of the procedure :   
      
  Input Parameters    : (3)     
  Output Parameters    : (none)     
      
  Result set     : insert  information    
      
  Assumptions     :     
      
  Modify Date     :     
      
  Modified By Developer   :     
      
  Comments      : ()    
  usp_GETCustomerDepositRPT '11/20/2011', '12/31/2011',4  
  *************************************************************************************************/  
  
    
           
BEGIN      
  
--DECLARE @VehicleReceivingID int=0   ;  
----Declare @OtherCharges money=0;  
--DECLARE @Amount money   =0   
--DECLARE @Desc varchar(100)      
--DECLARE @VehicleAmount money    =0  
--DECLARE @VehicleDesc varchar(100)  
--declare @ChargeID int=0  
--Declare @PerunitExp money=0  
--set @PerunitExp=(@TotalFrieght+@TotalInsurance+@TotalOtherCharges)/@TotalQty  
  
---BEGIN Variables For the Transactions  
  
Declare @ProductID int=0  
Declare @ReceivedQty float=0  
Declare @IntID int=0  
  
---Variables END  
  
if(@ActionType =1)  
BEGIN  
  
  
Begin Try  
  
BEGIN Tran UpdateInvoiceHeaderDetail  
INSERT INTO [PUR_InvoiceHeaderDetail]  
           ([InvoiceNo]  
        
        --   ,[InvoiceDate]  
           ,[SupplierID]  
           ,[GroupTypeID]  
           ,[CompanyID]  
           ,[AddedBy]  
           ,[AddedDTM]  
           ,[LastModBy]  
           ,[LastModDTM]  
           ,[TotalCostPrice]  
           ,[TotalInsurance]  
           ,[TotalFrieght]  
           ,[TotalQty]  
           ,[TotalOtherCharges]  
           ,[TotalInvoiceAmount]  
           ,[PaidAmount]  
         --  ,[Remarks]  
           ,[IsActive]  
           ,[FinancialYearID]  
           --,[CurrencyID]  
           --,[CurrencyRate]  
           --,[InvoiceDueDate]  
           ,[ContainerNumber]  
           --,[ShipmentNumber]  
           ,[PONumber]  
           ,[CurrencyID]   
          ,[CurrencyRate]   
          ,[InvoiceDueDate]  
          ,[ShipmentNumber]   
            
           )  
     VALUES  
           (  
             
           @InvoiceNo  
             
           
        --   ,@InvoiceDate  
           ,@CustomerID  
           ,@GroupType  
           ,@CompanyID  
           ,@AddedBy  
           ,GETDATE()  
           ,null  
           ,null  
           ,@TotalCostPrice  
           ,@TotalInsurance  
           ,@TotalFrieght  
           ,@TotalQty  
           ,@TotalOtherCharges  
           ,@TotalInvoiceAmount  
           ,0  
          -- ,@Remarks  
           ,1  
           ,@FinancialYearID  
           --,@CurrencyID  
           --,@CurrencyRate  
           ,@ContainerNumber  
           --,@ShipmentNumber, varchar(50),>  
           ,@PONumber  
          ,@CurrencyID   
          ,@CurrencyRate   
          ,@InvoiceDueDate  
          ,@ShipmentNumber    
         )  
--- Update Data in whole system regarding the vehical or Item recieving   
update POrd  
   set POrd.RecievedQty=POrd.RecievedQty+  ISNULL(item.value('@Qty', 'int'),0)   
   ,POrd.LastModBy=@LastModBy   
   ,POrd.LastModDTM=GETDATE()   
   FROM PUR_ProductPurchageOrderDetail  POrd, @XMlData.nodes('PurchaseOrderRecievedlst') r(item)  
  
   where  POrd.ProductID= item.value('@ProductID', 'int')   
   and  
   POrd.PONumber= @PONumber  
---------------------------------------  
  --update POrd  
  -- set POrd.AvailableQty=ISNULL(POrd.AvailableQty,0)+  ISNULL(item.value('@RecievedQty', 'int'),0)   
  -- ,POrd.LastModBy=@LastModBy   
  -- ,POrd.LastModDTM=GETDATE()   
  -- FROM ProductMST  POrd, @XMlData.nodes('PurchaseOrderRecievedlst') r(item)  
  
  -- where  POrd.ProductID= item.value('@ProductID', 'int')  
---------------------------------------------------------  
select top 1 @InvoiceHeaderID=InvoiceHeaderID from PUR_InvoiceHeaderDetail order by InvoiceHeaderID desc  
-----------------------------------------------------------  
update PUR_OrderHeader  
set PUR_OrderHeader.InvoiceHeaderID=@InvoiceHeaderID,PUR_OrderHeader.InvoiceNo=@InvoiceNo,PUR_OrderHeader.SupplierID=@CustomerID  
,CurrencyID=@CurrencyID,CurrencyRate=@CurrencyRate  
where PUR_OrderHeader.PONumber=@PONumber  
---------------------------------------  
IF(@GroupType=1)  
BEGIN  
INSERT INTO [PUR_VehicleRecevingDetail]  
           ([ContainerNumber]  
           ,[ProductID]  
           ,[VinNo]  
           ,[EngineNo]  
           ,[Qty]  
           ,[UnitID]  
          -- ,[UnitPriceUSD]  
          -- ,[UnitPriceGourdes]  
           ,[InvoiceNo]  
           ,[Sold]  
           --,[Retailer1]  
           --,[Retailer2]  
           --,[Dealer]  
           --,[CreditRate]  
           ,[FinancialYearID]  
           ,[StoreID]  
           ,[CompanyID]  
           ,[AddedBy]  
           ,[AddedDTM]  
             
           ,[PONumber]  
           ,[Model]  
           ,[IsApproved]  
           ,[ApproverRemarks]  
           ,[IsReturned]  
           ,[ReturnRemarks]  
           --,[CostPrice]  
           --,[UnitName]  
             
           )  
             
                      
     
 select  
           
            item.value('@ContainerNo', 'varchar(50)') ContainerNo  
           ,item.value('@ProductID', 'int') ProductID  
           ,item.value('@VinNo', 'varchar(50)') VinNo  
        ,item.value('@EngineNo', 'varchar(50)') EngineNo  
           ,1  
           ,0  
          -- ,<UnitPriceUSD, money,>  
         --  ,<UnitPriceGourdes, money,>  
           ,@InvoiceNo  
           ,0  
           --,<Retailer1, money,>  
           --,<Retailer2, money,>  
           --,<Dealer, money,>  
           --,<CreditRate, money,>  
           ,@FinancialYearID  
           ,@StoreID  
           ,@CompanyID  
           ,@AddedBy  
           ,getdate()  
             
           ,@PONumber  
       ,item.value('@ModelNo', 'varchar(50)') ModelNo  
           ,0  
           ,''  
           ,0  
           ,''  
           --,<CostPrice, money,>  
           --,<UnitName, varchar(50),>  
                     
             
       FROM @XMLItems.nodes('ItemList ') r(item);     
  
END  
  
if(@GroupType=2)  
BEGIN  
 --INSERT INTO [dbo].[PUR_PartRecevingOtherCharges]  
--           (  
--           [TransactionID]  
--           ,[USDAmt]  
--           ,[GourdesAmt]  
--           ,[ChargeCategory]  
--           ,[GourdesDescription]  
--           ,[CompanyID]  
--           ,[IsActive]  
--           ,[AddedBy]  
--           ,[AddedDTM]  
--           ,[LastModBy]  
--           ,[LastModDTM]  
--           ,[PONumber]  
--           ,[InvoiceHeaderID]  
--           )  
             
--           declare @XMLCharges xml='<OtherCharges ChargeID =  "2 " ChargeRate =  "1000 " ChargeName =  "Test Other Charge " /><OtherCharges ChargeID =  "3 " ChargeRate =  "600 " ChargeName =  "Test2 " /><OtherCharges ChargeID =  "6 " ChargeRate =  "25 " ChargeName =  "Test Charge-10001 " />'  
            
-- SELECT    
--    '',          
--    item.value('@ChargeRate', 'money') ChrageRate              
--    ,item.value('@ChargeID', 'int') ChargeCategoryID  
--    ,item.value('@ChargeName', 'Varchar(50)') ChrageName         
--    ,@CompanyID [CompanyID]    
--    --,@FinancialYearID [FinancialYearID]          
--    ,1     
--    ,@AddedBy [AddedBy]      
--    ,GETDATE() [AddedDTM]          
--    ,NULL [LastModBy]          
--    ,NULL [LastModDTM]    
--    ,@PONumber  
--    ,@InvoiceHeaderID    
--     FROM @XMLCharges.nodes('OtherCharges') r(item)  

 INSERT INTO [PUR_PartRecevingDetail]  
           ([ContainerNumber]  
           ,[ProductID]  
           ,[Qty]  
           ,[UnitID]  
           --,[UnitPriceUSD]  
           ,[UnitPriceGourdes]  
           ,[InvoiceNo]  
           --,[Retailer1]  
           --,[Retailer2]  
           --,[Dealer]  
           --,[CreditRate]  
           ,[FinancialYearID]  
           ,[StoreID]  
           ,[CompanyID]  
           ,[AddedBy]  
           ,[AddedDTM]  
           --,[LastModBy]  
           --,[LastModDTM]  
           ,[PONumber]  
           ,[Model]  
           ,[IsApproved]  
           ,[ApproverRemarks]  
           ,[IsReturned]  
           ,[ReturnRemarks]  
           ,[CostPrice]  
           ,[UnitName]
           )  
            
      
    select             
       item.value('@ContainerNo', 'varchar(50)') containerNo  
         ,item.value('@ProductID', 'Int') ProductID  
          , item.value('@Qty', 'int') [Qty]   
           ,item.value('@UnitID', 'Int') UnitID  
       ,item.value('@UnitPrice', 'Money') [UnitPrice]        
         
           ,  @InvoiceHeaderID    
           --,<Retailer1, money,>  
           --,<Retailer2, money,>  
           --,<Dealer, money,>  
           --,<CreditRate, money,>  
           ,@FinancialYearID  
           ,@StoreID  
           ,@CompanyID  
           ,@AddedBy  
           ,GETDATE()  
           --,@LastModBy  
          -- ,@LastModDTM, datetime,>  
           ,@PONumber  
           ,item.value('@Model', 'Varchar(50)') [Model]   
           ,0  
           ,''  
           ,0  
           ,0  
         ,item.value('@CostPrice', 'Money') CostPrice     
         ,item.value('@UnitName', 'Varchar(50)') UnitName   
             
       FROM @XMLData.nodes('PurchaseOrderRecievedlst ') r(item);     
END  

INSERT INTO [PUR_VehicleRecevingOtherCharges]  
    (  
    [VehicleRecevingID]  
    --  ,[USDAmt]  
    ,[GourdesAmt]  
    ,[ChargeCategory]  
    ,[GourdesDescription]  
    ,[CompanyID]  
    ,[IsActive]  
    ,[AddedBy]  
    ,[AddedDTM]  
    ,[LastModBy]  
    ,[LastModDTM]  
    ,[PONumber]  
    ,[InvoiceHeaderID]  
    ,[CurrencyID]  
    ,[CurrencyRate]  
    )  
    SELECT    
    ''  
    ,item.value('@ChargeRate', 'money') ChrageRate               
    ,item.value('@ChargeID', 'int') ChargeCategoryID  
    ,item.value('@ChargeName', 'Varchar(50)') ChrageName         
    ,@CompanyID [CompanyID]    
    --,@FinancialYearID [FinancialYearID]          
    ,1     
    ,@AddedBy [AddedBy]      
    ,GETDATE() [AddedDTM]          
    ,NULL [LastModBy]          
    ,NULL [LastModDTM]    
    ,@PONumber  
    ,@InvoiceHeaderID  
    ,item.value('@CurrencyID', 'int') ChargeCategoryID  
    ,item.value('@CurrencyRate', 'money') Rate               
      FROM @XMLCharges.nodes('OtherCharges') r(item)  
      
-- TODO: Set parameter values here.  
INSERT INTO [PUR_InvoiceHeaderItemDetails]   
     (  
       
   [InvoiceHeaderID]  
   ,[PONumber]  
   ,[InvoiceNo]  
   ,[ProductID]  
   ,[Model]  
   ,[RecievedQty]  
   ,[UnitName]  
   ,[UnitPrice]  
   ,[Amount]  
   ,[FinancialYearID]  
   ,[CompanyID]  
   ,[AddedBy]  
   ,[AddedDTM]  
   ,[LastModBy]  
   ,[LastModDTM]  
   ,[IsActive]  
   ,[PerUnitExpense]  
   ,[CostPrice]  
   ,[UnitID]  
   ,[StoreID]  
           )  
     SELECT         
   @InvoiceHeaderID      [InvoiceHeaderID]    
   ,@PONumber [PONumber]  
   ,@InvoiceNo [InvoiceNo]  
   ,item.value('@ProductID', 'Int') ProductID,  
   item.value('@Model', 'Varchar(50)') [Model]   
   ,item.value('@RecievedQty', 'int') [RecievedQty]             
   ,item.value('@UnitName', 'Varchar(15)') [Unit]            
   ,item.value('@UnitPrice', 'Money') [UnitPrice]        
   ,item.value('@TotalAmount', 'Money') [Amount]      
   ,@FinancialYearID [FinancialYearID]            
   ,@CompanyID [CompanyID]      
   ,@AddedBy [AddedBy]      
   ,GETDATE() [AddedDTM]            
   ,@LastModBy [LastModBy]                
   ,GETDATE() [LastModDTM]      
   ,1 [IsActive]     
   --,@PerUnitExp  
   ,@PerUnitCharges  --item.value('@PerUnitExpense', 'Money') PerUnitExpense      
   ,item.value('@CostPrice', 'Money')  
   ,item.value('@UnitID', 'int') UnitID  
   ,@StoreID  
      FROM @XMLData.nodes('PurchaseOrderRecievedlst ') r(item);     
      
 if( CURSOR_STATUS('global','CursorInv')>-1)  
 BEGIN  
 Deallocate CursorInv  
 END  
 DECLARE CursorInv Cursor for     
   SELECT               
   @StoreID  
   , item.value('@ProductID', 'Int') ProductID  
   ,item.value('@RecievedQty', 'float') [RecievedQty]             
   FROM @XMLData.nodes('PurchaseOrderRecievedlst ') r(item)  
 OPEN CursorInv      
 FETCH NEXT FROM CursorInv INTO @StoreID,@ProductID,@ReceivedQty  
 WHILE @@FETCH_STATUS = 0       
 BEGIN     
   if( Exists (Select * from INV_StockInformation where ProductID= @ProductID and StoreID=@StoreID))  
   BEGIN  
   update INV_StockInformation   
   set AvailableQty=AvailableQty+@ReceivedQty,  
   LastModBy=@AddedBy  
   ,LastModDTM=GETDATE()  
   where ProductID=@ProductID and StoreID= @StoreID  
  -- print @ProductID   
   END  
   Else  
   BEGIN  
   INSERT INTO [INV_StockInformation]  
      ([ProductID]  
      ,[AvailableQty]  
      ,[AdjustQty]  
      ,[CompanyID]  
      ,[StoreID]  
      ,[GroupType]  
      ,[AddedBy]  
      ,[AddedDTM]  
     )  
   VALUES  
   (   @ProductID  
      ,@ReceivedQty  
      ,0  
      ,@CompanyID  
      ,@StoreID  
      ,@GroupType  
      ,@AddedBy  
      ,GETDATE()  
   )  
    -- Print 'Insert'  
 END  
   
   FETCH NEXT FROM CursorInv INTO @StoreID,@ProductID,@ReceivedQty  
   END  
   Close CursorInv  
   deallocate  CursorInv  
    
      set @Result='Complete'  
Commit Tran UpdateInvoiceHeaderDetail  
END try  
BEGIN Catch  
  Rollback  Tran UpdateInvoiceHeaderDetail  
  Print 'Exception Caught'   
  Close CursorInv  
  deallocate  CursorInv  
end catch  
END  
if(@ActionType=2)  
BEGIN  
  
Begin Try  
BEGIN Tran UpdateInvoiceHeaderDetail  
  
UPDATE [dbo].[PUR_InvoiceHeaderDetail]  
   SET   
      [InvoiceDate] = GETDATE()  
      ,[LastModBy] = @LastModBy  
      ,[LastModDTM] = GETDATE()  
      ,[TotalCostPrice] =[TotalCostPrice]+ @TotalCostPrice   
      ,[TotalInsurance] =[TotalInsurance]+ @TotalInsurance  
      ,[TotalFrieght] = [TotalFrieght] +@TotalFrieght  
      ,[TotalQty] = @TotalQty+[TotalQty]   
      ,[TotalOtherCharges] =[TotalOtherCharges] + @TotalOtherCharges  
      ,[TotalInvoiceAmount] = @TotalInvoiceAmount  
      ,[CurrencyID] = @CurrencyID  
      ,[CurrencyRate] = @CurrencyRate  
      ,[InvoiceDueDate] = @InvoiceDueDate  
      ,[ContainerNumber] = @ContainerNumber  
      ,[ShipmentNumber] = @ShipmentNumber  
   WHERE InvoiceHeaderID =@InvoiceHeaderID  
update POrd  
  set POrd.RecievedQty=POrd.RecievedQty+  ISNULL(item.value('@Qty', 'int'),0)   
  ,POrd.LastModBy=@LastModBy   
  ,POrd.LastModDTM=GETDATE()   
  FROM PUR_ProductPurchageOrderDetail  POrd, @XMlData.nodes('PurchaseOrderRecievedlst') r(item)  
  
  where  POrd.ProductID= item.value('@ProductID', 'int')   
  and  
  POrd.PONumber= @PONumber  
  
IF(@GroupType=1)  
BEGIN  
INSERT INTO [PUR_VehicleRecevingDetail]  
           ([ContainerNumber]  
           ,[ProductID]  
           ,[VinNo]  
           ,[EngineNo]  
           ,[Qty]  
           ,[UnitID]  
          -- ,[UnitPriceUSD]  
          -- ,[UnitPriceGourdes]  
           ,[InvoiceNo]  
           ,[Sold]  
           --,[Retailer1]  
           --,[Retailer2]  
           --,[Dealer]  
           --,[CreditRate]  
           ,[FinancialYearID]  
           ,[StoreID]  
           ,[CompanyID]  
           ,[AddedBy]  
           ,[AddedDTM]  
             
           ,[PONumber]  
           ,[Model]  
           ,[IsApproved]  
           ,[ApproverRemarks]  
           ,[IsReturned]  
           ,[ReturnRemarks]  
           --,[CostPrice]  
           --,[UnitName]  
             
           )  
             
                      
     
 select  
           
    item.value('@ContainerNo', 'varchar(50)') ContainerNo  
           ,item.value('@ProductID', 'int') ProductID  
           ,item.value('@VinNo', 'varchar(50)') VinNo  
        ,item.value('@EngineNo', 'varchar(50)') EngineNo  
           ,1  
           ,0  
          -- ,<UnitPriceUSD, money,>  
         --  ,<UnitPriceGourdes, money,>  
           ,@InvoiceNo  
           ,0  
           --,<Retailer1, money,>  
           --,<Retailer2, money,>  
           --,<Dealer, money,>  
           --,<CreditRate, money,>  
           ,@FinancialYearID  
           ,@StoreID  
           ,@CompanyID  
           ,@LastModBy  
           ,getdate()  
             
           ,@PONumber  
       ,item.value('@ModelNo', 'varchar(50)') ModelNo  
           ,0  
           ,''  
           ,0  
           ,''  
           --,<CostPrice, money,>  
           --,<UnitName, varchar(50),>  
                     
             
       FROM @XMLItems.nodes('ItemList ') r(item);     
END  
  
if(@GroupType=2)  
BEGIN  
INSERT INTO [PUR_PartRecevingDetail]  
  ([ContainerNumber]  
  ,[ProductID]  
  ,[Qty]  
  ,[UnitID]  
  --,[UnitPriceUSD]  
  ,[UnitPriceGourdes]  
  ,[InvoiceNo]  
  --,[Retailer1]  
  --,[Retailer2]  
  --,[Dealer]  
  --,[CreditRate]  
  ,[FinancialYearID]  
  ,[StoreID]  
  ,[CompanyID]  
  ,[AddedBy]  
  ,[AddedDTM]  
  --,[LastModBy]  
  --,[LastModDTM]  
  ,[PONumber]  
  ,[Model]  
  ,[IsApproved]  
  ,[ApproverRemarks]  
  ,[IsReturned]  
  ,[ReturnRemarks]  
  ,[CostPrice]  
  ,[UnitName])  
select  
 item.value('@ContainerNo', 'varchar(50)') containerNo  
  ,item.value('@ProductID', 'Int') ProductID  
  , item.value('@Qty', 'int') [Qty]   
  ,item.value('@UnitID', 'int') UnitID  
  ,item.value('@UnitPrice', 'Money') [UnitPrice]        
  , @InvoiceHeaderID    
  ,@FinancialYearID  
  ,@StoreID  
  ,@CompanyID  
  ,@LastModBy  
  ,GETDATE()  
  ,@PONumber  
  ,item.value('@Model', 'Varchar(50)') [Model]   
  ,0  
  ,''  
  ,0  
  ,0  
  ,item.value('@CostPrice', 'Money') CostPrice     
  ,item.value('@UnitName', 'Varchar(50)') UnitName              
       FROM @XMLData.nodes('PurchaseOrderRecievedlst ') r(item);     
END  
INSERT INTO [PUR_VehicleRecevingOtherCharges]  
 (  
    [VehicleRecevingID]  
    --  ,[USDAmt]  
    ,[GourdesAmt]  
    ,[ChargeCategory]  
    ,[GourdesDescription]  
    ,[CompanyID]  
    ,[IsActive]  
    ,[AddedBy]  
    ,[AddedDTM]  
    ,[LastModBy]  
    ,[LastModDTM]  
    ,[PONumber]  
    ,[InvoiceHeaderID]  
    ,[CurrencyID]  
    ,[CurrencyRate]  
 )  
      
 SELECT    
    ''  
    ,item.value('@ChargeRate', 'money') ChrageRate               
    ,item.value('@ChargeID', 'int') ChargeCategoryID  
    ,item.value('@ChargeName', 'Varchar(50)') ChrageName         
    ,@CompanyID [CompanyID]    
    --,@FinancialYearID [FinancialYearID]          
    ,1     
    ,@LastModBy [AddedBy]      
    ,GETDATE() [AddedDTM]          
    ,NULL [LastModBy]          
    ,NULL [LastModDTM]    
    ,@PONumber  
    ,@InvoiceHeaderID  
    ,item.value('@CurrencyID', 'int') ChargeCategoryID  
    ,item.value('@CurrencyRate', 'money') Rate                   
      FROM @XMLCharges.nodes('OtherCharges') r(item)  
INSERT INTO [PUR_InvoiceHeaderItemDetails]   
     (  
   [InvoiceHeaderID]  
   ,[PONumber]  
   ,[InvoiceNo]  
   ,[ProductID]  
   ,[Model]  
   ,[RecievedQty]  
   ,[UnitName]  
   ,[UnitPrice]  
   ,[Amount]  
   ,[FinancialYearID]  
   ,[CompanyID]  
   ,[AddedBy]  
   ,[AddedDTM]  
   ,[LastModBy]  
   ,[LastModDTM]  
   ,[IsActive]  
   ,[PerUnitExpense]  
   ,[CostPrice]  
   ,[UnitID]  
   ,[StoreID]  
       )  
     SELECT      
   @InvoiceHeaderID      [InvoiceHeaderID]    
   ,@PONumber [PONumber]  
   ,@InvoiceNo [InvoiceNo]  
   ,item.value('@ProductID', 'Int') ProductID,  
   item.value('@Model', 'Varchar(50)') [Model]   
   ,item.value('@Qty', 'int') [RecievedQty]             
   ,item.value('@UnitName', 'Varchar(15)') [Unit]            
   ,item.value('@UnitPrice', 'Money') [UnitPrice]        
   ,item.value('@TotalAmount', 'Money') [Amount]      
   ,@FinancialYearID [FinancialYearID]            
   ,@CompanyID [CompanyID]      
   ,@LastModBy [AddedBy]      
   ,GETDATE() [AddedDTM]            
   ,@LastModBy [LastModBy]                
   ,GETDATE() [LastModDTM]      
   ,1 [IsActive]     
   --,@PerUnitExp  
  ,@PerUnitCharges  --item.value('@PerUnitExpense', 'Money') PerUnitExpense      
   ,item.value('@CostPrice', 'Money') CostPrice  
   ,item.value('@UnitID', 'int') UnitID  
   ,@StoreID  
      FROM @XMLData.nodes('PurchaseOrderRecievedlst ') r(item);     
   
 if( CURSOR_STATUS('global','CursorInv')>-1)  
 BEGIN  
 Deallocate CursorInv  
 END  
 DECLARE CursorInv Cursor for     
   SELECT               
   @StoreID  
   , item.value('@ProductID', 'Int') ProductID  
   ,item.value('@RecievedQty', 'float') [RecievedQty]             
   FROM @XMLData.nodes('PurchaseOrderRecievedlst ') r(item)  
 OPEN CursorInv      
 FETCH NEXT FROM CursorInv INTO @StoreID,@ProductID,@ReceivedQty  
 WHILE @@FETCH_STATUS = 0       
 BEGIN     
   if( Exists (Select * from INV_StockInformation where ProductID= @ProductID and StoreID=@StoreID))  
   BEGIN  
   update INV_StockInformation   
   set AvailableQty=AvailableQty+@ReceivedQty,  
   LastModBy=@LastModBy  
   ,LastModDTM=GETDATE()  
   
   where ProductID=@ProductID and StoreID= @StoreID  
   --print @ProductID   
   END  
   Else  
   BEGIN  
   INSERT INTO [INV_StockInformation]  
      ([ProductID]  
      ,[AvailableQty]  
      ,[AdjustQty]  
      ,[CompanyID]  
      ,[StoreID]  
      ,[GroupType]  
      ,[AddedBy]  
      ,[AddedDTM]  
     )  
   VALUES  
   (   @ProductID  
      ,@ReceivedQty  
      ,0  
      ,@CompanyID  
      ,@StoreID  
      ,@GroupType  
      ,@LastModBy  
      ,GETDATE()  
   )  
    -- Print 'Insert'  
 END  
   
   FETCH NEXT FROM CursorInv INTO @StoreID,@ProductID,@ReceivedQty  
   END  
   Close CursorInv  
   deallocate  CursorInv  
    
        
Commit Tran UpdateInvoiceHeaderDetail  
set @Result='Complete'  
END try  
BEGIN Catch  
   
 Print 'Exception Caught'  
 Rollback  Tran UpdateInvoiceHeaderDetail  
  Close CursorInv  
  deallocate  CursorInv  
END Catch  
  
END   
END  
  
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SAL_PartialOrderCancellation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SAL_PartialOrderCancellation]
GO 
Create Procedure [dbo].[usp_SAL_PartialOrderCancellation]  
@BillHeaderID bigint,  
@CustomerID int,  
@XMLData xml,  
@OpeningBalance money,  
@LastModBy varchar(50),  
@CancelAmt money  
  
As  
Begin  
BEGIN TRAN UPDATEPARTPARTIALCANCEL  
BEGIN TRY    
    
Declare @CurrencyID int=1 
update PUR      
set       
PUR.CancelQty= PUR.CancelQty+  item.value('@CancelQty', 'int')      
,PUR.LastModBy = @LastModBy      
,PUR.LastModDTM=GETDATE()    
FROM SAL_ProductSaleDetail PUR inner join  @XMlData.nodes('PartialCancel') r(item)   
on PUR.ProductSaleID=   item.value('@ProductSaleID', 'bigint')     
where PUR.ProductSaleID = item.value('@ProductSaleID', 'bigint')       
 
declare @FinancialYearID int
DECLARE @ParentID int  
declare @CompanyID int
declare @PaymentSourceID int
DECLARE @TType varchar(5)   
Declare @OrderNumber varchar(50)='ORD'+Convert(varchar,@BillHeaderID)
Declare @CommonAmount money=0.00  
declare @CurrencyRate money=0  
DECLARE @PaymentAmountUSD money=0.00  

select @ParentID=PaymentDetailsId,@PaymentSourceID=PaymentSourceID from PaymentDetails Where BillHeaderID=@BillHeaderID and TType='CR' order by PaymentDetailsId desc  

Select @CurrencyID=CurrencyID,@FinancialYearID=FinancialYearID,@CompanyID=CompanyID from SAL_BillHeaderDetail Where BillHeaderID=@BillHeaderID
Update SAL_BillHeaderDetail SET CancelAmt=CancelAmt+ @CancelAmt ,LastModDTM=GETDATE(),LastModBy=@LastModBy where BillHeaderID=@BillHeaderID 

if(Select COUNT(*) From SAL_BillHeaderDetail where BillHeaderID=@BillHeaderID and  UPPER(PaymentMode)='CASH')>0  
begin
if @CurrencyID=1
begin
Update CustomerMST Set OpeningBalance =OpeningBalance+@OpeningBalance,ModifiedDate=GETDATE(),ModifiedBy=@LastModBy where CustomerID=@CustomerID  
SET @CommonAmount=@OpeningBalance
end
else
begin
Update CustomerMST Set OpeningBalanceUSD =OpeningBalanceUSD+@OpeningBalance,ModifiedDate=GETDATE(),ModifiedBy=@LastModBy where CustomerID=@CustomerID  
SET @PaymentAmountUSD=@OpeningBalance
end
end
else if (Select COUNT(*) From SAL_BillHeaderDetail where BillHeaderID=@BillHeaderID and  UPPER(PaymentMode)='CREDIT')>0  
begin
if @CurrencyID=1
Update CustomerMST Set DebtAmountGourdes =ISNULL(DebtAmountGourdes,0)-@CancelAmt,ModifiedDate=GETDATE(),ModifiedBy=@LastModBy where CustomerID=@CustomerID  
else
Update CustomerMST Set DebtAmountUSD =ISNULL(DebtAmountUSD,0)-@CancelAmt,ModifiedDate=GETDATE(),ModifiedBy=@LastModBy where CustomerID=@CustomerID  
End


select @CurrencyRate=Rate from CurrencyMST where CurrencyID=@CurrencyID  
SET @TType ='DR'  
  
INSERT INTO [PaymentDetails]  
           ([PaymentMode]  
           ,[PaymentModeNo]  
           ,[PaymentAmount]  
           ,[PaymentAmountUSD]  
           ,[BankID]  
           ,[Expirationdate]  
           ,[AuthorizationNo]  
           ,[IsActive]  
           ,[AddedBy]  
           ,[AddedDTM]  
           ,[LastModBy]  
           ,[LastModDTM]  
           ,[FinancialYearID]  
           ,[CompanyID]  
           ,[CustomerID]  
           ,[BillHeaderID]  
           ,[ParentID]  
           ,[OrderNumber]  
           ,[TType]  
           ,CurrencyID  
           ,CurrencyRate  
           ,PaymentSourceID  
           ,Remarks  
           )  
     VALUES  
           ('REVERT'  
           ,''  
           ,@CommonAmount  
           ,@PaymentAmountUSD  
           ,0  
           ,NUll  
           ,NULL  
           ,1  
           ,@LastModBy  
           ,GETDATE()  
           ,null  
           ,null  
           ,@FinancialYearID  
           ,@CompanyID  
           ,@CustomerID  
           ,@BillHeaderID  
           ,@ParentID  
           ,@OrderNumber  
           ,@TType  
           ,@CurrencyID  
           ,@CurrencyRate  
           ,4
           ,'Partial Order Reimbursement : '+@OrderNumber  
             
)  
 
  
COMMIT TRAN UPDATEPARTPARTIALCANCEL    
    
END TRY    
BEGIN CATCH    
ROllback TRAN UPDATEPARTPARTIALCANCEL    
print 'ExeceptionCaught'       
END CATCH    
End  

GO
  
  
  
  
  
  