using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MMIE.Data.CUR;
using System.Data.SqlClient;
using MMIE.Common;
using System.Data;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;

namespace MMIE.DataAccess.CUR
{
    public class ExchangeCurrencyDA
    {
        public string SaveExchangeCurrency(ExchangeCurrency argExchangeCurrency)
        {
            string strUpadted = "";
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@PurchaseID", SqlDbType.VarChar, 15);
                arParms[0].Direction = ParameterDirection.Output;
                arParms[1] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[1].Value = argExchangeCurrency.InvoiceNo;
                arParms[2] = new SqlParameter("@PurchaseOrderNo", SqlDbType.VarChar);
                arParms[2].Value = argExchangeCurrency.PurchaseOrderNo;
                arParms[3] = new SqlParameter("@PurchaseDate", SqlDbType.DateTime);
                arParms[3].Value = Convert.ToDateTime(argExchangeCurrency.PurchaseDate);
                arParms[4] = new SqlParameter("@PurchaseCurrecyXML", SqlDbType.Xml);
                arParms[4].Value = argExchangeCurrency.xmlPurchaseCurrency;


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_CUR_InsertPurchaseCurrency", arParms);
                strUpadted = arParms[0].Value.ToString();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return strUpadted;
        }

        public DataSet GetPurchageCurrency(ExchangeCurrency argExchangeCurrency)
        {
            DataSet ds = new DataSet();
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@CustomerName ", SqlDbType.VarChar);
                arParms[0].Value = argExchangeCurrency.CustomerName;
                arParms[1] = new SqlParameter("@PurchaseCurrencyID", SqlDbType.Int);
                arParms[1].Value = argExchangeCurrency.PurchaseCurrencyID;
                arParms[2] = new SqlParameter("@FromDate", SqlDbType.Date);
                arParms[2].Value = argExchangeCurrency.FromDate.ToShortDateString();
                arParms[3] = new SqlParameter("@ToDate", SqlDbType.Date);
                arParms[3].Value =  argExchangeCurrency.ToDate.ToShortDateString();
                //arParms[3] = new SqlParameter("@ToDate", SqlDbType.DateTime);
                //arParms[3].Value = argExchangeCurrency.ToDate;
                //arParms[4] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                //arParms[4].Value = argExchangeCurrency.EquiCurrencyAmount;
                //arParms[5] = new SqlParameter("@PageSize", SqlDbType.Int);
                //arParms[5].Value = objExchangeCurrency.CustomerID;



                //------------------------
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_CUR_GetPurchageCurrency", ds, new string[] { "PurchageCurrency" }, arParms);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return ds;
        }
        public DataSet GetPurchageCurrencyReport(ExchangeCurrency argExchangeCurrency)
        {
            DataSet ds = new DataSet();
            try
            {
                

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@PurchaseCurrencyID", SqlDbType.VarChar);
                arParms[0].Value = argExchangeCurrency.PurchaseCurrencyID;

                arParms[1] = new SqlParameter("@FromDate", SqlDbType.DateTime);
                arParms[1].Value = argExchangeCurrency.FromDate;
                arParms[2] = new SqlParameter("@ToDate", SqlDbType.DateTime);
                arParms[2].Value = argExchangeCurrency.ToDate;

                //------------------------
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_CUR_GetPurchageCurrencyReport", ds, new string[] { "PurchageCurrency" }, arParms);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return ds;
        }


        public void UpdateCompanyBalance(ExchangeCurrency objExchangeCurrency)
        {
            
            try
            {

                SqlParameter[] arParms1 = new SqlParameter[5];

                arParms1[0] = new SqlParameter("@BranchID", SqlDbType.Int);
                arParms1[0].Value = objExchangeCurrency.CompanyID;
                arParms1[1] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms1[1].Value = objExchangeCurrency.PurchaseCurrencyID;
                arParms1[2] = new SqlParameter("@CompanyBalanceAmount", SqlDbType.Money);
                arParms1[2].Value = objExchangeCurrency.PurchaseCurrencyAmount;

                arParms1[3] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms1[3].Value = objExchangeCurrency.LastModBy.ToString();
                arParms1[4] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms1[4].Value = 1;

                //------------------------
                int noOfEffectedRecords1 = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateCompanyBalanceMSTByPurchaseCurr", arParms1);
               /// strUpadted = arParms[0].Value.ToString();
               /// 
                SqlParameter[] arParms2 = new SqlParameter[5];

                arParms2[0] = new SqlParameter("@BranchID", SqlDbType.Int);
                arParms2[0].Value = objExchangeCurrency.CompanyID;
                arParms2[1] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms2[1].Value = objExchangeCurrency.EquivalentCurrencyId;
                arParms2[2] = new SqlParameter("@CompanyBalanceAmount", SqlDbType.Money);
                arParms2[2].Value = objExchangeCurrency.EquiCurrencyAmount;

                arParms2[3] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms2[3].Value = objExchangeCurrency.LastModBy.ToString();
                arParms2[4] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms2[4].Value = 2;

                //------------------------
                int noOfEffectedRecords2 = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateCompanyBalanceMSTByPurchaseCurr", arParms2);
                /// strUpadted = arParms[0].Value.ToString();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            
        }


    }
}
