﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.PUR;

using MMIE.Data.PUR;
using MMIE.Data.Common;
//using MMIE.DataAccess;


namespace MMIE.DataAccess.PUR
{
 public   class InvoiceHeaderDetailsDA:DataAccessObjectBase
    {
    
     public InvoiceHeaderDetails GetSearchInvoiceHeaderDetailByID(Int64 ID)
     {
    InvoiceHeaderDetails Object = null;
         try
         {


             SqlParameter[] arParms = new SqlParameter[2];

             arParms[0] = new SqlParameter("@InvoiceHeaderID", SqlDbType.Int);
             arParms[0].Value = ID;



             DataSet ds = new DataSet();
             SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_PUR_GetSearchInvoiceHeader", ds, new string[] { "InvoiceHeaderDetails" }, arParms);
             Object = ORHelper<InvoiceHeaderDetails>.FromDataTable(ds.Tables["InvoiceHeaderDetails"]);

         }
         catch (Exception ex) //Exception of the layer(itself)/unhandle
         {
             PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
             LogManager.WriteErrorLogInDB(ex);
             throw new DataAccessException("5000001", ex);
         }

         return Object;
     }


     public List<InvoiceHeaderDetails> GetSearchInvoiceHeaderDetails(InvoiceHeaderDetails objInvoiceHeader)
     {
         List<InvoiceHeaderDetails> lstObject = null;
         try
         {


             SqlParameter[] arParms = new SqlParameter[5];

             arParms[0] = new SqlParameter("@InvoiceHeaderID", SqlDbType.Int);
             arParms[0].Value = objInvoiceHeader.InvoiceHeaderID;

             arParms[1] = new SqlParameter("@PONumber", SqlDbType.Int);
             arParms[1].Value = objInvoiceHeader.PONumber;

             arParms[2] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
             arParms[2].Value = objInvoiceHeader.InvoiceNo;

             arParms[3] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
             arParms[3].Value = objInvoiceHeader.CustomerName;

             arParms[4] = new SqlParameter("@IsActive", SqlDbType.Bit);
             arParms[4].Value = objInvoiceHeader.IsActive;




             SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[USP_PUR_GetSearchInvoiceHeader]", arParms);
             lstObject = ORHelper<InvoiceHeaderDetails>.FromDataReaderToList(dataReader);
             dataReader.Close();

         }
         catch (Exception ex) //Exception of the layer(itself)/unhandle
         {
             PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
             LogManager.WriteErrorLogInDB(ex);
             throw new DataAccessException("5000001", ex);
         }

         return lstObject;
     }



     public bool UpdateInvoiceHeaderDetails(InvoiceHeaderDetails objInvoiceHeader)
     {
         bool status = false;
         string Result = "";
         try
         {
             SqlParameter[] arParms = new SqlParameter[28];

             arParms[0] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
             arParms[0].Value = objInvoiceHeader.InvoiceNo;
             arParms[1] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
             arParms[1].Value = objInvoiceHeader.AddedBy;
             arParms[2] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
             arParms[2].Value = objInvoiceHeader.LastModBy;
             arParms[3] = new SqlParameter("@ActionType", SqlDbType.Int);
             arParms[3].Value = objInvoiceHeader.ActionType;
             arParms[4] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
             arParms[4].Value = objInvoiceHeader.CompanyID;
             arParms[5] = new SqlParameter("@InvoiceHeaderID", SqlDbType.Int);
             arParms[5].Value = objInvoiceHeader.InvoiceHeaderID;
             arParms[6] = new SqlParameter("@Remarks", SqlDbType.VarChar);
             arParms[6].Value = objInvoiceHeader.Remarks;
             arParms[7] = new SqlParameter("@CustomerID", SqlDbType.Int);
             arParms[7].Value = objInvoiceHeader.SupplierID;
             arParms[8] = new SqlParameter("@TotalInvoiceAmount", SqlDbType.Money);
             arParms[8].Value = objInvoiceHeader.TotalInvoiceAmount;

             arParms[9] = new SqlParameter("@GroupType", SqlDbType.Int);
             arParms[9].Value = objInvoiceHeader.GroupType;


             arParms[10] = new SqlParameter("@TotalCostPrice", SqlDbType.Money);
             arParms[10].Value = objInvoiceHeader.TotalCostPrice;

             arParms[11] = new SqlParameter("@TotalInsurance", SqlDbType.Money);
             arParms[11].Value = objInvoiceHeader.TotalInsurance;

             arParms[12] = new SqlParameter("@TotalFrieght", SqlDbType.Money);
             arParms[12].Value = objInvoiceHeader.TotalFrieght;

             arParms[13] = new SqlParameter("@XMLCharges", SqlDbType.Xml);
             arParms[13].Value = objInvoiceHeader.XMLCharges;

             //arParms[13] = new SqlParameter("@OtherChargeID", SqlDbType.VarChar);
             //arParms[13].Value = objInvoiceHeader.OtherChargeID;
             //------------------------

             arParms[14] = new SqlParameter("@InvoiceDueDate", SqlDbType.Date);
             arParms[14].Value = objInvoiceHeader.InvoiceDueDate.ToShortDateString();

             arParms[15] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
             arParms[15].Value = objInvoiceHeader.CurrencyRate;

             arParms[16] = new SqlParameter("@CurrencyID", SqlDbType.Int);
             arParms[16].Value = objInvoiceHeader.CurrencyID;

             arParms[17] = new SqlParameter("@ShipmentNumber", SqlDbType.VarChar);
             arParms[17].Value = objInvoiceHeader.ShipmentNumber;

             arParms[18] = new SqlParameter("@TotalQty", SqlDbType.Int);
             arParms[18].Value = objInvoiceHeader.TotalQty;

             arParms[19] = new SqlParameter("@PONumber", SqlDbType.Int);
             arParms[19].Value = objInvoiceHeader.PONumber;

             
             arParms[20] = new SqlParameter("@XMLData", SqlDbType.Xml);
             arParms[20].Value = objInvoiceHeader.XMLData;

             arParms[21] = new SqlParameter("@ContainerNumber", SqlDbType.VarChar);
             arParms[21].Value = objInvoiceHeader.ContainerNumber;
             arParms[22] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
             arParms[22].Value = objInvoiceHeader.FinancialYearID;


             //arParms[23] = new SqlParameter("@GourdesDesc", SqlDbType.VarChar);
             //arParms[23].Value = objInvoiceHeader.OtherChargeDesc;
             //arParms[24] = new SqlParameter("@AmountGourdes", SqlDbType.VarChar);
             //arParms[24].Value = objInvoiceHeader.OtherChargeAmount;

             

             arParms[23] = new SqlParameter("@TotalOtherCharges", SqlDbType.Money);
             arParms[23].Value = objInvoiceHeader.TotalOtherCharges;

             arParms[24] = new SqlParameter("@StoreID", SqlDbType.Int);
             arParms[24].Value = objInvoiceHeader.StoreID;

             arParms[25] = new SqlParameter("@Result", SqlDbType.VarChar,50);
             arParms[25].Direction = ParameterDirection.Output;



             arParms[26] = new SqlParameter("@XMLItems", SqlDbType.Xml);
             arParms[26].Value = objInvoiceHeader.XMLItems;

             arParms[27] = new SqlParameter("@PerUnitCharges", SqlDbType.Money);
             arParms[27].Value = objInvoiceHeader.PerUnitCharges;

             //------------------------
             //------------------------
             int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdateInvoiceHeaderDetails", arParms);
             if (noOfEffectedRecords > 0)
             {
                 Result =arParms[25].Value.ToString();
                 
             }
             if(Result=="Complete")
             status = true;

         }
         catch (Exception ex) //Exception of the layer(itself)/unhandle
         {
             PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
             LogManager.WriteErrorLogInDB(ex);
             throw new DataAccessException("5000001", ex);
         }

         return status;
     }


    }
}
