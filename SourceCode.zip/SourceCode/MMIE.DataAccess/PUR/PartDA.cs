﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.Common;


namespace MMIE.DataAccess.PUR
{
    public class PartDA : DataAccessObjectBase
    {

        public DataTable GetMaterialDetailNew(string productname, string Model, int GroupType)
        {
            DataTable dtable = new DataTable("ProductDetail");
            try
            {
                SqlParameter[] arParms = new SqlParameter[3];
                //arParms[0] = new SqlParameter("@IsUniqueMaterial", SqlDbType.Int);
                //arParms[0].Value = isUnique;
                //arParms[1] = new SqlParameter("@SaleTypeID", SqlDbType.Int);
                //arParms[1].Value = SaleTypeID;
                //arParms[2] = new SqlParameter("@StreetID", SqlDbType.Int);
                //arParms[2].Value = StreetID;
                //arParms[3] = new SqlParameter("@StreetChargeID", SqlDbType.Int);
                //arParms[3].Value = StreetChargeID;
                //arParms[4] = new SqlParameter("@CustomerID", SqlDbType.Int);
                //arParms[4].Value = CustomerID;
                arParms[0] = new SqlParameter("@ProductName", SqlDbType.VarChar);
                arParms[0].Value = productname;
                arParms[1] = new SqlParameter("@Model", SqlDbType.VarChar);
                arParms[1].Value = Model;
                arParms[2] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[2].Value = GroupType;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchProductsNew", arParms);
                dtable.Load(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }
            return dtable;
        }


        public Customer GetCustomerNameByName(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[3];
                arParms[0] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.CustomerName;

                arParms[1] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[1].Value = objCustomer.InvoiceNo;


                arParms[2] = new SqlParameter("@ContainerNumber", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.ContainerNumber;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCustomerName", ds, new string[] { "Customer" }, arParms);
                objRetCustomer = ORHelper<Customer>.FromDataTable(ds.Tables["Customer"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }

        public bool SavePurInvoiceNumber(Customer objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[7];

                arParms[0] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.InvoiceNo;
                arParms[1] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[1].Value = objCustomer.AddedBy;
                arParms[2] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.LastModBy;
                arParms[3] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[3].Value = objCustomer.ActionType;
                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[4].Value = objCustomer.CompanyID;
                arParms[5] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[5].Value = objCustomer.StoreID;
                arParms[6] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[6].Value = objCustomer.GroupType;



                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdateInvoiceNumber", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<Customer> SearchStore(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[0].Value = objStore.InvoiceNo;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetInvoiceDetails", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Product> SearchPurchaseOderDetails(Product objStore)
        {
            List<Product> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[0].Value = objStore.InvoiceNo;

                arParms[1] = new SqlParameter("@PONumber", SqlDbType.Int);
                arParms[1].Value = objStore.PONumber;

                arParms[2] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[2].Value = objStore.ProductID;

                arParms[3] = new SqlParameter("@Ordertype", SqlDbType.Int);
                arParms[3].Value = objStore.GroupType;


                arParms[4] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[4].Value = objStore.StoreID;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[USP_PUR_GetSearchPurchaseOrderDetailsNew]", arParms);
                lstObject = ORHelper<Product>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }




        public List<Customer> GetOrderPartsDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[0].Value = objStore.InvoiceNo;
                arParms[1] = new SqlParameter("@ContainerNumber", SqlDbType.VarChar);
                arParms[1].Value = objStore.ContainerNumber;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetOrderpartsDetails", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }





        public bool SavePurOtherCharges(Customer objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[13];

                arParms[0] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.InvoiceNo;
                arParms[1] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[1].Value = objCustomer.AddedBy;
                arParms[2] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.LastModBy;
                arParms[3] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[3].Value = objCustomer.ActionType;
                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[4].Value = objCustomer.CompanyID;
                arParms[5] = new SqlParameter("@AmountGourdes", SqlDbType.VarChar);
                arParms[5].Value = objCustomer.Amount;
                arParms[6] = new SqlParameter("@GourdesDesc", SqlDbType.VarChar);
                arParms[6].Value = objCustomer.Descr;
                arParms[7] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[7].Value = objCustomer.CustomerID;
                arParms[8] = new SqlParameter("@TotalAmount", SqlDbType.Decimal);
                arParms[8].Value = objCustomer.TotalAmount;
                arParms[9] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[9].Value = objCustomer.GroupType;



                arParms[10] = new SqlParameter("@TotalCostPrice", SqlDbType.Money);
                arParms[10].Value = objCustomer.TotalCostPrice;

                arParms[11] = new SqlParameter("@TotalInsurance", SqlDbType.Money);
                arParms[11].Value = objCustomer.TotalInsurance;

                arParms[12] = new SqlParameter("@TotalFrieght", SqlDbType.Money);
                arParms[12].Value = objCustomer.TotalFrieght;


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdateOtherCharges", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        public Customer GetPURTotalExpenses(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[2];
                arParms[0] = new SqlParameter("@InvoiceNumber", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.InvoiceNo;
                arParms[1] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[1].Value = objCustomer.ActionType;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetTotalExpenses", ds, new string[] { "Customer" }, arParms);
                objRetCustomer = ORHelper<Customer>.FromDataTable(ds.Tables["Customer"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }


        public bool SavePurVehicleOtherCharges(Customer objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[14];

                arParms[0] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.InvoiceNo;
                arParms[1] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[1].Value = objCustomer.AddedBy;
                arParms[2] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.LastModBy;
                arParms[3] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[3].Value = objCustomer.ActionType;
                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[4].Value = objCustomer.CompanyID;
                arParms[5] = new SqlParameter("@AmountGourdes", SqlDbType.VarChar);
                arParms[5].Value = objCustomer.Amount;
                arParms[6] = new SqlParameter("@GourdesDesc", SqlDbType.VarChar);
                arParms[6].Value = objCustomer.Descr;
                arParms[7] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[7].Value = objCustomer.CustomerID;
                arParms[8] = new SqlParameter("@TotalAmount", SqlDbType.Decimal);
                arParms[8].Value = objCustomer.TotalAmount;

                arParms[9] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[9].Value = objCustomer.GroupType;


                arParms[10] = new SqlParameter("@TotalCostPrice", SqlDbType.Money);
                arParms[10].Value = objCustomer.TotalCostPrice;

                arParms[11] = new SqlParameter("@TotalInsurance", SqlDbType.Money);
                arParms[11].Value = objCustomer.TotalInsurance;

                arParms[12] = new SqlParameter("@TotalFrieght", SqlDbType.Money);
                arParms[12].Value = objCustomer.TotalFrieght;

                arParms[13] = new SqlParameter("@OtherChargeID", SqlDbType.VarChar);
                arParms[13].Value = objCustomer.UnitID;
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdateOtherCharges", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public Customer GetPURVehicleTotalExpenses(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[2];
                arParms[0] = new SqlParameter("@InvoiceNumber", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.InvoiceNo;
                arParms[1] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[1].Value = objCustomer.ActionType;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetTotalExpenses", ds, new string[] { "Customer" }, arParms);
                objRetCustomer = ORHelper<Customer>.FromDataTable(ds.Tables["Customer"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }



        public List<Customer> GetVehicleReceivingDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[0].Value = objStore.InvoiceNo;
                arParms[1] = new SqlParameter("@ContainerNumber", SqlDbType.VarChar);
                arParms[1].Value = objStore.ContainerNumber;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetVehicleReceivingDetails", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        public List<Customer> GetPartsExpenseDetails(Customer objCustomer)
        {
            List<Customer> lstObject = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[2];
                arParms[0] = new SqlParameter("@InvoiceNumber", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.InvoiceNo;
                arParms[1] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[1].Value = objCustomer.ActionType;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetPartsExpenseDetails", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject; ;
        }


        public List<Customer> GetRefundOrderDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.OrderNo;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_SAL_GETREFUNDORDERDETAILS", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        public bool RefundQtyDetails(Customer objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[16];

                arParms[0] = new SqlParameter("@RefundQty", SqlDbType.Int);
                arParms[0].Value = objCustomer.RefundQty;
                arParms[1] = new SqlParameter("@ProductSaleID", SqlDbType.Int);
                arParms[1].Value = objCustomer.ProductSaleID;
                arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.OrderNo;
                arParms[3] = new SqlParameter("@ProductSaleDeleveryID", SqlDbType.Int);
                arParms[3].Value = objCustomer.ProductDeliveryID;
                arParms[4] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[4].Value = objCustomer.ProdID;
                arParms[5] = new SqlParameter("@ReturnRefundAmountUSD", SqlDbType.Decimal);
                arParms[5].Value = objCustomer.RefundAmountUSD;
                arParms[6] = new SqlParameter("@ReturnRefundAmountGourdes", SqlDbType.Decimal);
                arParms[6].Value = objCustomer.RefundAmountGourdes;
                arParms[7] = new SqlParameter("@ReturnRefundChargeAmountUSD", SqlDbType.Decimal);
                arParms[7].Value = objCustomer.RefundChargeUSD;
                arParms[8] = new SqlParameter("@ReturnRefundChargeAmountGourdes", SqlDbType.Decimal);
                arParms[8].Value = objCustomer.RefundChargeGourdes;
                arParms[9] = new SqlParameter("@ReturnRefundAdjustAmountUSD", SqlDbType.Decimal);
                arParms[9].Value = objCustomer.RefundAdjustAmtUSD;
                arParms[10] = new SqlParameter("@ReturnRefundAdjustAmountGourdes", SqlDbType.Decimal);
                arParms[10].Value = objCustomer.RefundAdjustAmtGourdes;
                arParms[11] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[11].Value = objCustomer.GroupType;
                arParms[12] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[12].Value = objCustomer.FinancialYearID;
                arParms[13] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[13].Value = objCustomer.CompanyID;
                arParms[14] = new SqlParameter("@Addedby", SqlDbType.VarChar);
                arParms[14].Value = objCustomer.AddedBy;
                arParms[15] = new SqlParameter("@LastModby", SqlDbType.VarChar);
                arParms[15].Value = objCustomer.ModifiedBy;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_SAL_UpdateRefundDetails", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public bool UpdateVehicleRecivingForReturn(Product objproduct)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[11];

                arParms[0] = new SqlParameter("@XMLData", SqlDbType.VarChar);
                arParms[0].Value = objproduct.XMLData;
                arParms[1] = new SqlParameter("@UnitPrice", SqlDbType.Decimal);
                arParms[1].Value = objproduct.UnitPrice;
                arParms[2] = new SqlParameter("@PerUnitExpense", SqlDbType.Decimal);
                arParms[2].Value = objproduct.PerUnitExpense;
                arParms[3] = new SqlParameter("@UnitID", SqlDbType.Int);
                arParms[3].Value = objproduct.UnitId;
                arParms[4] = new SqlParameter("@UnitName", SqlDbType.VarChar);
                arParms[4].Value = objproduct.UnitName;

                arParms[5] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[5].Value = objproduct.GroupType;


                arParms[6] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[6].Value = objproduct.FinancialYearID;
                arParms[7] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[7].Value = objproduct.CompanyID;

                arParms[8] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[8].Value = objproduct.LastModBy;
                arParms[9] = new SqlParameter("@InvoiceHeaderID", SqlDbType.Int);
                arParms[9].Value = objproduct.InvoiceHeaderID;
                arParms[10] = new SqlParameter("@PONumber", SqlDbType.Int);
                arParms[10].Value = objproduct.PONumber;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdateVehicleReturn", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public bool UpdatePartRecivingForReturn(Product objproduct)
        {
            bool status = false;
            try
            {
                SqlParameter[] arParms = new SqlParameter[7];
                arParms[0] = new SqlParameter("@XMLData", SqlDbType.VarChar);
                arParms[0].Value = objproduct.XMLData;
                arParms[1] = new SqlParameter("@PONumber", SqlDbType.Int);
                arParms[1].Value = objproduct.PONumber;
                arParms[2] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[2].Value = objproduct.FinancialYearID;
                arParms[3] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[3].Value = objproduct.CompanyID;
                arParms[4] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[4].Value = objproduct.LastModBy;
                arParms[5] = new SqlParameter("@InvoiceHeaderID", SqlDbType.Int);
                arParms[5].Value = objproduct.InvoiceHeaderID;
                arParms[6] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[6].Value = objproduct.GroupType;
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdatePartReturn", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;
            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }
            return status;
        }

      

        public DataTable GetPURProductDetail(Product.IsUniqueMaterial isUnique, Int32 GroupTypeID)
        {
            DataTable dtable = new DataTable("ProductDetail");
            try
            {
                SqlParameter[] arParms = new SqlParameter[2];
                arParms[0] = new SqlParameter("@IsUniqueMaterial", SqlDbType.Int);
                arParms[0].Value = isUnique;
                arParms[1] = new SqlParameter("@GroupTypeID", SqlDbType.Int);
                arParms[1].Value = GroupTypeID;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_PUR_GetSearchPurchaseOrderDetails", arParms);
                dtable.Load(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }
            return dtable;
        }


        public string UpdatePurchaseOrderDetail(Product objSalesVehicle)
        {

            string strUpadted = "";
            try
            {
                SqlParameter[] arParms = new SqlParameter[11];

                arParms[0] = new SqlParameter("@PONumber", SqlDbType.VarChar);
                arParms[0].Value = objSalesVehicle.SaleOrderNumber;

                arParms[1] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[1].Value = objSalesVehicle.xmlSalesTransactionDetail;

                arParms[2] = new SqlParameter("@message", SqlDbType.VarChar, 15);
                arParms[2].Direction = ParameterDirection.Output;

                arParms[3] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[3].Value = objSalesVehicle.FinancialYearID;

                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[4].Value = objSalesVehicle.CompanyID;

                arParms[5] = new SqlParameter("@Addedby", SqlDbType.VarChar);
                arParms[5].Value = objSalesVehicle.AddedBy;

                arParms[6] = new SqlParameter("@LastModby", SqlDbType.VarChar);
                arParms[6].Value = objSalesVehicle.ModifiedBy;

                arParms[7] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[7].Value = objSalesVehicle.IsActive;

                arParms[8] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[8].Value = objSalesVehicle.ActionType;

                arParms[9] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[9].Value = objSalesVehicle.Remark;

                arParms[10] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[10].Value = objSalesVehicle.GroupType;


                SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[USP_PUR_UpdatePurchaseProductDetails]", arParms);
                strUpadted = arParms[2].Value.ToString();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return strUpadted;
        }


        public List<Product> SearchOrder(Product objStore)
        {
            List<Product> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@PONumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.SaleOrderNumber;

                arParms[1] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[1].Value = objStore.GroupType;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_PUR_GetPurchaseOrderReceivingNote", arParms);
                lstObject = ORHelper<Product>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        public string UpdateVehicleReceivingOrderDetails(Product objSalesVehicle)
        {

            string strUpadted = "";
            try
            {
                SqlParameter[] arParms = new SqlParameter[15];

                arParms[0] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[0].Value = objSalesVehicle.xmlSalesTransactionDetail;

                arParms[1] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[1].Value = objSalesVehicle.StoreID;

                arParms[2] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[2].Value = objSalesVehicle.InvoiceNo;

                arParms[3] = new SqlParameter("@TotalAmount", SqlDbType.Decimal);
                arParms[3].Value = objSalesVehicle.TotalUSDAmount;

                arParms[4] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[4].Value = objSalesVehicle.GroupType;

                arParms[5] = new SqlParameter("@SupplierID", SqlDbType.Int);
                arParms[5].Value = objSalesVehicle.CustomerID;

                arParms[6] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[6].Value = objSalesVehicle.FinancialYearID;

                arParms[7] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[7].Value = objSalesVehicle.CompanyID;

                arParms[8] = new SqlParameter("@Addedby", SqlDbType.VarChar);
                arParms[8].Value = objSalesVehicle.AddedBy;

                arParms[9] = new SqlParameter("@LastModby", SqlDbType.VarChar);
                arParms[9].Value = objSalesVehicle.ModifiedBy;

                arParms[10] = new SqlParameter("@TotalCostPrice", SqlDbType.Money);
                arParms[10].Value = objSalesVehicle.TotalCostPrice;

                arParms[11] = new SqlParameter("@TotalInsurance", SqlDbType.Money);
                arParms[11].Value = objSalesVehicle.TotalInsurance;

                arParms[12] = new SqlParameter("@TotalFrieght", SqlDbType.Money);
                arParms[12].Value = objSalesVehicle.TotalFrieght;

                arParms[13] = new SqlParameter("@TotalOtherCharges", SqlDbType.Money);
                arParms[13].Value = objSalesVehicle.TotalOtherCharges;

                arParms[14] = new SqlParameter("@message", SqlDbType.VarChar, 15);
                arParms[14].Direction = ParameterDirection.Output;




                SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[USP_PUR_UpdateVehicleReceivingOrderDetails]", arParms);
                strUpadted = arParms[10].Value.ToString();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return strUpadted;
        }


        public string UpdatePartReceivingOrderDetails(Product objSalesVehicle)
        {

            string strUpadted = "";
            try
            {
                SqlParameter[] arParms = new SqlParameter[16];

                arParms[0] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[0].Value = objSalesVehicle.xmlSalesTransactionDetail;

                arParms[1] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[1].Value = objSalesVehicle.StoreID;

                arParms[2] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[2].Value = objSalesVehicle.InvoiceNo;

                arParms[3] = new SqlParameter("@TotalAmount", SqlDbType.Decimal);
                arParms[3].Value = objSalesVehicle.TotalUSDAmount;

                arParms[4] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[4].Value = objSalesVehicle.GroupType;

                arParms[5] = new SqlParameter("@SupplierID", SqlDbType.Int);
                arParms[5].Value = objSalesVehicle.CustomerID;

                arParms[6] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[6].Value = objSalesVehicle.FinancialYearID;

                arParms[7] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[7].Value = objSalesVehicle.CompanyID;

                arParms[8] = new SqlParameter("@Addedby", SqlDbType.VarChar);
                arParms[8].Value = objSalesVehicle.AddedBy;

                arParms[9] = new SqlParameter("@LastModby", SqlDbType.VarChar);
                arParms[9].Value = objSalesVehicle.ModifiedBy;

                arParms[10] = new SqlParameter("@message", SqlDbType.VarChar, 15);
                arParms[10].Direction = ParameterDirection.Output;


                arParms[11] = new SqlParameter("@TotalCostPrice", SqlDbType.Money);
                arParms[11].Value = objSalesVehicle.TotalCostPrice;

                arParms[12] = new SqlParameter("@TotalInsurance", SqlDbType.Money);
                arParms[12].Value = objSalesVehicle.TotalInsurance;

                arParms[13] = new SqlParameter("@TotalFrieght", SqlDbType.Money);
                arParms[13].Value = objSalesVehicle.TotalFrieght;

                arParms[14] = new SqlParameter("@TotalOtherCharges", SqlDbType.Money);
                arParms[14].Value = objSalesVehicle.TotalOtherCharges;

                arParms[15] = new SqlParameter("@TotalQty", SqlDbType.Int);
                arParms[15].Value = objSalesVehicle.TotalQty;




                SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[USP_PUR_UpdatePartReceivingOrderDetails]", arParms);
                strUpadted = arParms[10].Value.ToString();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return strUpadted;
        }


        public string UpdateOrderToSupplier(Product objSalesVehicle)
        {

            string strUpadted = "";
            try
            {
                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@PONumber", SqlDbType.VarChar);
                arParms[0].Value = objSalesVehicle.SaleOrderNumber;

                arParms[1] = new SqlParameter("@SupplierID", SqlDbType.Int);
                arParms[1].Value = objSalesVehicle.CustomerID;


                SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[USP_PUR_UpdateOrderToSupplier]", arParms);
                strUpadted = arParms[1].Value.ToString();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return strUpadted;
        }


        public List<Product> SearchPurchaseOrderApproverRate(Product objStore)
        {
            List<Product> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[0].Value = objStore.InvoiceNo;

                arParms[1] = new SqlParameter("@PONumber", SqlDbType.Int);
                arParms[1].Value = objStore.PONumber.ToString();

                arParms[2] = new SqlParameter("@IsChecked", SqlDbType.Bit);
                arParms[2].Value = objStore.IsApproved;

                arParms[3] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[3].Value = objStore.GroupType;

                arParms[4] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[4].Value = objStore.StoreID;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_PUR_GetSearchPurchaseOrderApprover", arParms);
                lstObject = ORHelper<Product>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public bool UpdatePurchaseOrderSalesPrice(Product objSalesVehicle)
        {
            bool status = false;

            try
            {
                SqlParameter[] arParms = new SqlParameter[8];

                arParms[0] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[0].Value = objSalesVehicle.XMLData;


                arParms[1] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[1].Value = objSalesVehicle.SaleOrderNumber;

                arParms[2] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[2].Value = objSalesVehicle.InvoiceNo;

                arParms[3] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[3].Value = objSalesVehicle.FinancialYearID;

                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[4].Value = objSalesVehicle.CompanyID;


                arParms[5] = new SqlParameter("@LastModby", SqlDbType.VarChar);
                arParms[5].Value = objSalesVehicle.LastModBy;

                arParms[6] = new SqlParameter("@OrderType", SqlDbType.Int);
                arParms[6].Value = objSalesVehicle.GroupType;

                arParms[7] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[7].Value = objSalesVehicle.StoreID;


                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdatePurchaseOrderSalesPrice", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return status;
        }



        //public string UpdatePartReceving( )
        //    string strUpadted = "";
        //try
        //{
        //    SqlParameter[] arParms = new SqlParameter[13];
        //    arParms[0] = new SqlParameter("@RegistrationCode", SqlDbType.BigInt);
        //    arParms[0].Value = Convert.ToInt64(objLookup.ItemCode);

        //    arParms[1] = new SqlParameter("@OPDCaseSheetDate", SqlDbType.DateTime);
        //    arParms[1].Value = objLookup.AddedDTM;


        //    arParms[4] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
        //    arParms[4].Value = objLookup.FinancialYearID;

        //    arParms[5] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
        //    arParms[5].Value = objLookup.CompanyID;

        //    arParms[6] = new SqlParameter("@IsActive", SqlDbType.Bit);
        //    arParms[6].Value = objLookup.IsActive;

        //    arParms[7] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
        //    arParms[7].Value = objLookup.AddedBy;

        //    arParms[8] = new SqlParameter("@AddedDTM", SqlDbType.DateTime);
        //    if (objLookup.AddedDTM <= DateTime.MinValue || objLookup.AddedDTM >= DateTime.MaxValue)
        //        arParms[8].Value = System.Data.SqlTypes.SqlDateTime.Null;
        //    else
        //    {
        //        arParms[8].Value = objLookup.AddedDTM;
        //    }

        //    arParms[9] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
        //    arParms[9].Value = objLookup.LastModBy;

        //    arParms[10] = new SqlParameter("@LastModDTM", SqlDbType.DateTime);
        //    if (objLookup.LastModDTM <= DateTime.MinValue || objLookup.LastModDTM >= DateTime.MaxValue)
        //        arParms[10].Value = System.Data.SqlTypes.SqlDateTime.Null;
        //    else
        //    {
        //        arParms[10].Value = objLookup.LastModDTM;
        //    }

        //    arParms[12] = new SqlParameter("@message", SqlDbType.VarChar, 15);
        //    arParms[12].Direction = ParameterDirection.Output;

        //    SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_OPD_UpdateCaseSheet", arParms);
        //    strUpadted = arParms[12].Value.ToString();
        //}
        //catch (Exception ex) //Exception of the business layer(itself)//unhandle
        //{
        //    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
        //    LogManager.WriteErrorLogInDB(ex);
        //    throw new BusinessProcessException("5000001", ex);
        //}
        //return strUpadted;
    }




    //    // OLD METHODS

    //    public string GetServerTime()
    //    {
    //        string cuurentTime = "";
    //        try
    //        {
    //            cuurentTime = DateTime.Now.ToString();
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return cuurentTime;
    //    }
    //    public List<ConsultantDA> GetConsultantDAGridList(int CompanyId, int LocationId)
    //    {
    //        List<ConsultantDA> lstConsultantDA = null;
    //        try
    //        {

    //            SqlParameter[] arParms = new SqlParameter[2];
    //            arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
    //            arParms[0].Value = CompanyId;
    //            arParms[1] = new SqlParameter("@LocationID", SqlDbType.Int);
    //            arParms[1].Value = LocationId;
    //            DataSet ds = new DataSet();
    //            //SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_GetConsultantDAGridList", ds, new string[] { "ConsultantDA" }, arParms);
    //            lstConsultantDA = ObjectUtil.GetDataObject<ConsultantDA>(ds);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return lstConsultantDA;
    //    }
    //    public List<ConsultantDA> GetConsultantDAByID(ConsultantDA objConsultantDA)
    //    {
    //        List<ConsultantDA> lstObject = null;
    //        try
    //        {

    //            SqlParameter[] arParms = new SqlParameter[1];
    //            arParms[0] = new SqlParameter("@ConsultantDAID", SqlDbType.Int);
    //            //arParms[0].Value = objConsultantDA.ConsultantDAID;

    //            DataSet ds = new DataSet();
    //            //SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_GetConsultantDAByID", ds, new string[] { "POC_Patient" }, arParms);
    //            lstObject = ObjectUtil.GetDataObject<ConsultantDA>(ds);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }
    //        return lstObject;
    //    }

    //    public int GetRegExpiryDay(out int day)
    //    {
    //        try
    //        {
    //            SqlParameter[] arParms = new SqlParameter[1];

    //            arParms[0] = new SqlParameter("@day", SqlDbType.Int);
    //            arParms[0].Direction = ParameterDirection.Output;

    //            //SqlHelper.ExecuteNonQuery(Globals.ConnectionString, CommandType.StoredProcedure, "usp_GetRegExpDay", arParms);
    //            day = Convert.ToInt32(arParms[0].Value);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return day;
    //    }

    //    public DataSet fillDepartment(int CompanyID, int LocationID)
    //    {
    //        DataSet ds = new DataSet();
    //        try
    //        {
    //            SqlParameter[] arParms = new SqlParameter[2];
    //            arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
    //            arParms[0].Value = CompanyID;
    //            arParms[1] = new SqlParameter("@LocationID", SqlDbType.Int);
    //            arParms[1].Value = LocationID;
    //            //SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_fillDepartment", ds, new string[] { "POC_Department" }, arParms);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return ds;
    //    }

    //    public DataSet fillPatBillCategory()
    //    {
    //        DataSet ds = new DataSet();
    //        try
    //        {

    //            // SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_fillPatBillCategory", ds, new string[] { "POC_PatientCategory" }, null);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return ds;
    //    }

    //    public DataSet fillPaymentType(int ID)
    //    {
    //        DataSet ds = new DataSet();
    //        try
    //        {

    //            SqlParameter[] arParms = new SqlParameter[1];
    //            arParms[0] = new SqlParameter("@PatientBillID", SqlDbType.Int);
    //            arParms[0].Value = ID;
    //            //SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_fillPaymentType", ds, new string[] { "POC_PaymentType" }, arParms);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }
    //        return ds;
    //    }

    //    public DataSet fillTariffCategory(int ID)
    //    {
    //        DataSet ds = new DataSet();
    //        try
    //        {

    //            SqlParameter[] arParms = new SqlParameter[1];
    //            arParms[0] = new SqlParameter("@PatientBillID", SqlDbType.Int);
    //            arParms[0].Value = ID;
    //            //  SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_fillTariffCategory", ds, new string[] { "POC_TariffCategory" }, arParms);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return ds;
    //    }

    //    public DataSet fillExemptionCategory(int ID)
    //    {
    //        DataSet ds = new DataSet();
    //        try
    //        {

    //            SqlParameter[] arParms = new SqlParameter[1];
    //            arParms[0] = new SqlParameter("@PatientBillID", SqlDbType.Int);
    //            arParms[0].Value = ID;
    //            //SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_fillExemptionCategory", ds, new string[] { "POC_ExemptionCategory" }, arParms);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return ds;
    //    }

    //    public DataSet fillSex(int ID)
    //    {
    //        DataSet ds = new DataSet();
    //        try
    //        {
    //            SqlParameter[] arParms = new SqlParameter[1];
    //            arParms[0] = new SqlParameter("@SalutationID", SqlDbType.Int);
    //            arParms[0].Value = ID;
    //            //SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_fillSex", ds, new string[] { "POC_Sex" }, arParms);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return ds;
    //    }

    //    public DataSet fillRefEmployee(int ID)
    //    {
    //        DataSet ds = new DataSet();
    //        try
    //        {

    //            SqlParameter[] arParms = new SqlParameter[1];
    //            //arParms[0] = new SqlParameter("@EmployeeID", SqlDbType.Int);
    //            //arParms[0].Value = ID;
    //            //SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_fillRefEmployee", ds, new string[] { "POC_Employee" }, arParms);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return ds;
    //    }

    //    public DataSet fillDesignation(int ID)
    //    {
    //        DataSet ds = new DataSet();
    //        try
    //        {

    //            SqlParameter[] arParms = new SqlParameter[1];
    //            arParms[0] = new SqlParameter("@EmployeeID", SqlDbType.Int);
    //            arParms[0].Value = ID;
    //            // SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_fillDesignation", ds, new string[] { "POC_Designation" }, arParms);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }

    //        return ds;
    //    }

    //    public bool SaveConsultantDA(List<ConsultantDA> lstConsultantDA, out string message)
    //    {
    //        bool retStatus = false;

    //        try
    //        {

    //            StringWriter writer = new StringWriter();
    //            ObjectUtil.ConvertTo<ConsultantDA>(lstConsultantDA).WriteXml(writer);
    //            //DataTable dtConsultantDA = ObjectUtil.ConvertTo<ConsultantDA>(lstConsultantDA);

    //            //DataSet ds = new DataSet();
    //            //ds.Tables.Add(dtConsultantDA);
    //            //ds.WriteXml(writer);
    //            SqlParameter[] arParms = new SqlParameter[2];
    //            arParms[0] = new SqlParameter("@XMLDOC", SqlDbType.VarChar);
    //            arParms[0].Value = writer.ToString();

    //            arParms[1] = new SqlParameter("@message", SqlDbType.VarChar, 100);
    //            arParms[1].Direction = ParameterDirection.Output;

    //            //SqlHelper.ExecuteNonQuery(Globals.ConnectionString, CommandType.StoredProcedure, "usp_UpdateConsultantDA", arParms);
    //            message = arParms[1].Value.ToString();

    //            retStatus = true;
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }
    //        return retStatus;
    //    }

    //    public long GetConsultantDACode(int CompanyID, int LocationID, int FinancialYearID, out long regCode)
    //    {
    //        try
    //        {
    //            SqlParameter[] arParms = new SqlParameter[4];
    //            arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
    //            arParms[0].Value = CompanyID;
    //            arParms[1] = new SqlParameter("@LocationID", SqlDbType.Int);
    //            arParms[1].Value = LocationID;
    //            arParms[2] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
    //            arParms[2].Value = FinancialYearID;
    //            arParms[3] = new SqlParameter("@regCode", SqlDbType.BigInt);
    //            arParms[3].Direction = ParameterDirection.Output;

    //            //SqlHelper.ExecuteNonQuery(Globals.ConnectionString, CommandType.StoredProcedure, "usp_GetConsultantDACode", arParms);
    //            regCode = Convert.ToInt32(arParms[3].Value);
    //        }
    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //        {
    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //            LogManager.WriteErrorLogInDB(ex);
    //            throw new BusinessProcessException("5000001", ex);
    //        }
    //        return regCode;
    //    }

    //    //    public long GetDeptNo(int DeptID, int CompanyID, int LocationID, out long DeptNo)
    //    //    {
    //    //        try
    //    //        {               
    //    //            //SqlParameter[] arParms = new SqlParameter[4];
    //    //            //arParms[0] = new SqlParameter("@DeptID", SqlDbType.Int);
    //    //            //arParms[0].Value = DeptID;
    //    //            //arParms[1] = new SqlParameter("@CompanyID", SqlDbType.Int);
    //    //            //arParms[1].Value = CompanyID;
    //    //            //arParms[2] = new SqlParameter("@LocationID", SqlDbType.Int);
    //    //            //arParms[2].Value = LocationID;
    //    //            //arParms[3] = new SqlParameter("@DeptNo", SqlDbType.BigInt);
    //    //            //arParms[3].Direction = ParameterDirection.Output;

    //    //            //SqlHelper.ExecuteNonQuery(Globals.ConnectionString, CommandType.StoredProcedure, "usp_GetConsultantDADeptNo", arParms);
    //    //            //DeptNo = Convert.ToInt32(arParms[3].Value);
    //    //        }
    //    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //    //        {
    //    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //    //            LogManager.WriteErrorLogInDB(ex);
    //    //            throw new BusinessProcessException("5000001", ex);
    //    //        }
    //    //        //return 123;
    //    //    }

    //    //    public long GetConsultantRequestNo(int CompanyID, int LocationID, out long RequestNo)
    //    //    {
    //    //        try
    //    //        {               
    //    //            //SqlParameter[] arParms = new SqlParameter[3];
    //    //            //arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
    //    //            //arParms[0].Value = CompanyID;
    //    //            //arParms[1] = new SqlParameter("@LocationID", SqlDbType.Int);
    //    //            //arParms[1].Value = LocationID;
    //    //            //arParms[2] = new SqlParameter("@RequestNo", SqlDbType.BigInt);
    //    //            //arParms[2].Direction = ParameterDirection.Output;

    //    //            //SqlHelper.ExecuteNonQuery(Globals.ConnectionString, CommandType.StoredProcedure, "usp_GetConsultantDARequestNo", arParms);
    //    //            //sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_REC_GetRegistrationMSTList", arParms);
    //    //            //RequestNo = Convert.ToInt32(arParms[2].Value);
    //    //        }
    //    //        catch (Exception ex) //Exception of the business layer(itself)//unhandle
    //    //        {
    //    //            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
    //    //            LogManager.WriteErrorLogInDB(ex);
    //    //            throw new BusinessProcessException("5000001", ex);
    //    //        }
    //    //       // return 12;
    //    //    }
    //    //}
    //}
}
