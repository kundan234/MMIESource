﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.PUR;

using MMIE.Data.PUR;
using MMIE.Data.Common;
//using MMIE.DataAccess;



namespace MMIE.DataAccess.PUR
{
   public  class ProductPurchaseOrderDA:DataAccessObjectBase
    {

        public List<ProductPurchaseOrder> GetSearchProductPurchaseOrderDetail(string Search)
        {
            List<ProductPurchaseOrder> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@Search", SqlDbType.VarChar);
                arParms[0].Value = Search;
                            SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetSearchPurchaseOrder", arParms);
                            lstObject = ORHelper<ProductPurchaseOrder>.FromDataReaderToList(dataReader);

                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public List<ProductPurchaseOrder> SearchProductPurchaseOrderDetail_New(ProductPurchaseOrder objPurchaseOrder)
        {
            List<ProductPurchaseOrder> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[0].Value = objPurchaseOrder.IsActive;

                arParms[1] = new SqlParameter("@IsApproved", SqlDbType.Bit);
                arParms[1].Value = objPurchaseOrder.IsApproved;

                arParms[2] = new SqlParameter("@PONumber", SqlDbType.Int);
                arParms[2].Value = objPurchaseOrder.PONumber;






                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_PUR_GetSearchPurchaseOrderDetails_New_1001]", arParms);
                lstObject = ORHelper<ProductPurchaseOrder>.FromDataReaderToList(dataReader);

                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Product> SearchPurchaseOderDetails(string strSearch)
        {
            List<Product> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@PONumber", SqlDbType.VarChar);
                arParms[0].Value = strSearch;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_PUR_GetSearchPurchaseOrderDetailsNew", arParms);
                lstObject = ORHelper<Product>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public bool SaveOrderDetailUpdate(ProductPurchaseOrder objPODetail)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[10];

                arParms[0] = new SqlParameter("@OrderID", SqlDbType.VarChar);
                arParms[0].Value = objPODetail.ID;

           

                arParms[1] = new SqlParameter("@IsPending", SqlDbType.Bit);
                arParms[1].Value = objPODetail.IsPending;

                arParms[2] = new SqlParameter("@IsApproved", SqlDbType.Bit);
                arParms[2].Value = objPODetail.IsApproved;

                arParms[3] = new SqlParameter("@IsRejected", SqlDbType.Bit);
                arParms[3].Value = objPODetail.IsRejected;
                arParms[4] = new SqlParameter("@Details", SqlDbType.VarChar);
                arParms[4].Value = objPODetail.Details;
                arParms[5] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[5].Value = objPODetail.LastModBy;


                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objPODetail.CompanyID;
                
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[7].Value = objPODetail.FinancialYearID;
                arParms[8] = new SqlParameter("@ApprovedQty", SqlDbType.Int);
                arParms[8].Value = objPODetail.ApprovedQty;


                arParms[9] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[9].Value = objPODetail.IsActive;

               
             
         


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdateOrderStatus", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
       
        public bool SaveProductPurchageOrderDetail(ProductPurchaseOrder objPODetail)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[10];

                arParms[0] = new SqlParameter("@ID", SqlDbType.VarChar);
                arParms[0].Value = objPODetail.ID;
                arParms[1] = new SqlParameter("@Model", SqlDbType.VarChar);
                arParms[1].Value = objPODetail.Model;

                arParms[2] = new SqlParameter("@ENName", SqlDbType.VarChar);
                arParms[2].Value = objPODetail.ENName;
                arParms[3] = new SqlParameter("@Color", SqlDbType.VarChar);
                arParms[3].Value = objPODetail.Color;
                arParms[4] = new SqlParameter("@Qty", SqlDbType.Int);
                arParms[4].Value = objPODetail.Qty;
                arParms[5] = new SqlParameter("@Unit", SqlDbType.VarChar);
                arParms[5].Value = objPODetail.Unit;
                arParms[6] = new SqlParameter("@ProductType", SqlDbType.Int);
                arParms[6].Value = objPODetail.ProductType;
                arParms[7] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[7].Value = objPODetail.CompanyID;
                arParms[8] = new SqlParameter("FinancialYearID", SqlDbType.Decimal);
                arParms[8].Value = objPODetail.FinancialYearID;
                arParms[9] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[9].Value = objPODetail.AddedBy;

                arParms[10] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[10].Value = objPODetail.LastModBy;

                arParms[11] = new SqlParameter("@IsPending", SqlDbType.Bit);
                arParms[11].Value = objPODetail.IsPending;

                arParms[12] = new SqlParameter("@IsApproved", SqlDbType.Bit);
                arParms[12].Value = objPODetail.IsApproved;

                arParms[13] = new SqlParameter("@IsRejected", SqlDbType.Bit);
                arParms[13].Value = objPODetail.IsRejected;
                 arParms[14] = new SqlParameter("@Details", SqlDbType.VarChar);
                arParms[14].Value = objPODetail.LastModBy;

                    arParms[15] = new SqlParameter("@IsActive", SqlDbType.VarChar);
                arParms[15].Value = objPODetail.IsActive;
             arParms[16] = new SqlParameter("@ActionType", SqlDbType.VarChar);
             arParms[16].Value = objPODetail.ActionType;
        


                //------------------------
             int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdatePurchaseOrderDetail", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public ProductPurchaseOrder GetProductPurchageOrderDetailByID(int ID)
        {
            ProductPurchaseOrder objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@Search", SqlDbType.VarChar);
                arParms[0].Value = "where ID="+Convert.ToString(ID);
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetSearchPurchaseOrder", ds, new string[] { "ProductPurchageOrderDetail" }, arParms);
                objRetCustomer = ORHelper<ProductPurchaseOrder>.FromDataTable(ds.Tables["ProductPurchageOrderDetail"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }


        public InvoiceHeaderDetails GetSearchProductPurchaseOrderByID(int ID)
        {
            InvoiceHeaderDetails objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@PONumber", SqlDbType.VarChar);
                arParms[0].Value = ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetSearchPurchaseOrderByID", ds, new string[] { "ProductPurchageOrderDetail" }, arParms);
                objRetCustomer = ORHelper<InvoiceHeaderDetails>.FromDataTable(ds.Tables["ProductPurchageOrderDetail"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }



       //Search Vehical List 

        public List<Product> SearchRecievedVehicalList(Product objProduct)
        {
            List<Product> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@PONumber", SqlDbType.Int);
                arParms[0].Value = objProduct.PONumber;
                arParms[1] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                arParms[1].Value = objProduct.CurrentIndex;

                arParms[2] = new SqlParameter("@PageSize", SqlDbType.Int);
                arParms[2].Value = objProduct.PageSize;
                


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_GetSearchRecieveVehicals", arParms);
                lstObject = ORHelper<Product>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public bool SaveVehicalRecievedList(Product objProduct)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[0].Value = objProduct.LastModBy ;

                arParms[1] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[1].Value = objProduct.XMLData;

                arParms[2] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[2].Value = objProduct.ActionType;

                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdateVehicleRecievingList", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


    }
}
