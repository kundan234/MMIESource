﻿using System;

using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.Common;
/*************************************************************************************************  
  
  Name of the Class			    : PaymentDA                      
  
  Description of the class	    : 
  
  Created Date					: 7th Dec 2010  
  
  Developer						: 
  
  Modify Date					: 
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.DataAccess.SAL
{
    public class OrderDA : DataAccessObjectBase
    {

        public List<Order> SearchOrder(Order  objOrder)
        {
            List<Order> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@Ordername", SqlDbType.VarChar);
                arParms[0].Value = objOrder.OrderNumber;
                arParms[1] = new SqlParameter("@GroupType", SqlDbType.Int );
                arParms[1].Value = objOrder.GroupType  ;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchOrderDetail", arParms);
                lstObject = ORHelper<Order>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Order> SearchBillHeader(Order objOrder)
        {
            List<Order> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objOrder.OrderNumber;
                arParms[1] = new SqlParameter("@BillHeaderID", SqlDbType.Int);
                arParms[1].Value = objOrder.BillHeaderID;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_SAL_GetSearchBillDetail]", arParms);
                lstObject = ORHelper<Order>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Order> SearchInvoiceOrderDelivery(BillInvoiceDetails objOrder)
        {
            List<Order> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@InvoiceNumber", SqlDbType.VarChar);
                arParms[0].Value = objOrder.InvoiceNumber;
                arParms[1] = new SqlParameter("@InvoiceID", SqlDbType.Int);
                arParms[1].Value = objOrder.InvoiceID;
                arParms[2] = new SqlParameter("@VinNo", SqlDbType.VarChar);
                arParms[2].Value = objOrder.VinNo;
                arParms[3] = new SqlParameter("@EngineNo", SqlDbType.VarChar);
                arParms[3].Value = objOrder.EngineNo;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchInvoiceDelivery", arParms);
                lstObject = ORHelper<Order>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }
        
        public List<Order> SearchActiveOrderList(Order objStore)
        {
            List<Order> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.OrderNumber;
                arParms[1] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[1].Value = objStore.CustomerName;
                arParms[2] = new SqlParameter("@PhoneNumber", SqlDbType.VarChar);
                arParms[2].Value = objStore.CustomerPhone;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchOrderDetails", arParms);
                lstObject = ORHelper<Order>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Order> SearchCustomerOrder(Order objOrder)
        {
            List<Order> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@CurrencyID", SqlDbType.VarChar);
                arParms[0].Value = objOrder.CurrencyID;

                arParms[1] = new SqlParameter("@CustomerName", SqlDbType.Int);
                arParms[1].Value = objOrder.CustomerName;

                arParms[2] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[2].Value = objOrder.CustomerID;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchCustomerOrders", arParms);
                lstObject = ORHelper<Order>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        //public List<Customer> SearchInvoiceDetails(Customer objOrder)
        //{
        //    List<Customer> lstObject = null;
        //    try
        //    {

        //        SqlParameter[] arParms = new SqlParameter[3];

        //        arParms[0] = new SqlParameter("@OrderNo", SqlDbType.VarChar);
        //        arParms[0].Value = objOrder.OrderNo;

        //        arParms[1] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
        //        arParms[1].Value = objOrder.InvoiceNo;

        //        arParms[2] = new SqlParameter("@ShipmentNumber", SqlDbType.VarChar);
        //        arParms[2].Value = objOrder.ShipmentNumber;
        //        SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetInvoiceHeaderDetails", arParms);
        //        lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
        //        dataReader.Close();

        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new DataAccessException("5000001", ex);
        //    }

        //    return lstObject;
        //}


        public List<BillInvoiceDetails> SearchOrderInvoiceList(BillInvoiceDetails objOrder)
        {
            List<BillInvoiceDetails> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[6];

                arParms[0] = new SqlParameter("@OrderNo", SqlDbType.VarChar);
                arParms[0].Value = objOrder.OrderNumber;

                arParms[1] = new SqlParameter("@BillHeaderID", SqlDbType.Int);
                arParms[1].Value = objOrder.BillHeaderID;

                arParms[2] = new SqlParameter("@ShipmentNumber", SqlDbType.VarChar);
                arParms[2].Value = objOrder.ShipmentNumber;

                arParms[3] = new SqlParameter("@InvoiceNumber", SqlDbType.VarChar);
                arParms[3].Value = objOrder.InvoiceNumber;

                arParms[4] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[4].Value = objOrder.CustomerID;
                arParms[5] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[5].Value = objOrder.CurrencyID;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetBillInvoiceList", arParms);
                lstObject = ORHelper<BillInvoiceDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public int UpdateSalesOrderInvoicePayment(PaymentDetails objInvoice)
        {

            int result = 0;
            try
            {
                SqlParameter[] arParms = new SqlParameter[25];

                arParms[0] = new SqlParameter("@BillHeaderID", SqlDbType.Int);
                arParms[0].Value = objInvoice.BillHeaderID;

                arParms[1] = new SqlParameter("@CurrencyID", SqlDbType.SmallInt);
                arParms[1].Value = objInvoice.CurrencyID;


                arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[2].Value = objInvoice.OrderNumber;

                arParms[3] = new SqlParameter("@InvoiceNumber", SqlDbType.VarChar);
                arParms[3].Value = objInvoice.InvoiceNo;


                arParms[4] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
                arParms[4].Value = objInvoice.CurrencyRate;

                arParms[6] = new SqlParameter("@PaymentAmount", SqlDbType.Money);
                arParms[6].Value = objInvoice.PaymentAmount;


                arParms[7] = new SqlParameter("@PaymentSourceID", SqlDbType.Int);
                arParms[7].Value = objInvoice.PaymentSourceID;

                arParms[8] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[8].Value = objInvoice.PaymentMode;

                arParms[9] = new SqlParameter("@AddedBy ", SqlDbType.VarChar);
                arParms[9].Value = objInvoice.AddedBy;

                arParms[10] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[10].Value = objInvoice.IsActive;


                arParms[11] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[11].Value = objInvoice.FinancialYearID;


                arParms[12] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[12].Value = objInvoice.Remarks;


                arParms[13] = new SqlParameter("@CustomerID", SqlDbType.SmallInt);
                arParms[13].Value = objInvoice.CustomerID;

                arParms[14] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[14].Value = objInvoice.CompanyID;

                arParms[15] = new SqlParameter("@LastModBy ", SqlDbType.VarChar);
                arParms[15].Value = objInvoice.LastModBy;

                arParms[16] = new SqlParameter("@PaymentModeNo ", SqlDbType.VarChar);
                arParms[16].Value = objInvoice.PaymentModeNo;

                arParms[17] = new SqlParameter("@ExpirationDate ", SqlDbType.VarChar);
                arParms[17].Value = objInvoice.Expdatetime;


                arParms[18] = new SqlParameter("@TransactionType ", SqlDbType.VarChar);
                arParms[18].Value = objInvoice.TransactionType;

                arParms[19] = new SqlParameter("@TType ", SqlDbType.VarChar);
                arParms[19].Value = objInvoice.TType;


                arParms[20] = new SqlParameter("@IsSales ", SqlDbType.VarChar);
                arParms[20].Value = objInvoice.IsSales;


                arParms[21] = new SqlParameter("@BankID ", SqlDbType.Int);
                arParms[21].Value = objInvoice.BankID;

                arParms[22] = new SqlParameter("@XMLData ", SqlDbType.Xml);
                arParms[22].Value = objInvoice.XMLData;

                arParms[23] = new SqlParameter("@DepositAmount", SqlDbType.Money);
                arParms[23].Value = objInvoice.PaymentAmountUSD;

                arParms[24] = new SqlParameter("@PaymentID ", SqlDbType.Int);
                arParms[24].Direction = ParameterDirection.Output;


                int noRow = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_UpdateBulkInvoicePayment", arParms);
                if (noRow > 0)
                    result = Convert.ToInt32(arParms[24].Value);


            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return result;
        }



        
    }
}
