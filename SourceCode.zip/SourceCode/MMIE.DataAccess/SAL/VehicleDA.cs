﻿using System;

using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using System.Collections.Generic;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.Common;

/*************************************************************************************************  
  
  Name of the Class			    : PaymentDA                      
  
  Description of the class	    : 
  
  Created Date					: 7th Dec 2010  
  
  Developer						: 
  
  Modify Date					: 
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.DataAccess.SAL
{
    public class VehicleDA : DataAccessObjectBase
    {
        //MMIE.Data.Common.isun
        public DataTable GetVehicleDetail(Product.IsUniqueMaterial isUnique, Int32 SaleTypeID, Int32 StreetID, Int32 StreetChargeID)
        {
            DataTable dtable = new DataTable("ProductDetail");
            try
            {
                SqlParameter[] arParms = new SqlParameter[4];
                arParms[0] = new SqlParameter("@IsUniqueMaterial", SqlDbType.Int);
                arParms[0].Value = isUnique;
                arParms[1] = new SqlParameter("@SaleTypeID", SqlDbType.Int);
                arParms[1].Value = SaleTypeID;
                arParms[2] = new SqlParameter("@StreetID", SqlDbType.Int);
                arParms[2].Value = StreetID;
                arParms[3] = new SqlParameter("@StreetChargeID", SqlDbType.Int);
                arParms[3].Value = StreetChargeID;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchVehicle", arParms);
                dtable.Load(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }
            return dtable;
        }

        public string UpdateSalesProductDetail(Product objSalesVehicle)
        {

            string strUpadted = "";
            try
            {
                SqlParameter[] arParms = new SqlParameter[40];

                arParms[0] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[0].Value = objSalesVehicle.StoreID;

                arParms[1] = new SqlParameter("@SalesStatus", SqlDbType.SmallInt);
                arParms[1].Value = objSalesVehicle.SalesStatus;


                arParms[2] = new SqlParameter("@SaleOrderNumber", SqlDbType.VarChar);
                arParms[2].Value = objSalesVehicle.SaleOrderNumber;

                arParms[3] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[3].Value = objSalesVehicle.InvoiceNo;


                arParms[4] = new SqlParameter("@BillDate ", SqlDbType.DateTime);
                if (objSalesVehicle.BillDate <= DateTime.MinValue || objSalesVehicle.AddedDTM >= DateTime.MaxValue)
                    arParms[4].Value = System.Data.SqlTypes.SqlDateTime.Null;
                else
                {
                    arParms[4].Value = objSalesVehicle.BillDate;
                }


                arParms[5] = new SqlParameter("@TotalUSDAmount", SqlDbType.Money);
                arParms[5].Value = objSalesVehicle.TotalAmount;

                arParms[6] = new SqlParameter("@TotalGourdesAmount", SqlDbType.Money);
                arParms[6].Value = objSalesVehicle.TotalGourdesAmount;

                arParms[7] = new SqlParameter("@PaidUSDAmount", SqlDbType.Money);
                arParms[7].Value = objSalesVehicle.PaidAmount;

                arParms[8] = new SqlParameter("@PaidGourdesAmount", SqlDbType.Money);
                arParms[8].Value = objSalesVehicle.PaidGourdesAmount;

                arParms[9] = new SqlParameter("@CreditUSDAmount", SqlDbType.Money);
                arParms[9].Value = objSalesVehicle.DueUSDAmount;

                arParms[10] = new SqlParameter("@CreditGrourdesAmount", SqlDbType.Money);
                arParms[10].Value = objSalesVehicle.DueGrourdesAmount;

                arParms[11] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[11].Value = objSalesVehicle.BillGroupCode;


                arParms[12] = new SqlParameter("@Remark", SqlDbType.VarChar);
                arParms[12].Value = objSalesVehicle.Remarks;


                arParms[13] = new SqlParameter("@CustomerID", SqlDbType.SmallInt);
                arParms[13].Value = objSalesVehicle.CustomerID;

                arParms[14] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[14].Value = objSalesVehicle.CompanyID;

                arParms[15] = new SqlParameter("@LastModBy ", SqlDbType.VarChar);
                arParms[15].Value = objSalesVehicle.LastModBy;

                arParms[16] = new SqlParameter("@AddedBy ", SqlDbType.VarChar);
                arParms[16].Value = objSalesVehicle.AddedBy;

                arParms[17] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[17].Value = objSalesVehicle.IsActive;


                arParms[18] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[18].Value = objSalesVehicle.FinancialYearID;


                arParms[19] = new SqlParameter("@Action", SqlDbType.Int);
                arParms[19].Value = objSalesVehicle.ActionType;

                arParms[20] = new SqlParameter("@PayMode", SqlDbType.VarChar);
                arParms[20].Value = objSalesVehicle.PaymentMode;

                arParms[21] = new SqlParameter("@StreetID", SqlDbType.Int);
                arParms[21].Value = objSalesVehicle.StreetID;

                arParms[22] = new SqlParameter("@TotalDeliveryChargesGrourdes", SqlDbType.Money);
                arParms[22].Value = objSalesVehicle.TotalDeliveryChargesGrourdes;

                arParms[23] = new SqlParameter("@BillHeaderId", SqlDbType.Int);
                arParms[23].Value = objSalesVehicle.BillHeaderID;

                arParms[24] = new SqlParameter("@UnitID", SqlDbType.Int);
                arParms[24].Value = objSalesVehicle.UnitId;


                arParms[25] = new SqlParameter("@AmountGourdes", SqlDbType.VarChar);
                arParms[25].Value = objSalesVehicle.Othercharges;

                arParms[26] = new SqlParameter("@GourdesDesc", SqlDbType.VarChar);
                arParms[26].Value = objSalesVehicle.OtherDesc;

                arParms[27] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[27].Value = objSalesVehicle.xmlSalesTransactionDetail;

                arParms[28] = new SqlParameter("@message", SqlDbType.VarChar, 15);
                arParms[28].Direction = ParameterDirection.Output;

                arParms[29] = new SqlParameter("@RemarksCheckout", SqlDbType.VarChar, 1000);
                arParms[29].Value = objSalesVehicle.RemarksCheckout;

                arParms[30] = new SqlParameter("@RemarksDelivery", SqlDbType.VarChar, 1000);
                arParms[30].Value = objSalesVehicle.RemarksDelivery;
                arParms[31] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[31].Value = objSalesVehicle.CurrencyID;
                arParms[32] = new SqlParameter("@OtherChargeID", SqlDbType.VarChar);
                arParms[32].Value = objSalesVehicle.OtherChargeID;

                arParms[33] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
                arParms[33].Value = objSalesVehicle.CurrencyRate;
                
                arParms[34] = new SqlParameter("@TotalDeliveryChargesUSD", SqlDbType.Money);
                arParms[34].Value = objSalesVehicle.TotalDeliveryChargesUSD;
                
                 arParms[35] = new SqlParameter("@TotalSalesTaxGrourdes", SqlDbType.Money);
                arParms[35].Value = objSalesVehicle.TotalSalesTaxGrourdes;

                arParms[36] = new SqlParameter("@TotalSalesTaxUSD", SqlDbType.Money);
                arParms[36].Value = objSalesVehicle.TotalSalesTaxUSD;

                arParms[37] = new SqlParameter("@TotalGrandTotalGourdes", SqlDbType.Money);
                arParms[37].Value = objSalesVehicle.TotalGrandTotalGourdes;

                arParms[38] = new SqlParameter("@TotalGrandTotalUSD", SqlDbType.Money);
                arParms[38].Value = objSalesVehicle.TotalGrandTotalUSD;

                arParms[39] = new SqlParameter("@BillDueDate", SqlDbType.Date);
                arParms[39].Value = objSalesVehicle.BillDueDate.ToShortDateString();




                SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_SAL_UpdateSalesProductDetail]", arParms);
                strUpadted = arParms[28].Value.ToString();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return strUpadted;
        }


        public bool CancelOrder(Product objSalesVehicle)
        {

            bool result = false;
            try
            {
                SqlParameter[] arParms = new SqlParameter[7];



                arParms[0] = new SqlParameter("@LastModBy ", SqlDbType.VarChar);
                arParms[0].Value = objSalesVehicle.LastModBy;

                arParms[1] = new SqlParameter("@FinancialYearID", SqlDbType.Bit);
                arParms[1].Value = objSalesVehicle.FinancialYearID;


                arParms[2] = new SqlParameter("@BillHeaderId", SqlDbType.Int);
                arParms[2].Value = objSalesVehicle.BillHeaderID;

                arParms[3] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[3].Value = objSalesVehicle.SaleOrderNumber;


                arParms[4] = new SqlParameter("@SalesStatus", SqlDbType.Int);
                arParms[4].Value = objSalesVehicle.SalesStatus;

                arParms[5] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[5].Value = objSalesVehicle.CustomerID;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.VarChar);
                arParms[6].Value = objSalesVehicle.CompanyID;


                int res = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateCancelOrder]", arParms);
                if (res > 0)
                {
                    result = true;
                }

            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return result;
        }


        public bool SaveCancelOrder(Product objSalesVehicle)
        {

            bool result = false;
            try
            {
                SqlParameter[] arParms = new SqlParameter[7];



                arParms[0] = new SqlParameter("@LastModBy ", SqlDbType.VarChar);
                arParms[0].Value = objSalesVehicle.LastModBy;

                arParms[1] = new SqlParameter("@FinancialYearID", SqlDbType.Bit);
                arParms[1].Value = objSalesVehicle.FinancialYearID;


                arParms[2] = new SqlParameter("@BillHeaderId", SqlDbType.Int);
                arParms[2].Value = objSalesVehicle.BillHeaderID;

                arParms[3] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[3].Value = objSalesVehicle.SaleOrderNumber;


                arParms[4] = new SqlParameter("@SalesStatus", SqlDbType.Int);
                arParms[4].Value = objSalesVehicle.SalesStatus;

                arParms[5] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[5].Value = objSalesVehicle.CustomerID;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.VarChar);
                arParms[6].Value = objSalesVehicle.CompanyID;


                int res = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_SAL_CancelOrder]", arParms);
                if (res > 0)
                {
                    result = true;
                }

            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return result;
        }


        public Product GetUnitDetailsByID(Product objProduct)
        {
            Product objRetProduct = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@UnitID", SqlDbType.VarChar);
                arParms[0].Value = objProduct.UnitId;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_GetUnitDetailsByID", ds, new string[] { "Unit" }, arParms);
                objRetProduct = ORHelper<Product>.FromDataTable(ds.Tables["Unit"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetProduct;
        }

        #region Search Vehical Details



        public List<Product> SearchVehicalList(Product objStore)
        {
            List<Product> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[8];

                arParms[0] = new SqlParameter("@ContainerNo", SqlDbType.VarChar);
                arParms[0].Value = objStore.ContainerNo;
                arParms[1] = new SqlParameter("@Model", SqlDbType.VarChar);
                arParms[1].Value = objStore.Model;

                arParms[2] = new SqlParameter("@Count", SqlDbType.Int);
                arParms[2].Value = objStore.PageSize;

                arParms[3] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[3].Value = objStore.ProductID;

                arParms[4] = new SqlParameter("@SaleOrderNumber", SqlDbType.VarChar);
                arParms[4].Value = objStore.SaleOrderNumber;

                arParms[5] = new SqlParameter("@ProductSaleID", SqlDbType.Int);
                arParms[5].Value = objStore.ProductSaleID;


                arParms[6] = new SqlParameter("@EngineNo", SqlDbType.VarChar);
                arParms[6].Value = objStore.EngineNo;



                arParms[7] = new SqlParameter("@VINNO", SqlDbType.VarChar);
                arParms[7].Value = objStore.VINNO;

                               

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchVehicalUnsold", arParms);
                lstObject = ORHelper<Product>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        #endregion




        public List<Product> SearchSalesCertificateList(Product objStore)
        {
            List<Product> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@StartDate", SqlDbType.Date);
                arParms[0].Value = objStore.StartDate;
                arParms[1] = new SqlParameter("@EndDate", SqlDbType.Date);
                arParms[1].Value = objStore.EndDate;

                arParms[2] = new SqlParameter("@VinNo", SqlDbType.VarChar);
                arParms[2].Value = objStore.VINNO;

                arParms[3] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[3].Value = objStore.CustomerName;


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchCertificateList", arParms);
                lstObject = ORHelper<Product>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

    }
}
