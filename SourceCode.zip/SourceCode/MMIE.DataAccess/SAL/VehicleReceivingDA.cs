﻿using System;

using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;


using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;

/*************************************************************************************************  
  
  Name of the Class			    : PaymentDA                      
  
  Description of the class	    : 
  
  Created Date					: 7th Dec 2010  
  
  Developer						: 
  
  Modify Date					: 
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.DataAccess.SAL
{
    public class VehicleReceivingDA : DataAccessObjectBase
    {
        #region Public Members

        //public void GetPayment()
        //{
        //    //List<LookupItem> objList = null;
        //    try
        //    {
        //        //SqlParameter[] arParms = new SqlParameter[0];
        //        //SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetFinancialYearList", arParms);
        //        //List<LookupItem> lstLookupItem = ORHelper<LookupItem>.FromDataReaderToList(dataReader);
        //        //dataReader.Close();
        //    }
        //    catch (Exception ex) //Exception of the business layer(itself)//unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new BusinessProcessException("5000001", ex);
        //    }
        //    //return objFinancialYearList;
        //}

        //public List<AccountGroup> GetAccountGroupByPatientTypeCode(PatientType patientDetail)
        //{
        //    List<AccountGroup> objList = null;
        //    try
        //    {
        //        SqlParameter[] arParms = new SqlParameter[1];
        //        arParms[0] = new SqlParameter("@PatientTypeCode", SqlDbType.VarChar);
        //        arParms[0].Value = patientDetail.PatientTypeCode;
        //        SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetAccountGroupByPatientTypeCode", arParms);
        //        List<AccountGroup> lstAccountGroup = ORHelper<AccountGroup>.FromDataReaderToList(dataReader);
        //        objList = lstAccountGroup;
        //        dataReader.Close();
        //    }
        //    catch (Exception ex) //Exception of the business layer(itself)//unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new BusinessProcessException("5000001", ex);
        //    }
        //    return objList;
        //}
        //public List<AccountGroup> GetAccountGroupByPatientTypeID(PatientType patientDetail)
        //{
        //    List<AccountGroup> objList = null;
        //    try
        //    {
        //        SqlParameter[] arParms = new SqlParameter[1];
        //        arParms[0] = new SqlParameter("@PatientTypeID", SqlDbType.VarChar);
        //        arParms[0].Value = patientDetail.PatientTypeID;
        //        SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetAccountGroupByPatientTypeID", arParms);
        //        List<AccountGroup> lstAccountGroup = ORHelper<AccountGroup>.FromDataReaderToList(dataReader);
        //        objList = lstAccountGroup;
        //        dataReader.Close();
        //    }
        //    catch (Exception ex) //Exception of the business layer(itself)//unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new BusinessProcessException("5000001", ex);
        //    }
        //    return objList;
        //}

        #endregion



    }
}
