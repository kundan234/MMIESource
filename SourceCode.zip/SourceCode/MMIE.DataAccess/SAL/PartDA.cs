﻿using System;

using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.Common;
/*************************************************************************************************  
  
  Name of the Class			    : PaymentDA                      
  
  Description of the class	    : 
  
  Created Date					: 7th Dec 2010  
  
  Developer						: 
  
  Modify Date					: 
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.DataAccess.SAL
{
    public class PartDA : DataAccessObjectBase
    {
        //MMIE.Data.Common.isun
        public DataTable GetMaterialDetail(Product.IsUniqueMaterial isUnique, Int32 SaleTypeID, Int32 StreetID, Int32 StreetChargeID)
        {
            DataTable dtable = new DataTable("ProductDetail");
            try
            {
                SqlParameter[] arParms = new SqlParameter[4];
                arParms[0] = new SqlParameter("@IsUniqueMaterial", SqlDbType.Int);
                arParms[0].Value = isUnique;
                arParms[1] = new SqlParameter("@SaleTypeID", SqlDbType.Int);
                arParms[1].Value = SaleTypeID;
                arParms[2] = new SqlParameter("@StreetID", SqlDbType.Int);
                arParms[2].Value = StreetID;
                arParms[3] = new SqlParameter("@StreetChargeID", SqlDbType.Int);
                arParms[3].Value = StreetChargeID;


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchProducts", arParms);
                dtable.Load(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }
            return dtable;
        }

        //MMIE.Data.Common.isun
        public DataTable GetMaterialDetailNew(Int32 StreetID, Int32 StreetChargeID, Int32 CustomerID, string productname, string Model,int GroupType)
        {
            DataTable dtable = new DataTable("ProductDetail");
            try
            {
                SqlParameter[] arParms = new SqlParameter[6];

                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = CustomerID;
                arParms[1] = new SqlParameter("@StreetID", SqlDbType.Int);
                arParms[1].Value = StreetID;

                arParms[2] = new SqlParameter("@ProductName", SqlDbType.VarChar);
                arParms[2].Value = productname;

                arParms[3] = new SqlParameter("@StreetChargeID", SqlDbType.Int);
                arParms[3].Value = StreetChargeID;
                
                arParms[4] = new SqlParameter("@Model", SqlDbType.VarChar);
                arParms[4].Value = Model;

                arParms[5] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[5].Value = GroupType;
                
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchProductsNew", arParms);
                dtable.Load(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }
            return dtable;
        }
          //MMIE.Data.Common.isun
        public DataTable GetMaterialVehicalDetail(Int32 StreetID, Int32 StreetChargeID, Int32 CustomerID, string productname, string Model, int GroupType,int StoreID)
        {
            DataTable dtable = new DataTable("ProductDetail");
            try
            {
                SqlParameter[] arParms = new SqlParameter[7];

                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = CustomerID;
                arParms[1] = new SqlParameter("@StreetID", SqlDbType.Int);
                arParms[1].Value = StreetID;

                arParms[2] = new SqlParameter("@ProductName", SqlDbType.VarChar);
                arParms[2].Value = productname;

                arParms[3] = new SqlParameter("@StreetChargeID", SqlDbType.Int);
                arParms[3].Value = StreetChargeID;
                
                arParms[4] = new SqlParameter("@Model", SqlDbType.VarChar);
                arParms[4].Value = Model;

                arParms[5] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[5].Value = GroupType;

                arParms[6] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[6].Value = StoreID;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchProductsVehical", arParms);
                dtable.Load(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }
            return dtable;
        }
        
        public string UpdateSalesProductDetail(Product objSalesProduct)        {

            string strUpadted = "";
            try
            {
                SqlParameter[] arParms = new SqlParameter[41];

                arParms[0] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[0].Value = objSalesProduct.StoreID;

                arParms[1] = new SqlParameter("@SalesStatus", SqlDbType.SmallInt);
                arParms[1].Value = objSalesProduct.SalesStatus;


                arParms[2] = new SqlParameter("@SaleOrderNumber", SqlDbType.VarChar);
                arParms[2].Value = objSalesProduct.SaleOrderNumber;

                arParms[3] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[3].Value = objSalesProduct.InvoiceNo;


                arParms[4] = new SqlParameter("@BillDate ", SqlDbType.DateTime);
                if (objSalesProduct.BillDate <= DateTime.MinValue || objSalesProduct.AddedDTM >= DateTime.MaxValue)
                    arParms[4].Value = System.Data.SqlTypes.SqlDateTime.Null;
                else
                {
                    arParms[4].Value = objSalesProduct.BillDate;
                }


                arParms[5] = new SqlParameter("@TotalUSDAmount", SqlDbType.Money);
                arParms[5].Value = objSalesProduct.TotalAmount;

                arParms[6] = new SqlParameter("@TotalGourdesAmount", SqlDbType.Money);
                arParms[6].Value = objSalesProduct.TotalGourdesAmount;

                arParms[7] = new SqlParameter("@PaidUSDAmount", SqlDbType.Money);
                arParms[7].Value = objSalesProduct.PaidAmount;

                arParms[8] = new SqlParameter("@PaidGourdesAmount", SqlDbType.Money);
                arParms[8].Value = objSalesProduct.PaidGourdesAmount;

                arParms[9] = new SqlParameter("@CreditUSDAmount", SqlDbType.Money);
                arParms[9].Value = objSalesProduct.DueUSDAmount;

                arParms[10] = new SqlParameter("@CreditGrourdesAmount", SqlDbType.Money);
                arParms[10].Value = objSalesProduct.DueGrourdesAmount;
             //   arParms[10].Value = 0;
                arParms[11] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[11].Value = objSalesProduct.BillGroupCode;


                arParms[12] = new SqlParameter("@Remark", SqlDbType.VarChar);
                arParms[12].Value = objSalesProduct.Remarks;


                arParms[13] = new SqlParameter("@CustomerID", SqlDbType.SmallInt);
                arParms[13].Value = objSalesProduct.CustomerID;

                arParms[14] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[14].Value = objSalesProduct.CompanyID;

                arParms[15] = new SqlParameter("@LastModBy ", SqlDbType.VarChar);
                arParms[15].Value = objSalesProduct.LastModBy;

                arParms[16] = new SqlParameter("@AddedBy ", SqlDbType.VarChar);
                arParms[16].Value = objSalesProduct.AddedBy;

                arParms[17] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[17].Value = objSalesProduct.IsActive;


                arParms[18] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[18].Value = objSalesProduct.FinancialYearID;


                arParms[19] = new SqlParameter("@Action", SqlDbType.Int);
                arParms[19].Value = objSalesProduct.ActionType;

                arParms[20] = new SqlParameter("@PayMode", SqlDbType.VarChar);
                arParms[20].Value = objSalesProduct.PaymentMode;
                //arParms[20].Value = 0;

                arParms[21] = new SqlParameter("@StreetID", SqlDbType.Int);
                arParms[21].Value = objSalesProduct.StreetID;

                arParms[22] = new SqlParameter("@DeliveryCharges", SqlDbType.Money);
                arParms[22].Value = objSalesProduct.DeliveryAmount;
                //arParms[22].Value = 0;

                arParms[23] = new SqlParameter("@BillHeaderId", SqlDbType.Int);
                arParms[23].Value = objSalesProduct.BillHeaderID;
                //arParms[23].Value = 0;

                arParms[24] = new SqlParameter("@UnitID", SqlDbType.Int);
                arParms[24].Value = objSalesProduct.UnitId;


                arParms[25] = new SqlParameter("@AmountGourdes", SqlDbType.VarChar);
                arParms[25].Value = objSalesProduct.Othercharges;

                arParms[26] = new SqlParameter("@GourdesDesc", SqlDbType.VarChar);
                arParms[26].Value = objSalesProduct.OtherDesc;

                arParms[27] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[27].Value = objSalesProduct.xmlSalesTransactionDetail;

                arParms[28] = new SqlParameter("@message", SqlDbType.VarChar, 15);
                arParms[28].Direction = ParameterDirection.Output;

                
                arParms[29] = new SqlParameter("@RemarksCheckout", SqlDbType.VarChar);
                arParms[29].Value = objSalesProduct.RemarksCheckout;
                arParms[30] = new SqlParameter("@RemarksDelivery", SqlDbType.VarChar);
                arParms[30].Value = objSalesProduct.RemarksDelivery;

                arParms[31] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[31].Value = objSalesProduct.CurrencyID;
                arParms[32] = new SqlParameter("@OtherChargeID", SqlDbType.VarChar);
                arParms[32].Value = objSalesProduct.OtherChargeID;
                arParms[33] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
                arParms[33].Value = objSalesProduct.CurrencyRate;
                arParms[34] = new SqlParameter("@BillDueDate", SqlDbType.Date);
                arParms[34].Value = objSalesProduct.BillDueDate.ToShortDateString();
                arParms[35] = new SqlParameter("@TotalDeliveryChargesGrourdes", SqlDbType.Money);
                arParms[35].Value = objSalesProduct.TotalDeliveryChargesGrourdes;
                arParms[36] = new SqlParameter("@TotalDeliveryChargesUSD", SqlDbType.Money);
                arParms[36].Value = objSalesProduct.TotalDeliveryChargesUSD;
                arParms[37] = new SqlParameter("@TotalSalesTaxGrourdes", SqlDbType.Money);
                arParms[37].Value = objSalesProduct.TotalSalesTaxGrourdes;
                arParms[38] = new SqlParameter("@TotalSalesTaxUSD", SqlDbType.Money);
                arParms[38].Value = objSalesProduct.TotalSalesTaxUSD;
                arParms[39] = new SqlParameter("@TotalGrandTotalGourdes", SqlDbType.Money);
                arParms[39].Value = objSalesProduct.TotalGrandTotalGourdes;
                arParms[40] = new SqlParameter("@TotalGrandTotalUSD", SqlDbType.Money);
                arParms[40].Value = objSalesProduct.TotalGrandTotalUSD;


                //SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_STR_UpdateMaterialStockDetail", arParms);
                //strUpadted = arParms[43].Value.ToString();
                SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_SAL_UpdateSalesProductDetail]", arParms);
                strUpadted = arParms[28].Value.ToString();
               
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "D7000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("D7000001", ex);
            }
            return strUpadted;
        }

        public List<Customer> SearchStore(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.OrderNo;
                arParms[1] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[1].Value = objStore.CustomerName;
                arParms[2] = new SqlParameter("@PhoneNumber", SqlDbType.VarChar);
                arParms[2].Value = objStore.CustomerPhone;
                arParms[3] = new SqlParameter("@EngineNo", SqlDbType.VarChar);
                arParms[3].Value = objStore.EngineNo;
                arParms[4] = new SqlParameter("@VinNo", SqlDbType.VarChar);
                arParms[4].Value = objStore.VinNo;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_SAL_GetOrderDeliveryDetails", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Customer> SearchOrderDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.OrderNo;
                arParms[1] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[1].Value = objStore.CustomerName;
                arParms[2] = new SqlParameter("@PhoneNumber", SqlDbType.VarChar);
                arParms[2].Value = objStore.CustomerPhone;
              
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchOrderDetails", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Customer> CheckOutSearchStore(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.OrderNo;
                arParms[1] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[1].Value = objStore.CustomerName;
                arParms[2] = new SqlParameter("@PhoneNumber", SqlDbType.VarChar);
                arParms[2].Value = objStore.CustomerPhone;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_SAL_GetOrderCheckOutDetails", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Customer> GetPartialOrderSearch(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.OrderNo;
                arParms[1] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[1].Value = objStore.CustomerName;
                arParms[2] = new SqlParameter("@PhoneNumber", SqlDbType.VarChar);
                arParms[2].Value = objStore.CustomerPhone;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetOrderPartialDetails", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Customer> SearchOrderAll(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.OrderNo;
                arParms[1] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[1].Value = objStore.CustomerName;
                arParms[2] = new SqlParameter("@PhoneNumber", SqlDbType.VarChar);
                arParms[2].Value = objStore.CustomerPhone;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_SAL_GetSearchOrder]", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Customer> BindOrderDetail(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.OrderNo;
                arParms[1] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[1].Value = objStore.GroupType;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetOrderCategoryDetails", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public int GETMAXBillHeaderID()
        {
            int PO=0;
              SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@PNumber", SqlDbType.Int);
                arParms[0].Direction = ParameterDirection.Output;  
                
            try
            {

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_GetMaxBillHeaderID]", arParms);
                if (noOfEffectedRecords > 0)
                {
                    PO = int.Parse(arParms[0].Value.ToString());
                }
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return PO;
        }
        public bool SaveShipNumber(Customer objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[9];

                arParms[0] = new SqlParameter("@OrderNo", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.OrderNo;
                arParms[1] = new SqlParameter("@SalesStatus", SqlDbType.Int);
                arParms[1].Value = objCustomer.SalesStatus;
                arParms[2] = new SqlParameter("@ShipID", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.ShipmentNumber;
                arParms[3] = new SqlParameter("@PaidUSDAmt", SqlDbType.Decimal);
                arParms[3].Value = objCustomer.PaidUSDAmt;
                arParms[4] = new SqlParameter("@DueUSDAmt", SqlDbType.Decimal);
                arParms[4].Value = objCustomer.DueUSDAmt;
                arParms[5] = new SqlParameter("@PaidGourdesAmt", SqlDbType.Decimal);
                arParms[5].Value = objCustomer.PaidGourdesAmt;
                arParms[6] = new SqlParameter("@DueGourdesAmt", SqlDbType.Decimal);
                arParms[6].Value = objCustomer.DueGourdesAmt;
                arParms[7] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[7].Value = objCustomer.XMLData;
                arParms[8] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[8].Value = objCustomer.IsActive;
              
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_UpdateShipmentNumber", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        public bool SaveBulkShipNumber(Order objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[17];

                arParms[0] = new SqlParameter("@OrderNo", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.OrderNumber;

                arParms[1] = new SqlParameter("@SalesStatus", SqlDbType.Int);
                arParms[1].Value = objCustomer.SalesStatus;
                arParms[2] = new SqlParameter("@ShipID", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.ShipmentNumber;

                //arParms[3] = new SqlParameter("@PaidUSDAmt", SqlDbType.Decimal);
                //arParms[3].Value = objCustomer.PaidUSDAmt;
                //arParms[4] = new SqlParameter("@DueUSDAmt", SqlDbType.Decimal);
                //arParms[4].Value = objCustomer.DueUSDAmt;
                //arParms[5] = new SqlParameter("@PaidGourdesAmt", SqlDbType.Decimal);
                //arParms[5].Value = objCustomer.PaidGourdesAmt;
                
                arParms[3] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[3].Value = objCustomer.XMLData;
                arParms[4] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[4].Value = objCustomer.IsActive;
                //arParms[5] = new SqlParameter("@VehicalSalesDetailsXML", SqlDbType.Xml);
                //arParms[5].Value = objCustomer.VehicalSalesDetailsXML;
                arParms[6] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[6].Value = objCustomer.GroupType;

                arParms[7] = new SqlParameter("@BillHeaderID", SqlDbType.Int);
                arParms[7].Value = objCustomer.BillHeaderID;
                arParms[8] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[8].Value = objCustomer.StoreID;

                arParms[9] = new SqlParameter("@DueAmountGourdes", SqlDbType.Money);
                arParms[9].Value = objCustomer.DueGrourdesAmount;
                arParms[10] = new SqlParameter("@DueAmountUSD", SqlDbType.Money);
                arParms[10].Value = objCustomer.DueUSDAmount;

                arParms[11] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[11].Value = objCustomer.PaymentMode;

                arParms[12] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[12].Value = objCustomer.LastModBy;
                arParms[13] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[13].Value = objCustomer.InvoiceNo;

                arParms[14] = new SqlParameter("@RemarksDelivery", SqlDbType.VarChar);
                arParms[14].Value = objCustomer.RemarksDelivery;

                arParms[15] = new SqlParameter("@Amount", SqlDbType.Money);
                arParms[15].Value = objCustomer.Amount;

                arParms[16] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[16].Value = objCustomer.CustomerID;


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_UpdateBulkShipmentNumber", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public bool UpdatePartPartialCancel(Order objOrder)
        {
            bool status = false;
            try
            {
                SqlParameter[] arParms = new SqlParameter[6];
                arParms[0] = new SqlParameter("@XMLData", SqlDbType.VarChar);
                arParms[0].Value = objOrder.XMLData;
                arParms[1] = new SqlParameter("@BillHeaderID", SqlDbType.BigInt);
                arParms[1].Value = objOrder.BillHeaderID;
                arParms[2] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[2].Value = objOrder.CustomerID;
                arParms[3] = new SqlParameter("@OpeningBalance", SqlDbType.Money);
                arParms[3].Value = objOrder.OpeningBalance;
                arParms[4] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[4].Value = objOrder.LastModBy;
                arParms[5] = new SqlParameter("@CancelAmt", SqlDbType.Money);
                arParms[5].Value = objOrder.CancelAmt;
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_PartialOrderCancellation", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;
            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }
            return status;
        }

        #region user for vehicle,pickup from PUR
        public List<Customer> GetRefundOrderDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objStore.OrderNo;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_SAL_GETREFUNDORDERDETAILS", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public bool RefundQtyDetails(Customer objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[20];

                arParms[0] = new SqlParameter("@RefundQty", SqlDbType.Int);
                arParms[0].Value = objCustomer.RefundQty;
                arParms[1] = new SqlParameter("@ProductSaleID", SqlDbType.Int);
                arParms[1].Value = objCustomer.ProductSaleID;
                arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.OrderNo;
                arParms[3] = new SqlParameter("@ProductSaleDeleveryID", SqlDbType.Int);
                arParms[3].Value = objCustomer.ProductDeliveryID;
                arParms[4] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[4].Value = objCustomer.ProdID;
                arParms[5] = new SqlParameter("@ReturnRefundAmountUSD", SqlDbType.Decimal);
                arParms[5].Value = objCustomer.RefundAmountUSD;
                arParms[6] = new SqlParameter("@ReturnRefundAmountGourdes", SqlDbType.Decimal);
                arParms[6].Value = objCustomer.RefundAmountGourdes;
                arParms[7] = new SqlParameter("@ReturnRefundChargeAmountUSD", SqlDbType.Decimal);
                arParms[7].Value = objCustomer.RefundChargeUSD;
                arParms[8] = new SqlParameter("@ReturnRefundChargeAmountGourdes", SqlDbType.Decimal);
                arParms[8].Value = objCustomer.RefundChargeGourdes;
                arParms[9] = new SqlParameter("@ReturnRefundAdjustAmountUSD", SqlDbType.Decimal);
                arParms[9].Value = objCustomer.RefundAdjustAmtUSD;
                arParms[10] = new SqlParameter("@ReturnRefundAdjustAmountGourdes", SqlDbType.Decimal);
                arParms[10].Value = objCustomer.RefundAdjustAmtGourdes;
                arParms[11] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[11].Value = objCustomer.GroupType;
                arParms[12] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[12].Value = objCustomer.FinancialYearID;
                arParms[13] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[13].Value = objCustomer.CompanyID;
                arParms[14] = new SqlParameter("@Addedby", SqlDbType.VarChar);
                arParms[14].Value = objCustomer.AddedBy;
                arParms[15] = new SqlParameter("@LastModby", SqlDbType.VarChar);
                arParms[15].Value = objCustomer.ModifiedBy;
                arParms[16] = new SqlParameter("@Quantity", SqlDbType.Float);
                arParms[16].Value = objCustomer.TotalRefundUnit;
                arParms[17] = new SqlParameter("@UnitName", SqlDbType.VarChar);
                arParms[17].Value = objCustomer.UnitName;

                arParms[18] = new SqlParameter("@VehicalPOID", SqlDbType.BigInt);
                arParms[18].Value = objCustomer.VehicalPOID;

                arParms[19] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[19].Value = objCustomer.RemarksCheckout;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_SAL_UpdateRefundDetails", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        #endregion
    }
}
