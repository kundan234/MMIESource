﻿using System;

using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.Common;

namespace MMIE.DataAccess.SAL
{
   public class CorrectionCertiFicateDA : DataAccessObjectBase
    {
        public List<Order> SearchCorrectionCertiFicate(Order objOrder)
        {
            List<Order> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[7];

                arParms[0] = new SqlParameter("@VIN", SqlDbType.VarChar);
                arParms[0].Value = objOrder.VinNo;
                arParms[1] = new SqlParameter("@EngineNo", SqlDbType.VarChar);
                arParms[1].Value = objOrder.EngineNo;
                arParms[2] = new SqlParameter("@modelNO", SqlDbType.VarChar);
                arParms[2].Value = objOrder.ModelNO;
                arParms[3] = new SqlParameter("@CoustomerName", SqlDbType.VarChar);
                arParms[3].Value = objOrder.CustomerName;
                arParms[4] = new SqlParameter("@Year", SqlDbType.Date);
                arParms[4].Value = objOrder.CertificateDate;
                arParms[5] = new SqlParameter("@brand", SqlDbType.VarChar);
                arParms[5].Value = objOrder.Brand;
                arParms[6] = new SqlParameter("@CertificateCorrectionID", SqlDbType.VarChar);
                arParms[6].Value = objOrder.CertificateCorrectionID;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_SAL_SearchCertificate]", arParms);
                lstObject = ORHelper<Order>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public Order GetProductDetailsByID(string ID)
        {
            Order objRetProduct = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];


                arParms[0] = new SqlParameter("@CertificateCorrectionID", SqlDbType.VarChar);
                arParms[0].Value = ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_SearchCertificate", ds, new string[] { "Details" }, arParms);
                objRetProduct = ORHelper<Order>.FromDataTable(ds.Tables["Details"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetProduct;
        }


        public bool UpdateCorrectionCertiFicate(Product objOrder)
        {
            List<Order> lstObject = null;
            bool result = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@VIN", SqlDbType.VarChar);
                arParms[0].Value = objOrder.VINNO;
                arParms[1] = new SqlParameter("@EngineNo", SqlDbType.VarChar);
                arParms[1].Value = objOrder.EngineNo;
                arParms[2] = new SqlParameter("@ProductSaleDeleveryID", SqlDbType.Int);
                arParms[2].Value = objOrder.ProductSaleDeleveryID;
                arParms[3] = new SqlParameter("@DeliveryDate", SqlDbType.Date);
                arParms[3].Value = objOrder.DeliveryDate;

                
                int res = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[USP_SAL_UpdateCertificate]", arParms);

                if (res > 0)
                    result=true;

              
              
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return result;
        }
    }
}
