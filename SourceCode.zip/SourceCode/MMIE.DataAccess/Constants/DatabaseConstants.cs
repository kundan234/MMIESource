﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
/*************************************************************************************************  
  
  Name of the Class			    : Lookups                      
  
  Description of the class	    : This class will have constants of Database like parameter name, storeprocedure and result set fields
  
  Created Date					: 23 Dec 2010  
  
  Developer						: Prem
  
  Modify Date					: 23/12/2010  
  
  Modified By Developer			: Prem
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.DataAccess.Constants
{
    internal static class CommonConstants
    {
        internal static class Parameters
        {
            public const string CurrentIndex = "@CurrentIndex";
            public const string PageSize = "@PageSize";
            
            public const string FinancialYearID = "@FinancialYearID";
            public const string CompanyID = "@CompanyID";

            public const string IsActive = "@IsActive";
            public const string AddedBy = "@AddedBy ";
            public const string AddedDTM = "@AddedDTM";
            public const string LastModBy = "@LastModBy";
            public const string LastModDTM = "@LastModDTM";
            public const string ActionType = "@ActionType";
            public const string IsExist = "@IsExist";
        }
    }

    #region Lookups Constants of database
    internal static class LookupConstants
    {
        internal static class StoreProcedures
        {
            public const string GetMasterLookup = "usp_GetMasterLookup";
            public const string SaveLookupMaster = "usp_SaveLookupMST";
            public const string UpdateLookupMaster = "usp_UpdateLookupMST";
            public const string GetPagedMasterLookup = "usp_GetPagedMasterLookup";
            public const string GetLookupItemByID = "usp_GetLookupItemByID";
            public const string GetConsultantPastDisease = "usp_OPD_IPD_GetConsultantPastDiseaseMST";
            public const string GetConsultantCinicalFinding = "usp_OPD_IPD_GetConsultantCinicalFindingMST";
            public const string UpdatePatientTypeMST = "usp_REC_UpdatePatientTypeMST";
            
            // STORE STORED PROCEDURES
            public const string UpdateStoreMST = "usp_STR_UpdateStoreMST";
            public const string SearchStoreMST = "usp_StoreCommonMasterData"; 
            public const string GetStoreMSTByID = "usp_StoreCommonMasterDataByID";
            public const string DeleteStoreMST = "usp_DeleteStoreCommonMasterData";
            
            // BILLING
            public const string VerifyBilling = "usp_BIL_VerifyBilling";
            public const string CancelBilling = "usp_BIL_CancelBilling";            
            public const string UpdateBillHeader = "usp_BIL_UpdateBillHeader";

            public const string Discharge = "usp_IPD_Discharge";
            
        }

        internal static class Parameters
        {
            public const string LookupsName = "@LookupsName";
            public const string ItemId = "@ItemId";
            public const string ItemId1 = "@ItemId1";
            public const string ItemCode = "@ItemCode";
            public const string ItemName = "@ItemName";
            public const string ShortDescription = "@ShortDescription";
            public const string LongDescription = "@LongDescription";
       }
    }
    #endregion
    #region Employee Detail
    internal static class EmployeeConstants
    {
        internal static class Parameters
        {
            public const string EmployeeID = "@EmployeeID";

            public const string UserLoginID = "@UserLoginID";

            public const string EmployeeUID = "@EmployeeUID";

            public const string EmployeeCode = "@EmployeeCode";

            public const string SalutationID = "@SalutationID";

            public const string EmployeeFirstName = "@EmployeeFirstName";

            public const string EmployeeLastName = "@EmployeeLastName";

            public const string EmployeeDOB = "@EmployeeDOB";

            public const string SexID = "@SexID";

            public const string BloodGroupID = "@BloodGroupID";

            public const string EmployeeHeight = "@EmployeeHeight";

            public const string EmployeeComplexion = "@EmployeeComplexion";

            public const string EmployeeAddress = "@EmployeeAddress";

            public const string EmployeeLandMark = "@EmployeeLandMark";

            public const string EmployeePhoneNo = "@EmployeePhoneNo";

            public const string EmployeeMobileNo = "@EmployeeMobileNo";

            public const string EmployeePermanentAddress = "@EmployeePermanentAddress";

            public const string EmployeePermanentLandMark = "@EmployeePermanentLandMark";

            public const string EmployeePermanentPhoneNo = "@EmployeePermanentPhoneNo";

            public const string EmployeePermanentMobileNo = "@EmployeePermanentMobileNo";

            public const string EmployeeEmail = "@EmployeeEmail";

            public const string EmployeeWeb = "@EmployeeWeb";
            //payment parameters
            public const string AppointmentDate = "@AppointmentDate";
            public const string ConfirmationDate = "@ConfirmationDate";
            public const string EmploymentTypeID = "@EmploymentTypeID";
            public const string EmployeePAN = "@EmployeePAN";
            public const string ProbationPeriod = "@ProbationPeriod";
            public const string PFNumber = "@PFNumber";
            public const string BasicSalary = "@BasicSalary";
            public const string GrossSalary = "@GrossSalary";
            public const string NetSalary = "@NetSalary";
            public const string VoIntPFContribution = "@VoIntPFContribution";
            public const string TDSMonthlyAmount = "@TDSMonthlyAmount";
            public const string BankTypeId = "@BankTypeId";
            public const string AccountNumber = "@AccountNumber";
            public const string PFLimitApplicable = "@PFLimitApplicable";
            public const string SalaryGenerationApplicable = "@SalaryGenerationApplicable";

            public const string EducationID = "@EducationID";

            public const string DesignationID = "@DesignationID";

            public const string DepartmentID = "@DepartmentID";

            public const string LocationID = "@LocationID";

            public const string MaritalStatusID = "@MaritalStatusID";

            public const string LoadPage = "@LoadPage";

            public const string EmployeePassportNo = "@EmployeePassportNo";

            public const string EmployeeDrivingLicence = "@EmployeeDrivingLicence";

            public const string EmployeeThumbPath = "@EmployeeThumbPath";

            public const string EmployeePhotoPath = "@EmployeePhotoPath";

            public const string EmployeeLanguage = "@EmployeeLanguage";

            public const string ReligionID = "@ReligionID";

            public const string NationalityID = "@NationalityID";

            public const string EmployeeTypeID = "@EmployeeTypeID";

            public const string EmployeeCategoryID = "@EmployeeCategoryID";

            public const string EmployeeDigitalSignaturePath = "@EmployeeDigitalSignaturePath";

            public const string EmployeeIdentificatioMark = "@EmployeeIdentificatioMark";

            public const string EmployeeIDExpire = "@EmployeeIDExpire";

            public const string Authorised = "@Authorised";

            public const string EmployeeActive = "@EmployeeActive";
        }

        internal static class StoreProcedures
        {
            public const string GetEmployees = "usp_PRL_GetEmployees";
            public const string GetEmployeeDetail = "usp_PRL_GetEmployeeDetail";
            public const string UpdateEmployee = "usp_PRL_UpdateEmployee";
            public const string IsEmployeeCodeExist = "usp_PRL_IsEmployeeCodeExist";
        }
    }

    internal static class EducationConstants
    {
        internal static class Parameters
        {
            public const string EmployeeID = "@EmployeeID";
            public const string QualificationID = "@QualificationID";
            public const string PassingYear = "@PassingYear";
            public const string BoardUniversity = "@BoardUniversity";
            public const string Institution = "@Institution";
            public const string Grade = "@Grade";
            public const string Subjects = "@Subjects";

        }
        internal static class StoreProcedures
        {
            public const string UpdateEducation = "usp_PRL_UpdateEducation";
        }
    }
    #endregion


#region Attandance
    internal static class AttandanceConstants
    {
        internal static class Parameters
        {
            public const string SalaryMonth = "@SalaryMonth";
            public const string DayX = "@DayX";
            public const string WorkingHour = "@WorkingHour";
            public const string DayXAttandanceType = "@DayXAttandanceType";
            public const string Total = "@Total";
        }
        internal static class StoreProcedures
        {
            public const string GetAttandance = "usp_PRL_GetAttandance";
            public const string UpdateAttandance = "usp_PRL_UpdateAttandance";
        }
    }
#endregion
}
