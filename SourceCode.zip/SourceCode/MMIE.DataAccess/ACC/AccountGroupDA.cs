﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.ACC; 

namespace MMIE.DataAccess.ACC
{
  public  class AccountGroupDA:DataAccessObjectBase
    {

      public List<AccountGroup> GetAccountGroupALL(bool All)
      {
          List<AccountGroup> lstAccountGroup = null;
          try
          {

              SqlParameter[] arParms = new SqlParameter[2];
              arParms[0] = new SqlParameter("@ActionType", SqlDbType.Int);
              if (All)
                  arParms[0].Value = 1;
              else
                  arParms[0].Value = 2;

              SqlDataReader sqlReader = null;
              sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetAccountGroupList", arParms);
              List<AccountGroup> listAccountGroup = ORHelper<AccountGroup>.FromDataReaderToList(sqlReader);
              lstAccountGroup = listAccountGroup;
          }
          catch (Exception ex) //Exception of the business layer(itself)//unhandle
          {
              PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
              LogManager.WriteErrorLogInDB(ex);
              throw new BusinessProcessException("5000001", ex);
          }
          return lstAccountGroup;
      }
        public bool SaveAccountGroup(AccountGroup objAccountGroup)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[14];
                arParms[0] = new SqlParameter("@AccountGroupID", SqlDbType.Int);
                arParms[0].Value = objAccountGroup.AccountGroupID;
                arParms[1] = new SqlParameter("@GroupName", SqlDbType.VarChar);
                arParms[1].Value = objAccountGroup.GroupName;
                arParms[2] = new SqlParameter("@Details", SqlDbType.VarChar);
                arParms[2].Value = objAccountGroup.Details;

              
 
                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[3].Value = objAccountGroup.IsActive;
                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objAccountGroup.AddedBy;
                arParms[5] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[5].Value = objAccountGroup.ActionType;

                arParms[6] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[6].Value = objAccountGroup.LastModBy;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[7].Value = objAccountGroup.FinancialYearID;
                arParms[8] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[8].Value = objAccountGroup.CompanyID;

              
                arParms[9] = new SqlParameter("@GroupTypeID", SqlDbType.SmallInt);
                arParms[9].Value = objAccountGroup.GroupTypeID;
                arParms[10] = new SqlParameter("@GroupTypeName", SqlDbType.VarChar);
                arParms[10].Value = objAccountGroup.GroupTypeName;
                arParms[11] = new SqlParameter("@AccountType", SqlDbType.VarChar);
                arParms[11].Value = objAccountGroup.AccountType;
                arParms[12] = new SqlParameter("@AccountNumber", SqlDbType.Int);
                arParms[12].Value = objAccountGroup.AccountNumber;
                arParms[13] = new SqlParameter("@VoucherGroupDetails", SqlDbType.VarChar);
                arParms[13].Value = objAccountGroup.VoucherGroupDetails;


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_UpdateAccountGroupMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<AccountGroup> GetSearchAccountGroup(AccountGroup objAccountGroup)
        {
            List<AccountGroup> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[7];

                arParms[0] = new SqlParameter("@AccountGroupID", SqlDbType.Int);
                arParms[0].Value = objAccountGroup.AccountGroupID;
                arParms[1] = new SqlParameter("@GroupName", SqlDbType.VarChar);
                arParms[1].Value = objAccountGroup.GroupName;
                arParms[2] = new SqlParameter("@Details", SqlDbType.VarChar);
                arParms[2].Value = objAccountGroup.Details;



                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[3].Value = objAccountGroup.IsActive;

                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[4].Value = objAccountGroup.CompanyID;

              
                arParms[5] = new SqlParameter("@GroupTypeID", SqlDbType.SmallInt);
                arParms[5].Value = objAccountGroup.GroupTypeID;

                arParms[6] = new SqlParameter("@AccountType", SqlDbType.VarChar);
                arParms[6].Value = objAccountGroup.AccountType;



                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetSearchAccountGroupMST", arParms);
                lstObject = ORHelper<AccountGroup>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<AccountGroup> GetVoucherGroupLedgerHeader(AccountGroup objAccountGroup)
        {
            List<AccountGroup> lstAccountGroup = null;
            try
            {
                SqlDataReader sqlReader = null;
                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@VoucherGroupID", SqlDbType.Int);
                arParms[0].Value = objAccountGroup.AccountGroupID;

                sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetVoucherGroup", arParms);
                List<AccountGroup> listAccountGroup = ORHelper<AccountGroup>.FromDataReaderToList(sqlReader);
                //SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetVoucherGroupLedgerHeader", ds, new string[] { "VoucherGroup", "LedgerHeader" }, arParms);
                lstAccountGroup = listAccountGroup;
            } 
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstAccountGroup;
        }
        public List<AccountGroup> GetSearchVoucherGroup(AccountGroup objAccountGroup)
        {
            List<AccountGroup> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];


                arParms[0] = new SqlParameter("@VoucherGroupID", SqlDbType.Int);
                arParms[0].Value = objAccountGroup.VoucherGroupID;

                arParms[1] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[1].Value = objAccountGroup.IsActive;

                arParms[2] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[2].Value = objAccountGroup.CompanyID;

                arParms[3] = new SqlParameter("@VoucherGroupName", SqlDbType.VarChar);
                arParms[3].Value = objAccountGroup.VoucherGroupName ;

                arParms[4] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[4].Value = objAccountGroup.Remarks;

                



                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetSearchVoucherGroup", arParms);
                lstObject = ORHelper<AccountGroup>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public AccountGroup GetAccountGroupByID(int ID)
        {
            AccountGroup objRetAccountGroup = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@AccountGroupID", SqlDbType.Int);
                arParms[0].Value = ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetSearchAccountGroupMST", ds, new string[] { "AccountGroup" }, arParms);
                objRetAccountGroup = ORHelper<AccountGroup>.FromDataTable(ds.Tables["AccountGroup"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetAccountGroup;
        }


        //public AccountGroup GetVoucherGroupByID(int ID)
        //{
        //    AccountGroup objRetAccountGroup = null;
        //    try
        //    {
        //        SqlParameter[] arParms = new SqlParameter[1];
        //        arParms[0] = new SqlParameter("@VoucherGroupID", SqlDbType.Int);
        //        arParms[0].Value = ID;
        //        DataSet ds = new DataSet();
        //        SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetSearchVoucherGroupMST", ds, new string[] { "AccountGroup" }, arParms);
        //        objRetAccountGroup = ORHelper<AccountGroup>.FromDataTable(ds.Tables["AccountGroup"]);

        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new DataAccessException("5000001", ex);
        //    }

        //    return objRetAccountGroup;
        //}
    }
}
