﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.ACC; 


namespace MMIE.DataAccess.ACC
{
public    class JournalDetailsDA:DataAccessObjectBase
    {

        public bool SaveJournalDetails(JournalDetails objJournalDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[12];
                arParms[0] = new SqlParameter("@JournalDetailsID", SqlDbType.VarChar);
                arParms[0].Value = objJournalDetails.JournalDetailsID;

                arParms[1] = new SqlParameter("@DebitAmount", SqlDbType.Money);
                arParms[1].Value = objJournalDetails.DebitAmount;

                arParms[2] = new SqlParameter("@CreditAmount", SqlDbType.Money);
                arParms[2].Value = objJournalDetails.CreditAmount;

                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[3].Value = objJournalDetails.IsActive;
                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objJournalDetails.AddedBy;
                arParms[5] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[5].Value = objJournalDetails.ActionType;

                arParms[6] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[6].Value = objJournalDetails.LastModBy;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[7].Value = objJournalDetails.FinancialYearID;
                arParms[8] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[8].Value = objJournalDetails.CompanyID;
                arParms[9] = new SqlParameter("@Details", SqlDbType.VarChar);
                arParms[9].Value = objJournalDetails.Details;
                arParms[10] = new SqlParameter("@AccountGroupID", SqlDbType.SmallInt);
                arParms[10].Value = objJournalDetails.AccountGroupID;
                arParms[11] = new SqlParameter("@Dated", SqlDbType.Date);
                arParms[11].Value = Convert.ToDateTime(objJournalDetails.EntryDate);

 


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_UpdateJournalDetails", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        //
        public bool SaveJournalEntry(JournalDetails objJournalDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[12];
                arParms[0] = new SqlParameter("@JournalDetailsID", SqlDbType.VarChar);
                arParms[0].Value = objJournalDetails.JournalDetailsID;
 
                arParms[1] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[1].Value = objJournalDetails.IsActive;
                arParms[2] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[2].Value = objJournalDetails.AddedBy;
                arParms[3] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[3].Value = objJournalDetails.ActionType;

                arParms[4] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[4].Value = objJournalDetails.LastModBy;
                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[5].Value = objJournalDetails.FinancialYearID;
                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[6].Value = objJournalDetails.CompanyID;
                arParms[7] = new SqlParameter("@Details", SqlDbType.VarChar);
                arParms[7].Value = objJournalDetails.Details;
 
                arParms[8] = new SqlParameter("@EntryDate", SqlDbType.Date);
                arParms[8].Value =Convert.ToDateTime(objJournalDetails.EntryDate);


                arParms[9] = new SqlParameter("@IsLocked", SqlDbType.SmallInt);
                arParms[9].Value = objJournalDetails.IsLocked;

                arParms[10] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[10].Value = objJournalDetails.XMLData;

                arParms[11] = new SqlParameter("@ReferenceNo", SqlDbType.VarChar);
                arParms[11].Value = Convert.ToString(objJournalDetails.ReferenceNo);

                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_UpdateJournalEntry", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        public bool SaveJournalEntryForMultipleRecords(JournalDetails objJournalDetails,int TotalRecords)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[9];
               
                arParms[0] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[0].Value = objJournalDetails.IsActive;
                arParms[1] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[1].Value = objJournalDetails.AddedBy;
                arParms[2] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[2].Value = objJournalDetails.ActionType;

                arParms[3] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[3].Value = objJournalDetails.LastModBy;
                arParms[4] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[4].Value = objJournalDetails.FinancialYearID;
                arParms[5] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[5].Value = objJournalDetails.CompanyID;
                arParms[6] = new SqlParameter("@IsLocked", SqlDbType.SmallInt);
                arParms[6].Value = objJournalDetails.IsLocked;

                arParms[7] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[7].Value = objJournalDetails.XMLData;

                arParms[8] = new SqlParameter("@TotalRecords", SqlDbType.SmallInt);
                arParms[8].Value = TotalRecords;
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_UpdateMultipleJournalEntry", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        public List<AccountGroup> GetMappedAccountGroup(AccountGroup objAccountGroup)
        {
            List<AccountGroup> lstAccountGroup = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];
                arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[0].Value = objAccountGroup.CompanyID;

                arParms[1] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[1].Value = objAccountGroup.FinancialYearID;

                SqlDataReader sqlReader = null;
                sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetMappedAccountGroupMST", arParms);
                List<AccountGroup> listAccountGroup = ORHelper<AccountGroup>.FromDataReaderToList(sqlReader);
                lstAccountGroup = listAccountGroup;
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstAccountGroup;
        }

    }
}
