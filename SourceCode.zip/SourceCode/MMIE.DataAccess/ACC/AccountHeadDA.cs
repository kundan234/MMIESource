﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.ACC; 

namespace MMIE.DataAccess.ACC
{
    public class AccountHeadDA : DataAccessObjectBase
    {

      
        public bool SaveAccountGroupHead(AccountHead objAccountHead)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[18];
                arParms[0] = new SqlParameter("@AccountHeadID", SqlDbType.Int);
                arParms[0].Value = objAccountHead.AccountHeadID;
                arParms[1] = new SqlParameter("@AccountGroupID", SqlDbType.Int);
                arParms[1].Value = objAccountHead.AccountGroupID;
                arParms[2] = new SqlParameter("@OpeningBalanceUSD", SqlDbType.Money);
                arParms[2].Value = objAccountHead.OpeningBalanceUSD;
                arParms[3] = new SqlParameter("@OpeningBalanceGourdes", SqlDbType.Money);
                arParms[3].Value = objAccountHead.OpeningBalanceGourdes;
                arParms[4] = new SqlParameter("@OpeningBalanceNatureType", SqlDbType.VarChar);
                arParms[4].Value = objAccountHead.OpeningBalanceNatureType;
                arParms[5] = new SqlParameter("@ClosingBalanceUSD", SqlDbType.Money);
                arParms[5].Value = objAccountHead.ClosingBalanceUSD;
                arParms[6] = new SqlParameter("@ClosingBalanceGourdes", SqlDbType.Money);
                arParms[6].Value = objAccountHead.ClosingBalanceGourdes;
                arParms[7] = new SqlParameter("@ClosingBalanceNatureType", SqlDbType.VarChar);
                arParms[7].Value = objAccountHead.ClosingBalanceNatureType;
                arParms[8] = new SqlParameter("@CreditLimitUSD", SqlDbType.Money);
                arParms[8].Value = objAccountHead.CreditLimitUSD;
                arParms[9] = new SqlParameter("@CreditLimitGourdes", SqlDbType.Money);
                arParms[9].Value = objAccountHead.CreditLimitGourdes;
                arParms[10] = new SqlParameter("@Description", SqlDbType.VarChar);
                arParms[10].Value = objAccountHead.Description;
                arParms[11] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[11].Value = objAccountHead.AddedBy;
                arParms[12] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[12].Value = objAccountHead.ActionType;
                arParms[13] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[13].Value = objAccountHead.LastModBy;
                arParms[14] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[14].Value = objAccountHead.FinancialYearID;
                arParms[15] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[15].Value = objAccountHead.CompanyID;

                arParms[16] = new SqlParameter("@AccountName", SqlDbType.VarChar);
                arParms[16].Value = objAccountHead.AccountName;
                arParms[17] = new SqlParameter("@AccountShortName", SqlDbType.VarChar);
                arParms[17].Value = objAccountHead.AccountShortName;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_ACC_UpdateAccountHeadMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) 
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<AccountHead> GetAccountHeadGroupList()
        {
            List<AccountHead> lstAccountGroup = null;
            try
            {
                SqlDataReader sqlReader = null;
                sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_ACC_GetAccountHeadDetailMST");
                List<AccountHead> listAccountGroup = ORHelper<AccountHead>.FromDataReaderToList(sqlReader);
                lstAccountGroup = listAccountGroup;
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstAccountGroup;
        }

        public AccountHead GetAccountGroupByID(int ID)
        {
            AccountHead objRetAccountGroup = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@AccountHeadID", SqlDbType.Int);
                arParms[0].Value = ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_ACC_GetAccountHeadByID", ds, new string[] { "AccountGroup" }, arParms);
                objRetAccountGroup = ORHelper<AccountHead>.FromDataTable(ds.Tables["AccountGroup"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetAccountGroup;
        }
    }
}
