﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.ACC; 


namespace MMIE.DataAccess.ACC
{
    public class AccountCompanyDA : DataAccessObjectBase
    {

        public List<AccountCompany> GetCompanyDetail()
        {
            List<AccountCompany> lstCompany = null;
            try
            {
                SqlDataReader sqlReader = null;
                sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCompanyDetail", null);
                List<AccountCompany> listCompany = ORHelper<AccountCompany>.FromDataReaderToList(sqlReader);
                lstCompany = listCompany;
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstCompany;
        }
        public bool SaveCompany(AccountCompany objCompany)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[23];
                arParms[0] = new SqlParameter("@AccountCompanyID", SqlDbType.VarChar);
                arParms[0].Value = objCompany.AccountCompanyID;
                arParms[1] = new SqlParameter("@CompanyCode", SqlDbType.VarChar);
                arParms[1].Value = objCompany.CompanyCode;
                arParms[2] = new SqlParameter("@CompanyName", SqlDbType.VarChar);
                arParms[2].Value = objCompany.CompanyName;
                arParms[3] = new SqlParameter("@CompanyLegalName", SqlDbType.VarChar);
                arParms[3].Value = objCompany.CompanyLegalName;
                arParms[4] = new SqlParameter("@CityID", SqlDbType.SmallInt);
                arParms[4].Value = objCompany.CityID;
                arParms[5] = new SqlParameter("@StateCode", SqlDbType.VarChar);
                arParms[5].Value = objCompany.StateCode;
                arParms[6] = new SqlParameter("@ZipCode", SqlDbType.VarChar);
                arParms[6].Value = objCompany.ZipCode;
                arParms[7] = new SqlParameter("@CountryID", SqlDbType.Int);
                arParms[7].Value = objCompany.CountryID;
                arParms[8] = new SqlParameter("@CompanyPhone", SqlDbType.VarChar);
                arParms[8].Value = objCompany.CompanyPhone;
                arParms[9] = new SqlParameter("@CompanyFaxNo", SqlDbType.VarChar);
                arParms[9].Value = objCompany.CompanyFaxNo;
                arParms[10] = new SqlParameter("@CompanyEmailID", SqlDbType.VarChar);
                arParms[10].Value = objCompany.CompanyEmailID;
                arParms[11] = new SqlParameter("@CompanyBusinessType", SqlDbType.VarChar);
                arParms[11].Value = objCompany.CompanyBusinessType;
                arParms[12] = new SqlParameter("@CompanyFiscalYearID", SqlDbType.Int);
                arParms[12].Value = objCompany.CompanyFiscalYearID;
                arParms[13] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[13].Value = objCompany.IsActive;
                arParms[14] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[14].Value = objCompany.AddedBy;
                arParms[15] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[15].Value = objCompany.LastModBy;
                arParms[16] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[16].Value = objCompany.FinancialYearID;
                arParms[17] = new SqlParameter("@CompanyID", SqlDbType.VarChar);
                arParms[17].Value = objCompany.CompanyID;
                arParms[18] = new SqlParameter("@CompanyAnnualRevenue", SqlDbType.Money);
                arParms[18].Value = objCompany.AnnualRevenue;
                arParms[19] = new SqlParameter("@CompanyWebsite", SqlDbType.VarChar);
                arParms[19].Value = objCompany.CompanyWebsite;
                arParms[20] = new SqlParameter("@CompanyAddress", SqlDbType.VarChar);
                arParms[20].Value = objCompany.CompanyAddress;
                arParms[21] = new SqlParameter("@CompanyLandMark", SqlDbType.VarChar);
                arParms[21].Value = objCompany.CompanyLandMark;
                arParms[22] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[22].Value = objCompany.ActionType;
               
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_UpdateCompanyMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<AccountCompany> SearchCompany(AccountCompany objCompany)
        {
            List<AccountCompany> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];                

                arParms[0] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                arParms[0].Value = objCompany.CurrentIndex;

                arParms[1] = new SqlParameter("@PageSize", SqlDbType.Int);
                arParms[1].Value = objCompany.PageSize;


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_ACC_GetCompanyDetailInfo", arParms);
                lstObject = ORHelper<AccountCompany>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public AccountCompany GetCompanyByID(AccountCompany objCompany)
        {
            AccountCompany objRetCompany = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[0].Value = objCompany.AccountCompanyID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_ACC_GetCompanyByID", ds, new string[] { "Company" }, arParms);
                objRetCompany = ORHelper<AccountCompany>.FromDataTable(ds.Tables["Company"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCompany;
        }
    }
}
