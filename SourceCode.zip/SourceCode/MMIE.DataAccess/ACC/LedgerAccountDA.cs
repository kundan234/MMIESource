﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.ACC; 

namespace MMIE.DataAccess.ACC
{
 public   class LedgerAccountDA:DataAccessObjectBase
    {
     public bool SaveLedgerAccount(LedgerDetails objLedgerAccount)
     {
         bool status = false;
         try
         {

             SqlParameter[] arParms = new SqlParameter[13];
             arParms[0] = new SqlParameter("@LedgerDetailsID", SqlDbType.VarChar);
             arParms[0].Value = objLedgerAccount.LedgerDetailsID;

             arParms[1] = new SqlParameter("@CreditAmount", SqlDbType.Money);
             arParms[1].Value = objLedgerAccount.CreditAmount;


             arParms[2] = new SqlParameter("@DebitAmount", SqlDbType.Money);
             arParms[2].Value = objLedgerAccount.DebitAmount;

        



             arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
             arParms[3].Value = objLedgerAccount.IsActive;
             arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
             arParms[4].Value = objLedgerAccount.AddedBy;
             arParms[5] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
             arParms[5].Value = objLedgerAccount.ActionType;

             arParms[6] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
             arParms[6].Value = objLedgerAccount.LastModBy;
             arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
             arParms[7].Value = objLedgerAccount.FinancialYearID;
             arParms[8] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
             arParms[8].Value = objLedgerAccount.CompanyID;
              
             arParms[9] = new SqlParameter("@AccountGroupID", SqlDbType.SmallInt);
             arParms[9].Value = objLedgerAccount.AccountGroupID;
            
           

             //------------------------
             int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_UpdateLedgerAccount", arParms);
             if (noOfEffectedRecords > 0)
                 status = true;

         }
         catch (Exception ex) //Exception of the layer(itself)/unhandle
         {
             PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
             LogManager.WriteErrorLogInDB(ex);
             throw new DataAccessException("5000001", ex);
         }

         return status;
     }

     public List<AccountGroup> GetMappedAccountGroup(AccountGroup objAccountGroup)
     {
         List<AccountGroup> lstAccountGroup = null;
         try
         {

             SqlParameter[] arParms = new SqlParameter[2];
             arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
             arParms[0].Value = objAccountGroup.CompanyID;

             arParms[1] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
            arParms[1].Value = objAccountGroup.FinancialYearID;
        
             SqlDataReader sqlReader = null;
             sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetMappedAccountGroupMST", arParms);
             List<AccountGroup> listAccountGroup = ORHelper<AccountGroup>.FromDataReaderToList(sqlReader);
             lstAccountGroup = listAccountGroup;
         }
         catch (Exception ex) //Exception of the business layer(itself)//unhandle
         {
             PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
             LogManager.WriteErrorLogInDB(ex);
             throw new BusinessProcessException("5000001", ex);
         }
         return lstAccountGroup;
     }


    }
}
