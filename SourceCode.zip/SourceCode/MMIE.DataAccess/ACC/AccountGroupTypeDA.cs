﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.ACC; 

namespace MMIE.DataAccess.ACC
{
  public  class AccountGroupTypeDA : DataAccessObjectBase
    {

      public List<AccountGroupType> GetSearchAccountGroupMaster(AccountGroupType objAccountGroup)
      {
          List<AccountGroupType> lstObject = null;
          try
          {

              SqlParameter[] arParms = new SqlParameter[6];


              

              arParms[0] = new SqlParameter("@AccountType", SqlDbType.VarChar);
              arParms[0].Value = objAccountGroup.AccountType;
              

              arParms[1] = new SqlParameter("@GroupTypeName", SqlDbType.VarChar);
              arParms[1].Value = objAccountGroup.GroupTypeName;

              arParms[2] = new SqlParameter("@AccountNumber", SqlDbType.Int);
              arParms[2].Value = objAccountGroup.AccountNumber;

              arParms[3] = new SqlParameter("@IsPLitem", SqlDbType.Bit);
              arParms[3].Value = objAccountGroup.IsPLItem;

              arParms[4] = new SqlParameter("@IsBalanceSheet", SqlDbType.Bit);
              arParms[4].Value = objAccountGroup.IsBalanceSheet;

              arParms[5] = new SqlParameter("@IsActive", SqlDbType.Bit);
              arParms[5].Value = objAccountGroup.IsActive;






              SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetSearchAccountGroupTypeMST", arParms);
              lstObject = ORHelper<AccountGroupType>.FromDataReaderToList(dataReader);
              dataReader.Close();

          }
          catch (Exception ex) //Exception of the layer(itself)/unhandle
          {
              PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
              LogManager.WriteErrorLogInDB(ex);
              throw new DataAccessException("5000001", ex);
          }

          return lstObject;
      }

        public bool SaveAccountGroupType(AccountGroupType objAccountGroupType)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[11];
                arParms[0] = new SqlParameter("@GroupTypeID", SqlDbType.Int);
                arParms[0].Value = objAccountGroupType.GroupTypeID;
                arParms[1] = new SqlParameter("@GroupTypeName", SqlDbType.VarChar);
                arParms[1].Value = objAccountGroupType.GroupTypeName;
                arParms[2] = new SqlParameter("@AccountType", SqlDbType.VarChar);
                arParms[2].Value = objAccountGroupType.AccountType;
                arParms[3] = new SqlParameter("@AccountNumber", SqlDbType.Int);
                arParms[3].Value = objAccountGroupType.AccountNumber;
                arParms[4] = new SqlParameter("@IsPLItem", SqlDbType.Bit);
                arParms[4].Value = objAccountGroupType.IsPLItem;
                arParms[5] = new SqlParameter("@IsBalanceSheet", SqlDbType.Bit);
                arParms[5].Value = objAccountGroupType.IsBalanceSheet;
                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[6].Value = objAccountGroupType.CompanyID;


                arParms[7] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[7].Value = objAccountGroupType.IsActive;
                arParms[8] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[8].Value = objAccountGroupType.AddedBy;
                

                arParms[9] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[9].Value = objAccountGroupType.LastModBy;
                arParms[10] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[10].Value = objAccountGroupType.FinancialYearID;

                arParms[10] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[10].Value = objAccountGroupType.ActionType;
                



                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_UpdateAccountGroupTypeMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public AccountGroupType GetAccountGroupTypeByID(int ID)
        {
            AccountGroupType objDAccountGroupType = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@GroupTypeID", SqlDbType.Int);
                arParms[0].Value = ID;
                
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetSearchAccountGroupTypeMST", ds, new string[] { "ACC_AccountGroupTypeMST" }, arParms);
                objDAccountGroupType = ORHelper<AccountGroupType>.FromDataTable(ds.Tables["ACC_AccountGroupTypeMST"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objDAccountGroupType;
        }
    }
}
