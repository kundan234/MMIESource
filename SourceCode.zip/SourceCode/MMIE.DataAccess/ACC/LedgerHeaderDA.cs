﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.ACC; 
namespace MMIE.DataAccess.ACC
{
   public class LedgerHeaderDA:DataAccessObjectBase
    {


        public bool SaveLedgerHeader(LedgerHeader objLedgerHeader)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[13];
                arParms[0] = new SqlParameter("@LedgerAccountID", SqlDbType.Int);
                arParms[0].Value = objLedgerHeader.LedgerAccountID;
                arParms[1] = new SqlParameter("@AccountGroupID", SqlDbType.Int);
                arParms[1].Value = objLedgerHeader.AccountGroupID;
                arParms[2] = new SqlParameter("@Details", SqlDbType.VarChar);
                arParms[2].Value = objLedgerHeader.Details;
                arParms[3] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[3].Value = objLedgerHeader.AddedBy;
                arParms[4] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[4].Value = objLedgerHeader.ActionType;

                arParms[5] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[5].Value = objLedgerHeader.LastModBy;
                arParms[6] = new SqlParameter("@VoucherGroupID", SqlDbType.SmallInt);
                arParms[6].Value = objLedgerHeader.VoucherGroupID;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[7].Value = objLedgerHeader.FinancialYearID;
                arParms[8] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[8].Value = objLedgerHeader.CompanyID;

                arParms[9] = new SqlParameter("@AccountName", SqlDbType.VarChar);
                arParms[9].Value = objLedgerHeader.AccountName;
                arParms[10] = new SqlParameter("@AccountNumber", SqlDbType.VarChar);
                arParms[10].Value = objLedgerHeader.AccountNumber;

                arParms[11] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[11].Value = objLedgerHeader.IsActive;

                arParms[12] = new SqlParameter("@RefrenceNumber", SqlDbType.Int);
                arParms[12].Value = objLedgerHeader.RefrenceNumber;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_ACC_UpdateLedgerHeader", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<LedgerHeader> GetSearchLedgerHeaderList(LedgerHeader objAccountGroup)
        {
            List<LedgerHeader> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[8];

                arParms[0] = new SqlParameter("@LedgerAccountID", SqlDbType.VarChar);
                arParms[0].Value = objAccountGroup.LedgerAccountID;
                arParms[1] = new SqlParameter("@AccountName", SqlDbType.VarChar);
                arParms[1].Value = objAccountGroup.AccountName;
                arParms[2] = new SqlParameter("@Details", SqlDbType.VarChar);
                arParms[2].Value = objAccountGroup.Details;



                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[3].Value = objAccountGroup.IsActive;

                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.VarChar);
                arParms[4].Value = objAccountGroup.CompanyID;


                arParms[5] = new SqlParameter("@AccountGroupID", SqlDbType.SmallInt);
                arParms[5].Value = objAccountGroup.AccountGroupID;


                arParms[6] = new SqlParameter("@VoucherGroupID", SqlDbType.SmallInt);
                arParms[6].Value = objAccountGroup.VoucherGroupID;
                arParms[7] = new SqlParameter("@GroupName", SqlDbType.VarChar);
                arParms[7].Value = objAccountGroup.GroupName;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_ACC_GetSearchLedgerHeaderList]", arParms);
                lstObject = ORHelper<LedgerHeader>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public LedgerHeader GetLedgerAccountByID(int ID)
        {
            LedgerHeader objRetAccountGroup = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@LedgerAccountID", SqlDbType.Int);
                arParms[0].Value = ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ACC_GetSearchLedgerHeaderList", ds, new string[] { "LedgerHeader" }, arParms);
                objRetAccountGroup = ORHelper<LedgerHeader>.FromDataTable(ds.Tables["LedgerHeader"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetAccountGroup;
        }
       
    }
}
