﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.PRL;

namespace MMIE.DataAccess.PRL
{
    public class EmployeeDA : DataAccessObjectBase
    {
   /*************************************************************************************************  
  
  Name of the Class			    : EmployeeDA                      
  
  Description of the class	    : 
  
  Created Date					: 28 Nov 2011  
  
  Developer						: Mithlesh
  
  Modify Date					:28/11/2011  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/

        public bool UpdateEmployeeDetail(Employee  objEmployee)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[41];

                arParms[0] = new SqlParameter("@EmployeeID", SqlDbType.Int);
                arParms[0].Value = objEmployee.EmployeeID;
                arParms[1] = new SqlParameter("@FirstName", SqlDbType.VarChar);
                arParms[1].Value = objEmployee.FirstName;
                arParms[2] = new SqlParameter("@LastName", SqlDbType.VarChar);
                arParms[2].Value = objEmployee.LastName;
                arParms[3] = new SqlParameter("@Gender", SqlDbType.Bit);
                arParms[3].Value = objEmployee.Gender;
                arParms[4] = new SqlParameter("@DOB", SqlDbType.VarChar);
                arParms[4].Value = objEmployee.DOB;
                arParms[5] = new SqlParameter("@Address", SqlDbType.VarChar );
                arParms[5].Value = objEmployee.Address;
                arParms[6] = new SqlParameter("@Street", SqlDbType.VarChar);
                arParms[6].Value = objEmployee.Street;
                arParms[7] = new SqlParameter("@CountryID", SqlDbType.Int );
                arParms[7].Value = objEmployee.CountryID  ;
                arParms[8] = new SqlParameter("@CityID", SqlDbType.Int);
                arParms[8].Value = objEmployee.CityID;
                arParms[9] = new SqlParameter("@PostalCode", SqlDbType.VarChar);
                arParms[9].Value = objEmployee.PostalCode;
                arParms[10] = new SqlParameter("@PhoneNo", SqlDbType.VarChar);
                arParms[10].Value = objEmployee.PhoneNo;
                arParms[11] = new SqlParameter("@CellNo", SqlDbType.VarChar);
                arParms[11].Value = objEmployee.CellNo;
                arParms[12] = new SqlParameter("@AlternativePhoneNo", SqlDbType.VarChar);
                arParms[12].Value = objEmployee.AlternativePhoneNo;
                arParms[13] = new SqlParameter("@Email", SqlDbType.VarChar);
                arParms[13].Value = objEmployee.Email;
                arParms[14] = new SqlParameter("@SacnIdType", SqlDbType.VarChar);
                arParms[14].Value = objEmployee.SacnIdType;
                arParms[15] = new SqlParameter("@ScanIDNo", SqlDbType.VarChar);
                arParms[15].Value = objEmployee.ScanIDNo;
                arParms[16] = new SqlParameter("@IdScanIDDetail", SqlDbType.VarChar);
                arParms[16].Value = objEmployee.IdScanIDDetail;
                arParms[17] = new SqlParameter("@HireDate", SqlDbType.VarChar);
                arParms[17].Value = objEmployee.HireDate;
                arParms[18] = new SqlParameter("@ReleaseDate", SqlDbType.VarChar);
                arParms[18].Value = objEmployee.ReleaseDate;
                arParms[19] = new SqlParameter("@EanringType", SqlDbType.VarChar);
                arParms[19].Value = objEmployee.EanringType;
                arParms[20] = new SqlParameter("@EarningRate", SqlDbType.BigInt );
                arParms[20].Value = objEmployee.EarningRate;
                arParms[21] = new SqlParameter("@EmployeeStatus", SqlDbType.Bit);
                arParms[21].Value = objEmployee.EmployeeStatus;
                arParms[22] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[22].Value = objEmployee.CompanyID;
                arParms[23] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[23].Value = objEmployee.AddedBy;
                arParms[24] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[24].Value = objEmployee.LastModBy;
                arParms[25] = new SqlParameter("@DesignationID", SqlDbType.Int);
                arParms[25].Value = objEmployee.DesignationID; 
                
                arParms[26] = new SqlParameter("@DepartmentID ", SqlDbType.Int);
                arParms[26].Value = objEmployee.DepartmentID;
                arParms[27] = new SqlParameter("@AccountNo  ", SqlDbType.VarChar);
                arParms[27].Value = objEmployee.AccountNo;
                
                arParms[28] = new SqlParameter("@PayFreequency", SqlDbType.VarChar);
                arParms[28].Value = objEmployee.PayFreequency;
                
                arParms[29] = new SqlParameter("@EmployeeTaxes", SqlDbType.Bit);
                arParms[29].Value = objEmployee.EmployeeTaxes; 
                
                arParms[30] = new SqlParameter("@RetirementPlan", SqlDbType.Bit);
                arParms[30].Value = objEmployee.RetirementPlan; 
                
                arParms[31] = new SqlParameter("@CompanyPaid", SqlDbType.Bit);
                arParms[31].Value = objEmployee.CompanyPaid;

                arParms[32] = new SqlParameter("@SickAllownces", SqlDbType.Decimal);
                arParms[32].Value = objEmployee.SickAllownces;
                
                arParms[33] = new SqlParameter("@Bonous", SqlDbType.Money);
                arParms[33].Value = objEmployee.Bonous;
                
                arParms[34] = new SqlParameter("@Allownces", SqlDbType.Decimal);
                arParms[34].Value = objEmployee.Allownces;
                
                arParms[35] = new SqlParameter("@EmployeeTypeID", SqlDbType.Int);
                arParms[35].Value = objEmployee.EmployeeTypeID;
                
                arParms[36] = new SqlParameter("@ClassTrackID", SqlDbType.Int);
                arParms[36].Value = objEmployee.ClassTrackID;

                arParms[37] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[37].Value = objEmployee.ActionType;


                arParms[38] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[38].Value = objEmployee.IsActive ;



                arParms[39] = new SqlParameter("@FinancialYearID", SqlDbType.Int );
                arParms[39].Value = objEmployee.FinancialYearID ;

                arParms[40] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[40].Value = objEmployee.CurrencyID;
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_UpdateEmployeeMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<Employee> SearchEmployee(Employee objEmployee)
        {
            List<Employee> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[7];

                arParms[0] = new SqlParameter("@FirstName", SqlDbType.VarChar);
                arParms[0].Value = objEmployee.FirstName;
                arParms[1] = new SqlParameter("@LastName", SqlDbType.VarChar);
                arParms[1].Value = objEmployee.LastName;
                arParms[2] = new SqlParameter("@PhoneNo", SqlDbType.VarChar);
                arParms[2].Value = objEmployee.PhoneNo;
                arParms[3] = new SqlParameter("@Cellno", SqlDbType.VarChar);
                arParms[3].Value = objEmployee.CellNo;
                arParms[4] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                arParms[4].Value = objEmployee.CurrentIndex;
                arParms[5] = new SqlParameter("@PageSize", SqlDbType.Int);
                arParms[5].Value = objEmployee.PageSize;
                arParms[6] = new SqlParameter("@Street", SqlDbType.VarChar);
                arParms[6].Value = objEmployee.Street;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_GetEmployee", arParms);
                lstObject = ORHelper<Employee>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Employee> GetSearchEmployeeList(Employee objEmployee)
        {
            List<Employee> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@EmployeeName", SqlDbType.VarChar);
                arParms[0].Value = objEmployee.FirstName;
                arParms[1] = new SqlParameter("@EmployeeID", SqlDbType.Int);
                arParms[1].Value = objEmployee.EmployeeID ;

                arParms[2] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[2].Value = objEmployee.IsActive ;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_GetSearchEmployeeList", arParms);
                lstObject = ORHelper<Employee>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public Employee GetEmployeeByID(Employee  objEmployee)
        {
            Employee  objRetEmployee = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@EmployeeID", SqlDbType.Int);
                arParms[0].Value = objEmployee.EmployeeID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_GetEmployeeByID", ds, new string[] { "Employee" }, arParms);
                objRetEmployee = ORHelper<Employee>.FromDataTable(ds.Tables["Employee"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetEmployee;
        }


    

       
        #region  Salary Operations


        public List<Employee> GetSearchEmployeeSalaryList(Employee objEmployee)
        {
            List<Employee> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];


                arParms[0] = new SqlParameter("@EmployeeID", SqlDbType.Int);
                arParms[0].Value = objEmployee.EmployeeID;


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_GetSearchEmployeeSalaryList", arParms);
                lstObject = ORHelper<Employee>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Employee> GetSearchSalaryList(Employee objEmployee)
        {
            List<Employee> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];


                arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[0].Value = objEmployee.CompanyID;
                arParms[1] = new SqlParameter("@FromDate", SqlDbType.Date);
                arParms[1].Value = objEmployee.FromDate;
                arParms[2] = new SqlParameter("@ToDate", SqlDbType.Date);
                arParms[2].Value = objEmployee.ToDate;


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_GetSearchSalaryList", arParms);
                lstObject = ORHelper<Employee>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

      

        public Employee GetEmployeeSalaryDetailsByID(Employee objEmployee)
        {
            Employee objRetEmployee = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[0].Value = objEmployee.ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_GetSearchSalaryByID", ds, new string[] { "Salary" }, arParms);
                objRetEmployee = ORHelper<Employee>.FromDataTable(ds.Tables["Salary"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetEmployee;
        }


        


        public bool CalculateEmployeeSalary(Employee objEmployee)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[6];

                arParms[0] = new SqlParameter("@PayFreequency", SqlDbType.VarChar);
                arParms[0].Value = objEmployee.PayFreequency;
                arParms[1] = new SqlParameter("@FromDate", SqlDbType.VarChar);
                arParms[1].Value = objEmployee.FromDate;
                arParms[2] = new SqlParameter("@ToDate", SqlDbType.VarChar);
                arParms[2].Value = objEmployee.ToDate;
                arParms[3] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[3].Value = objEmployee.CompanyID;

                arParms[4] = new SqlParameter("FinancialYearID", SqlDbType.Int);
                arParms[4].Value = objEmployee.FinancialYearID;

                arParms[5] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[5].Value = objEmployee.AddedBy;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_PRL_GeneratedSalary", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }



      

        #endregion

    }
}
