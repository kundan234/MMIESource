﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.PRL;

namespace MMIE.DataAccess.PRL
{
   public class LoanDA:DataAccessObjectBase
    {
        public bool UpdateLoanDetails(Loan objLoan)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[16];

                arParms[0] = new SqlParameter("@LoanID", SqlDbType.Int);
                arParms[0].Value = objLoan.LoanID;
                arParms[1] = new SqlParameter("@LoanDetails", SqlDbType.VarChar);
                arParms[1].Value = objLoan.LoanDetails;

                arParms[2] = new SqlParameter("@LoanAmount", SqlDbType.Money);
                arParms[2].Value = objLoan.LoanAmount ;
                arParms[3] = new SqlParameter("@DeductionAmount", SqlDbType.Money);
                arParms[3].Value = objLoan.DeductionAmount ;

                arParms[4] = new SqlParameter("@LoanDate", SqlDbType.Date );
                arParms[4].Value = objLoan.LoanDate;
                arParms[5] = new SqlParameter("@LoanDueDate", SqlDbType.Date);
                arParms[5].Value = objLoan.LoanDueDate ;

                arParms[6] = new SqlParameter("@LoanTypeID", SqlDbType.Int);
                arParms[6].Value = objLoan.LoanTypeID;

                arParms[7] = new SqlParameter("@EmployeeID", SqlDbType.Int);
                arParms[7].Value = objLoan.EmployeeID;

              
                arParms[8] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[8].Value = objLoan.IsActive;
                arParms[9] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[9].Value = objLoan.CompanyID;
                arParms[10] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[10].Value = objLoan.AddedBy;
                arParms[11] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[11].Value = objLoan.LastModBy;
             

                
                arParms[12] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[12].Value = objLoan.ActionType;




                arParms[14] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[14].Value = objLoan.FinancialYearID;

                arParms[15] = new SqlParameter("@IsApproved", SqlDbType.Bit);
                arParms[15].Value = objLoan.IsApproved;



                arParms[13] = new SqlParameter("@TotalInstallments", SqlDbType.Int);
                arParms[13].Value = objLoan.TotalInstallments;


                //arParms[18] = new SqlParameter("@PaidInstallments", SqlDbType.Int);
                //arParms[18].Value = objLoan.PaidInstallments;


                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_UpdateLoanMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<Loan> GetSearchLoanList(Loan objLoan)
        {
            List<Loan> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@EmployeeID", SqlDbType.Int);
                arParms[0].Value = objLoan.EmployeeID;
                arParms[1] = new SqlParameter("@LoanID", SqlDbType.Int);
                arParms[1].Value = objLoan.LoanID;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_GetSearchLoanList", arParms);
                lstObject = ORHelper<Loan>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


    }
}
