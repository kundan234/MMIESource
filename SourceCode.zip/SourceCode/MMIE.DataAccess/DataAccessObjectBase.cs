﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;

/*************************************************************************************************  
  
  Name of the Class			    : DataAccessObjectBase                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.DataAccess
{
    public class DataAccessObjectBase
    {
        static IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
        public DateTime SQL_DateTimeMininum = DateTime.Parse("01/01/1753", provider, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
        public DateTime SQL_DateTimeMaximum = DateTime.Parse("31/12/9999", provider, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
        
    }
}

