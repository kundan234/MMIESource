﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;

/*************************************************************************************************  
  
  Name of the Class			    : BaseData                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: 
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data
{
    /// <summary>
    /// 
    /// </summary>
    /// <remarks>
    /// Created By : Shubhakaran

    /// Create Date: 30-Nov-2010
    /// Purpose: 
    /// </remarks>

    
    [Serializable]
    public class BaseData
    {
        
        public short FinancialYearID { get; set; }

        
        public short CompanyID { get; set; }

        
        public bool IsActive { get; set; }

        
        public string AddedBy { get; set; }

        
        public DateTime AddedDTM { get; set; }

        
        public string LastModBy { get; set; }

        
        public DateTime LastModDTM { get; set; }

        
        //public EnumActionType ActionType;

        
        public int CurrentIndex { get; set; }

        
        public int PageSize { get; set; }

        
        public int MaximumRows { get; set; }

        
        public string XMLData { get; set; }
        
        #region Detail section

        
        public int LocationID { get; set; }

        
        public FinancialYear FinancialYear { get; set; }

        
        public Company Company { get; set; }

        #endregion

    }
   
    //public enum EnumActionType
    //{
    //    [EnumMember]
    //    Select, //0
    //    [EnumMember]
    //    Insert, //1
    //    [EnumMember]
    //    Update, //2
    //    [EnumMember]
    //    Delete, //3    
    //    [EnumMember]
    //    InsertUpdate //4
    //}

}
