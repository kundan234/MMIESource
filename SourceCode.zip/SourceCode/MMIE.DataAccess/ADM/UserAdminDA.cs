﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using MMIE.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.Common;



/*************************************************************************************************  
  
  Name of the Class			    : UserAdminDA                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: 
  
  Modify Date					: 
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.DataAccess.ADM
{
    public class UserAdminDA : DataAccessObjectBase
    {
        #region User Login


        public UserCE ValidateLogin(UserLogin objUser)
        {
            UserCE objUserCE = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@UserTypeID", SqlDbType.Int);
                arParms[0].Value = objUser.UserTypeID;

                arParms[1] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[1].Value = objUser.FinancialYearID;

                arParms[2] = new SqlParameter("@LoginId", SqlDbType.VarChar);
                arParms[2].Value = objUser.LoginId;

                arParms[3] = new SqlParameter("@Password", SqlDbType.VarChar);
                arParms[3].Value = objUser.Password;

                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[4].Value = objUser.CompanyID;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_ValidateLogin", ds, new string[] { "UserLogin", "Role", "UserDetail", "SiteMap" }, arParms);

                //******START OR mapping****************************//
                UserLogin retUser = ORHelper<UserLogin>.FromDataTable(ds.Tables["UserLogin"]);
                List<Role> lstRole = ORHelper<Role>.FromDataTableToList(ds.Tables["Role"]);
                UserDetail retUserDetail = ORHelper<UserDetail>.FromDataTable(ds.Tables["UserDetail"]);
                // List<SiteMap> lstSiteMap = ORHelper<SiteMap>.FromDataTableToList(ds.Tables["SiteMap"]);
                //******END OR mapping****************************//

                if (retUser != null)
                {
                    objUserCE = new UserCE();
                    objUserCE.UserLogin = retUser;
                    objUserCE.UserDetail = retUserDetail;
                    objUserCE.RoleList = lstRole;
                    //objUserCE.SiteMapList = lstSiteMap;
                    objUserCE.SiteMapDT = ds.Tables["SiteMap"];
                }

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objUserCE;
        }

        public bool SaveUser(UserCE objUserCE)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[11];

                arParms[0] = new SqlParameter("@UserTypeID", SqlDbType.Int);
                arParms[0].Value = objUserCE.UserLogin.UserTypeID;

                arParms[1] = new SqlParameter("@LoginId", SqlDbType.VarChar);
                arParms[1].Value = objUserCE.UserLogin.LoginId;

                arParms[2] = new SqlParameter("@Password", SqlDbType.VarChar);
                arParms[2].Value = objUserCE.UserLogin.Password;

                arParms[3] = new SqlParameter("@RoleID", SqlDbType.Int);
                arParms[3].Value = objUserCE.RoleList[0].RoleId;

                arParms[4] = new SqlParameter("@UserDetailID", SqlDbType.Int);
                arParms[4].Value = objUserCE.UserDetail.UserDetailID;

                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[5].Value = objUserCE.UserLogin.FinancialYearID;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objUserCE.UserLogin.CompanyID;

                arParms[7] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[7].Value = objUserCE.UserLogin.AddedBy;

                arParms[8] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[8].Value = objUserCE.UserLogin.LastModBy;

                arParms[9] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[9].Value = objUserCE.UserLogin.ActionType;

                arParms[10] = new SqlParameter("@UserLoginIdUpdate", SqlDbType.Int);
                arParms[10].Value = objUserCE.UserLogin.UserLoginId;






                //SqlParameter[] arParms = new SqlParameter[10];
                //arParms[0] = new SqlParameter("@UserTypeID", SqlDbType.Int);
                //arParms[0].Value = objUserCE.UserLogin.UserTypeID;

                //arParms[1] = new SqlParameter("@LoginId", SqlDbType.VarChar);
                //arParms[1].Value = objUserCE.UserLogin.LoginId;

                //arParms[2] = new SqlParameter("@Password", SqlDbType.VarChar);
                //arParms[2].Value = objUserCE.UserLogin.Password;

                //arParms[3] = new SqlParameter("@RoleID", SqlDbType.Int);
                //arParms[3].Value = objUserCE.RoleList[0].RoleId;

                //arParms[4] = new SqlParameter("@UserDetailID", SqlDbType.Int);
                //arParms[4].Value = "0";

                //arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                //arParms[5].Value = objUserCE.UserLogin.FinancialYearID;

                //arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                //arParms[6].Value = objUserCE.UserLogin.CompanyID;

                //arParms[7] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                //arParms[7].Value = objUserCE.UserLogin.AddedBy;

                //arParms[8] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                //arParms[8].Value = objUserCE.UserLogin.LastModBy;

                //arParms[9] = new SqlParameter("@ActionType", SqlDbType.Int);
                //arParms[9].Value = objUserCE.UserLogin.ActionType;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_SaveUser", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (SqlException ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("1", ex);
            }

            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<UserLogin> SearchUserLogin(UserLogin objUserLogin)
        {
            List<UserLogin> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@UserTypeID", SqlDbType.Int);
                arParms[0].Value = objUserLogin.UserTypeID;

                arParms[1] = new SqlParameter("@LoginID", SqlDbType.VarChar);
                arParms[1].Value = objUserLogin.LoginId;

                arParms[2] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                arParms[2].Value = objUserLogin.CurrentIndex;

                arParms[3] = new SqlParameter("@PageSize", SqlDbType.Int);
                arParms[3].Value = objUserLogin.PageSize;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_SearchUserLogin", arParms);
                lstObject = ORHelper<UserLogin>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public UserCE GetUserLoginByID(UserLogin objUser)
        {
            UserCE objUserCE = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@UserLoginID", SqlDbType.Int);
                arParms[0].Value = objUser.UserLoginId;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_GetUserLoginByID", ds, new string[] { "UserLogin", "Role", "UserDetail" }, arParms);

                UserLogin retUser = ORHelper<UserLogin>.FromDataTable(ds.Tables["UserLogin"]);
                List<Role> lstRole = ORHelper<Role>.FromDataTableToList(ds.Tables["Role"]);
                UserDetail retUserDetail = ORHelper<UserDetail>.FromDataTable(ds.Tables["UserDetail"]);

                if (retUser != null)
                {
                    objUserCE = new UserCE();
                    objUserCE.UserLogin = retUser;
                    objUserCE.UserDetail = retUserDetail;
                    objUserCE.RoleList = lstRole;
                }

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objUserCE;
        }

        public bool DeleteUser(UserLogin objUserLogin)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@UserLoginId", SqlDbType.Int);
                arParms[0].Value = objUserLogin.UserLoginId;

                arParms[1] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[1].Value = objUserLogin.LastModBy;

                arParms[2] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[2].Value = objUserLogin.ActionType;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_DeleteUser", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public bool UpdateLoginSchedule(UserLogin objUserLogin)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[15];

                arParms[0] = new SqlParameter("@UserLoginId", SqlDbType.Int);
                arParms[0].Value = objUserLogin.UserLoginId;

                arParms[1] = new SqlParameter("@MonStartTime", SqlDbType.VarChar);
                arParms[1].Value = objUserLogin.MonStartTime;

                arParms[2] = new SqlParameter("@MonEndTime", SqlDbType.VarChar);
                arParms[2].Value = objUserLogin.MonEndTime;

                arParms[3] = new SqlParameter("@TueStartTime", SqlDbType.VarChar);
                arParms[3].Value = objUserLogin.TueStartTime;

                arParms[4] = new SqlParameter("@TueEndTime", SqlDbType.VarChar);
                arParms[4].Value = objUserLogin.TueEndTime;

                arParms[5] = new SqlParameter("@ThurStartTime", SqlDbType.VarChar);
                arParms[5].Value = objUserLogin.ThurStartTime;

                arParms[6] = new SqlParameter("@ThurEndTime", SqlDbType.VarChar);
                arParms[6].Value = objUserLogin.ThurEndTime;

                arParms[7] = new SqlParameter("@FriStartTime", SqlDbType.VarChar);
                arParms[7].Value = objUserLogin.FriStartTime;

                arParms[8] = new SqlParameter("@FriEndTime", SqlDbType.VarChar);
                arParms[8].Value = objUserLogin.FriEndTime;

                arParms[9] = new SqlParameter("@SatStartTime", SqlDbType.VarChar);
                arParms[9].Value = objUserLogin.SatStartTime;

                arParms[10] = new SqlParameter("@SatEndTime", SqlDbType.VarChar);
                arParms[10].Value = objUserLogin.SatEndTime;

                arParms[11] = new SqlParameter("@SunStartTime", SqlDbType.VarChar);
                arParms[11].Value = objUserLogin.SunStartTime;

                arParms[12] = new SqlParameter("@SunEndTime", SqlDbType.VarChar);
                arParms[12].Value = objUserLogin.SunEndTime;

                arParms[13] = new SqlParameter("@WedStartTime", SqlDbType.VarChar);
                arParms[13].Value = objUserLogin.WedStartTime;

                arParms[14] = new SqlParameter("@WedEndTime", SqlDbType.VarChar);
                arParms[14].Value = objUserLogin.WedEndTime;


                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_UpdateLoginSchedule", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public UserLogin GetLoginSchedule(int intLoginId)
        {
            UserLogin objUserLogin = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];
                DataSet ds = new DataSet();

                arParms[0] = new SqlParameter("@UserLoginId", SqlDbType.Int);
                arParms[0].Value = intLoginId;

                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_GetLoginSchedule", ds, new string[] { "UserLogin" }, arParms);
                objUserLogin = ORHelper<UserLogin>.FromDataTable(ds.Tables["UserLogin"]);


            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objUserLogin;
        }



        #endregion

        #region Site Map

        public List<SiteMap> GetAllSiteMapItem(SiteMap objSiteMap)
        {
            List<SiteMap> lstSiteMap = null;
            try
            {
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_GetAllSiteMapItem", ds, new string[] { "SiteMap" }, null);
                lstSiteMap = ORHelper<SiteMap>.FromDataTableToList(ds.Tables["SiteMap"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstSiteMap;
        }

        public List<SiteMap> GetSiteMapRoleByRoleID(Role objRole)
        {
            List<SiteMap> lstSiteMap = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@RoleID", SqlDbType.Int);
                arParms[0].Value = objRole.RoleId;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_GetSiteMapRoleByRoleID", ds, new string[] { "SiteMap" }, arParms);
                lstSiteMap = ORHelper<SiteMap>.FromDataTableToList(ds.Tables["SiteMap"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstSiteMap;
        }

        public bool SaveSiteMapRole(Role objRole)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[7];

                arParms[0] = new SqlParameter("@RoleId", SqlDbType.Int);
                arParms[0].Value = objRole.RoleId;

                arParms[1] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[1].Value = objRole.FinancialYearID;

                arParms[2] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[2].Value = objRole.CompanyID;

                arParms[3] = new SqlParameter("@XMLData", SqlDbType.VarChar);
                arParms[3].Value = objRole.XMLData;

                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objRole.AddedBy;


                arParms[5] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[5].Value = objRole.LastModBy;

                arParms[6] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[6].Value = objRole.ActionType;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_SaveSiteMapRole", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        #endregion

        #region Role

        public bool SaveRole(Role objRole)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[22];

                arParms[0] = new SqlParameter("@RoleName", SqlDbType.VarChar);
                arParms[0].Value = objRole.RoleName;

                arParms[1] = new SqlParameter("@RoleCode", SqlDbType.VarChar);
                arParms[1].Value = objRole.RoleCode;

                arParms[2] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[2].Value = objRole.FinancialYearID;

                arParms[3] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[3].Value = objRole.CompanyID;

                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objRole.AddedBy;

                arParms[5] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[5].Value = objRole.LastModBy;

                arParms[6] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[6].Value = objRole.ActionType;

                arParms[7] = new SqlParameter("@RoleID", SqlDbType.Int);
                arParms[7].Value = objRole.RoleId;


                // Modified on 04th Jan 2012 by Budha Singh to add Roles
                arParms[8] = new SqlParameter("@IsAddOn", SqlDbType.Bit);
                arParms[8].Value = objRole.IsAddOn;
                arParms[9] = new SqlParameter("@IsModify", SqlDbType.Bit);
                arParms[9].Value = objRole.IsModify;
                arParms[10] = new SqlParameter("@IsCancelOn", SqlDbType.Bit);
                arParms[10].Value = objRole.IsCancelOn;
                arParms[11] = new SqlParameter("@IsDeleteOn", SqlDbType.Bit);
                arParms[11].Value = objRole.IsDeleteOn;
                arParms[12] = new SqlParameter("@IsPrintOn", SqlDbType.Bit);
                arParms[12].Value = objRole.IsPrintOn;
                arParms[13] = new SqlParameter("@IsPrintExportOn", SqlDbType.Bit);
                arParms[13].Value = objRole.IsPrintExportOn;

                arParms[14] = new SqlParameter("@IsChangeDateOn", SqlDbType.Bit);
                arParms[14].Value = objRole.IsChangeDateOn;
                arParms[15] = new SqlParameter("@IsChangeBranchOn", SqlDbType.Bit);
                arParms[15].Value = objRole.IsChangeBranchOn;
                arParms[16] = new SqlParameter("@IsApproverRecievedOn", SqlDbType.Bit);
                arParms[16].Value = objRole.IsApproverRecievedOn;
                arParms[17] = new SqlParameter("@IsApproverReimbursementOn", SqlDbType.Bit);
                arParms[17].Value = objRole.IsApproverReimbursementOn;
                arParms[18] = new SqlParameter("@IsApproverReturnOn", SqlDbType.Bit);
                arParms[18].Value = objRole.IsApproverReturnOn;

                arParms[19] = new SqlParameter("@IsRateChangeOn", SqlDbType.Bit);
                arParms[19].Value = objRole.IsRateChangeOn;

                arParms[20] = new SqlParameter("@IsPartialCancellationOn", SqlDbType.Bit);
                arParms[20].Value = objRole.IsPartialCancellationOn;
                arParms[21] = new SqlParameter("@IsCreditLimitChangeAllowed", SqlDbType.Bit);
                arParms[21].Value = objRole.IsCreditLimitChangeAllowed;


                // End Modified on 04th Jan 2012 by Budha Singh to add Roles

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_SaveRole", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public Role GetRoleByID(Role objRole)
        {
            Role objRetRole = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@RoleID", SqlDbType.Int);
                arParms[0].Value = objRole.RoleId;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_GetRoleByID", ds, new string[] { "Role" }, arParms);
                objRetRole = ORHelper<Role>.FromDataTable(ds.Tables["Role"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetRole;
        }

        public List<Role> SearchRole(Role objRole)
        {
            List<Role> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@RoleCode", SqlDbType.VarChar);
                arParms[0].Value = objRole.RoleCode;

                arParms[1] = new SqlParameter("@RoleName", SqlDbType.VarChar);
                arParms[1].Value = objRole.RoleName;

                arParms[2] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                arParms[2].Value = objRole.CurrentIndex;

                arParms[3] = new SqlParameter("@PageSize", SqlDbType.Int);
                arParms[3].Value = objRole.PageSize;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_SearchRole", arParms);
                lstObject = ORHelper<Role>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public bool DeleteRole(Role objRole)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@RoleId", SqlDbType.Int);
                arParms[0].Value = objRole.RoleId;

                arParms[1] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[1].Value = objRole.LastModBy;

                arParms[2] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[2].Value = objRole.ActionType;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_DeleteRole", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        #endregion

        #region Database BackUp

        public bool DatabaseBackUp(string pathDB, string name, string fileName, string backupName, string addedBy)
        {
            bool Status = false;
            DatabaseBackUp objdatabase = new Data.Common.DatabaseBackUp();
            SqlParameter[] arParms = new SqlParameter[5];

            arParms[0] = new SqlParameter("@Path", SqlDbType.VarChar);
            arParms[0].Value = pathDB;
            arParms[1] = new SqlParameter("@Name", SqlDbType.VarChar);
            arParms[1].Value = name;
            arParms[2] = new SqlParameter("@fileName", SqlDbType.VarChar);
            arParms[2].Value = fileName;
            arParms[3] = new SqlParameter("@backupName", SqlDbType.VarChar);
            arParms[3].Value = backupName;
            arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
            arParms[4].Value = addedBy;

            int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_CreateBackUP", arParms);
            if (noOfEffectedRecords > 0)
                Status = true;
            return Status;
        }

        public List<DatabaseBackUp> GetBackupList()
        {
            List<DatabaseBackUp> lstObject = null;
            try
            {
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_GetBackupList");
                lstObject = ORHelper<DatabaseBackUp>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        #endregion


        #region Checkout / Check In User

        public bool CheckoutUser(UserLogin objUser)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@LoginId", SqlDbType.VarChar);
                arParms[0].Value = objUser.LoginId;

                arParms[1] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[1].Value = objUser.LastModBy;

                arParms[2] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[2].Value = objUser.CompanyID;

                arParms[3] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[3].Value = objUser.ActionType;
                arParms[4] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[4].Value = objUser.FinancialYearID;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_CheckOutUser", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        public List<UserLogin> SearchCheckedOutUser(UserLogin objUserLogin)
        {
            List<UserLogin> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[0].Value = objUserLogin.IsActive;

                arParms[1] = new SqlParameter("@UserName", SqlDbType.VarChar);
                arParms[1].Value = objUserLogin.UserName;

                arParms[2] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[2].Value = objUserLogin.CompanyID;
                arParms[3] = new SqlParameter("@IsCheckOut", SqlDbType.Bit);
                arParms[3].Value = objUserLogin.IsCheckOut;




                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_SearchUserList", arParms);
                lstObject = ORHelper<UserLogin>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public bool CheckInUser(UserLogin objUser)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[0].Value = objUser.LastModBy;

                arParms[1] = new SqlParameter("@CompanyID", SqlDbType.VarChar);
                arParms[1].Value = objUser.CompanyID;

                arParms[2] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[2].Value = objUser.FinancialYearID;

                arParms[3] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[3].Value = objUser.XMLData;


                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_UpdateCheckedInUser", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }



        #endregion

    }
}

