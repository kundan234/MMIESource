﻿using System;

using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.Common;
/*************************************************************************************************  
  
  Name of the Class			    : PaymentDA                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2011  
  
  Developer						: Vijendra Singh
  
  Modify Date					: 
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.DataAccess.INV
{
    public class INVDA : DataAccessObjectBase
    {
       
        public List<Customer> SearchStore(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[0].Value = objStore.CompanyID;
                arParms[1] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[1].Value = objStore.StoreID;
                arParms[2] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[2].Value = objStore.GroupType;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_INV_GetStockQtyInformation", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public List<Order> SearchProductStockList(Order objStore)
        {
            List<Order> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[0].Value = objStore.ProductID;
                arParms[1] = new SqlParameter("@ProductName", SqlDbType.VarChar);
                arParms[1].Value = objStore.ProductName;
                arParms[2] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[2].Value = objStore.GroupType;
                arParms[3] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[3].Value = objStore.StoreID;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_INV_GetStockQtyInformation", arParms);
                lstObject = ORHelper<Order>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public bool UpdateStockQuantityNew(Order objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[10];

                arParms[0] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[0].Value = objCustomer.ProductID;
                arParms[1] = new SqlParameter("@AdjustQty", SqlDbType.Float);
                arParms[1].Value = objCustomer.AdjustQty;
                arParms[2] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[2].Value = objCustomer.GroupType;

                arParms[3] = new SqlParameter("@AvailableQty", SqlDbType.Float);
                arParms[3].Value = objCustomer.AvailableQty;
                arParms[4] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[4].Value = objCustomer.StoreID;
                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[5].Value = objCustomer.FinancialYearID;
                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objCustomer.CompanyID;

                arParms[7] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[7].Value = objCustomer.AddedBy;

                arParms[8] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[8].Value = objCustomer.Remarks;

                arParms[9] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[9].Value = objCustomer.ID;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_INV_UpdateStockQty", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        public bool UpdateStockQuantity(Customer objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[0].Value = objCustomer.ProductID;
                arParms[1] = new SqlParameter("@AdjustQty", SqlDbType.Int);
                arParms[1].Value = objCustomer.Quantity;
                arParms[2] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[2].Value = objCustomer.GroupType;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_INV_UpdateStockQty", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }



        public bool UpdateTransferStockQuantity(Order objOrder)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[0].Value = objOrder.ProductID;
                arParms[1] = new SqlParameter("@TransferQty", SqlDbType.Int);
                arParms[1].Value = objOrder.Qty;
                arParms[2] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[2].Value = objOrder.GroupType;
                arParms[3] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[3].Value = objOrder.StoreID;
                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[4].Value = objOrder.CompanyID;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_INV_UpdateTransferStockQty", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        public bool UpdateTransferStockQuantityVehical(Order objOrder)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[0].Value = objOrder.FinancialYearID;
                arParms[1] = new SqlParameter("@ToStore", SqlDbType.Int);
                arParms[1].Value = objOrder.ToStore;
                arParms[2] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[2].Value = objOrder.CompanyID;
                arParms[3] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[3].Value = objOrder.GroupType;
                arParms[4] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[4].Value = objOrder.XMLData;
           

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_INV_UpdateStockTransferQtyVehical", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public bool UpdateTransferStockQuantityParts(Order objOrder)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[6];

                arParms[0] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[0].Value = objOrder.AddedBy;

                arParms[1] = new SqlParameter("@ToStore", SqlDbType.Int);
                arParms[1].Value = objOrder.ToStore;
                arParms[2] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[2].Value = objOrder.CompanyID;
                arParms[3] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[3].Value = objOrder.GroupType;
             
                arParms[4] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[4].Value = objOrder.XMLData;
                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[5].Value = objOrder.FinancialYearID;
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_INV_UpdateStockTransferQtyParts", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
    }
}
