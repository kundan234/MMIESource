﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.BANK;

namespace MMIE.DataAccess.BANK
{
    
    public class BankAccountDA:DataAccessObjectBase
    {
        #region Bank Account Master
               
        public bool SaveBankAccount(BankAccount objAccount)
        {
            List<BankAccount> lstObject = null;
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[11];
                arParms[0] = new SqlParameter("@BankAccountID", SqlDbType.Int);
                arParms[0].Value = objAccount.BankAccountID;
                arParms[1] = new SqlParameter("@AccountNumber", SqlDbType.VarChar);
                arParms[1].Value = objAccount.AccountNumber;
                arParms[2] = new SqlParameter("@AccountDetails", SqlDbType.VarChar);
                arParms[2].Value = objAccount.AccountDetails;



                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[3].Value = objAccount.IsActive;
                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objAccount.AddedBy;
                arParms[5] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[5].Value = objAccount.ActionType;

                arParms[6] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[6].Value = objAccount.LastModBy;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[7].Value = objAccount.FinancialYearID;
                arParms[8] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[8].Value = objAccount.CompanyID;
                
                arParms[9] = new SqlParameter("@BankID", SqlDbType.SmallInt);
                arParms[9].Value = objAccount.BankID;
                arParms[10] = new SqlParameter("@Message", SqlDbType.VarChar);
                arParms[10].Direction = ParameterDirection.Output;
                arParms[10].Value = "";

                arParms[6] = new SqlParameter("@AccountType", SqlDbType.SmallInt);
                arParms[6].Value = objAccount.AccountType;
                //------------------------

                
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_BNK_UpdateBankAccountMST]", arParms);
                if (noOfEffectedRecords > 0 || arParms[10].Value=="")
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<BankAccount> GetSearchBankAccountList(BankAccount objBankAccount,bool IsSearched)
        {
            List<BankAccount> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[7];

                arParms[0] = new SqlParameter("@BankAccountID", SqlDbType.Int);
                arParms[0].Value = objBankAccount.BankAccountID;
                arParms[1] = new SqlParameter("@AccountDetails", SqlDbType.VarChar);
                arParms[1].Value = objBankAccount.AccountDetails;
                arParms[2] = new SqlParameter("@BankID", SqlDbType.Int);
                arParms[2].Value = objBankAccount.BankID;

                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                if (!IsSearched)
                    arParms[3].Value = null;
                else
                   arParms[3].Value = objBankAccount.IsActive;

                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[4].Value = objBankAccount.CompanyID;


                arParms[5] = new SqlParameter("@AccountNumber", SqlDbType.SmallInt);
                arParms[5].Value = objBankAccount.AccountNumber;

                arParms[6] = new SqlParameter("@AccountType", SqlDbType.SmallInt);
                arParms[6].Value = objBankAccount.AccountType;



                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_BNK_GetSearchBankAccountList", arParms);
                lstObject = ORHelper<BankAccount>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public BankAccount GetBankAccountByID(int ID)
        {
            BankAccount objRetAccount = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@BankAccountID", SqlDbType.Int);
                arParms[0].Value = ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_BNK_GetSearchBankAccountList", ds, new string[] { "BankAccount" }, arParms);
                objRetAccount = ORHelper<BankAccount>.FromDataTable(ds.Tables["BankAccount"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetAccount;
        }

        #endregion



    }
}
