﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.BANK;

namespace MMIE.DataAccess.BANK
{
   public class BankAccountDetailsDA : DataAccessObjectBase
    {

        #region Bank Account Master





        public bool SaveBankAccountDetails(BankAccountDetails objAccount)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[17];
                arParms[0] = new SqlParameter("@BankAccountID", SqlDbType.Int);
                arParms[0].Value = objAccount.BankAccountID;
                arParms[1] = new SqlParameter("@AccountDetailsID", SqlDbType.Int);
                arParms[1].Value = objAccount.AccountDetailsID;
                arParms[2] = new SqlParameter("@TransactionDetails", SqlDbType.VarChar);
                arParms[2].Value = objAccount.TransactionDetails;



                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[3].Value = objAccount.IsActive;
                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objAccount.AddedBy;
                arParms[5] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[5].Value = objAccount.ActionType;

                arParms[6] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[6].Value = objAccount.LastModBy;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[7].Value = objAccount.FinancialYearID;
                arParms[8] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[8].Value = objAccount.CompanyID;

                arParms[9] = new SqlParameter("@ReferenceID", SqlDbType.SmallInt);
                arParms[9].Value = objAccount.ReferenceID;


                arParms[10] = new SqlParameter("@TransactionAmount", SqlDbType.Money);
                arParms[10].Value = objAccount.TransactionAmount;
                arParms[11] = new SqlParameter("@TransactionAmountUSD", SqlDbType.Money);
                arParms[11].Value = objAccount.TransactionAmountUSD;
                arParms[12] = new SqlParameter("@ReferenceNo", SqlDbType.VarChar);
                arParms[12].Value = objAccount.ReferenceNo;

                arParms[13] = new SqlParameter("@IsChecked", SqlDbType.Bit);
                arParms[13].Value = objAccount.IsChecked;

                arParms[14] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[14].Value = objAccount.TType;
                arParms[15] = new SqlParameter("@TransactionType", SqlDbType.VarChar);
                arParms[15].Value = objAccount.TransactionType;
                arParms[16] = new SqlParameter("@TransactionMode", SqlDbType.VarChar);
                arParms[16].Value = objAccount.TransactionMode;


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_BNK_UpdateBankAccountDetails", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<BankAccountDetails> GetSearchBankAccountDetailsList(BankAccountDetails objBankAccount)
        {
            List<BankAccountDetails> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[9];

                arParms[0] = new SqlParameter("@BankAccountID", SqlDbType.Int);
                arParms[0].Value = objBankAccount.BankAccountID;
                arParms[1] = new SqlParameter("@AccountDetailsID", SqlDbType.VarChar);
                arParms[1].Value = objBankAccount.AccountDetailsID;
                arParms[2] = new SqlParameter("@TransactionMode", SqlDbType.VarChar);
                arParms[2].Value = objBankAccount.TransactionMode;

                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[3].Value = objBankAccount.IsActive;

                arParms[4] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[4].Value = objBankAccount.CompanyID;


                arParms[5] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[5].Value = objBankAccount.TType;


                arParms[6] = new SqlParameter("@ReferenceNo", SqlDbType.VarChar);
                arParms[6].Value = objBankAccount.ReferenceNo;


                arParms[7] = new SqlParameter("@TransactionType", SqlDbType.VarChar);
                arParms[7].Value = objBankAccount.TransactionType;

                arParms[8] = new SqlParameter("@TransactionDetails", SqlDbType.VarChar);
                arParms[8].Value = objBankAccount.TransactionDetails;




                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_BNK_GetSearchBankAccountDetails", arParms);
                lstObject = ORHelper<BankAccountDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        #endregion
    }
}
