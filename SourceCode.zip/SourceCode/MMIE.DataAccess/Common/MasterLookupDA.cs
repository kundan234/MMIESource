﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.Common;
using MMIE.DataAccess.Constants;

/*************************************************************************************************  
  
  Name of the Class			    : MasterLookupDA                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: 
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.DataAccess.Common
{
    public class MasterLookupDA : DataAccessObjectBase
    {
        #region Public Members       

        
        public List<LookupItem> GetLookupsList(LookupNames lookupName)
        {
            List<LookupItem> lstObject = null;
            try
            {
                SqlParameterHelper paraColl = new SqlParameterHelper();
                paraColl.Add(LookupConstants.Parameters.LookupsName, SqlDbType.VarChar, lookupName.ToString());

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetMasterLookup", paraColl.ToArray());
                lstObject = ORHelper<LookupItem>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }            
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstObject;
        }
        public List<LookupItem> GetLookupsList(int currentIndex, int pageSize, LookupNames lookupName)
        {
            List<LookupItem> lstObject = null;
            try
            {
                SqlParameterHelper paraColl = new SqlParameterHelper();
                paraColl.Add(LookupConstants.Parameters.LookupsName, SqlDbType.VarChar, lookupName.ToString());
                paraColl.Add(CommonConstants.Parameters.CurrentIndex, SqlDbType.Int, currentIndex);
                paraColl.Add(CommonConstants.Parameters.PageSize, SqlDbType.Int, pageSize);

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, LookupConstants.StoreProcedures.GetPagedMasterLookup, paraColl.ToArray());
                lstObject = ORHelper<LookupItem>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstObject;
        }
        public List<LookupItem> GetLookupItemListByCategoryName(string categoryName)
        {
            List<LookupItem> lstObject = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CategoryName", SqlDbType.VarChar);
                arParms[0].Value = categoryName;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSubCategoryMSTByCategoryName", arParms);
                lstObject = ORHelper<LookupItem>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }

            return lstObject;
        }
        public List<LookupItem> GetLookupItemListByName(LookupItem objLookupItem, LookupNames lookupName)
        {
            List<LookupItem> lstObject = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[4];
                arParms[0] = new SqlParameter("@LookupsName", SqlDbType.VarChar);
                arParms[0].Value = lookupName;

                arParms[1] = new SqlParameter("@ItemId", SqlDbType.Int);
                arParms[1].Value = objLookupItem.ItemId;

                arParms[2] = new SqlParameter("@ItemName", SqlDbType.VarChar);
                arParms[2].Value = objLookupItem.ItemName;

                arParms[3] = new SqlParameter("@ShortDescription", SqlDbType.VarChar);
                arParms[3].Value = objLookupItem.ShortDescription;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetMasterLookup", arParms);
                lstObject = ORHelper<LookupItem>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstObject;
        }

        public LookupItem GetLookupItemByID(int itemID, LookupNames lookupName)
        {
            List<LookupItem> lstObject = null;
            try
            {
                SqlParameterHelper paraColl = new SqlParameterHelper();
                paraColl.Add(LookupConstants.Parameters.LookupsName, SqlDbType.VarChar, lookupName.ToString());
                paraColl.Add(LookupConstants.Parameters.ItemId, SqlDbType.Int, itemID);

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, LookupConstants.StoreProcedures.GetLookupItemByID, paraColl.ToArray());
                lstObject = ORHelper<LookupItem>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstObject.FirstOrDefault();
        }
        public List<LookupItem> GetLookupItemListByID(int itemID, LookupNames lookupName)
        {
            List<LookupItem> lstObject = null;
            try
            {
                SqlParameterHelper paraColl = new SqlParameterHelper();
                paraColl.Add(LookupConstants.Parameters.LookupsName, SqlDbType.VarChar, lookupName.ToString());
                paraColl.Add(LookupConstants.Parameters.ItemId, SqlDbType.Int, itemID);

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, LookupConstants.StoreProcedures.GetLookupItemByID, paraColl.ToArray());
                lstObject = ORHelper<LookupItem>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstObject;
        }
        public List<LookupItem> GetLookupItemListByIDs(int itemID, int itemID1, LookupNames lookupName)
        {
            List<LookupItem> lstObject = null;
            try
            {
                SqlParameterHelper paraColl = new SqlParameterHelper();
                paraColl.Add(LookupConstants.Parameters.LookupsName, SqlDbType.VarChar, lookupName.ToString());
                paraColl.Add(LookupConstants.Parameters.ItemId, SqlDbType.Int, itemID);
                paraColl.Add(LookupConstants.Parameters.ItemId1, SqlDbType.Int, itemID1);

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, LookupConstants.StoreProcedures.GetLookupItemByID, paraColl.ToArray());
                lstObject = ORHelper<LookupItem>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstObject;
        }
        public String UpdateMasterItem(MasterItem objMasterItem)
        {
            String result = "";
            try
            {
                SqlParameter[] arParms = new SqlParameter[20];
                                
                // common 
                arParms[0] = new SqlParameter("@ItemId", SqlDbType.Int);
                arParms[0].Value = objMasterItem.ItemId;

                arParms[1] = new SqlParameter("@ItemCode", SqlDbType.VarChar);
                arParms[1].Value = objMasterItem.ItemCode;

                arParms[2] = new SqlParameter("@ItemName", SqlDbType.VarChar);
                arParms[2].Value = objMasterItem.ItemName;

                arParms[3] = new SqlParameter("@ShortDescription", SqlDbType.VarChar);
                arParms[3].Value = objMasterItem.LongDescription;

                arParms[4] = new SqlParameter("@LongDescription", SqlDbType.VarChar);
                arParms[4].Value = objMasterItem.LongDescription;

                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[5].Value = objMasterItem.FinancialYearID;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[6].Value = objMasterItem.CompanyID;

                arParms[7] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[7].Value = objMasterItem.IsActive;

                arParms[8] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[8].Value = objMasterItem.AddedBy;

                arParms[9] = new SqlParameter("@AddedDTM", SqlDbType.DateTime);
                if (objMasterItem.AddedDTM <= DateTime.MinValue || objMasterItem.AddedDTM >= DateTime.MaxValue)
                    arParms[9].Value = System.Data.SqlTypes.SqlDateTime.Null;
                else arParms[9].Value = objMasterItem.AddedDTM;

                arParms[10] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[10].Value = objMasterItem.LastModBy;

                arParms[11] = new SqlParameter("@LastModDTM", SqlDbType.DateTime);
                if (objMasterItem.AddedDTM <= DateTime.MinValue || objMasterItem.AddedDTM >= DateTime.MaxValue)
                    arParms[11].Value = System.Data.SqlTypes.SqlDateTime.Null;
                else arParms[11].Value = objMasterItem.LastModDTM;

                arParms[12] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[12].Value = objMasterItem.ActionType;

                arParms[13] = new SqlParameter("@OrderSeq", SqlDbType.Int);
                arParms[13].Value = objMasterItem.OrderSeq;

                arParms[14] = new SqlParameter("@ParentItemId", SqlDbType.Int);
                arParms[14].Value = objMasterItem.ParentItemId;

                arParms[15] = new SqlParameter("@LookupsName", SqlDbType.VarChar);
                arParms[15].Value = objMasterItem.LookupsName;

                // country master items
                arParms[16] = new SqlParameter("@CountryISD", SqlDbType.VarChar);
                arParms[16].Value = objMasterItem.CountryISD;

                arParms[17] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[17].Value = objMasterItem.CurrencyID;

                arParms[18] = new SqlParameter("@CountryTimeZone", SqlDbType.VarChar);
                arParms[18].Value = objMasterItem.CountryTimeZone;

                arParms[19] = new SqlParameter("@ResultCode", SqlDbType.VarChar);
                arParms[19].Direction = ParameterDirection.Output;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, LookupConstants.StoreProcedures.UpdateLookupMaster, arParms); // "usp_UpdateMasterLookup"
                result = arParms[19].Value.ToString();

                dataReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return result;
        }
        public int SaveLookupItem(LookupItem item, LookupNames lookupName)
        {
            int RecordAffected;
            try
            {
                SqlParameterHelper paraColl = new SqlParameterHelper();
                paraColl.Add(LookupConstants.Parameters.LookupsName, SqlDbType.VarChar, lookupName.ToString());
                paraColl.Add(LookupConstants.Parameters.ItemCode, SqlDbType.VarChar, item.ItemCode);
                paraColl.Add(LookupConstants.Parameters.ItemName, SqlDbType.VarChar, item.ItemName);
                paraColl.Add(LookupConstants.Parameters.ShortDescription, SqlDbType.VarChar, item.ShortDescription);
                paraColl.Add(LookupConstants.Parameters.LongDescription, SqlDbType.VarChar, item.LongDescription);
                paraColl.Add(CommonConstants.Parameters.FinancialYearID, SqlDbType.SmallInt, item.FinancialYearID);
                paraColl.Add(CommonConstants.Parameters.CompanyID, SqlDbType.SmallInt, item.CompanyID);
                paraColl.Add(CommonConstants.Parameters.IsActive, SqlDbType.Bit, item.IsActive);
                paraColl.Add(CommonConstants.Parameters.AddedBy, SqlDbType.VarChar, item.AddedBy);
                paraColl.Add(CommonConstants.Parameters.AddedDTM, SqlDbType.DateTime, item.AddedDTM == DateTime.Parse("01-01-0001") ? DateTime.Now : item.AddedDTM);
                paraColl.Add(CommonConstants.Parameters.LastModBy, SqlDbType.VarChar, item.LastModBy);
                paraColl.Add(CommonConstants.Parameters.LastModDTM, SqlDbType.DateTime, item.LastModDTM == DateTime.Parse("01-01-0001") ? DateTime.Now : item.LastModDTM);
                RecordAffected = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, LookupConstants.StoreProcedures.SaveLookupMaster, paraColl.ToArray());
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }

            return RecordAffected;
        }
        public int UpdateLookupItem(LookupItem item, LookupNames lookupName)
        {
            int RecordAffected;
            try
            {
                SqlParameterHelper paraColl = new SqlParameterHelper();
                paraColl.Add(LookupConstants.Parameters.LookupsName, SqlDbType.VarChar, lookupName.ToString());
                paraColl.Add(LookupConstants.Parameters.ItemId, SqlDbType.Int, item.ItemId);
                paraColl.Add(LookupConstants.Parameters.ItemCode, SqlDbType.VarChar, item.ItemCode);
                paraColl.Add(LookupConstants.Parameters.ItemName, SqlDbType.VarChar, item.ItemName);
                paraColl.Add(LookupConstants.Parameters.ShortDescription, SqlDbType.VarChar, item.ShortDescription);
                paraColl.Add(LookupConstants.Parameters.LongDescription, SqlDbType.VarChar, item.LongDescription);
                paraColl.Add(CommonConstants.Parameters.FinancialYearID, SqlDbType.SmallInt, item.FinancialYearID);
                paraColl.Add(CommonConstants.Parameters.CompanyID, SqlDbType.SmallInt, item.CompanyID);
                paraColl.Add(CommonConstants.Parameters.IsActive, SqlDbType.Bit, item.IsActive);
                paraColl.Add(CommonConstants.Parameters.LastModBy, SqlDbType.VarChar, item.LastModBy);
                paraColl.Add(CommonConstants.Parameters.LastModDTM, SqlDbType.DateTime, item.LastModDTM == DateTime.Parse("01-01-0001") ? DateTime.Now : item.LastModDTM);
                RecordAffected = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, LookupConstants.StoreProcedures.UpdateLookupMaster, paraColl.ToArray());
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }

            return RecordAffected;
        }

        public List<LookupItem> GetWardByFloorID(int floorID)
        {
            List<LookupItem> lstLookup = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@FloorID", SqlDbType.Int);
                arParms[0].Value = floorID;

                SqlDataReader sqlReader = null;
                sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_IPD_GetWardMST", arParms);
                lstLookup = ORHelper<LookupItem>.FromDataReaderToList(sqlReader);
                sqlReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstLookup;
        }
        public List<LookupItem> GetRoomByFloorIDWardID(int floorID, int wardID)
        {
            List<LookupItem> lstLookup = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@FloorID", SqlDbType.Int);
                arParms[0].Value = floorID;

                arParms[1] = new SqlParameter("@WardID", SqlDbType.Int);
                arParms[1].Value = wardID;

                SqlDataReader sqlReader = null;
                sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_IPD_GetRoomMST", arParms);
                lstLookup = ORHelper<LookupItem>.FromDataReaderToList(sqlReader);
                sqlReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstLookup;
        }

        #endregion
    }
}

