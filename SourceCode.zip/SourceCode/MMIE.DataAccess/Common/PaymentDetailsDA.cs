﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;



/*************************************************************************************************  
  
  Name of the Class			    : PaymentDetailsDA                      
  
  Description of the class	    : 
  
  Created Date					: 1  DEC 2011  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 1/12/2010  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.DataAccess.Common
{

    public class PaymentDetailsDA : DataAccessObjectBase
    {

        #region PaymentDetails

        public bool SaveBillPaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[30];

                arParms[0] = new SqlParameter("@PaymentDetailsID", SqlDbType.Int);
                arParms[0].Value = objPaymentDetails.PaymentDetailsId;

                arParms[1] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[1].Value = objPaymentDetails.PaymentMode;

                arParms[2] = new SqlParameter("@PaymentModeNo", SqlDbType.VarChar);
                arParms[2].Value = objPaymentDetails.PaymentModeNo;

                arParms[3] = new SqlParameter("@PaymentAmount", SqlDbType.Money);
                arParms[3].Value = objPaymentDetails.PaidGourdesAmt;

                arParms[4] = new SqlParameter("@PaymentAmountUSD", SqlDbType.Money);
                arParms[4].Value = objPaymentDetails.PaidUSDAmt;

                arParms[5] = new SqlParameter("@BankID", SqlDbType.SmallInt);
                arParms[5].Value = objPaymentDetails.BankID;

                arParms[6] = new SqlParameter("@Expirationdate", SqlDbType.Date);
                arParms[6].Value = objPaymentDetails.Expirationdate.ToShortDateString();

                arParms[7] = new SqlParameter("@AuthorizationNo", SqlDbType.Int);
                arParms[7].Value = objPaymentDetails.AuthorizationNo;

                arParms[8] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[8].Value = objPaymentDetails.CustomerID;


                arParms[9] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[9].Value = objPaymentDetails.IsActive;


                arParms[10] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[10].Value = objPaymentDetails.AddedBy;

                arParms[11] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[11].Value = objPaymentDetails.LastModBy;

                arParms[12] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[12].Value = objPaymentDetails.FinancialYearID;

                arParms[13] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[13].Value = objPaymentDetails.CompanyID;


                arParms[14] = new SqlParameter("@ParentID", SqlDbType.SmallInt);
                arParms[14].Value = objPaymentDetails.ParentID;

                arParms[15] = new SqlParameter("@BillHeaderID", SqlDbType.SmallInt);
                arParms[15].Value = objPaymentDetails.BillHeaderID;

                arParms[16] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[16].Value = objPaymentDetails.OrderNumber;

                arParms[17] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[17].Value = objPaymentDetails.TType;


                arParms[18] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[18].Value = objPaymentDetails.ActionType;

                arParms[19] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[19].Value = objPaymentDetails.Remarks;



                arParms[20] = new SqlParameter("@SalesStatus", SqlDbType.SmallInt);
                arParms[20].Value = objPaymentDetails.SalesStatus;

                arParms[21] = new SqlParameter("@ShipID", SqlDbType.VarChar);
                arParms[21].Value = objPaymentDetails.ShipID;

                arParms[22] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
                arParms[22].Value = objPaymentDetails.CurrencyRate;

                arParms[23] = new SqlParameter("@TransactionType", SqlDbType.VarChar);
                arParms[23].Value = objPaymentDetails.TransactionType;

                arParms[24] = new SqlParameter("@PaymentSourceID", SqlDbType.Int);
                arParms[24].Value = objPaymentDetails.PaymentSourceID;    // Added by ankit for source id

                arParms[25] = new SqlParameter("@RemarksCheck", SqlDbType.VarChar);
                arParms[25].Value = objPaymentDetails.RemarksCheck;    // Added by ankit for source id

                

                //arParms[22] = new SqlParameter("@PaidUSDAmt", SqlDbType.Decimal);
                //arParms[22].Value = objPaymentDetails.PaidUSDAmt;


                ////arParms[23] = new SqlParameter("@DueUSDAmt", SqlDbType.Decimal);
                ////arParms[23].Value = objPaymentDetails.DueUSDAmt;

                //arParms[24] = new SqlParameter("@PaidGourdesAmt", SqlDbType.Decimal);
                //arParms[24].Value = objPaymentDetails.PaidGourdesAmt;
                //arParms[25] = new SqlParameter("@DueGourdesAmt", SqlDbType.Decimal);
                //arParms[25].Value = objPaymentDetails.DueGourdesAmt;


                arParms[26] = new SqlParameter("@IsPurchase", SqlDbType.Bit);
                arParms[26].Value = objPaymentDetails.IsPurchase;

                arParms[27] = new SqlParameter("@IsSales", SqlDbType.Bit);
                arParms[27].Value = objPaymentDetails.IsSales;

                arParms[28] = new SqlParameter("@PurchaseOrderID", SqlDbType.Int);
                arParms[28].Value = objPaymentDetails.PurchaseOrderID;

                arParms[29] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[29].Value = objPaymentDetails.CurrencyID;

            

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_SAL_UpdateBillPayment]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        


        public bool SavePaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[30];

                arParms[0] = new SqlParameter("@PaymentDetailsID", SqlDbType.Int);
                arParms[0].Value = objPaymentDetails.PaymentDetailsId;

                arParms[1] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[1].Value = objPaymentDetails.PaymentMode;

                arParms[2] = new SqlParameter("@PaymentModeNo", SqlDbType.VarChar);
                arParms[2].Value = objPaymentDetails.PaymentModeNo;

                arParms[3] = new SqlParameter("@PaymentAmount", SqlDbType.Money);
                arParms[3].Value = objPaymentDetails.PaymentAmount;

                arParms[4] = new SqlParameter("@PaymentAmountUSD", SqlDbType.Money);
                arParms[4].Value = objPaymentDetails.PaymentAmountUSD;

                arParms[5] = new SqlParameter("@BankID", SqlDbType.SmallInt);
                arParms[5].Value = objPaymentDetails.BankID;

                arParms[6] = new SqlParameter("@Expirationdate", SqlDbType.Date);
                arParms[6].Value = objPaymentDetails.Expirationdate.ToShortDateString();

                arParms[7] = new SqlParameter("@AuthorizationNo", SqlDbType.Int);
                arParms[7].Value = objPaymentDetails.AuthorizationNo;

                arParms[8] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[8].Value = objPaymentDetails.CustomerID;


                arParms[9] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[9].Value = objPaymentDetails.IsActive;


                arParms[10] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[10].Value = objPaymentDetails.AddedBy;

                arParms[11] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[11].Value = objPaymentDetails.LastModBy;

                arParms[12] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[12].Value = objPaymentDetails.FinancialYearID;

                arParms[13] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[13].Value = objPaymentDetails.CompanyID;


                arParms[14] = new SqlParameter("@ParentID", SqlDbType.SmallInt);
                arParms[14].Value = objPaymentDetails.ParentID;

                arParms[15] = new SqlParameter("@BillHeaderID", SqlDbType.SmallInt);
                arParms[15].Value = objPaymentDetails.BillHeaderID;

                arParms[16] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[16].Value = objPaymentDetails.OrderNumber;

                arParms[17] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[17].Value = objPaymentDetails.TType;


                arParms[18] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[18].Value = objPaymentDetails.ActionType;

                arParms[19] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[19].Value = objPaymentDetails.Remarks;

                arParms[20] = new SqlParameter("@TransactionType", SqlDbType.VarChar);
                arParms[20].Value = objPaymentDetails.TransactionType;


                arParms[21] = new SqlParameter("@IsPurchase", SqlDbType.Bit);
                arParms[21].Value = objPaymentDetails.IsPurchase;

                arParms[22] = new SqlParameter("@IsSales", SqlDbType.Bit);
                arParms[22].Value = objPaymentDetails.IsSales;

                arParms[23] = new SqlParameter("@PurchaseOrderID", SqlDbType.Int);
                arParms[23].Value = objPaymentDetails.PurchaseOrderID;

                arParms[24] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[24].Value = objPaymentDetails.CurrencyID;

                arParms[25] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
                arParms[25].Value = objPaymentDetails.CurrencyRate;

                arParms[26] = new SqlParameter("@IsOthers", SqlDbType.Bit);
                arParms[26].Value = objPaymentDetails.IsOthers;

                arParms[27] = new SqlParameter("@OtherRefNo", SqlDbType.Int);
                arParms[27].Value = objPaymentDetails.OtherRefNo;

                arParms[28] = new SqlParameter("@PaymentSourceID", SqlDbType.Int);
                arParms[28].Value = objPaymentDetails.PaymentSourceID;

                arParms[29] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[29].Value = objPaymentDetails.InvoiceNo;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdatePaymentDetails]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        //public bool AdjustPaymentDetails(PaymentDetails objPaymentDetails)
        //{
        //    bool status = false;
        //    try
        //    {

        //        SqlParameter[] arParms = new SqlParameter[20];

        //        arParms[0] = new SqlParameter("@PaymentDetailsID", SqlDbType.Int);
        //        arParms[0].Value = objPaymentDetails.PaymentDetailsId;

        //        arParms[1] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
        //        arParms[1].Value = objPaymentDetails.PaymentMode;

        //        arParms[2] = new SqlParameter("@PaymentModeNo", SqlDbType.VarChar);
        //        arParms[2].Value = objPaymentDetails.PaymentModeNo;

        //        arParms[3] = new SqlParameter("@PaymentAmount", SqlDbType.Money);
        //        arParms[3].Value = objPaymentDetails.PaymentAmount;

        //        arParms[4] = new SqlParameter("@PaymentAmountUSD", SqlDbType.Money);
        //        arParms[4].Value = objPaymentDetails.PaymentAmountUSD;

        //        arParms[5] = new SqlParameter("@BankID", SqlDbType.SmallInt);
        //        arParms[5].Value = objPaymentDetails.BankID;

        //        arParms[6] = new SqlParameter("@Expirationdate", SqlDbType.Date);
        //        arParms[6].Value = objPaymentDetails.Expirationdate.ToShortDateString();

        //        arParms[7] = new SqlParameter("@AuthorizationNo", SqlDbType.Int);
        //        arParms[7].Value = objPaymentDetails.AuthorizationNo;

        //        arParms[8] = new SqlParameter("@CustomerID", SqlDbType.Int);
        //        arParms[8].Value = objPaymentDetails.CustomerID;


        //        arParms[9] = new SqlParameter("@IsActive", SqlDbType.Bit);
        //        arParms[9].Value = objPaymentDetails.IsActive;


        //        arParms[10] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
        //        arParms[10].Value = objPaymentDetails.AddedBy;

        //        arParms[11] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
        //        arParms[11].Value = objPaymentDetails.LastModBy;

        //        arParms[12] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
        //        arParms[12].Value = objPaymentDetails.FinancialYearID;

        //        arParms[13] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
        //        arParms[13].Value = objPaymentDetails.CompanyID;


        //        arParms[14] = new SqlParameter("@ParentID", SqlDbType.SmallInt);
        //        arParms[14].Value = objPaymentDetails.ParentID;

        //        arParms[15] = new SqlParameter("@BillHeaderID", SqlDbType.SmallInt);
        //        arParms[15].Value = objPaymentDetails.BillHeaderID;

        //        arParms[16] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
        //        arParms[16].Value = objPaymentDetails.OrderNumber;

        //        arParms[17] = new SqlParameter("@TType", SqlDbType.VarChar);
        //        arParms[17].Value = objPaymentDetails.TType;


        //        arParms[18] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
        //        arParms[18].Value = objPaymentDetails.ActionType;

        //        arParms[19] = new SqlParameter("@Remarks", SqlDbType.VarChar);
        //        arParms[19].Value = objPaymentDetails.Remarks;



        //        //        arParms[26] = new SqlParameter("@IsPurchase", SqlDbType.Bit);
        //        //        arParms[26].Value = objPaymentDetails.IsPurchase;

        //        //        arParms[27] = new SqlParameter("@IsSales", SqlDbType.Bit);
        //        //        arParms[27].Value = objPaymentDetails.IsSales;

        //        //        arParms[28] = new SqlParameter("@PurchaseOrderID", SqlDbType.Int);
        //        //        arParms[28].Value = objPaymentDetails.PurchaseOrderID;

        //        //        arParms[29] = new SqlParameter("@CurrencyID", SqlDbType.Int);
        //        //        arParms[29].Value = objPaymentDetails.CurrencyID;

        //        //        arParms[30] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
        //        //        arParms[30].Value = objPaymentDetails.CurrencyRate;


        //        int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdatePaymentAdjustment]", arParms);
        //        if (noOfEffectedRecords > 0)
        //            status = true;

        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new DataAccessException("5000001", ex);
        //    }

        //    return status;
        //}

       
        public PaymentDetails GetPaymentDetailsByID(int ID)
        {
            PaymentDetails objPaymentDetails = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[3];
                arParms[0] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[0].Value = ID;
                arParms[1] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[1].Value = 1;
                arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[2].Value = "";

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetPaymentDetailsByID", ds, new string[] { "PaymentDetails" }, arParms);
                objPaymentDetails = ORHelper<PaymentDetails>.FromDataTable(ds.Tables["PaymentDetails"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objPaymentDetails;
        }

        public List<PaymentDetails> GetPaymentDetailsListByBillID(int ID)
        {
            List<PaymentDetails> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[3];
                arParms[0] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[0].Value = ID;
                arParms[1] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[1].Value = 3;
                arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[2].Value = "";

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetPaymentDetailsByID", arParms);
                lstObject = ORHelper<PaymentDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<PaymentDetails> GetPaymentDetailsListByOrderID(string OrderNumber)
        {
            List<PaymentDetails> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[0].Value = 0;

                arParms[1] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[1].Value = 2;
                arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[2].Value = OrderNumber;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetPaymentDetailsByID", arParms);
                lstObject = ORHelper<PaymentDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<PaymentDetails> GetPaymentDetailsListByOrderIDCR(string OrderNumber)
        {
            List<PaymentDetails> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[0].Value = 0;

                arParms[1] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[1].Value = 5;
                arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[2].Value = OrderNumber;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetPaymentDetailsByID", arParms);
                lstObject = ORHelper<PaymentDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }




        public List<PaymentDetails> GetSearchPaymentDetails(PaymentDetails objPaymentDetails)
        {
            List<PaymentDetails> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[6];

                arParms[0] = new SqlParameter("@UserID", SqlDbType.VarChar);
                arParms[0].Value = objPaymentDetails.AddedBy;

                arParms[1] = new SqlParameter("@StartDate", SqlDbType.Date);
                arParms[1].Value = objPaymentDetails.StartDate.ToShortDateString();

                arParms[2] = new SqlParameter("@EndDate", SqlDbType.Date);
                arParms[2].Value = objPaymentDetails.EndDate.ToShortDateString();

                arParms[3] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[3].Value = objPaymentDetails.CompanyID;

                arParms[4] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[4].Value = objPaymentDetails.FinancialYearID;

                arParms[5] = new SqlParameter("@CurrencyId", SqlDbType.Int);
                arParms[5].Value = objPaymentDetails.CurrencyID;
                          


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_GetSearchPaymentList]", arParms);
                lstObject = ORHelper<PaymentDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public List<PaymentDetails> GetSearchUserCollection(PaymentDetails objPaymentDetails)
        {
            List<PaymentDetails> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[5];

                arParms[0] = new SqlParameter("@UserID", SqlDbType.VarChar);
                arParms[0].Value = objPaymentDetails.AddedBy;

                arParms[1] = new SqlParameter("@StartDate", SqlDbType.Date);
                arParms[1].Value = objPaymentDetails.StartDate.ToShortDateString();

                arParms[2] = new SqlParameter("@EndDate", SqlDbType.Date);
                arParms[2].Value = objPaymentDetails.EndDate.ToShortDateString();

                arParms[3] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[3].Value = objPaymentDetails.CompanyID;

                arParms[4] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[4].Value = objPaymentDetails.FinancialYearID;



                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchUserCollectionList", arParms);
                lstObject = ORHelper<PaymentDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        public bool SaveCheckOutPaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[0].Value = objPaymentDetails.AddedBy;

                arParms[1] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[1].Value = objPaymentDetails.CompanyID;

                arParms[2] = new SqlParameter("@FinancialYearID", SqlDbType.VarChar);
                arParms[2].Value = objPaymentDetails.FinancialYearID;

                arParms[3] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[3].Value = objPaymentDetails.XMLData;




                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_UpdateCheckedPayment", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        public bool SaveSafeBoxDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[6];

                arParms[0] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[0].Value = objPaymentDetails.AddedBy;



                arParms[1] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[1].Value = objPaymentDetails.CompanyID;

                arParms[2] = new SqlParameter("@FinancialYearID", SqlDbType.VarChar);
                arParms[2].Value = objPaymentDetails.FinancialYearID;

                arParms[3] = new SqlParameter("@XMLData", SqlDbType.Xml);
                arParms[3].Value = objPaymentDetails.XMLData;

                arParms[4] = new SqlParameter("@StartDate", SqlDbType.Date);
                arParms[4].Value = objPaymentDetails.StartDate.ToShortDateString();
                arParms[5] = new SqlParameter("@EndDate", SqlDbType.Date);
                arParms[5].Value = objPaymentDetails.EndDate.ToShortDateString();


                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_SAL_UpdateSafeBoxAmount]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

   
        public List<PaymentDetails> GetSearchPaymentDetailsCustomer(int ID)
        {
            List<PaymentDetails> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[3];
                arParms[0] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[0].Value = ID;
                arParms[1] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[1].Value = 4;
                arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[2].Value = "";

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetPaymentDetailsByID", arParms);
                lstObject = ORHelper<PaymentDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        #endregion

        #region Invoice Payments Functionality

        public List<PaymentDetails> GetPaymentDetailsListByInvoiceID(int ID)
        {
            List<PaymentDetails> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@InvoiceHeaderID", SqlDbType.Int);
                arParms[0].Value = ID;


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_PUR_GetSearchPaymentDetailsByInvoiceID]", arParms);
                lstObject = ORHelper<PaymentDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        /// <summary>
        /// Update the inovice Payment details 
        /// </summary>
        /// <param name="objPaymentDetails"></param>
        /// <returns></returns>
        public bool SaveInvoicePaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[25];

                arParms[0] = new SqlParameter("@PaymentDetailsID", SqlDbType.Int);
                arParms[0].Value = objPaymentDetails.PaymentDetailsId;

                arParms[1] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[1].Value = objPaymentDetails.PaymentMode;

                arParms[2] = new SqlParameter("@PaymentModeNo", SqlDbType.VarChar);
                arParms[2].Value = objPaymentDetails.PaymentModeNo;

                arParms[3] = new SqlParameter("@PaymentAmount", SqlDbType.Money);
                arParms[3].Value = objPaymentDetails.PaymentAmount;

                arParms[4] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[4].Value = objPaymentDetails.CurrencyID;

                arParms[5] = new SqlParameter("@BankID", SqlDbType.SmallInt);
                arParms[5].Value = objPaymentDetails.BankID;

                arParms[6] = new SqlParameter("@Expirationdate", SqlDbType.Date);
                arParms[6].Value = objPaymentDetails.Expirationdate.ToShortDateString();

                arParms[7] = new SqlParameter("@TransactionType", SqlDbType.VarChar);
                arParms[7].Value = objPaymentDetails.TransactionType;


                arParms[8] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[8].Value = objPaymentDetails.CustomerID;


                arParms[9] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[9].Value = objPaymentDetails.IsActive;


                arParms[10] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[10].Value = objPaymentDetails.AddedBy;

                arParms[11] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[11].Value = objPaymentDetails.LastModBy;

                arParms[12] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[12].Value = objPaymentDetails.FinancialYearID;

                arParms[13] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[13].Value = objPaymentDetails.CompanyID;


                arParms[14] = new SqlParameter("@ParentID", SqlDbType.SmallInt);
                arParms[14].Value = objPaymentDetails.ParentID;

                arParms[15] = new SqlParameter("@InvoiceNo", SqlDbType.VarChar);
                arParms[15].Value = objPaymentDetails.InvoiceNo;

                arParms[16] = new SqlParameter("@PONumber", SqlDbType.Int);
                arParms[16].Value = objPaymentDetails.PONumber;

                arParms[17] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[17].Value = objPaymentDetails.TType;


                arParms[18] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[18].Value = objPaymentDetails.ActionType;

                arParms[19] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[19].Value = objPaymentDetails.Remarks;

                arParms[20] = new SqlParameter("@PaidAmount", SqlDbType.Money);
                arParms[20].Value = objPaymentDetails.PaidGourdesAmt;

                arParms[21] = new SqlParameter("@IsPurchase", SqlDbType.Bit);
                arParms[21].Value = objPaymentDetails.IsPurchase;


                arParms[22] = new SqlParameter("@InvoiceHeaderID", SqlDbType.Int);
                arParms[22].Value = objPaymentDetails.PurchaseOrderID;



                arParms[23] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
                arParms[23].Value = objPaymentDetails.CurrencyRate;



                arParms[24] = new SqlParameter("@PaymentSourceID", SqlDbType.Int);
                arParms[24].Value = objPaymentDetails.PaymentSourceID;



                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PUR_UpdateInvoicePaymentDetails", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }



        public List<PaymentDetails> GetSearchInvoicePaymentDetailsList(PaymentDetails objPaymentDetails)
        {
            List<PaymentDetails> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[15];

                arParms[0] = new SqlParameter("@PaymentDetailsID", SqlDbType.Int);
                arParms[0].Value = objPaymentDetails.PaymentDetailsId;

                arParms[1] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[1].Value = 3;
                arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[2].Value = "";

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetPaymentDetailsByID", arParms);
                lstObject = ORHelper<PaymentDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public DataSet GetOtherPaymentDetails( DateTime dtFromDate, DateTime dtTodate)
        {
            

            DataSet ds = new DataSet();
            try
            {
                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@FromDate", SqlDbType.DateTime);
                arParms[0].Value = dtFromDate;

                arParms[1] = new SqlParameter("@ToDate", SqlDbType.DateTime);
                arParms[1].Value = dtTodate;

                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetOthersPaymentDetails", ds, null, arParms);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return ds;
        }


        #endregion

        #region Internal Paymenet Issue /Recieving
        public bool UpdatePaymentAdjustmentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[29];

                arParms[0] = new SqlParameter("@PaymentDetailsID", SqlDbType.Int);
                arParms[0].Value = objPaymentDetails.PaymentDetailsId;

                arParms[1] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[1].Value = objPaymentDetails.PaymentMode;

                arParms[2] = new SqlParameter("@PaymentModeNo", SqlDbType.VarChar);
                arParms[2].Value = objPaymentDetails.PaymentModeNo;

                arParms[3] = new SqlParameter("@PaymentAmount", SqlDbType.Money);
                arParms[3].Value = objPaymentDetails.PaymentAmount;

                arParms[4] = new SqlParameter("@PaymentAmountUSD", SqlDbType.Money);
                arParms[4].Value = objPaymentDetails.PaymentAmountUSD;

                arParms[5] = new SqlParameter("@BankID", SqlDbType.SmallInt);
                arParms[5].Value = objPaymentDetails.BankID;

                arParms[6] = new SqlParameter("@Expirationdate", SqlDbType.Date);
                arParms[6].Value = objPaymentDetails.Expirationdate.ToShortDateString();

                arParms[7] = new SqlParameter("@AuthorizationNo", SqlDbType.Int);
                arParms[7].Value = objPaymentDetails.AuthorizationNo;

                arParms[8] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[8].Value = objPaymentDetails.CustomerID;


                arParms[9] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[9].Value = objPaymentDetails.IsActive;


                arParms[10] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[10].Value = objPaymentDetails.AddedBy;

                arParms[11] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[11].Value = objPaymentDetails.LastModBy;

                arParms[12] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[12].Value = objPaymentDetails.FinancialYearID;

                arParms[13] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[13].Value = objPaymentDetails.CompanyID;


                arParms[14] = new SqlParameter("@ParentID", SqlDbType.SmallInt);
                arParms[14].Value = objPaymentDetails.ParentID;

                arParms[15] = new SqlParameter("@BillHeaderID", SqlDbType.SmallInt);
                arParms[15].Value = objPaymentDetails.BillHeaderID;

                arParms[16] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[16].Value = objPaymentDetails.OrderNumber;

                arParms[17] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[17].Value = objPaymentDetails.TType;


                arParms[18] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                arParms[18].Value = objPaymentDetails.ActionType;

                arParms[19] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[19].Value = objPaymentDetails.Remarks;

                arParms[20] = new SqlParameter("@TransactionType", SqlDbType.VarChar);
                arParms[20].Value = objPaymentDetails.TransactionType;


                arParms[21] = new SqlParameter("@IsPurchase", SqlDbType.Bit);
                arParms[21].Value = objPaymentDetails.IsPurchase;

                arParms[22] = new SqlParameter("@IsSales", SqlDbType.Bit);
                arParms[22].Value = objPaymentDetails.IsSales;

                arParms[23] = new SqlParameter("@PurchaseOrderID", SqlDbType.Int);
                arParms[23].Value = objPaymentDetails.PurchaseOrderID;

                arParms[24] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[24].Value = objPaymentDetails.CurrencyID;

                arParms[25] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
                arParms[25].Value = objPaymentDetails.CurrencyRate;

                arParms[26] = new SqlParameter("@IsOthers", SqlDbType.Bit);
                arParms[26].Value = objPaymentDetails.IsOthers;

                arParms[27] = new SqlParameter("@OtherRefNo", SqlDbType.Int);
                arParms[27].Value = objPaymentDetails.OtherRefNo;
                arParms[28] = new SqlParameter("@PaymentSourceID", SqlDbType.Int);
                 arParms[28].Value = objPaymentDetails.PaymentSourceID;


                 int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdatePaymentAdjustmentDetails]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }




        #endregion

        #region Employe Salary Payment Functionanliy
      

        public List<PaymentDetails> GetSearchEmployeePaymentDetailsList(PaymentDetails objPaymentDetails)
        {
            List<PaymentDetails> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[2];

                arParms[0] = new SqlParameter("@EmployeeID", SqlDbType.Int);
                arParms[0].Value = objPaymentDetails.PaymentDetailsId;

                arParms[1] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[1].Value = 3;
                //arParms[2] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                //arParms[2].Value = "";

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetPaymentDetailsByID", arParms);
                lstObject = ORHelper<PaymentDetails>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        /// <summary>
        /// Update the inovice Payment details 
        /// </summary>
        /// <param name="objPaymentDetails"></param>
        /// <returns></returns>
        public bool SaveEmployeePaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[19];

                arParms[0] = new SqlParameter("@PaymentDetailsID", SqlDbType.Int);
                arParms[0].Value = objPaymentDetails.PaymentDetailsId;

                arParms[1] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[1].Value = objPaymentDetails.PaymentMode;

                arParms[2] = new SqlParameter("@PaymentModeNo", SqlDbType.VarChar);
                arParms[2].Value = objPaymentDetails.PaymentModeNo;

                arParms[3] = new SqlParameter("@PaymentAmount", SqlDbType.Money);
                arParms[3].Value = objPaymentDetails.PaymentAmount;

                arParms[4] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[4].Value = objPaymentDetails.CurrencyID;

                arParms[5] = new SqlParameter("@BankID", SqlDbType.SmallInt);
                arParms[5].Value = objPaymentDetails.BankID;

                arParms[6] = new SqlParameter("@Expirationdate", SqlDbType.Date);
                arParms[6].Value = objPaymentDetails.Expirationdate.ToShortDateString();

                arParms[7] = new SqlParameter("@TransactionType", SqlDbType.VarChar);
                arParms[7].Value = objPaymentDetails.TransactionType;


                arParms[8] = new SqlParameter("@EmployeeID", SqlDbType.Int);
                arParms[8].Value = objPaymentDetails.EmployeeID ;

                arParms[9] = new SqlParameter("@PaymentSourceID", SqlDbType.Int);
                arParms[9].Value = objPaymentDetails.PaymentSourceID;


                //arParms[9] = new SqlParameter("@IsActive", SqlDbType.Bit);
                //arParms[9].Value = objPaymentDetails.IsActive;


                arParms[10] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[10].Value = objPaymentDetails.AddedBy;

                arParms[11] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[11].Value = objPaymentDetails.LastModBy;

                arParms[12] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[12].Value = objPaymentDetails.FinancialYearID;

                arParms[13] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[13].Value = objPaymentDetails.CompanyID;


                arParms[14] = new SqlParameter("@ParentID", SqlDbType.SmallInt);
                arParms[14].Value = objPaymentDetails.ParentID;

           
                arParms[15] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[15].Value = objPaymentDetails.TType;



                arParms[16] = new SqlParameter("@SalaryID", SqlDbType.Int);
                arParms[16].Value = objPaymentDetails.SalaryID;



                //arParms[16] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                //arParms[16].Value = objPaymentDetails.ActionType;

                arParms[17] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[17].Value = objPaymentDetails.Remarks;

                arParms[18] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
                arParms[18].Value = objPaymentDetails.CurrencyRate;


            
                //arParms[21] = new SqlParameter("@IsSales", SqlDbType.Bit);
                //arParms[21].Value = objPaymentDetails.IsSales;



                //arParms[21] = new SqlParameter("@IsOthers", SqlDbType.Bit);
                //arParms[21].Value = objPaymentDetails.IsOthers;





                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_UpdateSalaryPaymentDetails", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        #endregion

        #region EmployeeLoanPaymnet
        /// <returns></returns>
        public bool SaveEmployeeLoanPaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[20];

                arParms[0] = new SqlParameter("@PaymentDetailsID", SqlDbType.Int);
                arParms[0].Value = objPaymentDetails.PaymentDetailsId;

                arParms[1] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[1].Value = objPaymentDetails.PaymentMode;

                arParms[2] = new SqlParameter("@PaymentModeNo", SqlDbType.VarChar);
                arParms[2].Value = objPaymentDetails.PaymentModeNo;

                arParms[3] = new SqlParameter("@PaymentAmount", SqlDbType.Money);
                arParms[3].Value = objPaymentDetails.PaymentAmount;

                arParms[4] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[4].Value = objPaymentDetails.CurrencyID;

                arParms[5] = new SqlParameter("@BankID", SqlDbType.SmallInt);
                arParms[5].Value = objPaymentDetails.BankID;

                arParms[6] = new SqlParameter("@Expirationdate", SqlDbType.Date);
                arParms[6].Value = objPaymentDetails.Expirationdate.ToShortDateString();

                arParms[7] = new SqlParameter("@TransactionType", SqlDbType.VarChar);
                arParms[7].Value = objPaymentDetails.TransactionType;


                arParms[8] = new SqlParameter("@EmployeeID", SqlDbType.Int);
                arParms[8].Value = objPaymentDetails.EmployeeID;

                arParms[9] = new SqlParameter("@PaymentSourceID", SqlDbType.Int);
                arParms[9].Value = objPaymentDetails.PaymentSourceID;


                //arParms[9] = new SqlParameter("@IsActive", SqlDbType.Bit);
                //arParms[9].Value = objPaymentDetails.IsActive;


                arParms[10] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[10].Value = objPaymentDetails.AddedBy;

                arParms[11] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[11].Value = objPaymentDetails.LastModBy;

                arParms[12] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
                arParms[12].Value = objPaymentDetails.FinancialYearID;

                arParms[13] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[13].Value = objPaymentDetails.CompanyID;


                arParms[14] = new SqlParameter("@ParentID", SqlDbType.SmallInt);
                arParms[14].Value = objPaymentDetails.ParentID;


                arParms[15] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[15].Value = objPaymentDetails.TType;



                arParms[16] = new SqlParameter("@LoanID", SqlDbType.Int);
                arParms[16].Value = objPaymentDetails.LoanID;



                //arParms[16] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                //arParms[16].Value = objPaymentDetails.ActionType;

                arParms[17] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[17].Value = objPaymentDetails.Remarks;

                arParms[18] = new SqlParameter("@CurrencyRate", SqlDbType.Money);
                arParms[18].Value = objPaymentDetails.CurrencyRate;



                arParms[19] = new SqlParameter("@IsLoan", SqlDbType.Bit);
                arParms[19].Value = objPaymentDetails.IsLoan;



                //arParms[21] = new SqlParameter("@IsOthers", SqlDbType.Bit);
                //arParms[21].Value = objPaymentDetails.IsOthers;





                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_UpdateLoanPaymentDetails", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }





        #endregion


    }
}
