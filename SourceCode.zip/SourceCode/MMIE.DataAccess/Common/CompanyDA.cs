﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
using MMIE.Data.Common; 


namespace MMIE.DataAccess.Common
{
    public class CompanyDA : DataAccessObjectBase
    {

        public List<Company> GetCompanyDetail()
        {
            List<Company> lstCompany = null;
            try
            {
                SqlDataReader sqlReader = null;
                sqlReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCompanyDetail", null);
                List<Company> listCompany = ORHelper<Company>.FromDataReaderToList(sqlReader);
                lstCompany = listCompany;
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstCompany;
        }
        public bool SaveCompany(Company objCompany)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[18];

                arParms[0] = new SqlParameter("@CompanyType", SqlDbType.VarChar);
                arParms[0].Value = objCompany.CompanyType;
                arParms[1] = new SqlParameter("@CompanyName", SqlDbType.VarChar);
                arParms[1].Value = objCompany.CompanyName;
                arParms[2] = new SqlParameter("@Acronym", SqlDbType.VarChar);
                arParms[2].Value = objCompany.Acronym;
                arParms[3] = new SqlParameter("@Ville", SqlDbType.VarChar);
                arParms[3].Value = objCompany.Ville;
                arParms[4] = new SqlParameter("@Commune", SqlDbType.VarChar);
                arParms[4].Value = objCompany.Commune;
                arParms[5] = new SqlParameter("@Department", SqlDbType.VarChar);
                arParms[5].Value = objCompany.Department;
                arParms[6] = new SqlParameter("@FiscalYear", SqlDbType.VarChar);
                arParms[6].Value = objCompany.FiscalYear;             
                arParms[7] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[7].Value = objCompany.CompanyID;
                arParms[8] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[8].Value = objCompany.AddedBy;
                arParms[9] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[9].Value = objCompany.LastModBy;             
                arParms[10] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[10].Value = objCompany.ActionType;
                arParms[11] = new SqlParameter("@PinNo", SqlDbType.VarChar);
                arParms[11].Value = objCompany.PinNo;
                arParms[12] = new SqlParameter("@CompanyPhoneNo", SqlDbType.VarChar);
                arParms[12].Value = objCompany.CompanyPhoneNo;
                arParms[13] = new SqlParameter("@CompanyEmailID", SqlDbType.VarChar);
                arParms[13].Value = objCompany.CompanyEmailID;
                arParms[14] = new SqlParameter("@CompanyWebsite", SqlDbType.VarChar);
                arParms[14].Value = objCompany.CompanyWebsite;               
                arParms[15] = new SqlParameter("@CompanyLandMark", SqlDbType.VarChar);
                arParms[15].Value = objCompany.CompanyStreet;
                arParms[16] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[16].Value = objCompany.IsActive;
                arParms[17] = new SqlParameter("@CompanyFaxNo", SqlDbType.VarChar);
                arParms[17].Value = objCompany.CompanyFaxNo;
               
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateCompanyMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public List<Company> SearchCompany(Company objCompany)
        {
            List<Company> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[2];                

                arParms[0] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                arParms[0].Value = objCompany.CurrentIndex;

                arParms[1] = new SqlParameter("@PageSize", SqlDbType.Int);
                arParms[1].Value = objCompany.PageSize;


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCompanyDetailInfo", arParms);
                lstObject = ORHelper<Company>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public Company GetCompanyByID(Company objCompany)
        {
            Company objRetCompany = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[0].Value = objCompany.CompanyID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCompanyByID", ds, new string[] { "Company" }, arParms);
                objRetCompany = ORHelper<Company>.FromDataTable(ds.Tables["Company"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCompany;
        }
    }
}
