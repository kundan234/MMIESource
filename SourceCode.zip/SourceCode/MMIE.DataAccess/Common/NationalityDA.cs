﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;


using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;



namespace MMIE.DataAccess.Common
{
    public class NationalityDA : DataAccessObjectBase
    {
        //public List<Nationality> GetNationalityList()
        //{
        //    List<Nationality> lstObject = null;
        //    try
        //    {
        //        //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessLogicEvents, EnumPriority.High, EnumLogEvenType.Information));

        //        DataSet ds = new DataSet();
        //        //SqlHelper.FillDataset(Globals.ConnectionString, CommandType.StoredProcedure, "usp_GetNationality", ds, new string[] { "MaritalStatus" }, null);
        //        lstObject = ObjectUtil.GetDataObject<Nationality>(ds);
        //    }
        //    catch (Exception ex) //Exception of the business layer(itself)//unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new BusinessProcessException("5000001", ex);
        //    }

        //    return lstObject;
        //}

        //public string GetNationalityName(int NationalityID)
        //{
        //    string NationalityName = null;
        //   // SqlDataReader dr;
        //    try
        //    {
        //        SqlParameter[] arParms = new SqlParameter[1];
        //        arParms[0] = new SqlParameter("@NationalityID", SqlDbType.Int);
        //        arParms[0].Value = NationalityID;
                
        //    }
        //     catch (Exception ex) //Exception of the business layer(itself)//unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new BusinessProcessException("5000001", ex);
        //    }
            
        //    return NationalityName;
        //}
    }
}
