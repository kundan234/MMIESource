﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;

/*************************************************************************************************  
  
Name of the Class			    : StoreDA                      
  
Description of the class	    : 
  
Created Date					: 30 dec 2011  
  
Developer						: Kundan singh
  
Modify Date					: 19/10/2011  
  
Modified By Developer			: 
  
Comments						: ()
 
*************************************************************************************************/

namespace MMIE.DataAccess.Common
{
   public class ProductCategoryDA:DataAccessObjectBase
    {
        public bool SaveProductCategory(ProductCategory objProductCategory)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[9];
                arParms[0] = new SqlParameter("@ProductCategoryID", SqlDbType.Int);
                arParms[0].Value = objProductCategory.ProductCategoryID;
                arParms[1] = new SqlParameter("@ProductCategoryName", SqlDbType.VarChar);
                arParms[1].Value = objProductCategory.ProductCategoryName;
                arParms[2] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[2].Value = objProductCategory.AddedBy;
                arParms[3] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[3].Value = objProductCategory.LastModBy;
                arParms[4] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[4].Value = objProductCategory.IsActive;

                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[5].Value = objProductCategory.FinancialYearID;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objProductCategory.CompanyID;

                arParms[7] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[7].Value = objProductCategory.ActionType;
                arParms[8] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[8].Value = objProductCategory.GroupID;
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateProductCategoryMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        //-------------------

        //----------------------------------------------------------------

        public List<ProductCategory> GetProductCategoryList(bool All)
        {
            List<ProductCategory> lstProductCategory = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ActionType", SqlDbType.Bit);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetProductCategoryList", arParms);
                lstProductCategory = ORHelper<ProductCategory>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstProductCategory;
        }

        //----------------------------------------------------------------
        public ProductCategory GetProductCategoryByID(int ID)
        {
            ProductCategory objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ProductCategoryID", SqlDbType.Int);
                arParms[0].Value = ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "ProductCategory", ds, new string[] { "[usp_GetProductCategoryByID]" }, arParms);
                objRetCustomer = ORHelper<ProductCategory>.FromDataTable(ds.Tables["ProductCategory"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }


       // added by ankit 
        public List<ProductCategory> GetSearchProductCategory(ProductCategory CatogoryList)
        {
            List<ProductCategory> lstProductCategory = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[3];

                arParms[0] = new SqlParameter("@ProductCategoryName", SqlDbType.VarChar);
                arParms[0].Value = CatogoryList.ProductCategoryName;
                arParms[1] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[1].Value = CatogoryList.IsActive;
                arParms[2] = new SqlParameter("@GroupID", SqlDbType.Int);
                arParms[2].Value = CatogoryList.GroupID;



                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSearchProductCategoryList", arParms);
                lstProductCategory = ORHelper<ProductCategory>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstProductCategory;
        }

    }
}
