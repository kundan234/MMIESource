﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;


/*************************************************************************************************  
  
Name of the Class			    : TaxDA                      
  
Description of the class	    : 
  
Created Date					: 24 November 2011  
  
Developer						: Kundan Singh
  
Modify Date					: 24/11/2011  
  
Modified By Developer			: 
  
Comments						: ()
 
*************************************************************************************************/

namespace MMIE.DataAccess.Common
{
 public     class RemarksDA:DataAccessObjectBase
    {
      
  
        public bool SaveRemarks(Remarks objRemarks)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[10];
                arParms[0] = new SqlParameter("@RemarksID", SqlDbType.Int);
                arParms[0].Value = objRemarks.RemarksID;
                arParms[1] = new SqlParameter("@RemarksType", SqlDbType.VarChar);
                arParms[1].Value = objRemarks.RemarksType;

                arParms[2] = new SqlParameter("@RemarksDetails", SqlDbType.VarChar);
                arParms[2].Value = objRemarks.RemarksDetails;
               
                
                arParms[3] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[3].Value = objRemarks.AddedBy;
                arParms[4] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[4].Value = objRemarks.LastModBy;

                arParms[5] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[5].Value = objRemarks.IsActive;
                
                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objRemarks.CompanyID;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[7].Value = objRemarks.FinancialYearID;
                arParms[8] = new SqlParameter("@CustomerType", SqlDbType.VarChar);
                arParms[8].Value = objRemarks.CustomerType;
                arParms[9] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[9].Value = objRemarks.ActionType;
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateRemarksMST]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        //----------------------
        //---------------------------payroll tax----
        public List<Remarks> GetRemarksList(bool All)
        {
            List<Remarks> lstObject = null;
            try
            {
 

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetRemarksList", arParms);
                lstObject = ORHelper<Remarks>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public Remarks GetRemarksByID(int ID)
        {
            Remarks objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@RemarksID", SqlDbType.Int);
                arParms[0].Value = ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "Remarks", ds, new string[] { "usp_GetRemarksList" }, arParms);
                objRetCustomer = ORHelper<Remarks>.FromDataTable(ds.Tables["RemarksMST"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }

        public Remarks GetRemarksBycustomertype(string paymentmode)
        {
            Remarks objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CustomerType", SqlDbType.VarChar);
                arParms[0].Value = paymentmode;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "Remarks", ds, new string[] { "usp_GetRemarksByCustomerType" }, arParms);
                objRetCustomer = ORHelper<Remarks>.FromDataTable(ds.Tables["RemarksMST"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }


        public List<Remarks> GetSearchRemarksList(Remarks objRemarks)
        {
            List<Remarks> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@RemarksType", SqlDbType.VarChar);
                arParms[0].Value = objRemarks.RemarksType;

                arParms[1] = new SqlParameter("@RemarksDetails", SqlDbType.VarChar);
                arParms[1].Value = objRemarks.RemarksDetails;


                arParms[2] = new SqlParameter("@CustomerType", SqlDbType.VarChar);
                arParms[2].Value = objRemarks.CustomerType;


                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[3].Value = objRemarks.IsActive;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[Usp_GetSearchRemarks]", arParms);
                lstObject = ORHelper<Remarks>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

    }
}
