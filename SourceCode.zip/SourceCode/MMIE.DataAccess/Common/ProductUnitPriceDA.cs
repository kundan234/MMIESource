﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;
namespace MMIE.DataAccess.Common
{
 public   class ProductUnitPriceDA:DataAccessObjectBase
    {
     public List<Product> SearchProductUnitList(Product objProduct)
     {
         List<Product> lstObject = null;
         try
         {

             SqlParameter[] arParms = new SqlParameter[4];
             arParms[0] = new SqlParameter("@ProductID", SqlDbType.Int);
             arParms[0].Value = objProduct.ProductID;
             arParms[1] = new SqlParameter("@UnitId", SqlDbType.Int);
             arParms[1].Value = objProduct.UnitId;
             arParms[2] = new SqlParameter("@CustomerID", SqlDbType.Int);
             arParms[2].Value = objProduct.CustomerID;
             arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
             arParms[3].Value = objProduct.IsActive;


             SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSearchProductRateList", arParms);
             lstObject = ORHelper<Product>.FromDataReaderToList(dataReader);
             dataReader.Close();

         }
         catch (Exception ex) //Exception of the layer(itself)/unhandle
         {
             PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
             LogManager.WriteErrorLogInDB(ex);
             throw new DataAccessException("5000001", ex);
         }

         return lstObject;
     }


     public Product GetProductUnitByID(Product objProduct)
     {
         Product objRetProduct = null;
         try
         {
             SqlParameter[] arParms = new SqlParameter[2];
             arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
             arParms[0].Value = objProduct.CustomerID;
             arParms[1] = new SqlParameter("@ProductPriceID", SqlDbType.Int);
             arParms[1].Value = objProduct.ProductPriceID;
     

             DataSet ds = new DataSet();
             SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSearchProductRateByID", ds, new string[] { "ProductPrice" }, arParms);
             objRetProduct = ORHelper<Product>.FromDataTable(ds.Tables["ProductPrice"]);

         }
         catch (Exception ex) //Exception of the layer(itself)/unhandle
         {
             PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
             LogManager.WriteErrorLogInDB(ex);
             throw new DataAccessException("5000001", ex);
         }

         return objRetProduct;
     }
    }
}
