﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;

/*************************************************************************************************  
  
Name of the Class			    : TaxDA                      
  
Description of the class	    : 
  
Created Date					: 24 November 2011  
  
Developer						: Kundan Singh
  
Modify Date					: 24/11/2011  
  
Modified By Developer			: 
  
Comments						: ()
 
*************************************************************************************************/

namespace MMIE.DataAccess.Common
{
    public class BillHeaderDetailsDA : DataAccessObjectBase
    {


        public List<Order> GetSearchBillHeader(Order objBill)
        {
            List<Order> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[5];
                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objBill.OrderNumber;
                arParms[1] = new SqlParameter("@BillHeaderID", SqlDbType.VarChar);
                arParms[1].Value = objBill.BillHeaderID;
                arParms[2] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[2].Value = objBill.CustomerName;
                arParms[3] = new SqlParameter("@CustomerPhone", SqlDbType.VarChar);
                arParms[3].Value = objBill.CustomerPhone;
                arParms[4] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[4].Value = objBill.IsActive;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchBillDetail", arParms);
                lstObject = ORHelper<Order>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }

            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;

        }
        public List<Order> GetSearchOrderDetails(Order objBill)
        {
            List<Order> lstObject = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[3];
                arParms[0] = new SqlParameter("@OrderNumber", SqlDbType.VarChar);
                arParms[0].Value = objBill.OrderNumber;
                arParms[1] = new SqlParameter("@BillHeaderID", SqlDbType.VarChar);
                arParms[1].Value = objBill.BillHeaderID;               
                arParms[2] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[2].Value = objBill.IsActive;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SAL_GetSearchOrderHeaderDetails", arParms);
                lstObject = ORHelper<Order>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }

            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;

        }
    

    }
}
