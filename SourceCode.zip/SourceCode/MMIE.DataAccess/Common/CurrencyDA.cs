﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;


namespace MMIE.DataAccess.Common
{
    public class CurrencyDA : DataAccessObjectBase
    {
        #region Currency
        //-------------------save Product detail-----------------------

        public bool SaveCurrency(Currency objCurrency)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[10];

                arParms[0] = new SqlParameter("@CurrencyID", SqlDbType.VarChar);
                arParms[0].Value = objCurrency.CurrencyID;
                arParms[1] = new SqlParameter("@BaseFormat", SqlDbType.VarChar);
                arParms[1].Value = objCurrency.BaseFormat;
                arParms[2] = new SqlParameter("@ConvertTO", SqlDbType.VarChar);
                arParms[2].Value = objCurrency.ConvertTO;
                arParms[3] = new SqlParameter("@Rate", SqlDbType.Money);
                arParms[3].Value = objCurrency.Rate;
                arParms[4] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[4].Value = objCurrency.IsActive;
                arParms[5] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[5].Value = objCurrency.AddedBy;
                arParms[6] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[6].Value = objCurrency.LastModBy;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[7].Value = objCurrency.FinancialYearID;

                arParms[8] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[8].Value = objCurrency.CompanyID;
                arParms[9] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[9].Value = objCurrency.ActionType;
                


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateCurrencyMST]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        public bool SavePurchaseCurrencyMST(Currency objCurrency)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[10];

                arParms[0] = new SqlParameter("@CurrencyID", SqlDbType.VarChar);
                arParms[0].Value = objCurrency.CurrencyID;
                arParms[1] = new SqlParameter("@BaseFormat", SqlDbType.VarChar);
                arParms[1].Value = objCurrency.BaseFormat;
                arParms[2] = new SqlParameter("@ConvertTO", SqlDbType.VarChar);
                arParms[2].Value = objCurrency.ConvertTO;
                arParms[3] = new SqlParameter("@Rate", SqlDbType.Money);
                arParms[3].Value = objCurrency.Rate;
                arParms[4] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[4].Value = objCurrency.IsActive;
                arParms[5] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[5].Value = objCurrency.AddedBy;
                arParms[6] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[6].Value = objCurrency.LastModBy;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[7].Value = objCurrency.FinancialYearID;

                arParms[8] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[8].Value = objCurrency.CompanyID;
                arParms[9] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[9].Value = objCurrency.ActionType;



                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdatePurchaseCurrencyMST]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        //-------------------
        public Currency GetCurrencyByID(int ID)
        {
            Currency objRetCurrency = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[0].Value = ID;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCurrencyByID", ds, new string[] { "Currency" }, arParms);
                objRetCurrency = ORHelper<Currency>.FromDataTable(ds.Tables["Currency"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCurrency;
        }

        public List<Currency> GetCurrencyList(bool All)
        {
            List<Currency> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ActionType",SqlDbType.Bit);
                if(All)
                arParms[0].Value =1 ;
                else
                    arParms[0].Value = 2;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCurrencyList", arParms);
                lstObject = ORHelper<Currency>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Currency> GetPurchaseCurrencyList(bool All)
        {
            List<Currency> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ActionType", SqlDbType.Bit);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetPurchaseCurrencyList", arParms);
                lstObject = ORHelper<Currency>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

      
      

        #endregion

    }
}
