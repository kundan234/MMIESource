﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;


/*************************************************************************************************  
  
  Name of the Class			    : DepositTransactionDA
  
  Description of the class	    : 
  
  Created Date					: 17 NOV 2011  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: Kundan Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.DataAccess.Common
{
    public class DepositTransactionDA : DataAccessObjectBase
    {

        #region Deposit Transaction
        //-------------------save Product detail-----------------------

        public bool SaveTransaction(DepositTransaction objDepositTransaction)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[16];

                arParms[0] = new SqlParameter("@DepositID", SqlDbType.Int);
                arParms[0].Value = objDepositTransaction.DepositID;

                arParms[1] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[1].Value = objDepositTransaction.CustomerID;

                arParms[2] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[2].Value = objDepositTransaction.TType;

                arParms[3] = new SqlParameter("@Rate", SqlDbType.Money);
                arParms[3].Value = objDepositTransaction.Rate;

                arParms[4] = new SqlParameter("@AmountUSD", SqlDbType.Money);
                arParms[4].Value = objDepositTransaction.AmountUSD;

                arParms[5] = new SqlParameter("@ClosingAmountUSD", SqlDbType.Money);
                arParms[5].Value = objDepositTransaction.ClosingAmountUSD;

                arParms[6] = new SqlParameter("@Amount", SqlDbType.Money);
                arParms[6].Value = objDepositTransaction.Amount;

                arParms[7] = new SqlParameter("@ClosingAmount", SqlDbType.Money);
                arParms[7].Value = objDepositTransaction.ClosingAmount;
                

                arParms[8] = new SqlParameter("@TransactionDate", SqlDbType.Date);
                arParms[8].Value = objDepositTransaction.TransactionDate;

                arParms[9] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[9].Value = objDepositTransaction.FinancialYearID;

                arParms[10] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[10].Value = objDepositTransaction.CompanyID;

                arParms[11] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[11].Value = objDepositTransaction.IsActive;

                arParms[12] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[12].Value = objDepositTransaction.AddedBy;

                arParms[13] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[13].Value = objDepositTransaction.LastModBy;

                arParms[14] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[14].Value = objDepositTransaction.Remarks;


                arParms[15] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[15].Value = objDepositTransaction.ActionType;



                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateDepositTransaction]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        public int CreditAmount(DepositTransaction objDepositTransaction)
        {
            int status = 0;
            try
            {

                SqlParameter[] arParms = new SqlParameter[16];

 
                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = objDepositTransaction.CustomerID;

                arParms[1] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[1].Value = "CR";

                arParms[2] = new SqlParameter("@Rate", SqlDbType.Money);
                arParms[2].Value = objDepositTransaction.Rate;

                arParms[3] = new SqlParameter("@AmountUSD", SqlDbType.Money);
                arParms[3].Value = objDepositTransaction.AmountUSD;

                

                arParms[4] = new SqlParameter("@Amount", SqlDbType.Money);
                arParms[4].Value = objDepositTransaction.Amount;

                
                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[5].Value = objDepositTransaction.FinancialYearID;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objDepositTransaction.CompanyID;

                arParms[7] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[7].Value = 1;

                arParms[8] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[8].Value = objDepositTransaction.AddedBy;

                arParms[9] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[9].Value = objDepositTransaction.LastModBy;

                arParms[10] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[10].Value = objDepositTransaction.Remarks;


                arParms[11] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[11].Value = 1;
                arParms[12] = new SqlParameter("@Result", SqlDbType.Int);
                arParms[12].Direction = ParameterDirection.Output;

                arParms[13] = new SqlParameter("@OrderNo", SqlDbType.VarChar);
                arParms[13].Value = objDepositTransaction.OrderNo;

                arParms[14] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[14].Value = objDepositTransaction.CurrencyID;

                arParms[15] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[15].Value = objDepositTransaction.PaymentMode;


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateDepositTransactionBalance]", arParms);
                if (noOfEffectedRecords > 0)
                  //  status = true;
                    status = Convert.ToInt32(arParms[12].Value.ToString());

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        public int DebitAmount(DepositTransaction objDepositTransaction)
        {
            int status = 0;
            try
            {

                SqlParameter[] arParms = new SqlParameter[16];


                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = objDepositTransaction.CustomerID;

                arParms[1] = new SqlParameter("@TType", SqlDbType.VarChar);
                arParms[1].Value = "DR";

                arParms[2] = new SqlParameter("@Rate", SqlDbType.Money);
                arParms[2].Value = objDepositTransaction.Rate;

                arParms[3] = new SqlParameter("@AmountUSD", SqlDbType.Money);
                arParms[3].Value = objDepositTransaction.AmountUSD;



                arParms[4] = new SqlParameter("@Amount", SqlDbType.Money);
                arParms[4].Value = objDepositTransaction.Amount;


                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[5].Value = objDepositTransaction.FinancialYearID;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objDepositTransaction.CompanyID;

                arParms[7] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[7].Value = 1;

                arParms[8] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[8].Value = objDepositTransaction.AddedBy;

                arParms[9] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[9].Value = objDepositTransaction.LastModBy;

                arParms[10] = new SqlParameter("@Remarks", SqlDbType.VarChar);
                arParms[10].Value = objDepositTransaction.Remarks;


                arParms[11] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[11].Value = 1;

                arParms[12] = new SqlParameter("@Result", SqlDbType.Int);
                arParms[12].Direction = ParameterDirection.Output;
                arParms[13] = new SqlParameter("@OrderNo", SqlDbType.VarChar);
                arParms[13].Value = objDepositTransaction.OrderNo;

                arParms[14] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[14].Value = objDepositTransaction.CurrencyID;

                arParms[15] = new SqlParameter("@PaymentMode", SqlDbType.VarChar);
                arParms[15].Value = objDepositTransaction.PaymentMode;
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateDepositTransactionBalance]", arParms);
                if (noOfEffectedRecords > 0)
                   // status = true;
                    status = Convert.ToInt32(arParms[12].Value.ToString());

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        //-------------------
        public DepositTransaction GetDepositTransactionByID(int ID)
        {
            DepositTransaction objRetCurrency = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CurrencyID", SqlDbType.Int);
                arParms[0].Value = ID;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCurrencyByID", ds, new string[] { "Product" }, arParms);
                objRetCurrency = ORHelper<DepositTransaction>.FromDataTable(ds.Tables["DepositTransaction"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCurrency;
        }

        public List<DepositTransaction> GetDepositTransactionList(int ID)
        {
            List<DepositTransaction> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = ID;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetDepositListByCustomerID", arParms);
                lstObject = ORHelper<DepositTransaction>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }




        #endregion





    }
}
