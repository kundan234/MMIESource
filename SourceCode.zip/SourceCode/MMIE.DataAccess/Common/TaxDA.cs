﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;


/*************************************************************************************************  
  
Name of the Class			    : TaxDA                      
  
Description of the class	    : 
  
Created Date					: 24 November 2011  
  
Developer						: Kundan Singh
  
Modify Date					: 24/11/2011  
  
Modified By Developer			: 
  
Comments						: ()
 
*************************************************************************************************/


namespace MMIE.DataAccess.Common
{
    [Serializable]
    public class TaxDA:DataAccessObjectBase
    {

        public bool SaveTax(Tax objTax)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[9];
                arParms[0] = new SqlParameter("@TaxID", SqlDbType.Int);
                arParms[0].Value = objTax.TaxID;
                arParms[1] = new SqlParameter("@TaxName", SqlDbType.VarChar);
                arParms[1].Value = objTax.TaxName;
                arParms[2] = new SqlParameter("@TaxRate", SqlDbType.Money);
                arParms[2].Value = objTax.TaxRate;
                arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[3].Value = objTax.IsActive;
                
                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objTax.AddedBy;

                arParms[5] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[5].Value = objTax.LastModBy;
                arParms[6] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[6].Value = objTax.FinancialYearID;
                arParms[7] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[7].Value = objTax.CompanyID;
                arParms[8] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[8].Value = objTax.ActionType;
                
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateTaxMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
     
        //----------------------------------------------------------------

        public List<Tax> GetTaxList(bool All)
        {
            List<Tax> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
               if(All)
                arParms[0].Value = 1;
               else
                   arParms[0].Value = 2;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetTaxMSTList", arParms);
                lstObject = ORHelper<Tax>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        //----------------------------------------------------------------
        public Tax GetTaxByID(int ID)
        {
            Tax objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@TaxID", SqlDbType.Int);
                arParms[0].Value =ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "ups_GetTaxByID", ds, new string[] { "TaxMST" }, arParms);
                objRetCustomer = ORHelper<Tax>.FromDataTable(ds.Tables["TaxMST"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }
        //-------------save payroll tax-----------------
        public bool SaveRangeTax(Tax objTax)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[10];
                arParms[0] = new SqlParameter("@TaxID", SqlDbType.Int);
                arParms[0].Value = objTax.TaxID;
                arParms[1] = new SqlParameter("@FromRange", SqlDbType.VarChar);
                arParms[1].Value = objTax.FromRange;
                arParms[2] = new SqlParameter("@ToRange", SqlDbType.Money);
                arParms[2].Value = objTax.ToRange;
                arParms[3] = new SqlParameter("@TaxAmount", SqlDbType.Money);
                arParms[3].Value = objTax.TaxAmount;
                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objTax.AddedBy;
                arParms[5] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[5].Value = objTax.LastModBy;
                arParms[6] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[6].Value = objTax.ActionType;
                arParms[7] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[7].Value = objTax.IsActive;
                arParms[8] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[8].Value = objTax.CompanyID;
                arParms[9] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[9].Value = objTax.FinancialYearID;
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_UpdateTaxMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        //----------------------
        //-------------save payroll other tax-----------------
        public bool SaveOtherTax(Tax objTax)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[9];
                arParms[0] = new SqlParameter("@TaxID", SqlDbType.Int);
                arParms[0].Value = objTax.TaxID;
                arParms[1] = new SqlParameter("@TaxName", SqlDbType.VarChar);
                arParms[1].Value = objTax.TaxName;
                arParms[2] = new SqlParameter("@TaxRate", SqlDbType.Money);
                arParms[2].Value = objTax.TaxRate;
                arParms[3] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[3].Value = objTax.AddedBy;
                arParms[4] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[4].Value = objTax.LastModBy;
                
                arParms[5] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[5].Value = objTax.IsActive;
                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objTax.CompanyID;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[7].Value = objTax.FinancialYearID;
                arParms[8] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[8].Value = objTax.ActionType;
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_UpdateOtherTaxMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        //----------------------
        //---------------------------payroll tax----
        public List<Tax> SearchTax(bool All)
        {
            List<Tax> lstObject = null;
            try
            {

                //SqlParameter[] arParms = new SqlParameter[2];

                //arParms[0] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                //arParms[0].Value = objTax.CurrentIndex;

                //arParms[1] = new SqlParameter("@PageSize", SqlDbType.Int);
                //arParms[1].Value = objTax.PageSize;

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_GetTaxDetail", arParms);
                lstObject = ORHelper<Tax>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }
        public List<Tax> SearchOtherTax(bool All)
        {
            List<Tax> lstObject = null;
            try
            {

                //SqlParameter[] arParms = new SqlParameter[2];

                //arParms[0] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                //arParms[0].Value = objTax.CurrentIndex;

                //arParms[1] = new SqlParameter("@PageSize", SqlDbType.Int);
                //arParms[1].Value = objTax.PageSize;

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_PRL_GetOtherTaxDetail", arParms);
                lstObject = ORHelper<Tax>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }


        //-----------

    }
}
