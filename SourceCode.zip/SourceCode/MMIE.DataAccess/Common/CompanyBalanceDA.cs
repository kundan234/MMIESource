﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;

/*************************************************************************************************  
  
Name of the Class			    : TaxDA                      
  
Description of the class	    : 
  
Created Date					: 24 November 2011  
  
Developer						: Kundan Singh
  
Modify Date					: 24/11/2011  
  
Modified By Developer			: 
  
Comments						: ()
 
*************************************************************************************************/
namespace MMIE.DataAccess.Common
{
   public class CompanyBalanceDA:DataAccessObjectBase
    {

       public List<CompanyBalance> GetSearchCompanyBalanceList(CompanyBalance objCompanyCurrency)
       {
           List<CompanyBalance> lstObject = null;
           try
           {

               SqlParameter[] arParms = new SqlParameter[2];

               arParms[0] = new SqlParameter("@BranchID", SqlDbType.Int);
               arParms[0].Value = objCompanyCurrency.BranchID;
               arParms[1] = new SqlParameter("@CurrencyID", SqlDbType.Int);
               arParms[1].Value = objCompanyCurrency.CurrencyID;


               SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSearchBalanceMST", arParms);
               lstObject = ORHelper<CompanyBalance>.FromDataReaderToList(dataReader);
               dataReader.Close();

           }

           catch (Exception ex) //Exception of the layer(itself)/unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
               LogManager.WriteErrorLogInDB(ex);
               throw new DataAccessException("5000001", ex);
           }

           return lstObject;

       }
       public CompanyBalance GetCompanyBalanceStatus(CompanyBalance objBalance)
       {
           CompanyBalance objRetProduct = null;
           try
           {
               SqlParameter[] arParms = new SqlParameter[3];
               arParms[0] = new SqlParameter("@BranchID", SqlDbType.Int);
               arParms[0].Value = objBalance.BranchID;

               arParms[1] = new SqlParameter("@CurrencyID", SqlDbType.Int);
               arParms[1].Value = objBalance.CurrencyID;
               arParms[2] = new SqlParameter("@PaymentSourceID", SqlDbType.Int);
               arParms[2].Value = objBalance.PaymentSourceID;

               DataSet ds = new DataSet();
               SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_PMT_GetSearchCompanyBalanceStatus]", ds, new string[] { "CompanyBalanceStatus" }, arParms);
               objRetProduct = ORHelper<CompanyBalance>.FromDataTable(ds.Tables["CompanyBalanceStatus"]);

           }
           catch (Exception ex) //Exception of the layer(itself)/unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
               LogManager.WriteErrorLogInDB(ex);
               throw new DataAccessException("5000001", ex);
           }

           return objRetProduct;
       }


       public bool SaveCompanyBalanceDetails(CompanyBalance objPaymentDetails)
       {
           bool status = false;
           try
           {

               SqlParameter[] arParms = new SqlParameter[11];

               arParms[0] = new SqlParameter("@CompanyBalanceID", SqlDbType.Int);
               arParms[0].Value = objPaymentDetails.CompanyBalanceID;

               arParms[1] = new SqlParameter("@PaymentSourceID", SqlDbType.Int);
               arParms[1].Value = objPaymentDetails.PaymentSourceID;


               arParms[2] = new SqlParameter("@CompanyBalanceAmount", SqlDbType.Money);
               arParms[2].Value = objPaymentDetails.CompanyBalanceAmount;


               arParms[3] = new SqlParameter("@BranchID", SqlDbType.SmallInt);
               arParms[3].Value = objPaymentDetails.BranchID;

                            
               

               arParms[4] = new SqlParameter("@IsActive", SqlDbType.Bit);
               arParms[4].Value = objPaymentDetails.IsActive;


               arParms[5] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
               arParms[5].Value = objPaymentDetails.AddedBy;

               arParms[6] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
               arParms[6].Value = objPaymentDetails.LastModBy;

               arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.SmallInt);
               arParms[7].Value = objPaymentDetails.FinancialYearID;

               arParms[8] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
               arParms[8].Value = objPaymentDetails.CompanyID;


               arParms[9] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
               arParms[9].Value = objPaymentDetails.ActionType;



               arParms[10] = new SqlParameter("@CurrencyID", SqlDbType.Int);
               arParms[10].Value = objPaymentDetails.CurrencyID;

               int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateCompanyBalanceMST]", arParms);
               if (noOfEffectedRecords > 0)
                   status = true;

           }
           catch (Exception ex) //Exception of the layer(itself)/unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
               LogManager.WriteErrorLogInDB(ex);
               throw new DataAccessException("5000001", ex);
           }

           return status;
       }

    }
}
