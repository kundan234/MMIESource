﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;



/*************************************************************************************************  
  
  Name of the Class			    : OtherChargesDA                      
  
  Description of the class	    : 
  
  Created Date					: 30th Nov 2011  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 30/11/2010  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.DataAccess.Common
{
    public class OtherChargesDA
    {
        #region OtherCharges
        //-------------------save Product detail-----------------------

        public bool SaveOtherCharges( OtherCharges objOtherCharges)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[9];

                arParms[0] = new SqlParameter("@ChargeID", SqlDbType.Int);
                arParms[0].Value = objOtherCharges.ChargeID;
                arParms[1] = new SqlParameter("@ChargeName", SqlDbType.VarChar);
                arParms[1].Value = objOtherCharges.ChargeName;
                arParms[2] = new SqlParameter("@ChargeRate", SqlDbType.Money);
                arParms[2].Value = objOtherCharges.ChargeRate;

                arParms[3] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[3].Value = objOtherCharges.AddedBy;

                arParms[4] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[4].Value = objOtherCharges.LastModBy;
                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[5].Value = objOtherCharges.FinancialYearID;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objOtherCharges.CompanyID;


                arParms[7] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[7].Value = objOtherCharges.IsActive;

                arParms[8] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[8].Value = objOtherCharges.ActionType;



                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateOtherChargesMST]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        public OtherCharges GetAccountGroupTypeByID(int ID)
        {
            OtherCharges objOtherCharge = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ChargeID", SqlDbType.Int);
                arParms[0].Value = ID;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSearchCharge", ds, new string[] { "OtherCharge" }, arParms);
                objOtherCharge = ORHelper<OtherCharges>.FromDataTable(ds.Tables["OtherCharge"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objOtherCharge;
        }

        public List<OtherCharges> GetSearchOtherCharges(OtherCharges objOtherCharges)
        {
            List<OtherCharges> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[3];
                arParms[0] = new SqlParameter("@ChargeID", SqlDbType.Int);
                arParms[0].Value = objOtherCharges.ChargeID;

                arParms[1] = new SqlParameter("@ChargeName", SqlDbType.VarChar);
                arParms[1].Value = objOtherCharges.ChargeName;

                arParms[2] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[2].Value = objOtherCharges.IsActive;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSearchCharge", arParms);
                lstObject = ORHelper<OtherCharges>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

       


        #endregion



    }
}
