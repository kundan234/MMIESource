﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;

namespace MMIE.DataAccess.Common
{
    /*************************************************************************************************  
  
  Name of the Class			    : ProductDA                      
  
  Description of the class	    : 
  
  Created Date					: 20 October 2011  
  
  Developer						: Mithlesh
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


    public class ProductDA : DataAccessObjectBase
    {
        #region Product
        //-------------------save Product detail-----------------------

        public bool SaveProduct(Product objProduct)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[21];

                arParms[0] = new SqlParameter("@ProductName", SqlDbType.VarChar);
                arParms[0].Value = objProduct.ProductName;
                arParms[1] = new SqlParameter("@ReferenceName", SqlDbType.VarChar);
                arParms[1].Value = objProduct.ReferenceName;
                arParms[2] = new SqlParameter("@Model", SqlDbType.VarChar);
                arParms[2].Value = objProduct.Model;
                arParms[3] = new SqlParameter("@Color", SqlDbType.VarChar);
                arParms[3].Value = objProduct.Color;
                arParms[4] = new SqlParameter("@Descriptions", SqlDbType.VarChar);
                arParms[4].Value = objProduct.Descriptions;
                arParms[5] = new SqlParameter("@VehicalPower", SqlDbType.VarChar);
                arParms[5].Value = objProduct.VehicalPower;
                //arParms[5] = new SqlParameter("@Unit", SqlDbType.Int);
                //arParms[5].Value = objProduct.Unit;
                arParms[6] = new SqlParameter("@ProductImg", SqlDbType.VarChar);
                arParms[6].Value = objProduct.ProductImg;

                //-------------------old code-----------------
                arParms[7] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[7].Value = objProduct.CompanyID;
                arParms[8] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[8].Value = objProduct.AddedBy;
                arParms[9] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[9].Value = objProduct.LastModBy;
                arParms[10] = new SqlParameter("@GroupType", SqlDbType.Int);
                arParms[10].Value = objProduct.GroupType;
                arParms[11] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[11].Value = objProduct.ActionType;
                arParms[12] = new SqlParameter("@ProductId", SqlDbType.Int);
                arParms[12].Value = objProduct.ProductID;
                arParms[13] = new SqlParameter("@StatusType", SqlDbType.Bit);
                arParms[13].Value = objProduct.StatusType;
                arParms[14] = new SqlParameter("@Taxable", SqlDbType.Bit);
                arParms[14].Value = objProduct.Taxable;
                arParms[15] = new SqlParameter("@ApplyDeliveryCharges", SqlDbType.Bit);
                arParms[15].Value = objProduct.ApplyDeliveryCharges;
                arParms[16] = new SqlParameter("@CategoryID", SqlDbType.SmallInt);
                arParms[16].Value = objProduct.CategoryID;

                arParms[17] = new SqlParameter("@InsertXML", SqlDbType.Xml);
                arParms[17].Value = objProduct.InsertXML;
                arParms[18] = new SqlParameter("@UpdateXML", SqlDbType.Xml);
                arParms[18].Value = objProduct.UpdateXML;
                //arParms[19] = new SqlParameter("@Dealer", SqlDbType.Money);
                //arParms[19].Value = objProduct.Dealer;
                //arParms[20] = new SqlParameter("@CreditRate", SqlDbType.Money);
                //arParms[20].Value = objProduct.CreditRate;

                //arParms[17] = new SqlParameter("@Retailer1", SqlDbType.Money);
                //arParms[17].Value = objProduct.Retailer1;
                //arParms[18] = new SqlParameter("@Retailer2", SqlDbType.Money);
                //arParms[18].Value = objProduct.Retailer2;
                //arParms[19] = new SqlParameter("@Dealer", SqlDbType.Money);
                //arParms[19].Value = objProduct.Dealer;
                //arParms[20] = new SqlParameter("@CreditRate", SqlDbType.Money);
                //arParms[20].Value = objProduct.CreditRate;


                arParms[19] = new SqlParameter("@CylendorNo", SqlDbType.Int);
                arParms[19].Value = objProduct.CylendorNo;
                arParms[20] = new SqlParameter("@FuelType", SqlDbType.VarChar);
                arParms[20].Value = objProduct.FuelType;
                
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateProductMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        //-------------------
        public Product GetProductByID(Product objProduct)
        {
            Product objRetProduct = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[0].Value = objProduct.ProductID;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetProductByID", ds, new string[] { "Product" }, arParms);
                objRetProduct = ORHelper<Product>.FromDataTable(ds.Tables["Product"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetProduct;
        }

        //public Product GetProductEntryByID(Product objProduct)
        //{
        //    Product objRetProduct = null;
        //    try
        //    {
        //        SqlParameter[] arParms = new SqlParameter[1];
        //        arParms[0] = new SqlParameter("@ProductID", SqlDbType.Int);
        //        arParms[0].Value = objProduct.ProductID;

        //        DataSet ds = new DataSet();
        //        SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetProductEntryByID", ds, new string[] { "Product" }, arParms);
        //        objRetProduct = ORHelper<Product>.FromDataTable(ds.Tables["Product"]);

        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new DataAccessException("5000001", ex);
        //    }

        //    return objRetProduct;
        //}

        public List<Product> SearchProduct(Product objProduct)
        {
            List<Product> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[6];
                arParms[0] = new SqlParameter("@Grouptype", SqlDbType.Int);
                arParms[0].Value = objProduct.GroupType;
                arParms[1] = new SqlParameter("@ProductName", SqlDbType.VarChar);
                arParms[1].Value = objProduct.ProductName;
                arParms[2] = new SqlParameter("@ReferenceName", SqlDbType.VarChar);
                arParms[2].Value = objProduct.ReferenceName;
                arParms[3] = new SqlParameter("@Model", SqlDbType.VarChar);
                arParms[3].Value = objProduct.Model;
                arParms[4] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                arParms[4].Value = objProduct.CurrentIndex;
                arParms[5] = new SqlParameter("@PageSize", SqlDbType.Int);
                arParms[5].Value = objProduct.PageSize;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetProduct", arParms);
                lstObject = ORHelper<Product>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public bool DeleteProduct(Product objProduct)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[0].Value = objProduct.ProductID;

                //arParms[1] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                //arParms[1].Value = objProduct.LastModBy;

                //arParms[2] = new SqlParameter("@ActionType", SqlDbType.Int);
                //arParms[2].Value = objProduct.ActionType;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_DeleteProduct", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        #endregion
    }
}
