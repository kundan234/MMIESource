﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;

namespace MMIE.DataAccess.Common
{
    /*************************************************************************************************  
  
  Name of the Class			    : StoreDA                      
  
  Description of the class	    : 
  
  Created Date					: 19 October 2011  
  
  Developer						: Mithlesh
  
  Modify Date					: 19/10/2011  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


    public class StoreDA : DataAccessObjectBase
    {
        #region Store
        //-------------------save Store detail-----------------------

        public int SaveStore(Store objStore)
        {
            int  status = 0;
            try
            {

                SqlParameter[] arParms = new SqlParameter[31];
               
                arParms[0] = new SqlParameter("@StoreName", SqlDbType.VarChar);
                arParms[0].Value = objStore.StoreName;
                arParms[1] = new SqlParameter("@StoreTypeID", SqlDbType.Int);
                arParms[1].Value = objStore.StoreTypeID;
                arParms[2] = new SqlParameter("@StoreAddress", SqlDbType.VarChar);
                arParms[2].Value = objStore.StoreAddress;
                arParms[3] = new SqlParameter("@StoreStreet", SqlDbType.VarChar);
                arParms[3].Value = objStore.StoreStreet;
                arParms[4] = new SqlParameter("@StoreCityID", SqlDbType.Int);
                arParms[4].Value = objStore.StoreCityID;
                arParms[5] = new SqlParameter("@StoreCountryId", SqlDbType.Int);
                arParms[5].Value = objStore.StoreCountryID;
                arParms[6] = new SqlParameter("@StorePhone", SqlDbType.VarChar);
                arParms[6].Value = objStore.StorePhone;
                arParms[7] = new SqlParameter("@StoreMobile", SqlDbType.VarChar);
                arParms[7].Value = objStore.StoreMobile;
                arParms[8] = new SqlParameter("@StoreFax", SqlDbType.VarChar);
                arParms[8].Value = objStore.StoreFax;
                arParms[9] = new SqlParameter("@StoreEmail", SqlDbType.VarChar);
                arParms[9].Value = objStore.StoreEmail;
                arParms[10] = new SqlParameter("@StoreWebsite", SqlDbType.VarChar);
                arParms[10].Value = objStore.StoreWebsite;
                arParms[11] = new SqlParameter("@StorePostal", SqlDbType.VarChar);
                arParms[11].Value = objStore.StorePostal;
                arParms[12] = new SqlParameter("@ContactPersonPostal", SqlDbType.VarChar);
                arParms[12].Value = objStore.ContactPersonPostal;
                arParms[13] = new SqlParameter("@ContactPersonName", SqlDbType.VarChar);
                arParms[13].Value = objStore.ContactPersonName;
                arParms[14] = new SqlParameter("@ContactPersonAddress", SqlDbType.VarChar);
                arParms[14].Value = objStore.ContactPersonAddress;
                arParms[15] = new SqlParameter("@ContactPersonStreet", SqlDbType.VarChar);
                arParms[15].Value = objStore.ContactPersonStreet;
                arParms[16] = new SqlParameter("@ContactPersonCityID", SqlDbType.Int);
                arParms[16].Value = objStore.ContactPersonCityID;
                arParms[17] = new SqlParameter("@ContactPersonCountryID", SqlDbType.Int);
                arParms[17].Value = objStore.ContactPersonCountryID;                
                arParms[18] = new SqlParameter("@ContactPersonMobile", SqlDbType.VarChar);
                arParms[18].Value = objStore.ContactPersonMobile;
                arParms[19] = new SqlParameter("@ContactPersonFax", SqlDbType.VarChar);
                arParms[19].Value = objStore.ContactPersonFax;
                arParms[20] = new SqlParameter("@ContactPersonEmail", SqlDbType.VarChar);
                arParms[20].Value = objStore.ContactPersonEmail;
                arParms[21] = new SqlParameter("@ContactPersonWebsite", SqlDbType.VarChar);
                arParms[21].Value = objStore.ContactPersonWebsite;                                    
                arParms[22] = new SqlParameter("@StoreDocID", SqlDbType.VarChar);
                arParms[22].Value = objStore.StoreDocID;
                arParms[23] = new SqlParameter("@StoreDocDetail", SqlDbType.VarChar);
                arParms[23].Value = objStore.StoreDocDetail;
                arParms[24] = new SqlParameter("@CompanyID", SqlDbType.SmallInt);
                arParms[24].Value = objStore.CompanyID;
                arParms[25] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[25].Value = objStore.AddedBy;
                arParms[26] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[26].Value = objStore.LastModBy;
                arParms[27] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[27].Value = objStore.ActionType;
                arParms[28] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[28].Value = objStore.StoreID;
                arParms[29] = new SqlParameter("@StatusType", SqlDbType.Bit);
                arParms[29].Value = objStore.StatusType;
                arParms[30] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[30].Direction = ParameterDirection.Output;


                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateStoreMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = int.Parse(arParms[30].Value.ToString());
                
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        //-------------------save Store Documents Details-----------------------

        public bool SaveStoreDocument(StoreDocument objStore)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[6];
                arParms[0] = new SqlParameter("@ScanID", SqlDbType.Int);
                arParms[0].Value = objStore.ScanID;
                arParms[1] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[1].Value = objStore.StoreID;
                arParms[2] = new SqlParameter("@StoreScanID", SqlDbType.VarChar);
                arParms[2].Value = objStore.StoreScanID;
                arParms[3] = new SqlParameter("@StoreDescription", SqlDbType.VarChar);
                arParms[3].Value = objStore.StoreDescription;
                arParms[4] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[4].Value = objStore.ActionType;
                arParms[5] = new SqlParameter("@FriendlyName", SqlDbType.VarChar);
                arParms[5].Value = objStore.FriendlyName;
             

                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateStoreDocument", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        //--------------------------------------------------------------
        public Store GetStoreByID(Store objStore)
        {
            Store objRetStore = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[0].Value = objStore.StoreID;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetStoreByID", ds, new string[] { "Store" }, arParms);
                objRetStore = ORHelper<Store>.FromDataTable(ds.Tables["Store"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetStore;
        }

        public List<StoreDocument> SearchStoreDocument(int id)
        {
            List<StoreDocument> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@StoreId", SqlDbType.SmallInt);
                arParms[0].Value = id;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetStoreDocumentByID", arParms);
                lstObject = ORHelper<StoreDocument>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Store> SearchStore(Store objStore)
        {
            List<Store> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@StoreId", SqlDbType.SmallInt  );
                arParms[0].Value = objStore.StoreID;

                arParms[1] = new SqlParameter("@StoreName", SqlDbType.VarChar);
                arParms[1].Value = objStore.StoreName;

                arParms[2] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                arParms[2].Value = objStore.CurrentIndex;

                arParms[3] = new SqlParameter("@PageSize", SqlDbType.Int);
                arParms[3].Value = objStore.PageSize;

             
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SearchStore", arParms);
                lstObject = ORHelper<Store>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public bool DeleteStore(Store objStore)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@StoreID", SqlDbType.Int);
                arParms[0].Value = objStore.StoreID;

                //arParms[1] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                //arParms[1].Value = objStore.LastModBy;

                //arParms[2] = new SqlParameter("@ActionType", SqlDbType.Int);
                //arParms[2].Value = objStore.ActionType;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_DeleteStore", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        #endregion

        //----------------------get countryname and zipcode by cityname -----------------------
        public Store GetCountryByName(Store objStore)
        {
            Store objRetStore = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@Cityname", SqlDbType.VarChar);
                arParms[0].Value = objStore.CityName;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SearchCity", ds, new string[] { "Cityname" }, arParms);
                objRetStore = ORHelper<Store>.FromDataTable(ds.Tables["Cityname"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetStore;
        }

    }
}
