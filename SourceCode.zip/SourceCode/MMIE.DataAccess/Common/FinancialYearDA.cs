﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;

/*************************************************************************************************  
  
Name of the Class			    : TaxDA                      
  
Description of the class	    : 
  
Created Date					: 24 November 2011  
  
Developer						: Kundan Singh
  
Modify Date					: 24/11/2011  
  
Modified By Developer			: 
  
Comments						: ()
 
*************************************************************************************************/
namespace MMIE.DataAccess.Common
{
  public     class FinancialYearDA:DataAccessObjectBase
    {

      public List<FinancialYear> GetSearchFiancialYear(FinancialYear objBill)
      {
          List<FinancialYear> lstObject = null;
          try
          {

              SqlParameter[] arParms = new SqlParameter[4];

              arParms[0] = new SqlParameter("@Name", SqlDbType.VarChar);
              arParms[0].Value = objBill.Name;
              arParms[1] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
              arParms[1].Value = objBill.FinancialYearID;

              arParms[2] = new SqlParameter("@Description", SqlDbType.VarChar);
              arParms[2].Value = objBill.Description;

              arParms[3] = new SqlParameter("@IsActive", SqlDbType.VarChar);
              arParms[3].Value = objBill.IsActive;


              SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_ADM_GetSearchFinancialYearMST]", arParms);
              lstObject = ORHelper<FinancialYear>.FromDataReaderToList(dataReader);
              dataReader.Close();

          }

          catch (Exception ex) //Exception of the layer(itself)/unhandle
          {
              PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
              LogManager.WriteErrorLogInDB(ex);
              throw new DataAccessException("5000001", ex);
          }

          return lstObject;

      }


      public bool UpdateFinancialYear(FinancialYear objFinancialYear)
      {
          bool status = false;
          try
          {

              SqlParameter[] arParms = new SqlParameter[8];

              arParms[0] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
              arParms[0].Value = objFinancialYear.FinancialYearID;

              arParms[1] = new SqlParameter("@Description", SqlDbType.VarChar);
              arParms[1].Value = objFinancialYear.Description;

              arParms[2] = new SqlParameter("@Name", SqlDbType.VarChar);
              arParms[2].Value = objFinancialYear.Name;

              arParms[3] = new SqlParameter("@IsActive", SqlDbType.Bit);
              arParms[3].Value = objFinancialYear.IsActive;


              arParms[4] = new SqlParameter("@ActionType", SqlDbType.Int);
              arParms[4].Value = objFinancialYear.ActionType;

        

              arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
              arParms[6].Value = objFinancialYear.CompanyID;

              arParms[7] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
              arParms[7].Value = objFinancialYear.AddedBy;

              arParms[5] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
              arParms[5].Value = objFinancialYear.LastModBy;





              int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_ADM_UpdateFinancialYear", arParms);
              if (noOfEffectedRecords > 0)
                  status = true;

          }
          catch (Exception ex) //Exception of the layer(itself)/unhandle
          {
              PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
              LogManager.WriteErrorLogInDB(ex);
              throw new DataAccessException("5000001", ex);
          }

          return status;
      }

    }
}
