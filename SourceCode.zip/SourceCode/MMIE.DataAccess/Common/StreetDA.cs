﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;

namespace MMIE.DataAccess.Common
{
    /*************************************************************************************************  
  
  Name of the Class			    : StoreDA                      
  
  Description of the class	    : 
  
  Created Date					: 19 October 2011  
  
  Developer						: Mithlesh
  
  Modify Date					: 19/10/2011  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


    public class StreetDA : DataAccessObjectBase
    {

        public Street GetStreetByName(Street objStreet)
        {
            Street objRetStreet = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@Streetname", SqlDbType.VarChar);
                arParms[0].Value = objStreet.StreetName;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SearchStreet", ds, new string[] { "Streetname" }, arParms);
                objRetStreet = ORHelper<Street>.FromDataTable(ds.Tables["Streetname"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetStreet;
        }

        public Street GetStreetDetailsByName(Street objStreet)
        {
            Street objRetStreet = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@StreetName", SqlDbType.VarChar);
                arParms[0].Value = objStreet.StreetName;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_GetStreetDetails", ds, new string[] { "StreetName" }, arParms);
                objRetStreet = ORHelper<Street>.FromDataTable(ds.Tables["StreetName"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetStreet;
        }

        public Street GetProductDetailsByName(Street objStreet)
        {
            Street objRetStreet = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ProductName", SqlDbType.VarChar);
                arParms[0].Value = objStreet.ProductName;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_GetProductDetails", ds, new string[] { "ProductName" }, arParms);
                objRetStreet = ORHelper<Street>.FromDataTable(ds.Tables["ProductName"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetStreet;
        }


        public bool SaveStreetCharge(Street objStreet)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[13];
                arParms[0] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[0].Value = objStreet.ID;
                arParms[1] = new SqlParameter("@StreetName", SqlDbType.VarChar);
                arParms[1].Value = objStreet.StreetName;
                arParms[2] = new SqlParameter("@StreetID", SqlDbType.Int);
                arParms[2].Value = objStreet.StreetID;
                arParms[3] = new SqlParameter("@ProductID", SqlDbType.Int);
                arParms[3].Value = objStreet.ProductID;
                arParms[4] = new SqlParameter("@Charge1", SqlDbType.Money);
                arParms[4].Value = objStreet.ChargePrice1;
                arParms[5] = new SqlParameter("@Charge2", SqlDbType.Money);
                arParms[5].Value = objStreet.ChargePrice2;
                arParms[6] = new SqlParameter("@charge3", SqlDbType.Money);
                arParms[6].Value = objStreet.ChargePrice3;
                arParms[7] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[7].Value = objStreet.IsActive;
                arParms[8] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[8].Value = objStreet.AddedBy;
                arParms[9] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[9].Value = objStreet.LastModBy;
                arParms[10] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[10].Value = objStreet.FinancialYearID;
                arParms[11] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[11].Value = objStreet.CompanyID;
                arParms[12] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[12].Value = objStreet.ActionType;

                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_UpdateStreetChargeMst", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        public List<Street> GerStreetChargeProductList()
        {
            List<Street> lstObject = null;
            try
            {
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "USP_GetStreetProductMSTList");
                lstObject = ORHelper<Street>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        public bool SaveStreet(Street objStreet)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[11];
                arParms[0] = new SqlParameter("@StreetID", SqlDbType.Int);
                arParms[0].Value = objStreet.StreetID;
                arParms[1] = new SqlParameter("@StreetName", SqlDbType.VarChar);
                arParms[1].Value = objStreet.StreetName;

                arParms[2] = new SqlParameter("@CityID", SqlDbType.Int);
                arParms[2].Value = objStreet.CityID;


                arParms[3] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[3].Value = objStreet.AddedBy;
                arParms[4] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[4].Value = objStreet.LastModBy;

                arParms[5] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[5].Value = objStreet.IsActive;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objStreet.CompanyID;
                arParms[7] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[7].Value = objStreet.FinancialYearID;
                arParms[8] = new SqlParameter("@StateCode", SqlDbType.VarChar);
                arParms[8].Value = objStreet.StateCode;

                arParms[9] = new SqlParameter("@CountryID", SqlDbType.Int);
                arParms[9].Value = objStreet.CountryID;


                arParms[10] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[10].Value = objStreet.ActionType;


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateStreetMST]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        //----------------------
        //---------------------------payroll tax----
        public List<Street> GetStreetList(bool All)
        {
            List<Street> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ActionType", SqlDbType.SmallInt);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;
                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetListStreetMST", arParms);
                lstObject = ORHelper<Street>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public Street GetStreetByID(int ID)
        {
            Street objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@StreetID", SqlDbType.Int);
                arParms[0].Value = ID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "Street", ds, new string[] { "usp_GetStreetMSTByID" }, arParms);
                objRetCustomer = ORHelper<Street>.FromDataTable(ds.Tables["StreetMST"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }



        public List<Street> GetSearchStreetList(Street objStreet)
        {
            List<Street> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[8];

                arParms[0] = new SqlParameter("@StreetID", SqlDbType.SmallInt);
                arParms[0].Value = objStreet.StreetID;
                arParms[1] = new SqlParameter("@StreetName", SqlDbType.VarChar);
                arParms[1].Value = objStreet.StreetName;

                arParms[2] = new SqlParameter("@CityID", SqlDbType.Int);
                arParms[2].Value = objStreet.CityID;


                arParms[3] = new SqlParameter("@StateCode", SqlDbType.VarChar);
                arParms[3].Value = objStreet.StateCode;

                arParms[4] = new SqlParameter("@CountryID", SqlDbType.Int);
                arParms[4].Value = objStreet.CountryID;


                arParms[5] = new SqlParameter("@CityName", SqlDbType.VarChar);
                arParms[5].Value = objStreet.CityName;
                arParms[6] = new SqlParameter("@CountryName", SqlDbType.VarChar);
                arParms[6].Value = objStreet.CountryName;


                arParms[7] = new SqlParameter("@IsActive", SqlDbType.Bit); // added by ankit
                arParms[7].Value = objStreet.IsActive;



                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_GetSearchListStreetMST]", arParms);
                lstObject = ORHelper<Street>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

    }
}
