﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;



/*************************************************************************************************  
  
  Name of the Class			    : CityDA                      
  
  Description of the class	    : 
  
  Created Date					: 30th Nov 2011  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 30/11/2010  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.DataAccess.Common
{



    public class CityDA : DataAccessObjectBase
    {
        #region City
        //-------------------save Product detail-----------------------

        public bool SaveCity(CityMST objCity)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[12];

                arParms[0] = new SqlParameter("@CityID", SqlDbType.Int);
                arParms[0].Value = objCity.CityID;
                arParms[1] = new SqlParameter("@CountryID", SqlDbType.Int);
                arParms[1].Value = objCity.CountryId;
                arParms[2] = new SqlParameter("@Zip_Code", SqlDbType.Int);
                arParms[2].Value = objCity.Zip_Code;

                arParms[3] = new SqlParameter("@State_Code", SqlDbType.VarChar);
                arParms[3].Value = objCity.State_Code;

                arParms[4] = new SqlParameter("@CityName", SqlDbType.VarChar);
                arParms[4].Value = objCity.CityName;
                arParms[5] = new SqlParameter("@State_Name", SqlDbType.VarChar);
                arParms[5].Value = objCity.State_Name;

               

                arParms[6] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[6].Value = objCity.AddedBy;

                arParms[7] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[7].Value = objCity.LastModBy;
                arParms[8] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[8].Value = objCity.FinancialYearID;

                arParms[9] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[9].Value = objCity.CompanyID;
                

                arParms[10] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[10].Value = objCity.IsActive;

                arParms[11] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[11].Value = objCity.ActionType;



                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateCityMST]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        //-------------------
        public CityMST GetCityByID(int ID)
        {
            CityMST objRetCurrency = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CityID", SqlDbType.Int);
                arParms[0].Value = ID;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCityByID", ds, new string[] { "CityMST" }, arParms);
                objRetCurrency = ORHelper<CityMST>.FromDataTable(ds.Tables["CityMST"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCurrency;
        }

        public List<CityMST> GetCityList(bool All)
        {
            List<CityMST> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ActionType", SqlDbType.Bit);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCityMSTList", arParms);
                lstObject = ORHelper<CityMST>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<CityMST> GetCityListSearch(string Search)
        {
            List<CityMST> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@Search", SqlDbType.VarChar);
                
                    arParms[0].Value = Search;

                    SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCityListSearch", arParms);
                lstObject = ORHelper<CityMST>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        #endregion




    }

   
}
