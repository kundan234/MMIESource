﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;



/*************************************************************************************************  
  
  Name of the Class			    : CountryDA                      
  
  Description of the class	    : 
  
  Created Date					: 5 Jan 2011  
  
  Developer						: 
  
  Modify Date					: 05/01/2011  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.DataAccess.Common
{
    /// <summary>
    /// Summary description for Country
    /// </summary>
    public class CountryDA : DataAccessObjectBase
    {
        public List<Country> GetCountryList(bool All)
        {
            List<Country> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ActionType", SqlDbType.Bit);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCountryMSTList", arParms);
                lstObject = ORHelper<Country>.FromDataReaderToList(dataReader);
                dataReader.Close();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return lstObject;
        }

        public string GetCountryName(int CountryID)
        {
            string CountryName = null;
            //SqlDataReader dr;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CountryID", SqlDbType.Int);
                arParms[0].Value = CountryID;
                //dr = SqlHelper.ExecuteReader(Globals.ConnectionString, CommandType.StoredProcedure, "usp_GetOccupationNamebyID", arParms);
                //if (dr.HasRows)
                //{
                //    if (dr.Read())
                //    {
                //        OccupationName = dr["OccupationName"].ToString();
                //    }
                //}

            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("5000001", ex);
            }
            return CountryName;
        }
        //public string GetBedTypeDAName(int BedTypeDAID)
        //{
        //    string queryString = "SELECT * FROM Table1";
        //    //SqlClient.SqlConnection connection = new SqlClient.SqlConnection("Data Source=HCISSQL2;Initial Catalog=...;User ID=apps;Password=...");
        //    //SqlClient.SqlCommand command = new SqlClient.SqlCommand(queryString, connection);

        //    //connection.Open();

        //    DataTable dt = new DataTable();
        //    SqlDataAdapter ad = new SqlDataAdapter(command);
        //    ad.Fill(dt);
        //    if (dt.Rows.Count > 0)
        //    {

        //        DropDownList1.DataSource = dt;
        //        DropDownList1.DataTextField = "CountryName";
        //        DropDownList1.DataValueField = "CountryName";
        //        DropDownList1.DataBind();
        //    }

        //    connection.Close();

        //}
    }
}