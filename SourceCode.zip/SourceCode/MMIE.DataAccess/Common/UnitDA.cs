﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;



namespace MMIE.DataAccess.Common
{
   public class UnitDA : DataAccessObjectBase
    {

        public bool SaveUnit(UnitDT objUnit)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[9];
                arParms[0] = new SqlParameter("@UnitID", SqlDbType.Int);
                arParms[0].Value = objUnit.UnitID;
                arParms[1] = new SqlParameter("@UnitName", SqlDbType.VarChar);
                arParms[1].Value = objUnit.UnitName;
                arParms[2] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[2].Value = objUnit.AddedBy;
                arParms[3] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[3].Value = objUnit.LastModBy;
                arParms[4] = new SqlParameter("@IsActive", SqlDbType.Bit);
               arParms[4].Value = objUnit.IsActive;
              
                arParms[5] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[5].Value = objUnit.FinancialYearID;

                arParms[6] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[6].Value = objUnit.CompanyID;

                arParms[7] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[7].Value = objUnit.ActionType;
                arParms[8] = new SqlParameter("@Details", SqlDbType.VarChar);
                arParms[8].Value = objUnit.Details;
               
              
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateUnitMST", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        //-------------------

        //----------------------------------------------------------------

        public List<UnitDT> GetUnitList(bool All)
        {
            List<UnitDT> lstUnit = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ActionType", SqlDbType.Bit);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetAllUnit", arParms);
                lstUnit = ORHelper<UnitDT>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstUnit;
        }

        //----------------------------------------------------------------
        public List<UnitDT> GetSearchUnitList(UnitDT objUnit )
        {
            List<UnitDT> lstUnit = null;
            SqlParameter[] arParms = new SqlParameter[3];
            try
            {
                //arParms[0] = new SqlParameter("@UnitID", SqlDbType.Int);
                //arParms[0].Value = objUnit.UnitID;
               
                arParms[0] = new SqlParameter("@UnitName", SqlDbType.VarChar);  // added by ankit
                arParms[0].Value = objUnit.UnitName;

                arParms[1] = new SqlParameter("@Details", SqlDbType.VarChar);   // added by ankit
                arParms[1].Value = objUnit.Details;

                
                arParms[2] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[2].Value = objUnit.IsActive;




                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSearchUnitMST", arParms);
                lstUnit = ORHelper<UnitDT>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstUnit;
        }

       
       public bool DeleteUnitByID(UnitDT objUnit)
        {

            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@UnitID", SqlDbType.Int);
                arParms[0].Value = objUnit.UnitID;


                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_DeleteUnit", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

    }
   
}

