﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;



/*************************************************************************************************  
  
  Name of the Class			    : BankDA                      
  
  Description of the class	    : 
  
  Created Date					: 17/Jan/2012
  
  Developer						: Budha Singh
  
  Modify Date					: 17/Jan/2012
  
  Modified By Developer			: Budha Singh
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.DataAccess.Common
{



    public class BankDA : DataAccessObjectBase
    {
        #region Bank
        //-------------------save Product detail-----------------------

        public bool SaveBank(Bank objBank)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[10];

                arParms[0] = new SqlParameter("@BankID", SqlDbType.Int);
                arParms[0].Value = objBank.BankID;

                arParms[1] = new SqlParameter("@BankAccountNo", SqlDbType.VarChar);
                arParms[1].Value = objBank.BankAccountNo;

                arParms[2] = new SqlParameter("@BankName", SqlDbType.VarChar);
                arParms[2].Value = objBank.BankName;

                arParms[3] = new SqlParameter("@BankAddress", SqlDbType.VarChar);
                arParms[3].Value = objBank.BankAddress;
                
                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objBank.AddedBy;

                arParms[5] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[5].Value = objBank.LastModBy;
                arParms[6] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[6].Value = objBank.FinancialYearID;

                arParms[7] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[7].Value = objBank.CompanyID;                

                arParms[8] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[8].Value = objBank.IsActive;

                arParms[9] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[9].Value = objBank.ActionType;
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateBankMST]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        //-------------------
        public Bank GetBankByID(int ID)
        {
            Bank objRetCurrency = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@BankID", SqlDbType.Int);
                arParms[0].Value = ID;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetBankMSTList", ds, new string[] { "BankMST" }, arParms);
                objRetCurrency = ORHelper<Bank>.FromDataTable(ds.Tables["BankMST"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCurrency;
        }

        public List<Bank> GetBankList(bool All)
        {
            List<Bank> lstObject = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@IsActive", SqlDbType.Bit);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetBankMSTList", arParms);
                lstObject = ORHelper<Bank>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<Bank> GetBankListSearch(Bank objBank)
        {
            List<Bank> lstObject = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[4];

                arParms[0] = new SqlParameter("@BankID", SqlDbType.Int);
                arParms[0].Value = objBank.BankID;

                arParms[1] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[1].Value = objBank.IsActive;

                arParms[2] = new SqlParameter("@BankName", SqlDbType.VarChar);
                arParms[2].Value = objBank.BankName;

                arParms[3] = new SqlParameter("@BankAddress", SqlDbType.VarChar);
                arParms[3].Value = objBank.BankAddress;


                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetBankMSTList", arParms);
                lstObject = ORHelper<Bank>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        #endregion
    }

   
}
