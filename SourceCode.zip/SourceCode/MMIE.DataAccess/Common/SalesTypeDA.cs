﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common;
using MMIE.Common.Util;




/*************************************************************************************************  
  
  Name of the Class			    : SalesTypeDA                      
  
  Description of the class	    : 
  
  Created Date					: 30th Nov 2010  
  
  Developer						: Kundan Singh
  
  Modify Date					: 29/11/2010  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.DataAccess.Common
{
    public 
        class SalesTypeDA:DataAccessObjectBase
    {
        #region SalesTypeDA

        public bool SaveSalesType(SalesType objSalesType)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[9];

                arParms[0] = new SqlParameter("@SalesTypeID", SqlDbType.Int);
                arParms[0].Value = objSalesType.SalesTypeID;
                arParms[1] = new SqlParameter("@SalesTypeName", SqlDbType.VarChar);
                arParms[1].Value = objSalesType.SalesTypeName;
                //arParms[2] = new SqlParameter("@SalesTypeRate", SqlDbType.Money);
                //arParms[2].Value = objSalesType.SalesTypeRate;

                arParms[2] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[2].Value = objSalesType.ActionType;

                arParms[3] = new SqlParameter("@IsActive", SqlDbType.VarChar);
                arParms[3].Value = objSalesType.IsActive;


                arParms[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[4].Value = objSalesType.AddedBy;

                arParms[5] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[5].Value = objSalesType.LastModBy;
                arParms[6] = new SqlParameter("@FinancialYearID", SqlDbType.Int);
                arParms[6].Value = objSalesType.FinancialYearID;

                arParms[7] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[7].Value = objSalesType.CompanyID;


            


                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "[usp_UpdateSalesTypeMST]", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        //-------------------
        public SalesType GetSalesTypeByID(int ID)
        {
            SalesType objSalesType = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CityID", SqlDbType.Int);
                arParms[0].Value = ID;

                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSalesTypeMSByID", ds, new string[] { "SalesTypeMST" }, arParms);
                objSalesType = ORHelper<SalesType>.FromDataTable(ds.Tables["SalesTypeMST"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objSalesType;
        }

        public List<SalesType> GetSalesTypeList(bool All)
        {
            List<SalesType> lstObject = null;
            try
            {


                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@ActionType", SqlDbType.Int);
                if (All)
                    arParms[0].Value = 1;
                else
                    arParms[0].Value = 2;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSalesTypeMSTList", arParms);
                lstObject = ORHelper<SalesType>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public List<SalesType> GetSearchSalesType(SalesType objsalestype)
        {
            List<SalesType> lstObject = null;
            try
            {



                SqlParameter[] arParms = new SqlParameter[2];


                arParms[0] = new SqlParameter("@SalesName", SqlDbType.VarChar);
                arParms[0].Value = objsalestype.SalesTypeName;

                arParms[1] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[1].Value = objsalestype.IsActive;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetSearchSalesType", arParms);
                lstObject = ORHelper<SalesType>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }



        #endregion



    }
}
