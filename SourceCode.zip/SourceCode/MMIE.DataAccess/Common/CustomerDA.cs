﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using MMIE.Data.Common;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Common ;
using MMIE.Common.Util;

namespace MMIE.DataAccess.Common
{
    /*************************************************************************************************  
  
  Name of the Class			    : CustomerDA                      
  
  Description of the class	    : 
  
  Created Date					: 19 October 2011  
  
  Developer						: Mithlesh
  
  Modify Date					: 19/10/2011  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


   public class CustomerDA : DataAccessObjectBase
    {

        #region Customer
        //-------------------save customer detail-----------------------

        public int SaveCustomer(Customer objCustomer)
        {
            int status = 0;
            try
            {

                SqlParameter[] arParms = new SqlParameter[36];

                //----------------------------------
                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = objCustomer.CustomerID;
                arParms[1] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[1].Value = objCustomer.CustomerName;
                arParms[2] = new SqlParameter("@CustomerAddress", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.CustomerAddress;
                arParms[3] = new SqlParameter("@CustomerStreet", SqlDbType.VarChar);
                arParms[3].Value = objCustomer.CustomerStreet;
                arParms[4] = new SqlParameter("@CustomerCityID", SqlDbType.Int);
                arParms[4].Value = objCustomer.CustomerCityID;
                arParms[5] = new SqlParameter("@CustomerCountryId", SqlDbType.Int);
                arParms[5].Value = objCustomer.CustomerCountryID;
                arParms[6] = new SqlParameter("@CustomerPhone", SqlDbType.VarChar);
                arParms[6].Value = objCustomer.CustomerPhone;
                arParms[7] = new SqlParameter("@CustomerMobile", SqlDbType.VarChar);
                arParms[7].Value = objCustomer.CustomerMobile;
                arParms[8] = new SqlParameter("@CustomerFax", SqlDbType.VarChar);
                arParms[8].Value = objCustomer.CustomerFax;
                arParms[9] = new SqlParameter("@CustomerEmail", SqlDbType.VarChar);
                arParms[9].Value = objCustomer.CustomerEmail;
                arParms[10] = new SqlParameter("@CustomerWebsite", SqlDbType.VarChar);
                arParms[10].Value = objCustomer.CustomerWebsite;

                //------------------------------------refrence detail------------
                arParms[11] = new SqlParameter("@CustReferenceName", SqlDbType.VarChar);
                arParms[11].Value = objCustomer.CustReferenceName;
                arParms[12] = new SqlParameter("@CustReferenceAddress", SqlDbType.VarChar);
                arParms[12].Value = objCustomer.CustReferenceAddress;
                arParms[13] = new SqlParameter("@CustReferenceStreet",  SqlDbType.VarChar);
                arParms[13].Value = objCustomer.CustReferenceStreet;
                arParms[14] = new SqlParameter("@CustReferenceCityID", SqlDbType.Int);
                arParms[14].Value = objCustomer.CustReferenceCityID;
                arParms[15] = new SqlParameter("@CustReferenceCountryID", SqlDbType.Int);
                arParms[15].Value = objCustomer.CustReferenceCountryID;
                arParms[16] = new SqlParameter("@CustReferencePhone", SqlDbType.VarChar);
                arParms[16].Value = objCustomer.CustReferencePhone;
                arParms[17] = new SqlParameter("@CustReferenceMobile", SqlDbType.VarChar);
                arParms[17].Value = objCustomer.CustReferenceMobile;
                arParms[18] = new SqlParameter("@CustReferenceFax", SqlDbType.VarChar);
                arParms[18].Value = objCustomer.CustReferenceFax;
                arParms[19] = new SqlParameter("@CustReferenceEmail", SqlDbType.VarChar);
                arParms[19].Value = objCustomer.CustReferenceEmail;
                arParms[20] = new SqlParameter("@CustReferenceWebsite",  SqlDbType.VarChar);
                arParms[20].Value = objCustomer.CustReferenceWebsite;
                //-------------------------------------------------------
                arParms[21] = new SqlParameter("@CType", SqlDbType.VarChar);
                arParms[21].Value = objCustomer.CType;
                //-------------------old code-----------------              
                arParms[22] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[22].Value = objCustomer.AddedBy;
                arParms[23] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                arParms[23].Value = objCustomer.LastModBy;
                arParms[24] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[24].Value = objCustomer.ActionType;
                arParms[25] = new SqlParameter("@CompanyID", SqlDbType.Int);
                arParms[25].Value = objCustomer.CompanyID;
                arParms[26] = new SqlParameter("@StatusType", SqlDbType.Bit);
                arParms[26].Value = objCustomer.StatusType;

                arParms[27] = new SqlParameter("@CustomerType", SqlDbType.VarChar);
                arParms[27].Value = objCustomer.CustomerType;
                arParms[28] = new SqlParameter("@IsPriceVisible", SqlDbType.Bit);
                arParms[28].Value = objCustomer.IsPriceVisible;

                arParms[29] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[29].Value = objCustomer.IsActive;

                arParms[30] = new SqlParameter("@SalesTypeID", SqlDbType.Int);
                arParms[30].Value = objCustomer.SalesTypeID;


                arParms[31] = new SqlParameter("@MaxCreditLimit", SqlDbType.Money);
                arParms[31].Value = objCustomer.MaxCreditLimit;


                arParms[32] = new SqlParameter("@MaxCreditLimitUSD", SqlDbType.Money);
                arParms[32].Value = objCustomer.MaxCreditLimitUSD;


                arParms[33] = new SqlParameter("@ID", SqlDbType.Int);
                arParms[33].Direction = ParameterDirection.Output;

                arParms[34] = new SqlParameter("@StreetChargeID", SqlDbType.Int);
                arParms[34].Value = objCustomer.StreetChargeID;
                arParms[35] = new SqlParameter("@MaximumDueDays", SqlDbType.Int);
                arParms[35].Value = objCustomer.MaximumDueDays;
              
                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateCustomerMST", arParms);
                
                if (noOfEffectedRecords > 0)
                    status = int.Parse(arParms[33].Value.ToString());

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        //-----------------------save customer document detail-----
        public bool SaveCustomerDocument(CustomerDocument objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[11];
                arParms[0] = new SqlParameter("@ScanID", SqlDbType.Int);
                arParms[0].Value = objCustomer.ScanID;
                arParms[1] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[1].Value = objCustomer.CustomerID;
                arParms[2] = new SqlParameter("@CustomerScanID", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.CustomerScanID;
                arParms[3] = new SqlParameter("@CustomerDescription", SqlDbType.VarChar);
                arParms[3].Value = objCustomer.CustomerDescription;
                arParms[4] = new SqlParameter("@ActionType", SqlDbType.Int);
                arParms[4].Value = objCustomer.ActionType;
                arParms[5] = new SqlParameter("@FriendlyName", SqlDbType.VarChar);
                arParms[5].Value = objCustomer.FriendlyName;
                arParms[6] = new SqlParameter("@DocumentType", SqlDbType.VarChar);
                arParms[6].Value = objCustomer.DocumentType;
                arParms[7] = new SqlParameter("@DocumentID", SqlDbType.VarChar);
                arParms[7].Value = objCustomer.DocumentID;
                arParms[8] = new SqlParameter("@IsActive", SqlDbType.Bit);
                arParms[8].Value = objCustomer.IsActive;
                arParms[9] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                arParms[9].Value = objCustomer.AddedBy;
                
                arParms[10] = new SqlParameter("@LastModBy", SqlDbType.Int);
                arParms[10].Value = objCustomer.LastModBy;

                //------------------------
                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_UpdateCustomerDocument", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }
        //-------------------

       //----------------------------------------------------------------

        public List<CustomerDocument> SearchCustomerDocument(int id)
        {
            List<CustomerDocument> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@CustomerId", SqlDbType.SmallInt);
                arParms[0].Value = id;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCustomerDocumentByID", arParms);
                lstObject = ORHelper<CustomerDocument>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

       //----------------------------------------------------------------
        public Customer GetCustomerByID(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = objCustomer.CustomerID ;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCustomerByID", ds, new string[] { "Customer" }, arParms);
                objRetCustomer = ORHelper<Customer>.FromDataTable(ds.Tables["Customer"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }
        public Customer GetCustomerDetailsByID(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = objCustomer.CustomerID;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCustomerDetailsByID", ds, new string[] { "Customer" }, arParms);
                objRetCustomer = ORHelper<Customer>.FromDataTable(ds.Tables["Customer"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }


        public List<Customer> SearchCustomer(Customer objCustomer)
        {
            List<Customer> lstObject = null;
            try
            {

                SqlParameter[] arParms = new SqlParameter[6];                

                arParms[0] = new SqlParameter("@CustomerName", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.CustomerName ;
                arParms[1] = new SqlParameter("@CustomerStreet", SqlDbType.VarChar);
                arParms[1].Value = objCustomer.CustomerStreet;
                arParms[2] = new SqlParameter("@CustomerPhone", SqlDbType.VarChar);
                arParms[2].Value = objCustomer.CustomerPhone;
                arParms[3] = new SqlParameter("@CustomerMobile", SqlDbType.VarChar);
                arParms[3].Value = objCustomer.CustomerMobile;
                arParms[4] = new SqlParameter("@CurrentIndex", SqlDbType.Int);
                arParms[4].Value = objCustomer.CurrentIndex;
                arParms[5] = new SqlParameter("@PageSize", SqlDbType.Int);
                arParms[5].Value = objCustomer.PageSize;

                SqlDataReader dataReader = SqlHelper.ExecuteReader(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_GetCustomer", arParms);
                lstObject = ORHelper<Customer>.FromDataReaderToList(dataReader);
                dataReader.Close();

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return lstObject;
        }

        public bool DeleteCustomer(Customer objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = objCustomer.CustomerID;

                //arParms[1] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                //arParms[1].Value = objCustomer.LastModBy;

                //arParms[2] = new SqlParameter("@ActionType", SqlDbType.Int);
                //arParms[2].Value = objCustomer.ActionType;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_DeleteCustomer", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }


        public bool DisableCustomer(Customer objCustomer)
        {
            bool status = false;
            try
            {

                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@CustomerID", SqlDbType.Int);
                arParms[0].Value = objCustomer.CustomerID;

                //arParms[1] = new SqlParameter("@LastModBy", SqlDbType.VarChar);
                //arParms[1].Value = objCustomer.LastModBy;

                //arParms[2] = new SqlParameter("@ActionType", SqlDbType.Int);
                //arParms[2].Value = objCustomer.ActionType;

                int noOfEffectedRecords = SqlHelper.ExecuteNonQuery(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_DisableCustomer", arParms);
                if (noOfEffectedRecords > 0)
                    status = true;

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return status;
        }

        #endregion
        #region Get City and Contry code
        public Customer GetCountryByName(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];
                arParms[0] = new SqlParameter("@Cityname", SqlDbType.VarChar);
                arParms[0].Value = objCustomer.CityName;
                DataSet ds = new DataSet();
                SqlHelper.FillDataset(GlobalConstant.ConnectionString, CommandType.StoredProcedure, "usp_SearchCity", ds, new string[] { "Cityname" }, arParms);
                objRetCustomer = ORHelper<Customer>.FromDataTable(ds.Tables["Cityname"]);

            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return objRetCustomer;
        }


        #endregion

    }
}
