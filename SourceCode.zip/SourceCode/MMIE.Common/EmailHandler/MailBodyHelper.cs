using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Xsl;

/*************************************************************************************************  
  
  Name of the Class			    : MailBodyHelper                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Common.EmailHandler
{
    public class MailBodyHelper
    {
        public string GenerateMailBody(string inputXml, string xslPath)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(inputXml);
            XslCompiledTransform transform = new XslCompiledTransform();
            //Load the XSL stylsheet into XslCompiledTransform 
            transform.Load(xslPath);
            StringWriter writer = new StringWriter();
            //Transform the xml contents into HTML by applying XSL
            transform.Transform(xmlDoc, null, writer);
            string bodyOfMail = writer.ToString();
            return bodyOfMail;
        }
    }
}
