using System;
using System.Collections.Generic;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : MailParameter                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Common.EmailHandler
{
    /// <summary>
    /// This class have mail attributes information.
    /// </summary>
    public class MailParameter
    {
        private string m_from = string.Empty;
        private string m_displayName = string.Empty;
        private string m_to = string.Empty;
        private string m_cc = string.Empty;
        private string m_bcc = string.Empty;
        private string m_subject = string.Empty;
        private string m_body = string.Empty;
        private string[] m_attachment;

        public string From
        {
            get
            {
                return m_from;
            }
            set
            {
                m_from = value;
            }
        }

        public string DisplayName
        {
            get
            {
                return m_displayName;
            }
            set
            {
                m_displayName = value;
            }
        }

        public string To
        {
            get
            {
                return m_to;
            }
            set
            {
                m_to = value;
            }
        }

        public string CC
        {
            get
            {
                return m_cc;
            }
            set
            {
                m_cc = value;
            }
        }

        public string BCC
        {
            get
            {
                return m_bcc;
            }
            set
            {
                m_bcc = value;
            }
        }

        public string Subject
        {
            get
            {
                return m_subject;
            }
            set
            {
                m_subject = value;
            }
        }

        public string Body
        {
            get
            {
                return m_body;
            }
            set
            {
                m_body = value;
            }
        }

        public string[] Attachment
        {
            get
            {
                return m_attachment;
            }
            set
            {
                m_attachment = value;
            }
        }
    }
}
