using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Net.Mail;

/*************************************************************************************************  
  
  Name of the Class			    : MailService                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Common.EmailHandler
{
    /// <summary>
    /// You can use this class to send a smtp mail.
    /// </summary>
    public class MailService
    {
        private static bool mailSent = false;

        /// <summary>
        /// Static method to send mail
        /// </summary>
        /// <param name="mailParameter">The MailParameter object whose information should be used to send mail.</param>                
        public static void SendMail(MailParameter mailParameter)
        {
            try
            {
                // MailMessage is used to represent the e-mail being sent
                //using (MailMessage message = new MailMessage(mailParameter.From, mailParameter.To, mailParameter.Subject, mailParameter.Body))
                using (MailMessage message = new MailMessage())
                {
                    message.From = new MailAddress(mailParameter.From.Trim());
                    message.Body = mailParameter.Body.Trim();
                    message.Subject = mailParameter.Subject.Trim();

                    //For multiple To address seperated with ; delimiter
                    if (mailParameter.To != null)
                    {
                        string[] arrTo = mailParameter.To.Split(new char[] { ';' });
                        foreach (string toAdd in arrTo)
                        {
                            MailAddress toAddress = new MailAddress(toAdd.Trim());
                            message.To.Add(toAddress);
                        }
                    }

                    //For multiple CC address seperated with ; delimiter
                    if (mailParameter.CC != null)
                    {
                        if (mailParameter.CC.Trim().Length > 0)
                        {
                            string[] arrCC = mailParameter.CC.Split(new char[] { ';' });
                            foreach (string ccAdd in arrCC)
                            {
                                MailAddress ccAddress = new MailAddress(ccAdd.Trim());
                                message.CC.Add(ccAddress);
                            }
                        }
                    }

                    //For multiple BCC address seperated with ; delimiter
                    if (mailParameter.BCC != null)
                    {
                        if (mailParameter.BCC.Trim().Length > 0)
                        {
                            string[] arrBCC = mailParameter.BCC.Split(new char[] { ';' });
                            foreach (string bccAdd in arrBCC)
                            {
                                MailAddress bccAddress = new MailAddress(bccAdd.Trim());
                                message.Bcc.Add(bccAddress);
                            }
                        }
                    }


                    message.IsBodyHtml = true;
                    SmtpClient mailClient = new SmtpClient();

                    //Use the Windows credentials of the client logged on account                    
                    mailClient.UseDefaultCredentials = true;
                    //mailClient.DeliveryMethod = SmtpDeliveryMethod.PickupDirectoryFromIis;

                    if (mailParameter.Attachment != null)
                    {
                        //Check if the length of the string is greater than 0
                        if (mailParameter.Attachment.Length != 0)
                        {
                            foreach (string str in mailParameter.Attachment)
                            {
                                Attachment attach = new Attachment(str);
                                message.Attachments.Add(attach);
                            }
                        }
                    }

                    //Send delivers the message to the mail server
                    mailClient.Send(message);
                }
            }
            catch (Exception ex)
            {
                throw new SmtpException("Error in sending mail", ex);
            }
        }

        /// <summary>
        /// Static method to send mail
        /// </summary>
        /// <param name="mailParameter">A mail additional data that should be used to send mail.</param>                
        public static void SendMail(string from, string to, string cc,
                            string bcc, string subject, string body,
                             string attachments)
        {
            try
            {
                // MailMessage is used to represent the e-mail being sent
                //using (MailMessage message = new MailMessage(from, to, subject, body))
                using (MailMessage message = new MailMessage())
                {
                    message.From = new MailAddress(from.Trim());
                    message.Body = body.Trim();
                    message.Subject = subject.Trim();

                    //For multiple To address seperated with ; delimiter
                    if (to != null)
                    {
                        string[] arrTo = to.Split(new char[] { ';' });
                        foreach (string toAdd in arrTo)
                        {
                            MailAddress toAddress = new MailAddress(toAdd.Trim());
                            message.To.Add(toAddress);
                        }
                    }

                    //For multiple CC address seperated with ; delimiter
                    if (cc != null)
                    {
                        if (cc.Trim().Length > 0)
                        {
                            string[] arrCC = cc.Split(new char[] { ';' });
                            foreach (string ccAdd in arrCC)
                            {
                                MailAddress ccAddress = new MailAddress(ccAdd.Trim());
                                message.CC.Add(ccAddress);
                            }
                        }
                    }

                    //For multiple BCC address seperated with ; delimiter
                    if (bcc != null)
                    {
                        if (bcc.Trim().Length > 0)
                        {
                            string[] arrBCC = bcc.Split(new char[] { ';' });
                            foreach (string bccAdd in arrBCC)
                            {
                                MailAddress bccAddress = new MailAddress(bccAdd.Trim());
                                message.Bcc.Add(bccAddress);
                            }
                        }
                    }


                    message.IsBodyHtml = true;
                    SmtpClient mailClient = new SmtpClient();
                    //Use the Windows credentials of the client logged on account                    
                    mailClient.UseDefaultCredentials = true;
                    //mailClient.DeliveryMethod = SmtpDeliveryMethod.PickupDirectoryFromIis;

                    if (attachments != null)
                    {
                        attachments = attachments.Trim();
                        //Check if the length of the string is greater than 0
                        if (attachments.Length != 0)
                        {
                            //Get the list of semi-colon separated attachments into an array
                            string[] arr = attachments.Split(';');
                            foreach (string str in arr)
                            {
                                Attachment attach = new Attachment(str);
                                message.Attachments.Add(attach);
                            }
                        }
                    }
                    //Send delivers the message to the mail server
                    mailClient.Send(message);
                }
            }
            catch (Exception ex)
            {
                throw new SmtpException("Error in sending mail", ex);
            }
        }

        /// <summary>
        /// Static method to send mail as Async
        /// </summary>
        /// <param name="mailParameter">The MailParameter object whose information should be used to send mail.</param>                
        public static void SendAsyncMail(MailParameter mailParameter)
        {
            try
            {
                SmtpClient client = new SmtpClient();
                MailMessage message = new MailMessage();

                message.Body = mailParameter.Body;
                //message.BodyEncoding = System.Text.Encoding.UTF8;
                message.Subject = mailParameter.Subject;
                //message.SubjectEncoding = System.Text.Encoding.UTF8;

                MailAddress fromAddress = new MailAddress(mailParameter.From);
                message.From = fromAddress;

                //For multiple To address seperated with ; delimiter
                if (mailParameter.To != null)
                {
                    string[] arrTo = mailParameter.To.Split(new char[] { ';' });
                    foreach (string toAdd in arrTo)
                    {
                        MailAddress toAddress = new MailAddress(toAdd.Trim());
                        message.To.Add(toAddress);
                    }
                }

                //For multiple CC address seperated with ; delimiter
                if (mailParameter.CC != null)
                {
                    if (mailParameter.CC.Trim().Length > 0)
                    {
                        string[] arrCC = mailParameter.CC.Split(new char[] { ';' });
                        foreach (string ccAdd in arrCC)
                        {
                            MailAddress ccAddress = new MailAddress(ccAdd.Trim());
                            message.CC.Add(ccAddress);
                        }
                    }
                }

                //For multiple BCC address seperated with ; delimiter
                if (mailParameter.BCC != null)
                {
                    if (mailParameter.BCC.Trim().Length > 0)
                    {
                        string[] arrBCC = mailParameter.BCC.Split(new char[] { ';' });
                        foreach (string bccAdd in arrBCC)
                        {
                            MailAddress bccAddress = new MailAddress(bccAdd.Trim());
                            message.Bcc.Add(bccAddress);
                        }
                    }
                }

                //Use the Windows credentials of the client logged on account                    
                client.UseDefaultCredentials = true;

                if (mailParameter.Attachment != null)
                {
                    //Check if the length of the string is greater than 0
                    if (mailParameter.Attachment.Length != 0)
                    {
                        foreach (string str in mailParameter.Attachment)
                        {
                            Attachment attach = new Attachment(str);
                            message.Attachments.Add(attach);
                        }
                    }
                }


                // Set the method that is called back when the send operation ends.
                client.SendCompleted += new SendCompletedEventHandler(SendCompletedCallback);

                // The userState can be any object that allows your callback 
                // method to identify this send operation.
                // the userToken is a string constant.
                string userState = "test message1";
                client.SendAsync(message, userState);

                // If mail hasn't been sent yet,
                // then cancel the pending operation.
                if (mailSent == false)
                {
                    client.SendAsyncCancel();
                }

                // Clean up.
                message.Dispose();
            }
            catch (Exception ex)
            {
                throw new SmtpException("Error in sending mail", ex);
            }
        }

        private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
        {
            try
            {  
                // Get the unique identifier for this asynchronous operation.
                String token = (string)e.UserState;

                if (e.Cancelled)
                {
                    //Console.WriteLine("[{0}] Send canceled.", token);
                    throw new SmtpException(token + " Send canceled.");
                }

                if (e.Error != null)
                {
                    //Console.WriteLine("[{0}] {1}", token, e.Error.ToString());
                    throw new SmtpException(token + " " + e.Error.ToString());
                }
                else
                {
                    //Console.WriteLine("Message sent.");
                }

                mailSent = true;
            }
            catch (Exception ex)
            {
                mailSent = false;
                throw new SmtpException("Error in sending mail", ex);
            }
        }

    }
}
