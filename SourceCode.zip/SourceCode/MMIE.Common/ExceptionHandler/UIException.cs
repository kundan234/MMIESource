using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

/*************************************************************************************************  
  
  Name of the Class			    : UIException                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Common.ExceptionHandler
{
    [Serializable]
    public class UIException : ApplicationException
    {
        // Default constructor 
        public UIException()
            : base()
        {

        }
        //New 

        // Constructor with message 
        public UIException(string message)
            : base(message)
        {
        }


        // Constructor with message, inner Exception 
        public UIException(string message, System.Exception inner)
            : base(message, inner)
        {
        }

        // Protected constructor to de-serialize data 
        protected UIException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
