using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

/*************************************************************************************************  
  
  Name of the Class			    : ReportsException                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Common.ExceptionHandler
{
    [Serializable]
    public class ReportsException : ApplicationException
    {
        // Default constructor 
        public ReportsException()
            : base()
        {

        }
        //New 

        // Constructor with message 
        public ReportsException(string message)
            : base(message)
        {
        }


        // Constructor with message, inner Exception 
        public ReportsException(string message, System.Exception inner)
            : base(message, inner)
        {
        }

        // Protected constructor to de-serialize data 
        protected ReportsException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
