using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

/*************************************************************************************************  
  
  Name of the Class			    : DataException                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Common.ExceptionHandler
{
    [Serializable]
    public class DataAccessException : ApplicationException
    {
        // Default constructor 
        public DataAccessException()
            : base()
        {

        }
        //New 

        // Constructor with message 
        public DataAccessException(string message)
            : base(message)
        {
        }


        // Constructor with message, inner Exception 
        public DataAccessException(string message, System.Exception inner)
            : base(message, inner)
        {
        }

        // Protected constructor to de-serialize data 
        protected DataAccessException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
