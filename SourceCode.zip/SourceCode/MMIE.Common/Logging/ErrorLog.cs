using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Logging;
using Microsoft.Practices.EnterpriseLibrary.Logging.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Logging.ExtraInformation;
using Microsoft.Practices.EnterpriseLibrary.Logging.Filters;

/*************************************************************************************************  
  
  Name of the Class			    : ErorrLog                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Shubhakaran Patel
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Common.Logging
{
    public class ErorrLog
    {
        public int ErrorLineNumber
        {
            get;
            set;
        }

        public int ErrorSeverityNumber
        {
            get;
            set;
        }

        public int ErrorStateStatus
        {
            get;
            set;
        }

        public string ErrorMessageDetails
        {
            get;
            set;
        }

        public string ProcedureName
        {
            get;
            set;
        }

        public EnumErrorLogSourceTier LogSourceTier
        {
            get;
            set;
        }

        public ErorrLog(EnumErrorLogSourceTier LogSourceTier, int ErrorLineNumber, int ErrorSeverityNumber, int ErrorStateStatus, string ProcedureName, string ErrorMessageDetails)
        {
            this.ErrorLineNumber = ErrorLineNumber;
            this.ErrorSeverityNumber = ErrorSeverityNumber;
            this.ErrorStateStatus = ErrorStateStatus;
            this.ErrorMessageDetails = ErrorMessageDetails;
            this.ProcedureName = ProcedureName;
            this.LogSourceTier = LogSourceTier;
        }

        public ErorrLog(EnumErrorLogSourceTier LogSourceTier, string ErrorMessageDetails)
        {
            this.ErrorMessageDetails = ErrorMessageDetails;
            this.LogSourceTier = LogSourceTier;
        }
    }

    public enum EnumErrorLogSourceTier
    {
        Web = 1,
        App = 2,
        DB = 3
    }

}
