﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data;

namespace MMIE.Common
{
    public static class GlobalConstant
    {

        public static string ConnectionString;       
        public static string xlsConnectionString; 
        public static string EncryptionKey;        
        public static string DateFormat;
        
        public static DateTime MinSQLDateTime ; //= DateTime.Parse("01/01/1753", provider, System.Globalization.DateTimeStyles.NoCurrentDateDefault);

        static GlobalConstant()
        {
            //Connection for SQL Server Database
            ConnectionString = ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString;            
            EncryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];            
            DateFormat = ConfigurationManager.AppSettings["DateFormat"];

            IFormatProvider provider = new System.Globalization.CultureInfo("en-CA", true);
            MinSQLDateTime = DateTime.Parse("01/01/1753", provider, System.Globalization.DateTimeStyles.NoCurrentDateDefault);
        }

        public const int PageSize = 10;

        public const string UserAdminService_Http = "WSHttpBinding_IUserAdminService";
        public const string UserAdminService_Tcp = "NetTcpBinding_IUserAdminService";

        public const string MasterLookupService_Http = "WSHttpBinding_IMasterLookupService";
        public const string MasterLookupService_Tcp = "NetTcpBinding_IMasterLookupService";

        public const string RegistrationService_Http = "WSHttpBinding_IRegistrationService";
        public const string RegistrationService_Tcp = "NetTcpBinding_IRegistrationService";

        public const string BillingService_Http = "WSHttpBinding_IBillingService";
        public const string BillingService_Tcp = "NetTcpBinding_IBillingService";

        public const string PaymentService_Http = "WSHttpBinding_IPaymentService";
        public const string PaymentService_Tcp = "NetTcpBinding_IPaymentService";

        public const string AppointmentService_Http = "WSHttpBinding_IAppointmentService";
        public const string AppointmentService_Tcp = "NetTcpBinding_IAppointmentService";

        public const string LedgerService_Http = "WSHttpBinding_ILedgerService";
        public const string LedgerService_Tcp = "NetTcpBinding_ILedgerService";

        public const string FoodService_Http = "WSHttpBinding_IFoodService";
        public const string FoodService_Tcp = "NetTcpBinding_IFoodService";

        public const string ProductService_Http = "WSHttpBinding_IProductService";
        public const string ProductService_Tcp = "NetTcpBinding_IProductService";

        public const string SupplierService_Http = "WSHttpBinding_ISupplierService";
        public const string SupplierService_Tcp = "NetTcpBinding_ISupplierService";

        public const string BedService_Http = "WSHttpBinding_IBedService";
        public const string BedService_Tcp = "NetTcpBinding_IBedService";

        public const string ClinicService_Http = "WSHttpBinding_IClinicService";
        public const string ClinicService_Tcp = "NetTcpBinding_IClinicService";

        public const string DiseaseService_Http = "WSHttpBinding_IDiseaseService";
        public const string DiseaseService_Tcp = "NetTcpBinding_IDiseaseService";

        public const string InvestigationService_Http = "WSHttpBinding_IInvestigationService";
        public const string InvestigationService_Tcp = "NetTcpBinding_IInvestigationService";

        public const string MedicineService_Http = "WSHttpBinding_IMedicineService";
        public const string MedicineService_Tcp = "NetTcpBinding_IMedicineService";

        public const string RoomService_Http = "WSHttpBinding_IRoomService";
        public const string RoomService_Tcp = "NetTcpBinding_IRoomService";

        public const string EmployeeService_Http = "WSHttpBinding_IEmployeeService";
        public const string EmployeeService_Tcp = "NetTcpBinding_IEmployeeService";

        public const string LabService_Http = "WSHttpBinding_ILabService";
        public const string LabService_Tcp = "NetTcpBinding_ILabService";

        public const string StoreService_Http = "WSHttpBinding_IStoreService";
        public const string StoreService_Tcp = "NetTcpBinding_IStoreService";


        //public const string StoreService_Http = "WSHttpBinding_IStoreService";
        //public const string StoreService_Tcp = "NetTcpBinding_IStoreService";

        //public const string LedgerDA_Http = "WSHttpBinding_ILedgerDA";
        //public const string LedgerDA_Tcp = "NetTcpBinding_ILedgerDA";

        //public const string AppointmentBO_Http = "WSHttpBinding_IAppointmentBO";
        //public const string AppointmentBO_Tcp = "NetTcpBinding_IAppointmentBO";

        //public const string BillingHeaderBO_Http = "WSHttpBinding_IBillingHeaderBO";
        //public const string BillingHeaderBO_Tcp = "NetTcpBinding_IBillingHeaderBO";

        //public const string FoodDA_Http = "WSHttpBinding_IFoodDA";
        //public const string FoodDA_Tcp = "NetTcpBinding_IFoodDA";

        //public const string ConsultantDA_Http = "WSHttpBinding_IConsultantDA";
        //public const string ConsultantDA_Tcp = "NetTcpBinding_IConsultantDA";

        //public const string RoomGroupDA_Http = "WSHttpBinding_IRoomGroupDA";
        //public const string RoomGroupDA_Tcp = "NetTcpBinding_IRoomGroupDA";

        //public const string DoctorClinicDetailBO_Http = "WSHttpBinding_IDoctorClinicDetailBO";
        //public const string DoctorClinicDetailBO_Tcp = "NetTcpBinding_IDoctorClinicDetailBO";

        //public const string PickerDA_Http = "WSHttpBinding_IPickerDA";
        //public const string PickerDA_Tcp = "NetTcpBinding_IPickerDA";

        //public const string BillingHeaderDA_Http = "WSHttpBinding_IBillingHeaderDA";
        //public const string BillingHeaderDA_Tcp = "NetTcpBinding_IBillingHeaderDA";

        ////public const string BillingHeaderDA_Http = "WSHttpBinding_IBillingHeaderDA";
        ////public const string BillingHeaderDA_Tcp = "NetTcpBinding_IBillingHeaderDA";

        


    }

    // NOT RECOMMENDED
    // PLEASE USED LookupsName AS MODIFIED
    // LookupsName will be found in MMIE.Contracts.DataContracts.Common

    public enum StoreCommonMasterTables
    {
        STR_UnitMST = 1,
        STR_VendorClassificationMST = 2,
        STR_MaterialFormMST = 3,
        STR_MaterialGroupMST = 4,
        STR_VendorTypeMST = 5
    }
}
