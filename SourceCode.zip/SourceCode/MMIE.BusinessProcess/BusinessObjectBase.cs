﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

/*************************************************************************************************  
  
  Name of the Class			    : BusinessObjectBase                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess
{
    public class BusinessObjectBase
    {
       
       
    }
}
