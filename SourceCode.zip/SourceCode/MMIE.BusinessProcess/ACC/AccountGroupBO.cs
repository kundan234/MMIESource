﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.ACC;
using MMIE.DataAccess.ACC;


/*************************************************************************************************  
  
  Name of the Class			    : AccountGroupBO                      
  
  Description of the class	    : 
  
  Created Date					: 5th jan 2011  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 05/01/2011  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.ACC
{
  public  class AccountGroupBO:BusinessObjectBase
    {

      public List<AccountGroup> GetAccountGroupList(bool All)
      {
          List<AccountGroup> listLookUpList = null;
          try
          {
              //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
              AccountGroupDA objMasterLookup = new AccountGroupDA();
              List<AccountGroup> listLookup = objMasterLookup.GetAccountGroupALL(All);
              listLookUpList = listLookup;
          }
          catch (Exception ex) //Exception of the business layer(itself)//unhandle
          {
              PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
              LogManager.WriteErrorLogInDB(ex);
              throw new BusinessProcessException("4000001", ex);
          }
          return listLookUpList;
      }

        public bool SaveAccountGroup(AccountGroup objAccountGroup)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                AccountGroupDA objAccountGroupDA = new AccountGroupDA();
                status = objAccountGroupDA.SaveAccountGroup(objAccountGroup);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }
        public List<AccountGroup> GetSearchAccountGroup(AccountGroup objAccountGroup)
        {
            List<AccountGroup> lstObject = null;
            try
            {
                AccountGroupDA objAccountGroupDA = new AccountGroupDA();
                lstObject = objAccountGroupDA.GetSearchAccountGroup(objAccountGroup);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
        public List<AccountGroup> GetSearchVoucherGroup(AccountGroup objAccountGroup)
        {
            List<AccountGroup> lstObject = null;
            try
            {
                AccountGroupDA objAccountGroupDA = new AccountGroupDA();
                lstObject = objAccountGroupDA.GetSearchVoucherGroup(objAccountGroup);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
        public List<AccountGroup> GetVoucherGroupLedgerHeader(AccountGroup objAccountGroup)
        {
            List<AccountGroup> listObject = null;
            try
            {
                AccountGroupDA objAccountGroupDA = new AccountGroupDA();
                listObject = objAccountGroupDA.GetVoucherGroupLedgerHeader(objAccountGroup);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return listObject;
        }
        public AccountGroup GetAccountGroupByID(AccountGroup objAccountGroup)
        {
            AccountGroup objRetAccountGroup = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                AccountGroupDA objAccountGroupDA = new AccountGroupDA();
                objRetAccountGroup = objAccountGroupDA.GetAccountGroupByID(objAccountGroup.AccountGroupID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetAccountGroup;
        }


        //public AccountGroup GetVoucherGroupByID(AccountGroup objAccountGroup)
        //{
        //    AccountGroup objRetAccountGroup = null;
        //    try
        //    {
        //        //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
        //        AccountGroupDA objAccountGroupDA = new AccountGroupDA();
        //        objRetAccountGroup = objAccountGroupDA.GetVoucherGroupByID(objAccountGroup.VoucherGroupID);
        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
        //        LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
        //        throw new BusinessProcessException("4000001", ex);
        //    }
        //    return objRetAccountGroup;
        //}


    }
}
