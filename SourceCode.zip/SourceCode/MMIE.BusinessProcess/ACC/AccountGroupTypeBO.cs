﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.ACC;
using MMIE.DataAccess.ACC;

namespace MMIE.BusinessProcess.ACC
{
   public class AccountGroupTypeBO : BusinessObjectBase
    {
       public bool SaveAccountGroupType(AccountGroupType objAccountGroupType)
       {
           bool status = false;
           try
           {
               //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
               AccountGroupTypeDA objAccountGroupDA = new AccountGroupTypeDA();
               status = objAccountGroupDA.SaveAccountGroupType(objAccountGroupType);
           }
           catch (Exception ex) //Exception of the layer(itself)/unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
               LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
               throw new BusinessProcessException("4000001", ex);
           }
           return status;
       }

       public List<AccountGroupType> GetAccountGroupTypeList(AccountGroupType objaccountGroupType)
       {
           List<AccountGroupType> listLookUpList = null;
           try
           {
               //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
               AccountGroupTypeDA objMasterLookup = new AccountGroupTypeDA();

               List<AccountGroupType> listLookup = objMasterLookup.GetSearchAccountGroupMaster(objaccountGroupType);
               listLookUpList = listLookup;
           }
           catch (Exception ex) //Exception of the business layer(itself)//unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
               LogManager.WriteErrorLogInDB(ex);
               throw new BusinessProcessException("4000001", ex);
           }
           return listLookUpList;
       }

       public AccountGroupType GetAccountGroupTypeByID(AccountGroupType objAccountGroup)
       {
           AccountGroupType objBOAccountGroupType = null;
           try
           {
               //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
               AccountGroupTypeDA objAccountGroupTypeDA = new AccountGroupTypeDA();
               objBOAccountGroupType = objAccountGroupTypeDA.GetAccountGroupTypeByID(objAccountGroup.GroupTypeID);
           }
           catch (Exception ex) //Exception of the layer(itself)/unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
               LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
               throw new BusinessProcessException("4000001", ex);
           }
           return objBOAccountGroupType;
       }
    }
}
