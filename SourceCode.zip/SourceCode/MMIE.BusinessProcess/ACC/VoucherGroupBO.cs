﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.ACC;
using MMIE.DataAccess.ACC;

namespace MMIE.BusinessProcess.ACC
{
    public class VoucherGroupBO : BusinessObjectBase
    {

        public bool SaveAccountGroup(AccountGroup objAccountGroup)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                VoucherGroupDA objVoucherGroupDA = new VoucherGroupDA();
                status = objVoucherGroupDA.SaveAccountGroup(objAccountGroup);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public AccountGroup GetVoucherGroupByID(AccountGroup objAccountGroup)
        {
            AccountGroup objRetAccountGroup = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                VoucherGroupDA objAccountGroupDA = new VoucherGroupDA();
                objRetAccountGroup = objAccountGroupDA.GetVoucherGroupByID(objAccountGroup.VoucherGroupID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetAccountGroup;
        }
    }
}
