﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.ACC;
using MMIE.DataAccess.ACC;


/*************************************************************************************************  
  
  Name of the Class			    : CompanyBO                      
  
  Description of the class	    : 
  
  Created Date					: 5th jan 2011  
  
  Developer						: Budha Singh
  
  Modify Date					: 05/01/2011  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.ACC
{
    public class AccountCompanyBO : BusinessObjectBase
    {       
        public List<AccountCompany> GetCompanyDetail()
        {
            List<AccountCompany> listLookUpList = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                AccountCompanyDA objMasterLookup = new AccountCompanyDA();
                List<AccountCompany> listLookup = objMasterLookup.GetCompanyDetail();
                listLookUpList = listLookup;
            }            
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return listLookUpList;
        }

        public bool SaveCompany(AccountCompany  objCompany)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                AccountCompanyDA objAccountCompanyDA = new AccountCompanyDA();
                status = objAccountCompanyDA.SaveCompany(objCompany);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }
        public List<AccountCompany> SearchCompany(AccountCompany objCompany)
        {
            List<AccountCompany> lstObject = null;
            try
            {
                AccountCompanyDA objAccountCompanyDA = new AccountCompanyDA();
                lstObject = objAccountCompanyDA.SearchCompany(objCompany);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public AccountCompany GetCompanyByID(AccountCompany objCompany)
        {
            AccountCompany objRetCompany = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                AccountCompanyDA objAccountCompanyDA = new AccountCompanyDA();
                objRetCompany = objAccountCompanyDA.GetCompanyByID(objCompany);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCompany;
        }
    }
}

