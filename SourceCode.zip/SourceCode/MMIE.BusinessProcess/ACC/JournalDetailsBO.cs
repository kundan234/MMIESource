﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.ACC;
using MMIE.DataAccess.ACC;


namespace MMIE.BusinessProcess.ACC
{
  public  class JournalDetailsBO :BusinessObjectBase
    {

        public bool SaveJournalDetails(JournalDetails objLedger)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                JournalDetailsDA objJournalDetailsDA = new JournalDetailsDA();
                status = objJournalDetailsDA.SaveJournalDetails(objLedger);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

      public bool SaveJournalEntry(JournalDetails objLedger)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                JournalDetailsDA objJournalDetailsDA = new JournalDetailsDA();
                status = objJournalDetailsDA.SaveJournalEntry(objLedger);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }
      public bool SaveJournalEntryForMultiple(JournalDetails objLedger,int TotalRecords)
      {
          bool status = false;
          try
          {
              //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
              JournalDetailsDA objJournalDetailsDA = new JournalDetailsDA();
              status = objJournalDetailsDA.SaveJournalEntryForMultipleRecords(objLedger, TotalRecords);
          }
          catch (Exception ex) //Exception of the layer(itself)/unhandle
          {
              PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
              LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
              throw new BusinessProcessException("4000001", ex);
          }
          return status;
      }

        public List<AccountGroup> GetAccountGroupList(AccountGroup obj)
        {
            List<AccountGroup> listLookUpList = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                JournalDetailsDA objMasterLookup = new JournalDetailsDA();
                List<AccountGroup> listLookup = objMasterLookup.GetMappedAccountGroup(obj);
                listLookUpList = listLookup;
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return listLookUpList;
        }
    }
}
