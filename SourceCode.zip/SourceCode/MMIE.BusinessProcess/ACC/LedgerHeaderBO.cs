﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.ACC;
using MMIE.DataAccess.ACC;


namespace MMIE.BusinessProcess.ACC
{
  public  class LedgerHeaderBO:BusinessObjectBase
    {

            public bool SaveLedgerHeader(LedgerHeader objLedger)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                LedgerHeaderDA objLedgerHeaderDA = new LedgerHeaderDA();
                status = objLedgerHeaderDA.SaveLedgerHeader(objLedger);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

            public List<LedgerHeader> GetSearchLedgerHeader(LedgerHeader objLedgerHeader)
            {
                List<LedgerHeader> lstObject = null;
                try
                {
                    LedgerHeaderDA objAccountGroupDA = new LedgerHeaderDA();
                    lstObject = objAccountGroupDA.GetSearchLedgerHeaderList(objLedgerHeader);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return lstObject;
            }

            public LedgerHeader GetAccountGroupByID(LedgerHeader objAccountGroup)
            {
                LedgerHeader objRetAccountGroup = null;
                try
                {
                    //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                    LedgerHeaderDA objAccountGroupDA = new LedgerHeaderDA();
                    objRetAccountGroup = objAccountGroupDA.GetLedgerAccountByID(objAccountGroup.LedgerAccountID);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return objRetAccountGroup;
            }

    }
    
}
