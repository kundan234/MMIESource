﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.DataAccess.BANK;
using MMIE.Data.BANK;



/*************************************************************************************************  
  
  Name of the Class			    : UserAdminBO                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: 
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/
namespace MMIE.BusinessProcess.BANK
{
    public class BankAccountBO
    {
        #region bank Account
        /// <summary>
        /// Save bank Account
        /// </summary>
        /// <param name="objBankAccount"></param>
        /// <returns></returns>
        public bool SaveBankAccount(BankAccount objBankAccount)
        {
            bool status = false;
            try
            {
                BankAccountDA objBankAccountDA = new BankAccountDA();
                status = objBankAccountDA.SaveBankAccount(objBankAccount);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<BankAccount> GetSearchBankAccount(BankAccount objBankAccount,bool All)
        {
            List<BankAccount> lstObject = null;
            try
            {
                BankAccountDA objBankAccountDA = new BankAccountDA();
                lstObject = objBankAccountDA.GetSearchBankAccountList(objBankAccount,All);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
        public BankAccount GetBankAccountByID(BankAccount objBankAccount)
        {
            BankAccount objRetBankAccount = new BankAccount();
            try
            {
                BankAccountDA objBankAccountDA = new BankAccountDA();
                //objRetBankAccount = objBankAccountDA.GetBankAccountByID(objBankAccount.BankAccountID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetBankAccount;
        }
        #endregion

        #region Bank Account Details
        
        /// <summary>
        /// Save bank Account Deatils
        /// </summary>
        /// <param name="objBankAccountDetails"></param>
        /// <returns></returns>
        public bool SaveBankAccountDetails(BankAccountDetails objBankAccountDetails)
        {
            bool status = false;
            try
            {
                BankAccountDetailsDA objBankAccountDetailsDA = new BankAccountDetailsDA();
                status = objBankAccountDetailsDA.SaveBankAccountDetails(objBankAccountDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        /// <summary>
        /// Get Bank Account details by searching conditions
        /// </summary>
        /// <param name="objBankAccountDetails"></param>
        /// <returns></returns>
        public List<MMIE.Data.BANK.BankAccountDetails> GetSearchBankAccountDetails(BankAccountDetails objBankAccountDetails)
        {
            List<MMIE.Data.BANK.BankAccountDetails> lstObject = null;
            try
            {
                BankAccountDetailsDA objBankAccountDA = new BankAccountDetailsDA();
                lstObject = objBankAccountDA.GetSearchBankAccountDetailsList(objBankAccountDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        //public BankAccountDetails GetBankAccountDetailsByID(BankAccountDetails objBankAccount)
        //{
        //    BankAccount objRetBankAccount = new BankAccount();
        //    try
        //    {
        //        BankAccountDetailsDA objBankAccountDA = new BankAccountDetailsDA();
        //        objRetBankAccount = objBankAccountDA.getGetBankAccountByID(objBankAccount.BankAccountID);
        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
        //        LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
        //        throw new BusinessProcessException("4000001", ex);
        //    }
        //    return objRetBankAccount;
        //}
        #endregion
    }
}
