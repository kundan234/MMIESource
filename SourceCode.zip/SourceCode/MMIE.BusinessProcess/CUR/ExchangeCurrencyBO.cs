﻿using System;
using MMIE.Data.CUR;
using MMIE.Common.ExceptionHandler;
using MMIE.Common.Logging;
using MMIE.DataAccess.CUR;
using System.Data;


namespace MMIE.BusinessProcess.CUR
{
    public class ExchangeCurrencyBO
    {
        public string SaveExchangeCurrency(ExchangeCurrency objExchangeCurrency)
        {
            string strUpadted = "";
            try
            {

                ExchangeCurrencyDA objExchangeCurrencyDA = new ExchangeCurrencyDA();
                strUpadted = objExchangeCurrencyDA.SaveExchangeCurrency(objExchangeCurrency);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return strUpadted;
        }

        public DataSet GetPurchageCurrency(ExchangeCurrency argExchangeCurrency)
        {
            DataSet ds = null;
            try
            {

                ExchangeCurrencyDA objExchangeCurrencyDA = new ExchangeCurrencyDA();
                ds = objExchangeCurrencyDA.GetPurchageCurrency(argExchangeCurrency);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return ds;
        }

        public DataSet GetPurchageCurrencyReport(ExchangeCurrency argExchangeCurrency)
        {
            DataSet ds = null;
            try
            {

                ExchangeCurrencyDA objExchangeCurrencyDA = new ExchangeCurrencyDA();
                ds = objExchangeCurrencyDA.GetPurchageCurrencyReport(argExchangeCurrency);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }

            return ds;
        }

        public void UpdateCompanyBalance(ExchangeCurrency objExchangeCurrency)
        {
            try
            {
                ExchangeCurrencyDA objExchangeCurrencyDA = new ExchangeCurrencyDA();
                objExchangeCurrencyDA.UpdateCompanyBalance(objExchangeCurrency);
            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new DataAccessException("5000001", ex);
            }
        }

       
    }
}
