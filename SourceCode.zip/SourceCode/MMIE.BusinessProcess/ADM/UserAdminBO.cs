﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Data.Common;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.DataAccess.ADM;

/*************************************************************************************************  
  
  Name of the Class			    : UserAdminBO                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: 
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.ADM
{
    public class UserAdminBO : BusinessObjectBase
    {

        #region User Login

        public UserCE ValidateLogin(UserLogin objUser)
        {
            UserCE objUserCE = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                objUserCE = objUserAdminDA.ValidateLogin(objUser);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objUserCE;
        }

        public bool SaveUser(UserCE objUserCE)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.SaveUser(objUserCE);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<UserLogin> SearchUserLogin(UserLogin objUserLogin)
        {
            List<UserLogin> lstObject = null;
            try
            {
                UserAdminDA objUserAdminDA = new UserAdminDA();
                lstObject = objUserAdminDA.SearchUserLogin(objUserLogin);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public UserCE GetUserLoginByID(UserLogin objUserLogin)
        {
            UserCE objUserCE = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                objUserCE = objUserAdminDA.GetUserLoginByID(objUserLogin);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objUserCE;
        }

        public bool DeleteUser(UserLogin objUserLogin)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.DeleteUser(objUserLogin);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public bool UpdateLoginSchedule(UserLogin objUserLogin)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.UpdateLoginSchedule(objUserLogin);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public UserLogin GetLoginSchedule(int intLoginId)
        {
            UserLogin objUserLogin = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                objUserLogin = objUserAdminDA.GetLoginSchedule(intLoginId);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objUserLogin;
        }
        #endregion

        #region Site Map

        public List<SiteMap> GetAllSiteMapItem(SiteMap objSiteMap)
        {
            List<SiteMap> objUserCE = null;
            try
            {
                UserAdminDA objUserAdminDA = new UserAdminDA();
                objUserCE = objUserAdminDA.GetAllSiteMapItem(objSiteMap);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objUserCE;
        }

        public List<SiteMap> GetSiteMapRoleByRoleID(Role objRole)
        {
            List<SiteMap> objUserCE = null;
            try
            {
                UserAdminDA objUserAdminDA = new UserAdminDA();
                objUserCE = objUserAdminDA.GetSiteMapRoleByRoleID(objRole);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objUserCE;
        }

        public bool SaveSiteMapRole(Role objRole)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.SaveSiteMapRole(objRole);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        #endregion

        #region Role

        public bool SaveRole(Role objRole)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.SaveRole(objRole);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<Role> SearchRole(Role objRole)
        {
            List<Role> lstObject = null;
            try
            {
                UserAdminDA objUserAdminDA = new UserAdminDA();
                lstObject = objUserAdminDA.SearchRole(objRole);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public Role GetRoleByID(Role objRole)
        {
            Role objRetRole = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                objRetRole = objUserAdminDA.GetRoleByID(objRole);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetRole;
        }

        public bool DeleteRole(Role objRole)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.DeleteRole(objRole);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        #endregion


        #region Checkout User
        public bool CheckoutUser(UserLogin objRole)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.CheckoutUser(objRole);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public bool CheckInUser(UserLogin objRole)
        {
            bool status = false;
            try
            {

                objRole.ActionType = EnumActionType.Update;
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.CheckoutUser(objRole);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public bool CheckInUserList(UserLogin objRole)
        {
            bool status = false;
            try
            {

                objRole.ActionType = EnumActionType.Update;
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.CheckInUser(objRole);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public List<UserLogin> SearchCheckedOutUser(UserLogin objUserLogin)
        {
            List<UserLogin> lstObject = null;
            try
            {
                UserAdminDA objUserAdminDA = new UserAdminDA();
                lstObject = objUserAdminDA.SearchCheckedOutUser(objUserLogin);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
        #endregion

        #region DBBackUp
        public bool DataBaseBackUp(string path, string name, string fileName, string backupName, string addedBy)
        {
            bool status = false;
            try
            {
                UserAdminDA objUserAdminDA = new UserAdminDA();
                status = objUserAdminDA.DatabaseBackUp(path, name, fileName, backupName, addedBy);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<DatabaseBackUp> GetBackupList()
        {
            List<DatabaseBackUp> lstObject = null;
            try
            {
                UserAdminDA objUserAdminDA = new UserAdminDA();
                lstObject = objUserAdminDA.GetBackupList();
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            
            return lstObject;
        }

        #endregion



    }
}

