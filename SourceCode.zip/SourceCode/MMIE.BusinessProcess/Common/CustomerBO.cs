﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common ;
/*************************************************************************************************  
  
  Name of the Class			    : CustomerBO                      
  
  Description of the class	    : 
  
  Created Date					: 19 oct 2011  
  
  Developer						: Mithlesh
  
  Modify Date					: 19/10/2011  
  
  Modified By Developer			: Mithlesh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.Common
{

   public class CustomerBO : BusinessObjectBase
    {
        //-----------------------------new code by mk on 19/10/2010--------------
   #region Customer
       public int SaveCustomer(Customer objCustomer)
        {
            int status = 0;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CustomerDA objCustomerDA = new CustomerDA();
                status = objCustomerDA.SaveCustomer(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

       //------------------------method for save customer document--------------
       public bool SaveCustomerDocument(List<CustomerDocument> objCustomer)
       {
           bool status = false;
           try
           {
               //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
               CustomerDA objCustomerDA = new CustomerDA();
               foreach (CustomerDocument obj in objCustomer)
               {
                   status = objCustomerDA.SaveCustomerDocument(obj);
               }
               status = true;
           }
           catch (Exception ex) //Exception of the layer(itself)/unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
               LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
               throw new BusinessProcessException("4000001", ex);
           }
           return status;
       }
       //------------------

       //--------------------------------------------------//

       public List<CustomerDocument> SearchCustomerDocument(int id)
       {
           List<CustomerDocument> lstObject = null;
           try
           {
               CustomerDA objCustomerDA = new CustomerDA();
               lstObject = objCustomerDA.SearchCustomerDocument(id);
           }
           catch (Exception ex) //Exception of the layer(itself)/unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
               LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
               throw new BusinessProcessException("4000001", ex);
           }
           return lstObject;
       }
       //---------------------------------------------////
       /// <summary>
       /// 
       /// </summary>
       /// <param name="objCustomer"></param>
       /// <returns></returns>




        public List<Customer> SearchCustomer(Customer objCustomer)
        {
            List<Customer> lstObject = null;
            try
            {
                CustomerDA objCustomerDA = new CustomerDA();
                lstObject = objCustomerDA.SearchCustomer(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
       
        public Customer GetCustomerByID(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CustomerDA objCustomerDA = new CustomerDA();
                objRetCustomer = objCustomerDA.GetCustomerByID(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCustomer;
        }
        public Customer GetCustomerDetailsByID(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CustomerDA objCustomerDA = new CustomerDA();
                objRetCustomer = objCustomerDA.GetCustomerDetailsByID(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCustomer;
        }

        public bool DeleteCustomer(Customer objCustomer)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CustomerDA objCustomerDA = new CustomerDA();
                status = objCustomerDA.DeleteCustomer(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public bool DisableCustomer(Customer objCustomer)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CustomerDA objCustomerDA = new CustomerDA();
                status = objCustomerDA.DisableCustomer(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        #endregion
        #region City Country Functions
        public Customer GetCountryByName(Customer  objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CustomerDA objCustomerDA = new CustomerDA();
                objRetCustomer = objCustomerDA.GetCountryByName(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCustomer;
        }

        #endregion

    }
}
