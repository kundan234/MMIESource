﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;
/*************************************************************************************************  
  
  Name of the Class			    : CustomerBO                      
  
  Description of the class	    : 
  
  Created Date					: 19 oct 2011  
  
  Developer						: Mithlesh
  
  Modify Date					: 19/10/2011  
  
  Modified By Developer			: Mithlesh 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.Common
{
    public class RemarksBO:BusinessObjectBase
    {
        public bool SaveRemarks(Remarks objRemarks)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                RemarksDA objUnitDA = new RemarksDA();
                status = objUnitDA.SaveRemarks(objRemarks);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }



        public List<Remarks> GetRemarksList(bool All)
        {
            List<Remarks> lstUnit = null;
            try
            {
                RemarksDA objUnitDA = new RemarksDA();
                lstUnit = objUnitDA.GetRemarksList(All);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstUnit;
        }

        

        public Remarks GetRemarksByID(int ID)
        {
            Remarks objRemarks = new Remarks();
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                RemarksDA objUnitDA = new RemarksDA();
             
                objRemarks = objUnitDA.GetRemarksByID(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRemarks;
        }

        public Remarks GetRemarksByCustomerType(string paymentMode)
        {
            Remarks objRemarks = new Remarks();
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                RemarksDA objUnitDA = new RemarksDA();

                objRemarks = objUnitDA.GetRemarksBycustomertype(paymentMode);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRemarks;
        }
        public List<Remarks> GetSearchRemarksList(Remarks objRemarks)
        {
            List<Remarks> lstUnit = null;
            try
            {
                RemarksDA objUnitDA = new RemarksDA();
                lstUnit = objUnitDA.GetSearchRemarksList(objRemarks);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstUnit;
        }

    }
}
