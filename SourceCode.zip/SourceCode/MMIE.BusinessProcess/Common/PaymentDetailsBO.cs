﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;
/*************************************************************************************************  
  
  Name of the Class			    : PaymentDetailsBO                      
  
  Description of the class	    : 
  
  Created Date					: 1 Dec 2011  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 1/11/2011  
  
  Modified By Developer			: Kundan Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.BusinessProcess.Common
{
    public class PaymentDetailsBO : BusinessObjectBase
    {

        #region PaymentDetailsBO

        public bool UpdatePaymentAdjustmentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                status = objPaymentDetailsDA.UpdatePaymentAdjustmentDetails(objPaymentDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }
        /// <summary>
        /// Accept Payement for the sales order - Including partial payment and lumsum payemnt
        /// </summary>
        /// <param name="objPaymentDetails"></param>
        /// <returns></returns>
        public bool SaveBillPaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                status = objPaymentDetailsDA.SaveBillPaymentDetails(objPaymentDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        //Function Update the payement Related Data
        public bool SavePaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                status = objPaymentDetailsDA.SavePaymentDetails(objPaymentDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

      

        public bool SaveCheckOutPaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                status = objPaymentDetailsDA.SaveCheckOutPaymentDetails(objPaymentDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public bool SaveSafoBoxDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                status = objPaymentDetailsDA.SaveSafeBoxDetails(objPaymentDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

   

        public List<PaymentDetails> GetPaymentDetailsListByBillID(int ID)
        {
            List<PaymentDetails> lstObject = null;
            try
            {
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                lstObject = objPaymentDetailsDA.GetPaymentDetailsListByBillID(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public List<PaymentDetails> GetSearchUserCollection(PaymentDetails obj)
        {
            List<PaymentDetails> lstObject = null;
            try
            {
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                lstObject = objPaymentDetailsDA.GetSearchUserCollection(obj);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
        public List<PaymentDetails> GetPaymentDetailsListByOrderID(string OrderNumber)
        {
            List<PaymentDetails> lstObject = null;
            try
            {
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                lstObject = objPaymentDetailsDA.GetPaymentDetailsListByOrderID(OrderNumber);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public List<PaymentDetails> GetPaymentDetailsListByOrderCR(string OrderNumber)
        {
            List<PaymentDetails> lstObject = null;
            try
            {
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                lstObject = objPaymentDetailsDA.GetPaymentDetailsListByOrderIDCR(OrderNumber);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public PaymentDetails GetPaymentDetailsByID(int ID)
        {
            PaymentDetails objRetProduct = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                objRetProduct = objPaymentDetailsDA.GetPaymentDetailsByID(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetProduct;
        }



        public List<PaymentDetails> GetSearchPaymentDetails(PaymentDetails obj)
        {
            List<PaymentDetails> lstObject = null;
            try
            {
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                lstObject = objPaymentDetailsDA.GetSearchPaymentDetails(obj);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }




        #endregion
        #region Customer Payment History
        public List<PaymentDetails> GetSearchPaymentDetailsCustomer(int ID)
        {
            List<PaymentDetails> lstObject = null;
            try
            {
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                lstObject = objPaymentDetailsDA.GetSearchPaymentDetailsCustomer(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
#endregion

        #region InvoicePaymentDetails

        public List<PaymentDetails> GetPaymentDetailsListByInvoiceID(int ID)
        {
            List<PaymentDetails> lstObject = null;
            try
            {
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                lstObject = objPaymentDetailsDA.GetPaymentDetailsListByInvoiceID(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public bool SaveInvoicePaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                status = objPaymentDetailsDA.SaveInvoicePaymentDetails(objPaymentDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        #endregion

        public DataSet GetOtherPaymentDetails(DateTime dtFromDate, DateTime dtTodate)
        {
            DataSet ds = new DataSet();
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                ds = objPaymentDetailsDA.GetOtherPaymentDetails(dtFromDate, dtTodate);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return ds;
        }

        #region Salary Payment
        public bool SaveEmployeePaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                status = objPaymentDetailsDA.SaveEmployeePaymentDetails(objPaymentDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        #endregion 

        #region Loan Payment Details

        public bool SaveEmployeeLoanPaymentDetails(PaymentDetails objPaymentDetails)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PaymentDetailsDA objPaymentDetailsDA = new PaymentDetailsDA();
                status = objPaymentDetailsDA.SaveEmployeeLoanPaymentDetails(objPaymentDetails);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        #endregion
    }
}
