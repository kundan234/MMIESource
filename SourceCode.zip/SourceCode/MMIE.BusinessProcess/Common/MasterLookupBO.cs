﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;

/*************************************************************************************************  
  
  Name of the Class			    : MasterLookupBO                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.Common
{
    public class MasterLookupBO : BusinessObjectBase
    {       

        public List<LookupItem> GetLookupsList(LookupNames lookupName)
        {
            List<LookupItem> listLookUpList = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                MasterLookupDA objMasterLookup = new MasterLookupDA();
                List<LookupItem> listLookup = objMasterLookup.GetLookupsList(lookupName);
                listLookUpList = listLookup;
            }            
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return listLookUpList;
        }

        public List<LookupItem> GetLookupsList(int currentIndex, int pageSize,LookupNames lookupName)
        {
            List<LookupItem> listLookUpList = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                MasterLookupDA objMasterLookup = new MasterLookupDA();
                List<LookupItem> listLookup = objMasterLookup.GetLookupsList(currentIndex, pageSize, lookupName);
                listLookUpList = listLookup;
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return listLookUpList;
        }
        public List<LookupItem> GetLookupItemListByName(LookupItem objLookupItem, LookupNames lookupName)
        {
            List<LookupItem> lstObject = null;
            try
            {
                MasterLookupDA objMasterLookup = new MasterLookupDA();
                lstObject = objMasterLookup.GetLookupItemListByName( objLookupItem, lookupName);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
        public LookupItem GetLookupItemByID(int itemID, LookupNames lookupName)
        {
            LookupItem lookupItem = null;
            try
            {
                MasterLookupDA objMasterLookup = new MasterLookupDA();
                lookupItem = objMasterLookup.GetLookupItemByID(itemID, lookupName);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return lookupItem;
        }
        public List<LookupItem> GetLookupItemListByID(int itemID, LookupNames lookupName)
        {
            List<LookupItem> lookupItem = null;
            try
            {
                MasterLookupDA objMasterLookup = new MasterLookupDA();
                lookupItem = objMasterLookup.GetLookupItemListByID(itemID, lookupName);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return lookupItem;
        }
        public List<LookupItem> GetLookupItemListByIDs(int itemID, int itemID1, LookupNames lookupName)
        {
            List<LookupItem> lookupItem = null;
            try
            {
                MasterLookupDA objMasterLookup = new MasterLookupDA();
                lookupItem = objMasterLookup.GetLookupItemListByIDs(itemID, itemID1, lookupName);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return lookupItem;
        }
        public List<LookupItem> GetLookupItemListByCategoryName(string categoryName)
        {
            List<LookupItem> listLookUpList = null;
            try
            {
                MasterLookupDA objMasterLookupDA = new MasterLookupDA();
                listLookUpList = objMasterLookupDA.GetLookupItemListByCategoryName(categoryName);                
            }           
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return listLookUpList;
        }
        public String UpdateMasterItem(MasterItem objMasterItem)
        {
            String strResult = "";
            try
            {
                MasterLookupDA objMasterLookupDA = new MasterLookupDA();
                strResult = objMasterLookupDA.UpdateMasterItem(objMasterItem);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return strResult;
        }
        public int SaveLookupItem(LookupItem item, LookupNames lookupName)
        {
            int recordAffected;
            try
            {
                MasterLookupDA objMasterLookupDA = new MasterLookupDA();
                recordAffected = objMasterLookupDA.SaveLookupItem(item, lookupName);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return recordAffected;
        }

        public int UpdateLookupItem(LookupItem item, LookupNames lookupName)
        {
            int recordAffected;
            try
            {
                MasterLookupDA objMasterLookupDA = new MasterLookupDA();
                recordAffected = objMasterLookupDA.UpdateLookupItem(item, lookupName);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return recordAffected;
        }
        //Service Master

        //public List<Service> GetService(Service objServiceItem)
        //{
        //    List<Service> listServiceList = null;
        //    try
        //    {
        //        //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
        //        ServiceDA objServiceDA = new ServiceDA();
        //        List<Service> listService = objServiceDA.GetService(objServiceItem);
        //        listServiceList = listService;
        //    }
        //    catch (Exception ex) //Exception of the business layer(itself)//unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new BusinessProcessException("4000001", ex);
        //    }
        //    return listServiceList;
        //}

        //public bool UpdateService(Service objServiceItem)
        //{
        //    bool Statues = false;
        //    try
        //    {
        //        ServiceDA objServiceDA = new ServiceDA();
        //        Statues = objServiceDA.UpdateService(objServiceItem);
        //    }
        //    catch (Exception ex) //Exception of the business layer(itself)//unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
        //        LogManager.WriteErrorLogInDB(ex);
        //        throw new BusinessProcessException("4000001", ex);
        //    }
        //    return Statues;
        //}

        public List<LookupItem> GetWardByFloorID(int floorID)
        {
            List<LookupItem> listServiceList = null;
            try
            {
                MasterLookupDA objServiceDA = new MasterLookupDA();
                List<LookupItem> listService = objServiceDA.GetWardByFloorID(floorID);
                listServiceList = listService;
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return listServiceList;
        }

        public List<LookupItem> GetRoomByFloorIDWardID(int floorID, int wardID)
        {
            List<LookupItem> listServiceList = null;
            try
            {
                MasterLookupDA objServiceDA = new MasterLookupDA();
                List<LookupItem> listService = objServiceDA.GetRoomByFloorIDWardID(floorID, wardID);
                listServiceList = listService;
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return listServiceList;
        }
    }
}

