﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;
/*************************************************************************************************  
  
  Name of the Class			    : ProductBO                      
  
  Description of the class	    : 
  
  Created Date					: 20 oct 2011  
  
  Developer						: Kundan
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: Kundan 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.Common
{
   public class ProductUnitPriceBO: BusinessObjectBase
    {
       public List<Product> SearchProductUnitList(Product objProduct)
       {
           List<Product> lstObject = null;
           try
           {
               ProductUnitPriceDA objProductDA = new ProductUnitPriceDA();
               lstObject = objProductDA.SearchProductUnitList(objProduct);
           }
           catch (Exception ex) //Exception of the layer(itself)/unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
               LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
               throw new BusinessProcessException("4000001", ex);
           }
           return lstObject;
       }



       public Product GetProductUnitByID(Product objProduct)
       {
           Product objRetProduct = null;
           try
           {
               //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
               ProductUnitPriceDA objProductDA = new ProductUnitPriceDA();
               objRetProduct = objProductDA.GetProductUnitByID(objProduct);
           }
           catch (Exception ex) //Exception of the layer(itself)/unhandle
           {
               PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
               LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
               throw new BusinessProcessException("4000001", ex);
           }
           return objRetProduct;
       }

    }
}
