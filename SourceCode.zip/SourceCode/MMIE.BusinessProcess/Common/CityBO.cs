﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;
/*************************************************************************************************  
  
  Name of the Class			    : CityBO                      
  
  Description of the class	    : 
  
  Created Date					: 27 NOV 2011  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: Kundan Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.BusinessProcess.Common
{
  public  class CityBO:BusinessObjectBase
    {
        
           
            #region City
            public bool SaveCity(CityMST objCity)
            {
                bool status = false;
                try
                {
                    //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                    CityDA objCityDA = new CityDA();
                    status = objCityDA.SaveCity(objCity);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return status;
            }


            public List<CityMST> GetCityList(bool All)
            {
                List<CityMST> lstObject = null;
                try
                {
                    CityDA objCityDA = new CityDA();
                    lstObject = objCityDA.GetCityList(All);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return lstObject;
            }


            public List<CityMST> GetCityListSearch(string SearchCityName, string SearchStateName="", string SearchZipCode="",string SearchStateCode="")
            {



                List<CityMST> lstObject = null;
                try
                {
                    string StateMent = "";

                    if (SearchCityName != "")
                    {
                        StateMent += "  CityName Like '" + SearchCityName.Trim() + "%' ";
                    }
                    if (SearchStateName != "")
                    {
                        StateMent += "and State_Name Like '" + SearchStateName.Trim() + "%' ";
                    }



                    if (SearchZipCode != "")
                    {
                        StateMent += "and Zip_Code ='" + SearchZipCode.Trim() + "' ";
                    }

                    if (SearchStateCode != "")
                    {
                        StateMent += "and State_Code = '" + SearchStateCode.Trim() + "'";
                    }




                    CityDA objCityDA = new CityDA();
                    lstObject = objCityDA.GetCityListSearch(StateMent);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return lstObject;
            }
            public CityMST GetCityByID(int ID)
            {
                CityMST objRetProduct = null;
                try
                {
                    //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                    CityDA objCityDA = new CityDA();
                    objRetProduct = objCityDA.GetCityByID(ID);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return objRetProduct;
            }


            #endregion


        }

    
}
