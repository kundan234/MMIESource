﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;
/*************************************************************************************************  
  
  Name of the Class			    : DepositTransactionBO                      
  
  Description of the class	    : 
  
  Created Date					: 17 NOV 2011  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: Kundan Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.Common
{
    public class DepositTransactionBO : BusinessObjectBase
    {
        //-----------------------------new code by mk on 17/11/2011--------------
        #region DepositTransaction
        public bool SaveDepositTransaction(DepositTransaction objDepositTransaction)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                DepositTransactionDA objDepositTransactionDA = new DepositTransactionDA();
                status = objDepositTransactionDA.SaveTransaction(objDepositTransaction);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public int DebitAmount(DepositTransaction objDepositTransaction)
        {
            int status = 0;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                DepositTransactionDA objDepositTransactionDA = new DepositTransactionDA();
                status = objDepositTransactionDA.DebitAmount(objDepositTransaction);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public int CreditAmount(DepositTransaction objDepositTransaction)
        {
            int status = 0;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                DepositTransactionDA objDepositTransactionDA = new DepositTransactionDA();
                status = objDepositTransactionDA.CreditAmount(objDepositTransaction);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<DepositTransaction> GetDepositTransactionList(int ID)
        {
            List<DepositTransaction> lstObject = null;
            try
            {
                DepositTransactionDA objDepositTransactionDA = new DepositTransactionDA();
                lstObject = objDepositTransactionDA.GetDepositTransactionList(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public DepositTransaction GetDepositTransactionByID(int ID)
        {
            DepositTransaction objDepositTransaction = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                DepositTransactionDA objCurrencyDA = new DepositTransactionDA();
                objDepositTransaction = objCurrencyDA.GetDepositTransactionByID(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objDepositTransaction;
        }


        #endregion

    }
}
