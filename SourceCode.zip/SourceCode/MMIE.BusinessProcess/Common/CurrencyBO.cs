﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;
/*************************************************************************************************  
  
  Name of the Class			    : CurrencyBO                      
  
  Description of the class	    : 
  
  Created Date					: 17 NOV 2011  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: Kundan Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.Common
{
  public  class CurrencyBO
    {
        //-----------------------------new code by mk on 17/11/2011--------------
        #region Currency
      public bool SaveCurrency(Currency objCurrency)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CurrencyDA objCurrencyDA = new CurrencyDA();
                status = objCurrencyDA.SaveCurrency(objCurrency);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

      public bool SavePurchaseCurrencyMST(Currency objCurrency)
      {
          bool status = false;
          try
          {
              //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
              CurrencyDA objCurrencyDA = new CurrencyDA();
              status = objCurrencyDA.SavePurchaseCurrencyMST(objCurrency);
          }
          catch (Exception ex) //Exception of the layer(itself)/unhandle
          {
              PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
              LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
              throw new BusinessProcessException("4000001", ex);
          }
          return status;
      }


      public List<Currency> GetCurrencyList(bool All)
        {
            List<Currency> lstObject = null;
            try
            {
                CurrencyDA objCurrencyDA = new CurrencyDA();
                lstObject = objCurrencyDA.GetCurrencyList(All);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

      public List<Currency> GetPurchaseCurrencyList(bool All)
      {
          List<Currency> lstObject = null;
          try
          {
              CurrencyDA objCurrencyDA = new CurrencyDA();
              lstObject = objCurrencyDA.GetPurchaseCurrencyList(All);
          }
          catch (Exception ex) //Exception of the layer(itself)/unhandle
          {
              PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
              LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
              throw new BusinessProcessException("4000001", ex);
          }
          return lstObject;
      }

      public Currency GetCurrencyByID(int ID)
        {
            Currency objRetProduct = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CurrencyDA objCurrencyDA = new CurrencyDA();
                objRetProduct = objCurrencyDA.GetCurrencyByID(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetProduct;
        }

       
        #endregion


    }
}
