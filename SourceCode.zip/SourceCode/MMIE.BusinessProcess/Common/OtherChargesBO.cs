﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;


/*************************************************************************************************  
  
  Name of the Class			    : OtherChargesBO                      
  
  Description of the class	    : 
  
  Created Date					: 24th Mov 2011  
  
  Developer						: Kundan  Singh Jeena
  
  Modify Date					: 24/11/2011  
  
  Modified By Developer			: Kundan  Singh  Jeena
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.Common
{
    public class OtherChargesBO
    {
        #region OtherCharges
        public bool SaveOtherCharges(OtherCharges objOtherCharges)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                OtherChargesDA objOtherChargesDA = new OtherChargesDA();
                status = objOtherChargesDA.SaveOtherCharges(objOtherCharges);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<OtherCharges> GetSearchOtherCharges(OtherCharges objOtherCharges)
        {
            List<OtherCharges> lstOtherCharges = null;
            try
            {
                OtherChargesDA objOtherChargesDA = new OtherChargesDA();
                lstOtherCharges = objOtherChargesDA.GetSearchOtherCharges(objOtherCharges);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstOtherCharges;
        }


       

        public OtherCharges GetOtherChargeByID(OtherCharges objOtherCharge)
        {
            OtherCharges objBOOtherCharge = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                OtherChargesDA objAccountGroupTypeDA = new OtherChargesDA();
                objBOOtherCharge = objAccountGroupTypeDA.GetAccountGroupTypeByID(objOtherCharge.ChargeID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objBOOtherCharge;
        }

    }
#endregion
}


