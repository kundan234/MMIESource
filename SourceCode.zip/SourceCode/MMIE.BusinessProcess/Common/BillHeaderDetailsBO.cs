﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;

/*************************************************************************************************  
  
  Name of the Class			    : TaxBO                      
  
  Description of the class	    : 
  
  Created Date					: 24th Mov 2011  
  
  Developer						: Kundan  Singh Jeena
  
  Modify Date					: 24/11/2011  
  
  Modified By Developer			: Kundan  Singh  Jeena
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.Common
{
    public class BillHeaderDetailsBO : BaseData
    {
        public List<Order> GetSearchBillHeader(Order objOrder)
        {
            List<Order> lstObject = null;
            try
            {
                BillHeaderDetailsDA objOrderDA = new BillHeaderDetailsDA();
                lstObject = objOrderDA.GetSearchBillHeader(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
        public List<Order> GetSearchOrderDetails(Order objOrder)
        {
            List<Order> lstObject = null;
            try
            {
                BillHeaderDetailsDA objOrderDA = new BillHeaderDetailsDA();
                lstObject = objOrderDA.GetSearchOrderDetails(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
    }
}
