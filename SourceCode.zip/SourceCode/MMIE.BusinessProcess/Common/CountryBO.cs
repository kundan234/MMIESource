﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;


/*************************************************************************************************  
  
  Name of the Class			    : TaxBO                      
  
  Description of the class	    : 
  
  Created Date					: 24th Mov 2011  
  
  Developer						: Kundan  Singh Jeena
  
  Modify Date					: 24/11/2011  
  
  Modified By Developer			: Kundan  Singh  Jeena
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.Common
{
  public   class CountryBO:BusinessObjectBase
    {


        #region Country
        //public bool SaveTax(Country objCountry)
        //{
        //    bool status = false;
        //    try
        //    {
        //        //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
        //        CountryDA objCountryDA = new CountryDA();
        //        status = objCountryDA.SaveCountry(objCountry);
        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
        //        LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
        //        throw new BusinessProcessException("4000001", ex);
        //    }
        //    return status;
        //}

      public List<Country> GetCountryList(bool All)
        {
            List<Country> lstTax = null;
            try
            {
                CountryDA objCountryDA = new CountryDA();
                lstTax = objCountryDA.GetCountryList(All);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstTax;
        }

        //public Tax GetTaxByID(int ID)
        //{
        //    Tax objRetTax = null;
        //    try
        //    {
        //        //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
        //        TaxDA objTaxDA = new TaxDA();
        //        objRetTax = objTaxDA.GetTaxByID(ID);
        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
        //        LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
        //        throw new BusinessProcessException("4000001", ex);
        //    }
        //    return objRetTax;
        //}



        #endregion


    }
}
