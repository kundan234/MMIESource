﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;
/*************************************************************************************************  
  
  Name of the Class			    : ProductBO                      
  
  Description of the class	    : 
  
  Created Date					: 20 oct 2011  
  
  Developer						: Kundan
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: Kundan 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.Common
{

    public class ProductBO : BusinessObjectBase
    {
        //-----------------------------new code by mk on 19/10/2010--------------
        #region Product
        public bool SaveProduct(Product objProduct)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                ProductDA objProductDA = new ProductDA();
                status = objProductDA.SaveProduct(objProduct);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public List<Product> SearchProudct(Product objProduct)
        {
            List<Product> lstObject = null;
            try
            {
                ProductDA objProductDA = new ProductDA();
                lstObject = objProductDA.SearchProduct(objProduct);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public Product GetProductByID(Product objProduct)
        {
            Product objRetProduct = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                ProductDA objProductDA = new ProductDA();
                objRetProduct = objProductDA.GetProductByID(objProduct);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetProduct;
        }
        public Product GetProductEntryByID(Product objProduct)
        {
            Product objRetProduct = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                ProductDA objProductDA = new ProductDA();
                objRetProduct = objProductDA.GetProductByID(objProduct);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetProduct;
        }

        public bool DeleteProduct(Product objProduct)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                ProductDA objProductDA = new ProductDA();
                status = objProductDA.DeleteProduct(objProduct);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        #endregion

    }
}
