﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;

/*************************************************************************************************  
  
  Name of the Class			    : BankBO                      
  
  Description of the class	    : 
  
  Created Date					: 27 NOV 2011  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: Kundan Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.BusinessProcess.Common
{
  public  class BankBO:BusinessObjectBase
    {
        
           
            #region Bank
            public bool SaveBank(Bank objBank)
            {
                bool status = false;
                try
                {
                    //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                    BankDA objBankDA = new BankDA();
                    status = objBankDA.SaveBank(objBank);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return status;
            }


            public List<Bank> GetBankList(bool All)
            {
                List<Bank> lstObject = null;
                try
                {
                    BankDA objBankDA = new BankDA();
                    lstObject = objBankDA.GetBankList(All);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return lstObject;
            }


            public List<Bank> GetBankListSearch(Bank objBank)
            {



                List<Bank> lstObject = null;
                try
                {
                     




                    BankDA objBankDA = new BankDA();
                    lstObject = objBankDA.GetBankListSearch(objBank);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return lstObject;
            }
            public Bank GetBankByID(int ID)
            {
                Bank objRetProduct = null;
                try
                {
                    //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                    BankDA objBankDA = new BankDA();
                    objRetProduct = objBankDA.GetBankByID(ID);
                }
                catch (Exception ex) //Exception of the layer(itself)/unhandle
                {
                    PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                    LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                    throw new BusinessProcessException("4000001", ex);
                }
                return objRetProduct;
            }


            #endregion


        }

    
}
