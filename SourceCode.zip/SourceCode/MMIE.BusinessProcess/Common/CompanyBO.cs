﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;


/*************************************************************************************************  
  
  Name of the Class			    : CompanyBO                      
  
  Description of the class	    : 
  
  Created Date					: 5th jan 2011  
  
  Developer						: Budha Singh
  
  Modify Date					: 05/01/2011  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.Common
{
    public class CompanyBO : BusinessObjectBase
    {       
        public List<Company> GetCompanyDetail()
        {
            List<Company> listLookUpList = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CompanyDA objMasterLookup = new CompanyDA();
                List<Company> listLookup = objMasterLookup.GetCompanyDetail();
                listLookUpList = listLookup;
            }            
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return listLookUpList;
        }

        public bool SaveCompany(Company  objCompany)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CompanyDA objCompanyDA = new CompanyDA();
                status = objCompanyDA.SaveCompany(objCompany);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }
        public List<Company> SearchCompany(Company objCompany)
        {
            List<Company> lstObject = null;
            try
            {
                CompanyDA objCompanyDA = new CompanyDA();
                lstObject = objCompanyDA.SearchCompany(objCompany);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public Company GetCompanyByID(Company objCompany)
        {
            Company objRetCompany = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CompanyDA objCompanyDA = new CompanyDA();
                objRetCompany = objCompanyDA.GetCompanyByID(objCompany);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCompany;
        }
    }
}

