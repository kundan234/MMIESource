﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;
/*************************************************************************************************  
  
  Name of the Class			    : SalesTypeBO                      
  
  Description of the class	    : 
  
  Created Date					: 30th Nov 2010  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 29/11/2010  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.BusinessProcess.Common
{
public    class SalesTypeBO
    {

        #region City
    public bool SaveSalesType(SalesType objSalesType)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                SalesTypeDA objSalesTypeDA = new SalesTypeDA();
                status = objSalesTypeDA.SaveSalesType(objSalesType);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


    public List<SalesType> GetSalesTypeList(bool All)
        {
            List<SalesType> lstObject = null;
            try
            {
                SalesTypeDA objSalesTypeDA = new SalesTypeDA();
                lstObject = objSalesTypeDA.GetSalesTypeList(All);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

    public SalesType GetSalesTypeByID(int ID)
        {
            SalesType objRetProduct = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                SalesTypeDA objSalesTypeDA = new SalesTypeDA();
                objRetProduct = objSalesTypeDA.GetSalesTypeByID(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetProduct;
        }



    public List<SalesType> GetSearchSalesType(SalesType objSalesType)
    {
        List<SalesType> lstSalesType = null;
        try
        {
            SalesTypeDA objsalesTypeDA = new SalesTypeDA();
            lstSalesType = objsalesTypeDA.GetSearchSalesType(objSalesType);
        }
        catch (Exception ex) //Exception of the layer(itself)/unhandle
        {
            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
            LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
            throw new BusinessProcessException("4000001", ex);
        }
        return lstSalesType;
    }
        #endregion


    }
}
