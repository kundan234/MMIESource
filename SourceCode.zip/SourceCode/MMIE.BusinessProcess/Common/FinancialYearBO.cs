﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;

/*************************************************************************************************  
  
  Name of the Class			    : BankBO                      
  
  Description of the class	    : 
  
  Created Date					: 27 NOV 2011  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: Kundan Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.Common
{
   public class FinancialYearBO:BusinessObjectBase
    {
        #region Bank
       public bool UpdateFinancialYear(FinancialYear objBank)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                FinancialYearDA objBankDA = new FinancialYearDA();
                status = objBankDA.UpdateFinancialYear(objBank);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public List<FinancialYear> GetSearchFinancialYear(FinancialYear objFin)
        {
            List<FinancialYear> lstObject = null;
            try
            {
                FinancialYearDA objBankDA = new FinancialYearDA();
                lstObject = objBankDA.GetSearchFiancialYear(objFin);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        //public FinancialYear GetBankByID(int ID)
        //{
        //    FinancialYear objRetProduct = null;
        //    try
        //    {
        //        //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
        //        FinancialYearDA objBankDA = new FinancialYearDA();
        //        objRetProduct = objBankDA.GetSearchFiancialYearByID(ID);
        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
        //        LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
        //        throw new BusinessProcessException("4000001", ex);
        //    }
        //    return objRetProduct;
        //}



    }
}
        #endregion