﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;


/*************************************************************************************************  
  
  Name of the Class			    : ProductCategoryBO                      
  
  Description of the class	    : 
  
  Created Date					: 24th Mov 2011  
  
  Developer						: Kundan  Singh Jeena
  
  Modify Date					: 24/11/2011  
  
  Modified By Developer			: Kundan  Singh  Jeena
  
  Comments						: ()
 
  *************************************************************************************************/
namespace MMIE.BusinessProcess.Common
{
   public  class ProductCategoryBO:BusinessObjectBase
    {


        #region ProductCategory
        public bool SaveProductCategory(ProductCategory objProductCategory)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                ProductCategoryDA objProductCategoryDA = new ProductCategoryDA();
                status = objProductCategoryDA.SaveProductCategory(objProductCategory);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<ProductCategory> GerProductCategoryList(bool All)
        {
            List<ProductCategory> lstProductCategory = null;
            try
            {
                ProductCategoryDA objProductCategoryDA = new ProductCategoryDA();
                lstProductCategory = objProductCategoryDA.GetProductCategoryList(All);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstProductCategory;
        }

        public ProductCategory GetProductCategoryByID(int ID)
        {
            ProductCategory objRetProductCategory = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                ProductCategoryDA objProductCategoryDA = new ProductCategoryDA();
                objRetProductCategory = objProductCategoryDA.GetProductCategoryByID(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetProductCategory;
        }

        //--------------------- ProductCategoryes for payroll

       //added by ankit
        public List<ProductCategory> GerSearchProductCategory(ProductCategory Category)
        {
            List<ProductCategory> lstProductCategory = null;
            try
            {
                ProductCategoryDA objProductCategoryDA = new ProductCategoryDA();
                lstProductCategory = objProductCategoryDA.GetSearchProductCategory(Category);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstProductCategory;
        }
        #endregion
    }
}
