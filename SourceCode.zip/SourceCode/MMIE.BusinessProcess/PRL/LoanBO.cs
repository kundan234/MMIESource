﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.DataAccess.PRL;
using MMIE.Data.PRL;



/*************************************************************************************************  
  
  Name of the Class			    : EmployeeBO                      
  
  Description of the class	    : 
  
  Created Date					: 05 15 2011  
  
  Developer						: Kundan
  
  Modify Date					:  
  
  Modified By Developer			: Kundan
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.PRL
{
   public class LoanBO:BusinessObjectBase
    {
        public bool UpdateLoanDetails(Loan  objLoan)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                LoanDA objEmployeeDA = new LoanDA();
                status = objEmployeeDA.UpdateLoanDetails(objLoan);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<Loan> SearchEmployee(Loan objEmployee)
        {
            List<Loan> lstObject = null;
            try
            {
                LoanDA objEmp = new LoanDA();
                lstObject = objEmp.GetSearchLoanList(objEmployee);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
    }
}
