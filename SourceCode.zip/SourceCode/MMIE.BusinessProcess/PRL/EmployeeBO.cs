﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.DataAccess.PRL ;
using MMIE.Data.PRL;



/*************************************************************************************************  
  
  Name of the Class			    : EmployeeBO                      
  
  Description of the class	    : 
  
  Created Date					: 28th nov 2011  
  
  Developer						: Mithlesh
  
  Modify Date					:  
  
  Modified By Developer			: Mithlesh
  
  Comments						: ()
 
  *************************************************************************************************/
namespace MMIE.BusinessProcess.PRL
{
    public class EmployeeBO : BusinessObjectBase
    {
        public bool UpdateEmployeeDetail(Employee objEmployee)     
        {        
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                EmployeeDA objEmployeeDA = new EmployeeDA();
                status = objEmployeeDA.UpdateEmployeeDetail(objEmployee);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<Employee> SearchEmployee(Employee  objEmployee)
        {
            List<Employee> lstObject = null;
            try
            {
                EmployeeDA objEmp = new EmployeeDA();
                lstObject = objEmp.SearchEmployee(objEmployee);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public List<Employee> GetSearchEmployeeList(Employee objEmployee)
        {
            List<Employee> lstObject = null;
            try
            {
                EmployeeDA objEmp = new EmployeeDA();
                lstObject = objEmp.GetSearchEmployeeList(objEmployee);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public List<Employee> GetSearchEmployeeSalaryList(Employee objEmployee)
        {
            List<Employee> lstObject = null;
            try
            {
                EmployeeDA objEmp = new EmployeeDA();
                lstObject = objEmp.GetSearchEmployeeSalaryList(objEmployee);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public List<Employee> GetSearchSalaryList(Employee objEmployee)
        {
            List<Employee> lstObject = null;
            try
            {
                EmployeeDA objEmp = new EmployeeDA();
                lstObject = objEmp.GetSearchSalaryList(objEmployee);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


      

        public Employee GetEmployeeByID(Employee objEmployee)
        {
            Employee  objRetEmployee = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                EmployeeDA objEmp = new EmployeeDA();
                objRetEmployee = objEmp.GetEmployeeByID(objEmployee); 
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetEmployee;
        }

        public Employee GetEmployeeSalaryDetailsByID(Employee objEmployee)
        {
            Employee  objRetEmployee = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                EmployeeDA objEmp = new EmployeeDA();
                objRetEmployee = objEmp.GetEmployeeSalaryDetailsByID(objEmployee); 
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetEmployee;
        }
        
        public bool CalculateEmployeeSalary(Employee objEmployee)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                EmployeeDA objEmployeeDA = new EmployeeDA();
                status = objEmployeeDA.CalculateEmployeeSalary(objEmployee);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

    }
}
