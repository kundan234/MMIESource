﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.INV;


/*************************************************************************************************  
  
  Name of the Class			    : ConsultantBO                      
  
  Description of the class	    : 
  
  Created Date					: 22nd Dec 2010  
  
  Developer						: Vijendra Singh
  
  Modify Date					: 02/12/2011 
  
  Modified By Developer			: Vijendra Singh 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.INV
{
    public class INVBO : BusinessObjectBase
    {

        public List<Customer> SearchStore(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                INVDA objStoreDA = new INVDA();
                lstObject = objStoreDA.SearchStore(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }



        public List<Order> SearchProductStockList(Order objStore)
        {
            List<Order> lstObject = null;
            try
            {
                INVDA objStoreDA = new INVDA();
                lstObject = objStoreDA.SearchProductStockList(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public bool UpdateStockQuantityNew(Order objCustomer)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                INVDA objCustomerDA = new INVDA();
                status = objCustomerDA.UpdateStockQuantityNew(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public bool UpdateStockQuantity(Customer objCustomer)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                INVDA objCustomerDA = new INVDA();
                status = objCustomerDA.UpdateStockQuantity(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

      
        public bool UpdateTransferStockQuantityParts(Order objOrder)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                INVDA objCustomerDA = new INVDA();
                status = objCustomerDA.UpdateTransferStockQuantityParts(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }
        public bool UpdateTransferStockQuantityVehical(Order objOrder)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                INVDA objCustomerDA = new INVDA();
                status = objCustomerDA.UpdateTransferStockQuantityVehical(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }
        //public bool UpdateTransferStockQuantity(Customer objCustomer)
        //{
        //    bool status = false;
        //    try
        //    {
        //        //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
        //        INVDA objCustomerDA = new INVDA();
        //        status = objCustomerDA.UpdateTransferStockQuantity(objCustomer);
        //    }
        //    catch (Exception ex) //Exception of the layer(itself)/unhandle
        //    {
        //        PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
        //        LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
        //        throw new BusinessProcessException("4000001", ex);
        //    }
        //    return status;
        //}

    }
}
