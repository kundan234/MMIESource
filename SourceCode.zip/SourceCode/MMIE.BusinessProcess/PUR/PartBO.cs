﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.PUR;


/*************************************************************************************************  
  
  Name of the Class			    : ConsultantBO                      
  
  Description of the class	    : 
  
  Created Date					: 22nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 22/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.PUR
{
    public class PartBO : BusinessObjectBase
    {



        public static DataTable GetMaterialDetailNew( string productname, string Model, int GroupType)
        {
            DataTable dtable = null;
            try
            {
                PartDA objPartDA = new PartDA();
                dtable = objPartDA.GetMaterialDetailNew(productname, Model, GroupType);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);

            }
            return dtable;
        }

        public string UpdateReceivingItems(DataSet dsimportReceivingItems)
        {
            string message = "";
            try
            {
                //ConsultantDA objPrescriptionDA = new ConsultantDA();
                //message = objPrescriptionDA.UpdateConsultantComplaint(objLookup);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return message;
        }


        public Customer GetCustomerNameByName(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                objRetCustomer = objCustomerDA.GetCustomerNameByName(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCustomer;
        }



        public bool SavePurInvoiceNumber(Customer objCustomer)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.SavePurInvoiceNumber(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public List<Customer> SearchStore(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.SearchStore(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public List<Product> SearchPurchaseOderDetails(Product objStore)
        {
            List<Product> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.SearchPurchaseOderDetails(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public List<Customer> GetOrderPartsDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.GetOrderPartsDetails(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }



        public bool SavePurOtherCharges(Customer objCustomer)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.SavePurOtherCharges(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }


        public Customer GetPURTotalExpenses(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                objRetCustomer = objCustomerDA.GetPURTotalExpenses(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCustomer;
        }


        public bool SavePurVehicleOtherCharges(Customer objCustomer)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.SavePurVehicleOtherCharges(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }



        public Customer GetPURVehicleTotalExpenses(Customer objCustomer)
        {
            Customer objRetCustomer = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                objRetCustomer = objCustomerDA.GetPURVehicleTotalExpenses(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCustomer;
        }

        public List<Customer> GetVehicleReceivingDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.GetVehicleReceivingDetails(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }



        public List<Customer> GetPartsExpenseDetails(Customer objCustomer)
        {
            List<Customer> lstObject = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                lstObject = objCustomerDA.GetPartsExpenseDetails(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public List<Customer> GetRefundOrderDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.GetRefundOrderDetails(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public bool RefundQtyDetails(Customer objCustomer)
        {
            bool status = false;
            try
            {
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.RefundQtyDetails(objCustomer);
            }
            catch (Exception ex) 
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public bool UpdateVehicleRecivingForReturn(Product objproduct)
        {
            bool status = false;
            try
            {
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.UpdateVehicleRecivingForReturn(objproduct);
            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public bool UpdatePartRecivingForReturn(Product objproduct)
        {
            bool status = false;
            try
            {
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.UpdatePartRecivingForReturn(objproduct);
            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

       

        public static DataTable GetPURProductDetail(Product.IsUniqueMaterial isUnique, Int32 SaleTypeID)
        {
            DataTable dtable = null;
            try
            {
                PartDA objVehicleDA = new PartDA();
                dtable = objVehicleDA.GetPURProductDetail(isUnique, SaleTypeID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);

            }
            return dtable;
        }


        public string UpdatePurchaseOrderDetail(Product objSalesProductList)
        {

            string message = "";
            try
            {
                PartDA objPartDA = new PartDA();
                message = objPartDA.UpdatePurchaseOrderDetail(objSalesProductList);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return message;
        }


        public List<Product> SearchOrder(Product objStore)
        {
            List<Product> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.SearchOrder(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public string UpdateVehicleReceivingOrderDetails(Product objSalesProductList)
        {

            string message = "";
            try
            {
                PartDA objPartDA = new PartDA();
                message = objPartDA.UpdateVehicleReceivingOrderDetails(objSalesProductList);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return message;
        }
        public string UpdatePartReceivingOrderDetails(Product objSalesProductList)
        {

            string message = "";
            try
            {
                PartDA objPartDA = new PartDA();
                message = objPartDA.UpdatePartReceivingOrderDetails(objSalesProductList);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return message;
        }


        public string UpdateOrderToSupplier(Product objSalesProductList)
        {

            string message = "";
            try
            {
                PartDA objPartDA = new PartDA();
                message = objPartDA.UpdateOrderToSupplier(objSalesProductList);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return message;
        }



        public List<Product> SearchPurchaseOrderApproverRate(Product objStore)
        {
            List<Product> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.SearchPurchaseOrderApproverRate(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public bool UpdatePurchaseOrderSalesPrice(Product objCustomer)
        {
            bool Status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                Status = objCustomerDA.UpdatePurchaseOrderSalesPrice(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return Status;
        }



    }
}
