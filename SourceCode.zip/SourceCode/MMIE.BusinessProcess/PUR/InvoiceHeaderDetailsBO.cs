﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Data.PUR;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.PUR;


/*************************************************************************************************  
  
  Name of the Class			    : ConsultantBO                      
  
  Description of the class	    : 
  
  Created Date					: 22nd Dec 2010  
  
  Developer						: Kundan  Singh
  
  Modify Date					: 22/12/2010  
  
  Modified By Developer			: Kundan Singh 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.PUR
{

    public class InvoiceHeaderDetailsBO:BusinessObjectBase
    {

        #region  Invoice Header Functionaliyty

        public bool UpdateInvoiceHeaderDetails(InvoiceHeaderDetails objInvoiceHeader)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                InvoiceHeaderDetailsDA objCustomerDA = new InvoiceHeaderDetailsDA();
                status = objCustomerDA.UpdateInvoiceHeaderDetails(objInvoiceHeader);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public List<InvoiceHeaderDetails> GetSearchInvoiceHeaderDetails(InvoiceHeaderDetails objStore)
        {
            List<InvoiceHeaderDetails> lstObject = null;
            try
            {
                InvoiceHeaderDetailsDA objStoreDA = new InvoiceHeaderDetailsDA();
                lstObject = objStoreDA.GetSearchInvoiceHeaderDetails(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public InvoiceHeaderDetails GetSearchInvoiceHeaderDetailsByID(InvoiceHeaderDetails objCustomer)
        {
            InvoiceHeaderDetails objRetCustomer = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                InvoiceHeaderDetailsDA objCustomerDA = new InvoiceHeaderDetailsDA();
                objRetCustomer = objCustomerDA.GetSearchInvoiceHeaderDetailByID(objCustomer.InvoiceHeaderID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCustomer;
        }



        #endregion
    }
}
