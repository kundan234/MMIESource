﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;

using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.PUR;
using MMIE.DataAccess.PUR;
using MMIE.Data.Common;

/*************************************************************************************************  
  
  Name of the Class			    : ConsultantBO                      
  
  Description of the class	    : 
  
  Created Date					: 19nd Dec 2010  
  
  Developer						: Kundan Singh Jeena
  
  Modify Date					: 22/12/2010  
  
  Modified By Developer			: Kundan Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.PUR
{
 public   class ProductPurchaseOrderBO:BusinessObjectBase
    {

     public bool SaveOrderDetailUpdate(List<ProductPurchaseOrder> lstPODetails)
     {
         bool status = false;
         int i = 0;
         try
         {
             //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
             if (lstPODetails.Count < 1) return false;
             
             foreach (ProductPurchaseOrder objOrder in lstPODetails)
             {

                 ProductPurchaseOrderDA objCustomerDA = new ProductPurchaseOrderDA();
                 if (!objCustomerDA.SaveOrderDetailUpdate(objOrder))
                     i = 1;
             }


         }
         catch (Exception ex) //Exception of the layer(itself)/unhandle
         {
             PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
             LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
             throw new BusinessProcessException("4000001", ex);
         }

         if (i == 0)
         {
             status = true;
         }
         else
             status = false;

         return status;
     }
     public bool SaveProductPurchageOrderDetail(ProductPurchaseOrder objPODetails)
    {
        bool status = false;
        try
        {
            //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
            ProductPurchaseOrderDA objCustomerDA = new ProductPurchaseOrderDA();
            status = objCustomerDA.SaveProductPurchageOrderDetail(objPODetails);
        }
        catch (Exception ex) //Exception of the layer(itself)/unhandle
        {
            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
            LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
            throw new BusinessProcessException("4000001", ex);
        }
        return status;
    }


    public List<ProductPurchaseOrder> SearchProductPurchageOrderDetail(int ProductType, string OrderFrom, string OrderTo, int CompanyID, string StatusType)
        {
            List<ProductPurchaseOrder> lstObject = null;
            try
            {
                string Search="";
                Search = "Where PUR_ProductPurchageOrderDetail.ProductType=" + ProductType.ToString() + "and PUR_ProductPurchageOrderDetail.CompanyID=" + CompanyID.ToString() + "and (OrderDate Between convert(Date, '" + OrderFrom.Trim() + "') and convert(Date,'" + OrderTo.Trim() + "'))";

                if(StatusType=="Pending")
                {
                Search    +="and IsPending=1";
                }
                else if(StatusType=="Approved")
                {
                    Search += "and IsApproved=1";
                }
                else if(StatusType=="Rejected")
                {
                    Search += "and IsRejected=1";
                }


                ProductPurchaseOrderDA objStoreDA = new ProductPurchaseOrderDA();
                lstObject = objStoreDA.GetSearchProductPurchaseOrderDetail(Search);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


    public List<ProductPurchaseOrder> SearchProductPurchageOrderDetail(string OrderNo)
    {
        List<ProductPurchaseOrder> lstObject = null;
        try
        {
            string Search = "";
            //Search = "Where PUR_ProductPurchageOrderDetail.PONumber=" + OrderNo.ToString().Trim();
            Search = "Where  PUR_OrderHeader.PONumber=" + OrderNo.ToString().Trim();
            

            ProductPurchaseOrderDA objStoreDA = new ProductPurchaseOrderDA();
            lstObject = objStoreDA.GetSearchProductPurchaseOrderDetail(Search);
        }
        catch (Exception ex) //Exception of the layer(itself)/unhandle
        {
            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
            LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
            throw new BusinessProcessException("4000001", ex);
        }
        return lstObject;
    }


    public List<ProductPurchaseOrder> SearchProductPurchaseOrderDetail_New(ProductPurchaseOrder objPurchaseOrder)
    {
        List<ProductPurchaseOrder> lstObject = null;
        try
        {
           

            ProductPurchaseOrderDA objStoreDA = new ProductPurchaseOrderDA();
            lstObject = objStoreDA.SearchProductPurchaseOrderDetail_New(objPurchaseOrder);
        }
        catch (Exception ex) //Exception of the layer(itself)/unhandle
        {
            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
            LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
            throw new BusinessProcessException("4000001", ex);
        }
        return lstObject;
    }


    public List<Product> SearchPurchageOrderDetail(string OrderNo)
    {
        List<Product> lstObject = null;
        try
        {
            string Search = "";
            //Search = "Where PUR_ProductPurchageOrderDetail.PONumber=" + OrderNo.ToString().Trim();
            Search = OrderNo.ToString().Trim();


            ProductPurchaseOrderDA objStoreDA = new ProductPurchaseOrderDA();
            lstObject = objStoreDA.SearchPurchaseOderDetails(Search);
        }
        catch (Exception ex) //Exception of the layer(itself)/unhandle
        {
            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
            LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
            throw new BusinessProcessException("4000001", ex);
        }
        return lstObject;
    }



    public ProductPurchaseOrder GetProductPurchageOrderDetailByID(int ID)
        {

            ProductPurchaseOrder objRetCustomer = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                ProductPurchaseOrderDA objCustomerDA = new ProductPurchaseOrderDA();
                objRetCustomer = objCustomerDA.GetProductPurchageOrderDetailByID(ID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetCustomer;
        }


    public InvoiceHeaderDetails GetProductPurchaseOrderDetailByID(int ID)
    {

        InvoiceHeaderDetails objRetCustomer = null;
        try
        {
            //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
            ProductPurchaseOrderDA objCustomerDA = new ProductPurchaseOrderDA();
            objRetCustomer = objCustomerDA.GetSearchProductPurchaseOrderByID(ID);
        }
        catch (Exception ex) //Exception of the layer(itself)/unhandle
        {
            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
            LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
            throw new BusinessProcessException("4000001", ex);
        }
        return objRetCustomer;
    }


     //Search Receive Vehical List

    public List<Product> SearchRecievedVehicalList(Product objProduct)
    {
        List<Product> lstObject = null;
        try
        {
            ProductPurchaseOrderDA objStoreDA = new ProductPurchaseOrderDA();
            lstObject = objStoreDA.SearchRecievedVehicalList(objProduct);
        }
        catch (Exception ex) //Exception of the layer(itself)/unhandle
        {
            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
            LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
            throw new BusinessProcessException("4000001", ex);
        }
        return lstObject;
    }

    public bool SaveVehicalRecievedList(Product objPODetails)
    {
        bool status = false;
        try
        {
            //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
            ProductPurchaseOrderDA objCustomerDA = new ProductPurchaseOrderDA();
            status = objCustomerDA.SaveVehicalRecievedList(objPODetails);
        }
        catch (Exception ex) //Exception of the layer(itself)/unhandle
        {
            PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
            LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
            throw new BusinessProcessException("4000001", ex);
        }
        return status;
    }

 
     
    }
}
