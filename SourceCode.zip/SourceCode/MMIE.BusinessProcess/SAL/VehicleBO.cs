﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.DataAccess.SAL;
using MMIE.Data.Common;



/*************************************************************************************************  
  
  Name of the Class			    : PaymentBO                      
  
  Description of the class	    : 
  
  Created Date					: 7th Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 07/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.SAL
{
    public class VehicleBO : BusinessObjectBase
    {
        public static DataTable GetVehicleDetail(Product.IsUniqueMaterial isUnique, Int32 SaleTypeID, Int32 StreetID, Int32 StreetChargeID)
        {
            DataTable dtable = null;
            try
            {
                VehicleDA objVehicleDA = new VehicleDA();
                dtable = objVehicleDA.GetVehicleDetail(isUnique, SaleTypeID, StreetID, StreetChargeID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);

            }
            return dtable;
        }




        public string UpdateSalesProductDetail(Product objSalesProductList)
        {

            string message = "";
            try
            {
                VehicleDA objVehicleDA = new VehicleDA();
                message = objVehicleDA.UpdateSalesProductDetail(objSalesProductList);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return message;
        }


        public bool CancelOrder(Product objSalesProductList)
        {

            bool result = false;
            try
            {
                VehicleDA objVehicleDA = new VehicleDA();
                result = objVehicleDA.CancelOrder(objSalesProductList);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return result;
        }


        public bool SaveCancelOrder(Product objSalesProductList)
        {

            bool result = false;
            try
            {
                VehicleDA objVehicleDA = new VehicleDA();
                result = objVehicleDA.SaveCancelOrder(objSalesProductList);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return result;
        }

        public Product GetUnitDetailsByID(Product objProduct)
        {
            Product objRetProduct = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                VehicleDA objVehicleDA = new VehicleDA();
                objRetProduct = objVehicleDA.GetUnitDetailsByID(objProduct);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetProduct;
        }

        public List<Product> SearchVehicalList(Product objProduct)
        {
            List<Product> lst = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                VehicleDA objVehicleDA = new VehicleDA();
                lst = objVehicleDA.SearchVehicalList(objProduct);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lst;
        }



        public List<Product> SearchSalesCertificateList(Product objProduct)
        {
            List<Product> lst = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                VehicleDA objVehicleDA = new VehicleDA();
                lst = objVehicleDA.SearchSalesCertificateList(objProduct);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lst;
        }

    }
}
