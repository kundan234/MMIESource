﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.DataAccess.SAL;
using MMIE.Data.Common;


namespace MMIE.BusinessProcess.SAL
{
   public class CorrectionCertificateBO : BusinessObjectBase
    {

        public List<Order> SearchCorrectionCertificate(Order objOrder)
        {
            List<Order> lstObject = null;
            try
            {
                CorrectionCertiFicateDA objCertificateDA = new CorrectionCertiFicateDA();

                lstObject = objCertificateDA.SearchCorrectionCertiFicate(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public Order GetAccountGroupTypeByID(Order objProDuct)
        {
            Order objProductData = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                CorrectionCertiFicateDA objCorrectionDA = new CorrectionCertiFicateDA();
                objProductData = objCorrectionDA.GetProductDetailsByID(objProDuct.CertificateCorrectionID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objProductData;
        }

        public bool UpdateCorrectionCertificate(Product objOrder)
        {
            bool result  = false;
            try
            {
                CorrectionCertiFicateDA objCertificateDA = new CorrectionCertiFicateDA();

                result = objCertificateDA.UpdateCorrectionCertiFicate(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return result;
        }
    }
}
