﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.DataAccess.SAL;
using MMIE.Data.Common;



/*************************************************************************************************  
  
  Name of the Class			    : PaymentBO                      
  
  Description of the class	    : 
  
  Created Date					: 7th Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 07/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.SAL
{
    public class OrderBO : BusinessObjectBase
    {
        public List<Order> SearchOrder(Order  objOrder)
        {
            List<Order> lstObject = null;
            try
            {
                OrderDA objOrderDA = new OrderDA();
                lstObject = objOrderDA.SearchOrder(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public List<Order> SearchActiveOrderList(Order objOrder)
        {
            List<Order> lstObject = null;
            try
            {
                OrderDA objOrderDA = new OrderDA();
                lstObject = objOrderDA.SearchActiveOrderList(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public List<Order> SearchCustomerOrder(Order objOrder)
        {
            List<Order> lstObject = null;
            try
            {
                OrderDA objOrderDA = new OrderDA();
                lstObject = objOrderDA.SearchCustomerOrder(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public List<Order> SearchBillHeader(Order objOrder)
        {
            List<Order> lstObject = null;
            try
            {
                OrderDA objOrderDA = new OrderDA();
                lstObject = objOrderDA.SearchBillHeader(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public List<BillInvoiceDetails> SearchOrderInvoiceList(BillInvoiceDetails objOrder)
        {
            List<BillInvoiceDetails> lstObject = null;
            try
            {
                OrderDA objOrderDA = new OrderDA();
                lstObject = objOrderDA.SearchOrderInvoiceList(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public int UpdateSalesOrderInvoicePayment(PaymentDetails objOrder)
        {
            int result = 0;
            try
            {
                OrderDA objOrderDA = new OrderDA();
                result = objOrderDA.UpdateSalesOrderInvoicePayment(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return result;
        }

        public List<Order> SearchInvoiceOrderDelivery(BillInvoiceDetails objOrder)
        {
            List<Order> lstObject = null;
            try
            {
                OrderDA objOrderDA = new OrderDA();
                lstObject = objOrderDA.SearchInvoiceOrderDelivery(objOrder);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        
    }
}
