﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using  MMIE.DataAccess.SAL;
using MMIE.Data.Common;



/*************************************************************************************************  
  
  Name of the Class			    : PaymentBO                      
  
  Description of the class	    : 
  
  Created Date					: 7th Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 07/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.BusinessProcess.SAL
{
    public class PartBO : BusinessObjectBase
    {
        public static DataTable GetMaterialDetail(Product.IsUniqueMaterial isUnique, Int32 SaleTypeID, Int32 StreetID, Int32 StreetChargeID)
        {
            DataTable dtable = null;
            try
            {
                PartDA objPartDA = new PartDA();
                dtable = objPartDA.GetMaterialDetail(isUnique, SaleTypeID, StreetID, StreetChargeID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);

            }
            return dtable;
        }



        public static DataTable GetMaterialDetailNew(Int32 StreetID, Int32 StreetChargeID, Int32 CustomerID, string productname, string Model, int GroupType)
        {
            DataTable dtable = null;
            try
            {
                PartDA objPartDA = new PartDA();
                dtable = objPartDA.GetMaterialDetailNew(StreetID, StreetChargeID, CustomerID, productname, Model,GroupType);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);

            }
            return dtable;
        }


        public static DataTable GetMaterialVehicalDetail(Int32 StreetID, Int32 StreetChargeID, Int32 CustomerID, string productname, string Model, int GroupType, int StoreID)
        {
            DataTable dtable = null;
            try
            {
                PartDA objPartDA = new PartDA();
                dtable = objPartDA.GetMaterialVehicalDetail(StreetID, StreetChargeID, CustomerID, productname, Model, GroupType,StoreID);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "5000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);

            }
            return dtable;
        }




        public string UpdateSalesProductDetail(Product objSalesProductList )
        {

            string message = "";
            try
            {
                PartDA objPartDA = new PartDA();
                message = objPartDA.UpdateSalesProductDetail(objSalesProductList);
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return message;
        }


        public List<Customer> SearchStore(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.SearchStore(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public List<Customer> SearchOrderDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.SearchOrderDetails(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public List<Customer> CheckOutSearchStore(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.CheckOutSearchStore(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public List<Customer> GetPartialOrderSearch(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.GetPartialOrderSearch(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public List<Customer> SearchOrderAll(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.SearchOrderAll(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }
        public List<Customer> BindOrderDetail(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.BindOrderDetail(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }

        public bool UpdatePartPartialCancel(Order objOrder)
        {
            bool status = false;
            try
            {
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.UpdatePartPartialCancel(objOrder);
            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        public int GETMAXBillHeaderID()
        {
            int  listLookUpList = 0;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objMasterLookup = new PartDA();

                listLookUpList = objMasterLookup.GETMAXBillHeaderID();
            }
            catch (Exception ex) //Exception of the business layer(itself)//unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "330001");
                LogManager.WriteErrorLogInDB(ex);
                throw new BusinessProcessException("4000001", ex);
            }
            return listLookUpList;
        }



        public bool SaveShipNumber(Customer objCustomer)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.SaveShipNumber(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }
        

        public bool SaveBulkShipNumber(Order objCustomer)
        {
            bool status = false;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.SaveBulkShipNumber(objCustomer);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }

        #region Use for vehicle return, Pickup from PUR by ankit
        public List<Customer> GetRefundOrderDetails(Customer objStore)
        {
            List<Customer> lstObject = null;
            try
            {
                PartDA objStoreDA = new PartDA();
                lstObject = objStoreDA.GetRefundOrderDetails(objStore);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return lstObject;
        }


        public bool RefundQtyDetails(Customer objCustomer)
        {
            bool status = false;
            try
            {
                PartDA objCustomerDA = new PartDA();
                status = objCustomerDA.RefundQtyDetails(objCustomer);
            }
            catch (Exception ex)
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return status;
        }
        #endregion
    }
}
