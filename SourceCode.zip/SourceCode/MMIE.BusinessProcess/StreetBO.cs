﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using MMIE.Common.Logging;
using MMIE.Common.ExceptionHandler;
using MMIE.Data.Common;
using MMIE.DataAccess.Common;

/*************************************************************************************************  
  
  Name of the Class			    : StoreBO                      
  
  Description of the class	    : 
  
  Created Date					: 20 oct 2011  
  
  Developer						: Mithlesh
  
  Modify Date					: 20/10/2011  
  
  Modified By Developer			: Mithlesh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.BusinessProcess.Common
{

    public class StreetBO : BusinessObjectBase
    {
        public Street GetStreetByName(Street objStreet)
        {
            Street objRetStreet = null;
            try
            {
                //LogManager.WriteLog(new LogSource(this, LogManager.WhoCalledMe(), EnumLogCategory.BusinessProcessEvents, EnumPriority.High, EnumLogEvenType.Information));
                StreetDA objStreetDA = new StreetDA();
                objRetStreet = objStreetDA.GetStreetByName(objStreet);
            }
            catch (Exception ex) //Exception of the layer(itself)/unhandle
            {
                PolicyBasedExceptionHandler.HandleException(PolicyBasedExceptionHandler.PolicyName.BusinessProcessExceptionPolicy, ex, "4000001");
                LogManager.WriteErrorLogInDB(ex, EnumErrorLogSourceTier.App);
                throw new BusinessProcessException("4000001", ex);
            }
            return objRetStreet;
        }
    }
}
