﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;


namespace MMIE.Data.ACC
{
    [Serializable]
    public class LedgerHeader:BaseData
    {

        public int LedgerAccountID { get; set; }
        public string AccountName { get; set; }
        public int AccountGroupID { get; set; }
        public string GroupName { get; set; }
        public string VoucherGroupName { get; set; }
        public string AccountNumber { get; set; }
        public int VoucherGroupID { get; set; }
        public string Details { get; set; }
        public decimal Balance { get; set; }
        public int RefrenceNumber { get; set; }
    
    }
}
