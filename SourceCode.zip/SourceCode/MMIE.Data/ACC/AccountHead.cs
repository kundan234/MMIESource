﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using MMIE.Data.Common;


namespace MMIE.Data.ACC
{
    [Serializable]
    public class AccountHead : BaseData
    {
        public int AccountHeadID { get; set; }
        public int AccountGroupID { get; set; }
        public decimal OpeningBalanceUSD { get; set; }
        public decimal OpeningBalanceGourdes { get; set; }
        public string OpeningBalanceNatureType { get; set; }
        public decimal ClosingBalanceUSD { get; set; }
        public decimal ClosingBalanceGourdes { get; set; }
        public string ClosingBalanceNatureType { get; set; }
        public decimal CreditLimitUSD { get; set; }
        public decimal CreditLimitGourdes { get; set; }
        public string Description { get; set; }
        //public int CompanyID { get; set; }
        public string GroupName { get; set; }
        public string AccountName { get; set; }
        public string AccountShortName { get; set; }

        //public int FinancialYearID { get; set; }
        //public string AddedBy { get; set; }
        //public DateTime AddedDTM { get; set; }
        //public string LastModBy { get; set; }
        //public DateTime LastModDTM { get; set; }  

    }
}
