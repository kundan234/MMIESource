﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;


namespace MMIE.Data.ACC
{
    [Serializable]
     public  class AccountGroupType : BaseData
    {

            public int GroupTypeID { get; set; }
            public  string   GroupTypeName { get; set; }
            public string  AccountType { get; set; }
            public int  AccountNumber { get; set; }
            public bool  IsPLItem { get; set; }
            public bool IsBalanceSheet { get; set; }
            public int CompanyID { get; set; }
            
            
            public string AddedBy { get; set; }
   
            public string LastModBy { get; set; }

            
            public int FinancialYearID { get; set; }
    }
}
