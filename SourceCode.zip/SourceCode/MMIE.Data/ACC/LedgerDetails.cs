﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;


namespace MMIE.Data.ACC
{
    [Serializable]
  public class LedgerDetails : BaseData
    {
        public int LedgerDetailsID { get; set; }
        public int JournalHeaderID { get; set; }
        public int JournalDetailsID { get; set; }
        public int AccountHeadID { get; set; }
        public int AccountGroupID { get; set; }
        public string TType { get; set; }
        public decimal DebitAmount { get; set; }
        public decimal CreditAmount { get; set; }
       
        public decimal Balance { get; set; }
        public bool BalanceType { get; set; }
        public bool IsLocked { get; set; }  
        
        //////////// Additional Members For Data //////////////
        public string GroupName { get; set; }


    }
}
