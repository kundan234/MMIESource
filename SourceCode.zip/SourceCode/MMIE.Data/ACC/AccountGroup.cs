﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;


namespace MMIE.Data.ACC
{
    [Serializable]
   public class AccountGroup:BaseData
    {
        public int AccountGroupID { get; set; }
        public int VoucherGroupID { get; set; }

        public string VoucherGroupName { get; set; }
        public string Remarks { get; set; }
        public string GroupName { get; set; }
        public string Details { get; set; }
        
        public  int GroupTypeID { get; set; }
        
        public int CompanyID { get; set; }
        public bool IsActive { get; set; }
        public string AddedBy { get; set; }
   
        public string LastModBy { get; set; }

        public string GroupTypeName { get; set; }
        public string AccountType { get; set; }
        public int AccountNumber { get; set; }

        public string VoucherGroupDetails { get; set; }



    }
}
