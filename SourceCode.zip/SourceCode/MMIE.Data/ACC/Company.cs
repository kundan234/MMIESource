﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;

namespace MMIE.Data.ACC
{
    [Serializable]

    public class AccountCompany : BaseData
    {
        //
        public Int16 AccountCompanyID { get; set; }
        public Int16 CompanyID { get; set; }
        public string CompanyName { get; set; }
        public string CompanyLegalName { get; set; }        
        public string CompanyCode { get; set; }
        public Int16 CompanyTypeID { get; set; }
        public string CompanyAddress { get; set; }        
        public string CompanyLandMark { get; set; }
        public int CityID { get; set; }
        public string CityName { get; set; }
        public int DistrictID { get; set; }
        public int StateID { get; set; }
        public string StateCode { get; set; }
        public string  ZipCode { get; set; }     
        public int CountryID { get; set; }
        public string CountryName { get; set; }
        public string CompanyPhone { get; set; }
        public string CompanyFaxNo { get; set; }
        public string CompanyEmailID { get; set; }
        public string CompanyBusinessType { get; set; }
        public int CompanyFiscalYearID { get; set; }
        public string CompanyWebsite { get; set; }
        public decimal AnnualRevenue { get; set; }
      
    }
}
