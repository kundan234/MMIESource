﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using MMIE.Data.Common;

namespace MMIE.Data.ACC
{
    [Serializable]
    public class VoucherGroup :BaseData
    {
        public int VoucherGroupID { get; set; }
        public string VoucherGroupName { get; set; }
        public string Remarks { get; set; }
   

    }
}
