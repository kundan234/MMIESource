﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;


namespace MMIE.Data.ACC
{
    [Serializable]
  public class LedgerAccount : BaseData
    {
        public int LedgerID { get; set; }
        public int AccountGroupID { get; set; }
        public int CompanyAccountID { get; set; }
        public int AccountHeadID { get; set; }
        public decimal AmountUSD { get; set; }
        public decimal Amount { get; set; }
        public string Details { get; set; }
        public int CompanyID { get; set; }
        public bool IsActive { get; set; }
        public string AddedBy { get; set; }
        public DateTime AddedDTM { get; set; }
        public string LastModBy { get; set; }
        public DateTime LastModDTM { get; set; }
        public int FinancialYearID { get; set; }
        public string Dated { get; set; }
        public string Source { get; set; }
  
        public decimal OpeningBalance { get; set; }
        public decimal OpeningBalanceUSD { get; set; }
        public decimal ClosingBalanceUSD { get; set; }
        public decimal ClosingBalance { get; set; }  

    }
}
