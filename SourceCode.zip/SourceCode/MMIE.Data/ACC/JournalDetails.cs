﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;


namespace MMIE.Data.ACC
{
    [Serializable]
    public class JournalDetails : BaseData
    {
        public int JournalDetailsID { get; set; }
        public int JournalHeaderID { get; set; }
        public int LedgerAccountID { get; set; }
        public int AccountGroupID { get; set; }
        public string TType { get; set; }
        public decimal DebitAmount { get; set; }
        public decimal CreditAmount { get; set; }
        public string LF { get; set; }

        public string ReferenceNo { get; set; }
        
       
            //public int CompanyID { get; set; }
            //public bool IsActive { get; set; }
            //public string AddedBy { get; set; }
            //public DateTime AddedDTM { get; set; }
            //public string LastModBy { get; set; }
            //public DateTime LastModDTM { get; set; }
            //public int FinancialYearID { get; set; }
            

        public bool IsLocked { get; set; }

        public string EntryDate { get; set; }

        public string Details { get; set; }
        public string AccountName { get; set; }
        public string GroupName { get; set; }
        public string XMLData { get; set; }
        public int TransactionID { get; set; }

    }



}
