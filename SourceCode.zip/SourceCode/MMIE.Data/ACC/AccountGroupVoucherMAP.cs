﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;

namespace MMIE.Data.ACC
{
    [Serializable]
 public    class AccountGroupVoucherMAP :BaseData
    {

        public int AccountGroupVoucherID { get; set; }
        public int AccountGroupID { get; set; }
        public int VoucherGroupID { get; set; }
       
    }
}
