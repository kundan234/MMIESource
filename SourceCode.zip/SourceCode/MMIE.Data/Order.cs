﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Role                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.Data.Common
{

    [Serializable]
    public class Order : BaseData
    {
        public Int64  BillHeaderID { get; set; }
        public string  InvoiceNo { get; set; }
        public string OrderNumber { get; set; }
        public string ShipmentNumber { get; set; }
        public decimal TotalUSDAmount { get; set; }
        public decimal TotalGourdesAmount { get; set; }
         public DateTime  InvoiceDate { get; set; }
         public int GroupType { get; set; }
         public int CustomerID { get; set; }
         public int SalesStatus { get; set; }
         public decimal PaidUSDAmount { get; set; }
         public decimal PaidGourdesAmount { get; set; }
         public decimal DueUSDAmount { get; set; }
         public decimal DueGrourdesAmount { get; set; }
         public decimal DeliveryCharges { get; set; }
         public int StreetID { get; set; }
         public string Remarks { get; set; }
         public int PaymentMode { get; set; }
         public int StoreID { get; set; }
         public string  StoreName { get; set; }
         public Int64  ProductSaleID { get; set; }
         public int ProductID { get; set; }
         public string  VinNo { get; set; }
         public string  EngineNo { get; set; }
         public string IssuedQty { get; set; }
         public int UnitID { get; set; }
         public decimal  Rate { get; set; }
         public decimal  Amount { get; set; }
         public string UnitPriceGourdes { get; set; }
         public Int64 ProductReceivedTransID { get; set; }
       //  public int DeliveryQty   { get; set; }   
      //   public int ChargedID { get; set; }
      //   public int VehicleRecevingID { get; set; }
     //    public decimal USDAmt { get; set; }
    //     public decimal GourdesAmt { get; set; }
         //public int ChargeCategory { get; set; }
         //public string  GourdesDescription { get; set; }               
        // public int IsActive { get; set; }
         public string CustomerName { get; set; }
         public string CustomerAddress { get; set; }
         public string CustomerStreet { get; set; }
         public int CustomerCityID { get; set; }
         public int CustomerCountryID { get; set; }
         public string CustomerPhone { get; set; }
         public string CustomerMobile { get; set; }
         public string CustomerFax { get; set; }
         public string CustomerEmail { get; set; }
         public string CustomerWebsite { get; set; }
         public string CustReferenceName { get; set; }
         public string CustReferenceAddress { get; set; }
         public string CustReferenceStreet { get; set; }
         public int CustReferenceCityID { get; set; }
         public int CustReferenceCountryID { get; set; }
         public string CustReferencePhone { get; set; }
         public string CustReferenceMobile { get; set; }
         public string CustReferenceFax { get; set; }
         public string CustReferenceEmail { get; set; }
         public string CustReferenceWebsite { get; set; }
         public string  model { get; set; }       
         public string ProductName { get; set; }
         public Int32  TotalAmount { get; set; }


    }
}
