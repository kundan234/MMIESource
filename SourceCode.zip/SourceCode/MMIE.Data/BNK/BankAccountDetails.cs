﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;


namespace MMIE.Data.BANK
{
    
    [Serializable]
    public  class BankAccountDetails:BaseData
    {

        public int AccountDetailsID { get; set; }
        public int BankAccountID { get; set; }
        public string TransactionMode { get; set; }
        public string TransactionType { get; set; }
        public string TType { get; set; }
        public string TransactionDetails { get; set; }
        public string ReferenceNo { get; set; }
        public decimal TransactionAmount { get; set; }
        public decimal TransactionAmountUSD { get; set; }
        public decimal ClosingAmount { get; set; }
        public decimal ClosingAmountUSD { get; set; }

        public string  AddedBy { get; set; }
        
        public string LastModBy { get; set; }
              
        
        public int ReferenceID { get; set; }
        public int ParentID { get; set; }
        public bool IsChecked { get; set; }
        


    }
}
