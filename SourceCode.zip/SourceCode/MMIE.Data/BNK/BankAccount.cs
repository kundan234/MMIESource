﻿
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;

namespace MMIE.Data.BANK
{
    [Serializable]
    public class BankAccount:BaseData
    {

        public int BankAccountID { get; set; }
        public string AccountNumber { get; set; }
        public string AccountDetails { get; set; }
        public decimal BalanceAmount { get; set; }
        public decimal BalanceAmountUSD { get; set; }
        public string BankName { get; set; }
        public int BankID { get; set; }
        public string AccountType { get; set; }
    
        
    }
}
