﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : City                      
  
  Description of the class	    : 
  
  Created Date					: 15th Nov 2011  
  
  Developer						: Kundan  Singh Jeena
  
  Modify Date					: 15/11/2011  
  
  Modified By Developer			: Kundan  Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.Data.Common
{
    public class UnitDT : BaseData
    {
        public int UnitID { get; set; }
        public string UnitName{get; set; }
        public string AddedBy { get; set; }
        public string LastModBy { get; set; }
        public bool StatusType { get; set; }
        public bool IsActive { get; set; }
        public int ActionType { get; set; }
        public int CompanyID { get; set; }
        public int FinancialYearID { get; set; }
        public string Details { get; set; }
        public decimal EquivalentUnit { get; set; }
        public int ProductCategoryID { get; set; }
        public string ProductCategoryName { get; set; }
        
    }
}
