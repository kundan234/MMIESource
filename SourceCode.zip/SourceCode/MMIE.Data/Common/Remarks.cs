﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : City                      
  
  Description of the class	    : 
  
  Created Date					: 26th Dec 2010  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 26/12/2011  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    [Serializable]
    public class Remarks:BaseData 
    {

        public int RemarksID { get; set; }
        public string RemarksType { get; set; }
        public string RemarksDetails { get; set; }
        public string CustomerType { get; set; }
        public bool            IsActive { get; set; }
        public string AddedBy { get; set; }

        public string LastModBy { get; set; }
        
        public int FinancialYearID { get; set; }
        public int CompanyID { get; set; }

      public  int ActionType { get; set; }
    }
}
