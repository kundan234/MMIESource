﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Bank                      
  
  Description of the class	    : 
  
  Created Date					: 17th Jan 2012
  
  Developer						: Budha Singh
  
  Modify Date					: 29/11/2010  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    [Serializable]
    public class Bank : BaseData
    {
       public Int16 BankID { get; set; }
       public string  BankAccountNo { get; set; }
       public string  BankName { get; set; }
       public string  BankAddress { get; set; }

     }
}
