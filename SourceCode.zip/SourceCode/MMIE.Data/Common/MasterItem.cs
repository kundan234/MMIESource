﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
//using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : LookupItem                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Shantikumar Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Shantikumar Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
  
    [Serializable]
    public class MasterItem : LookupItem
    {
        [DataMember]
        public string LookupsName { get; set; }
        
        // Country Master Items
               
        [DataMember]
        public string CountryISD { get; set; }

        [DataMember]
        public int CurrencyID { get; set; }

        [DataMember]
        public string CountryTimeZone { get; set; }
       

    }
}

