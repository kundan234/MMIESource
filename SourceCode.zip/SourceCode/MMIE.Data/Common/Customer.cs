﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
/*************************************************************************************************  
  
  Name of the Class			    : Country                      
  
  Description of the class	    : 
  
  Created Date					: 19-Oct-2011
  
  Developer						: Mithlesh
  
  Modify Date					: 19-Oct-2011

  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    [Serializable]
    public class Customer : BaseData
    {

        public Int64 VehicalPOID { get; set; }
        public Int64 BillHeaderID { get; set; }
        public string StoreName { get; set; }
        public string Descr { get; set; }
        public string Qty { get; set; }
        public string UnitID { get; set; }
        public double AvailableQty { get; set; }
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerStreet { get; set; }
        public int CustomerCityID { get; set; }
        public int CustomerCountryID { get; set; }
        public string CustomerPhone { get; set; }
        public string CustomerMobile { get; set; }
        public string CustomerFax { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerWebsite { get; set; }
        public string CustReferenceName { get; set; }
        public string CustReferenceAddress { get; set; }
        public string CustReferenceStreet { get; set; }
        public int CustReferenceCityID { get; set; }
        public int CustReferenceCountryID { get; set; }
        public string CustReferencePhone { get; set; }
        public string CustReferenceMobile { get; set; }
        public string CustReferenceFax { get; set; }
        public string CustReferenceEmail { get; set; }
        public string CustReferenceWebsite { get; set; }
        public string CType { get; set; }
        //public string AddedBy { get; set; }
        public string AddedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string CustomerScanID { get; set; }
        public string CustomerDescription { get; set; }
        public string InvoiceNo { get; set; }
        public string mno { get; set; }
        
        public string Unitprice { get; set; }
        public string Amount { get; set; }
        public int ProductID { get; set; }
       
        public decimal UnitPriceUSD { get; set; }
        public decimal UnitPriceGourdes{ get; set; }
        public double TotalAmount { get; set; }
        public decimal TotalGourdesAmt { get; set; }
        public string ProductName { get; set; }
        public string Model { get; set; }
        public string Color { get; set; }
        public string ReferenceName { get; set; }
        public bool StatusType { get; set; }
        public string EngineNo { get; set; }
        public string VinNo { get; set; }
        public string OrderNo { get; set; }
        public int GroupType { get; set; }
        public Int64 MaxBillHeaderID { get; set; }
        public int SalesStatus { get; set; }
        public string ShipmentNumber { get; set; }
        public decimal TotalUSDAmt { get; set; }
        public decimal PaidUSDAmt { get; set; }
        public decimal PaidGourdesAmt { get; set; }
        public decimal DueUSDAmt { get; set; }
        public decimal DueGourdesAmt { get; set; }
        public string PaymentMode { get; set; }
        public string ContainerNumber { get; set; }
        public Int64 ProductSaleID { get; set; }
        public int ProdID { get; set; }
        public int DeliveryQty { get; set; }
        public int PendingQty { get; set; }
        public decimal DeliveryRate { get; set; }
        public Int64 ProductDeliveryID { get; set; }

        public decimal RefundAmountUSD { get; set; }
        public decimal RefundAmountGourdes { get; set; }
        public decimal RefundChargeUSD { get; set; }
        public decimal RefundChargeGourdes { get; set; }
        public decimal RefundAdjustAmtUSD { get; set; }
        public decimal RefundAdjustAmtGourdes { get; set; }
        public int RefundQty { get; set; }
        public int Quantity { get; set; }
        public decimal PriceUSD { get; set; }
        public decimal Retailer1 { get; set; }
        public decimal Retailer2 { get; set; }
        public decimal Dealer { get; set; }
        public decimal CreditRate { get; set; }
        public int SalesTypeID { get; set; }
        public Int32 StoreID { get; set; }
        public decimal Rate { get; set; }
        public int StreetChargeID { get; set; }
        public decimal DeliveryCharge { get; set; }
        public decimal SaleTax { get; set; }
        // public int ActionType { get; set; }
        ////////////////////////////////////////////

        public string CustomerType { get; set; }
        public bool IsPriceVisible { get; set; }
        public bool IsActive { get; set; }
        public decimal OpeningBalance { get; set; }
        public decimal OpeningBalanceUSD { get; set; }
        public decimal MaxCreditLimit { get; set; }
        public decimal MaxCreditLimitUSD { get; set; }
        public string StreetName { get; set; }



        ///////////////////////////////////////////////

        //////////////City Details////////////////////////////
        public string CityName { get; set; }
        public string CountryName { get; set; }
        public string CityName1 { get; set; }
        public string CountryName1 { get; set; }
        public int CityID { get; set; }
        public int CountryID { get; set; }
        public int Zip_Code { get; set; }
        /////////////////////////////////////////
        public string RemarksCheckout { get; set; }
        public string RemarksDelivery { get; set; }
        public string CurrencyName { get; set; }
        public int CurrencyID { get; set; }
        public decimal CurrencyRate { get; set; }
        public decimal DebtAmountGourdes { get; set; }
        public decimal DebtAmountUSD { get; set; }
        public string VehicalSalesDetailsXML { get; set; }
        public DateTime BillDueDate { get; set; }
        public decimal TotalGrandTotalUSD { get; set; }
        public decimal TotalGrandTotalGourdes { get; set; }
        public int MaximumDueDays { get; set; }

        public decimal TotalCostPrice { get; set; }
        public decimal TotalFrieght { get; set; }
        public decimal TotalInsurance { get; set; }
        // add by ankit
        public decimal EquivalentUnit { get; set; } 
        public string UnitName { get; set; } 
        public decimal EquivalentQuantity { get; set; }
        public double TotalRefundUnit { get; set; } 
        //*********************
    }
}
