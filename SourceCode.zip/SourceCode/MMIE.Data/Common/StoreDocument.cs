﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;


/*************************************************************************************************  
  
  Name of the Class			    : Country                      
  
  Description of the class	    : 
  
  Created Date					: 19-Oct-2011
  
  Developer						: Mithlesh
  
  Modify Date					: 19-Oct-2011

  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    [Serializable]
    public class StoreDocument
    {
        public int ScanID { get; set; }
        public int StoreID { get; set; }
        public string StoreScanID { get; set; }
        public string StoreDescription { get; set; }
        public int ActionType { get; set; }
        public string FriendlyName { get; set; }
   
    }
}
