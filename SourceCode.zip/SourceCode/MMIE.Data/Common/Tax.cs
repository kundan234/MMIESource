﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMIE.Data.Common
{
      [Serializable]
  public   class Tax : BaseData
    {
        public int TaxID { get; set; }
        public string TaxName { get; set; }
        public decimal TaxRate { get; set; }
        public bool IsActive  { get; set; }
        public string  AddedBy { get; set; }
        public string  LastModBy { get; set; }
        public int ActionType { get; set; }
        public int CompanyID { get; set; }
        public int FinancialYearID { get; set; }
        public Int64 FromRange { get; set; }
        public Int64 ToRange { get; set; }
        public decimal TaxAmount { get; set; }  
    }
}
