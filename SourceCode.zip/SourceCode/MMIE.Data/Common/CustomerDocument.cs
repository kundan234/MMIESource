﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;


/*************************************************************************************************  
  
  Name of the Class			    : Country                      
  
  Description of the class	    : 
  
  Created Date					: 19-Oct-2011
  
  Developer						: Mithlesh
  
  Modify Date					: 19-Oct-2011

  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    [Serializable]
    public class CustomerDocument
    {
        public int ScanID { get; set; }
        public int CustomerID { get; set; }
        public string CustomerScanID { get; set; }
        public string CustomerDescription { get; set; }
        public string FriendlyName { get; set; }
        public int ActionType { get; set; }
        public string DocumentType { get; set; }
        public bool IsActive { get; set; }
        public string LastModBy { get; set; }
        public string AddedBy { get; set; }
        public string DocumentID { get; set; }


    }
}
