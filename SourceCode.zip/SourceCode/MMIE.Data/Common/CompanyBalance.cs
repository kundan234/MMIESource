﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Bank                      
  
  Description of the class	    : 
  
  Created Date					: 17th Jan 2012
  
  Developer						: Budha Singh
  
  Modify Date					: 29/11/2010  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    [Serializable]
    public class CompanyBalance :BaseData
    {
        public int CompanyBalanceID { get; set; }
        public int BranchID { get; set; }
        public int CurrencyID { get; set; }
        public decimal CompanyBalanceAmount { get; set; }

        public string  CompanyName { get; set; }
        public string CurrencyName { get; set; }
        public string PaymentSourceName { get; set; }
       
        
        
        
        public int PaymentSourceID { get; set; }  


    }
}
