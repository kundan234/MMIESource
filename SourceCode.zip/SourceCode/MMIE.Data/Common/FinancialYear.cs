﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
////using System.ServiceModel;
using System.Runtime.Serialization;


namespace MMIE.Data.Common
{
   
    [Serializable]
    public class FinancialYear : BaseData
    {
        //[DataMember]
        //public int FinancialYearID { get; set; }
     
        public string FinancialYearCode { get; set; }
       
        public string Name { get; set; }
        
        public string Description { get; set; }
    }
}
