﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : City                      
  
  Description of the class	    : 
  
  Created Date					: 15th Nov 2011  
  
  Developer						: Kundan  Singh Jeena
  
  Modify Date					: 15/11/2011  
  
  Modified By Developer			: Kundan  Singh Jeena
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.Data.Common
{
  public  class Currency
    {

        public int CurrencyID { get; set; }
        public int PurchaseCurrencyID { get; set; }
        public string BaseFormat { get; set; }
        public string ConvertTO { get; set; }
        public decimal Rate { get; set; }
        public bool IsActive { get; set; }
        public string AddedBy { get; set; }
        public string LastModBy { get; set; }
        public int ActionType { get; set; }
        public int CompanyID { get; set; }
        public int FinancialYearID { get; set; }
        public string CIDRate { get; set; }


    }
}
