﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Country                      
  
  Description of the class	    : 
  
  Created Date					: 19-Oct-2011
  
  Developer						: Mithlesh
  
  Modify Date					: 19-Oct-2011

  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    [Serializable]
    public class Product : BaseData
    {
        //public string OtherChargeDetails { get; set; }//Kundan: Added to Carry the Other charge Description List to DAL
        //public string OtherChargeAmount { get; set; }//Kundan: Added to Carry the Other charge Amount List to DAL
        //public string OtherChargeID { get; set; }//Kundan: Added to Carry the Other charge ID List to DAL

        public int ProductPriceID { get; set; }
        public int ProductType { get; set; }
   
        public string VehicalPower { get; set; }
        public string StoreName { get; set; }
        public string CustomerName { get; set; }
        public int CylendorNo { get; set; }
        public string FuelType { get; set; }
        public Int64 ProductSaleDeleveryID { get; set; }
        public int DeliveryQty { get; set; }
        
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string DeliveryDate { get; set; }

        public decimal UnitPrice { get; set; }
        public decimal CostPrice { get; set; }
        public decimal PerUnitCharges { get; set; }


        public int InvoiceItemID { get; set; }
          public int InvoiceHeaderID { get; set; }
        public int RecievedQty { get; set; }
        public long VehiclePOID { get; set; }
        public long PartRecevingID { get; set; }
        public bool IsReturned { get; set; }
        public int ProductID { get; set; }
        public int TotalQty { get; set; }
        public int Qty { get; set; }
        public decimal TotalCostPrice { get; set; }
        public decimal TotalFrieght { get; set; }
        public decimal TotalInsurance { get; set; }
        public decimal TotalOtherCharges { get; set; }


        public decimal TotalPurchaseCost { get; set; }
        public decimal OtherExp { get; set; }
        
        public decimal PerUnitExpense { get; set; }


        public bool IsApproved{ get; set; }
        public string ApproverRemarks{ get; set; }
        public int PONumber { get; set; }
        public string ProductName { get; set; }
        public string ReferenceName { get; set; }
        public string Model { get; set; }
        public string Color { get; set; }
        public string Descriptions { get; set; }
        public int Unit { get; set; }
        public int GroupType { get; set; }
        public string ProductImg { get; set; }
        public string ProductImage { get; set; }
        public string GroupName { get; set; }
        public string UnitName { get; set; }
        public int GroupId { get; set; }
        public int ModeOfPaymentID { get; set; }
        public int UnitId { get; set; }
        public decimal Amount { get; set; }

        public string AddedDate { get; set; }
        public string ModifiedBy { get; set; }

        public decimal PaidAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal TotalAmount { get; set; }
        public int IssuedQty { get; set; }
        public int BalancedQty { get; set; }
        public long StockMaterialReceivedTransID { get; set; }
        public string Remark { get; set; }
        public long StockProductReceivedTransID { get; set; }
        public decimal CreditAmount { get; set; }
        public int StoreID { get; set; }
        public DateTime BillDate { get; set; }
        public int BillGroupCode { get; set; }
        public string xmlSalesTransactionDetail { get; set; }
        public string SaleOrderID { get; set; }
        public string SaleOrderNumber { get; set; }
        public string InvoiceNo { get; set; }
        public string EngineNo { get; set; }
        public string VINNO { get; set; }
        public string ReceiptNo { get; set; }

        public decimal TotalUSDAmount { get; set; }
        //public decimal TotalUSDAmount { get; set; }
        public decimal TotalGourdesAmount { get; set; }
        //public decimal TotalGourdesAmount { get; set; }
        //public decimal PaidUSDAmount  { get; set; }
        //public decimal PaidUSDAmount  { get; set; }
        public decimal PaidGourdesAmount { get; set; }
        public decimal PaidUSDAmount { get; set; }
        public decimal DueUSDAmount { get; set; }
        //public decimal DueUSDAmount { get; set; }
        public decimal DueGrourdesAmount { get; set; }
        //public decimal DueGrourdesAmount { get; set; }
        public int CustomerID { get; set; }
        // public Single PaidAmount { get; set; }
        // public Single DiscountAmount { get; set; }
        public decimal UnitPriceUSD { get; set; }
        public decimal UnitPriceGourdes { get; set; }
        public string strDate { get; set; }
        public decimal CreditGourdesAmount { get; set; }
        public decimal DeliveryAmount { get; set; }
        public decimal DeliveryGourdesAmount { get; set; }
        public int StreetID { get; set; }
        public string PaymentMode { get; set; }
        public bool StatusType { get; set; }
        public bool Taxable { get; set; }
        public int SalesStatus { get; set; }
        public int BillHeaderID { get; set; }
        public string Othercharges { get; set; }
        public string OtherDesc { get; set; }
        public Int64 ProductSaleID { get; set; }
        public int ProdID { get; set; }
        public decimal Rate { get; set; }
        public string StreetName { get; set; }
        public int ChargePrice { get; set; }
        public decimal EquivalentUnit { get; set; }

        public int StreetChargeID { get; set; }
        public decimal DeliveryChargeUSD { get; set; }
        public decimal DeliveryChargeGourdes { get; set; }
        public decimal SaleTaxUSD { get; set; }
        public decimal SaleTaxGourdes { get; set; }
        public decimal TaxRate { get; set; }
        public decimal StreetCharges { get; set; }
        public decimal SalesTaxGourdes { get; set; }
        public decimal Retailer1 { get; set; }
        public decimal Retailer2 { get; set; }
        public decimal Dealer { get; set; }
        public decimal CreditRate { get; set; }
        public string ContainerNo { get; set; }
        public string RemarksCheckout { get; set; }
        public string RemarksDelivery { get; set; }
        public string Remarks { get; set; }
    

        public enum IsUniqueMaterial
        {
            [EnumMember]
            IsUnique = 1,
            [EnumMember]
            IsNotUnique = 0,
        }


   
        public bool ApplyDeliveryCharges { get; set; }
        public int CategoryID { get; set; }
        public int CurrencyID { get; set; }

        public string OtherChargeID { get; set; }
        public decimal CurrencyRate { get; set; }
        public decimal DebtAmountGourdes { get; set; }
        public decimal DebtAmountUSD { get; set; }

        
        public decimal TotalDeliveryChargesGrourdes { get; set; }
        public decimal TotalDeliveryChargesUSD { get; set; }
        public decimal TotalSalesTaxGrourdes { get; set; }
        public decimal TotalSalesTaxUSD { get; set; }
        public decimal TotalGrandTotalGourdes { get; set; }
        public decimal TotalGrandTotalUSD { get; set; }
        public Int64 ProductSalesID { get; set; }
        public bool Sold { get; set; }

        public string SalesDetailsXML { get; set; }

        public DateTime BillDueDate { get; set; }
        public int MaximumDueDays { get; set; }

        public string UpdateXML { get; set; }

        public string InsertXML { get; set; }

    }
}
