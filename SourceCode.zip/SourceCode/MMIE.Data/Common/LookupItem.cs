﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using MMIE.Data.Common;  
//using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : LookupItem                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    
    [Serializable]
    public class LookupItem : BaseData
    {
      
        public int ItemId { get; set; } 

      
        public string ItemName { get; set; }

      
        public string ItemCode { get; set; }

      
        public string ItemCode1 { get; set; }

      
        public string ShortDescription { get; set; }

      
        public string LongDescription { get; set; }

      
        public int OrderSeq { get; set; }

      
        public int ParentItemId { get; set; }


       
    }
}

