﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMIE.Data.Common
{
    public class DepositTransaction : BaseData
    {

        public int CurrencyID { get; set; }
        public int DepositID { get; set; }
        public int CustomerID { get; set; }
        public string TType { get; set; }
        public decimal Rate { get; set; }
        public decimal Amount { get; set; }
        public decimal ClosingAmount { get; set; }
        public decimal AmountUSD { get; set; }
        public decimal ClosingAmountUSD { get; set; }
        public DateTime TransactionDate { get; set; }
        public int FinancialYearID { get; set; }
        public int CompanyID { get; set; }
        public bool IsActive { get; set; }
        public string AddedBy { get; set; }
        public string LastModBy { get; set; }
        public string Remarks { get; set; }
        public string PaymentMode { get; set; }
        public int  ActionType { get; set; }
        public string OrderNo { get; set; }

        

    }
}
