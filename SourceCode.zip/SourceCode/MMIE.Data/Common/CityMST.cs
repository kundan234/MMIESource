﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : City                      
  
  Description of the class	    : 
  
  Created Date					: 7th Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 29/11/2010  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    
    [Serializable]
    public class CityMST : BaseData
    {
        
        public int CityID { get; set; }

        
        public string CityCode { get; set; }
        
        
        public string CityName { get; set; }

       
        public int CountryId { get; set; }
        public int Zip_Code { get; set; }
        public string State_Code { get; set; }
        public string State_Name { get; set; }
        public bool IsActive { get; set; }
        public string AddedBy { get; set; }
        public string LastModBy { get; set; }
        public int FinancialYearID { get; set; }
        public int CompanyID { get; set; }
        public string CountryName { get; set; }
      
      
    }
}

