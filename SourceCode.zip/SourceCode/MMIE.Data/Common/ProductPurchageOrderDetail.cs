﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : City                      
  
  Description of the class	    : 
  
  Created Date					: 16th Dec 2010  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 16/12/2011  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()

  *************************************************************************************************/


namespace MMIE.Data.Common
{
    [Serializable]
 public   class ProductPurchageOrderDetail:BaseData
    {

        public int ID { get; set; }
        public string  PONumber { get; set; }
        public string Model { get; set; }
        public string Color { get; set; }
        public int Qty { get; set; }
        public string Unit { get; set; }
        public string ENName { get; set; }
        //public string RaisedBy { get; set; }
        //public DateTime RaisedDate { get; set; }
        public string OrderDate { get; set; }
        public int ProductType { get; set; }
        public int CompanyID { get; set; }
        public int FinancialYearID { get; set; }
        public string AddedBy { get; set; }

        public string LastModBy { get; set; }
        
        public bool IsPending { get; set; }
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public string Details { get; set; }
        public bool IsActive { get; set; }
        public int ActionType { get; set; }
  

    }
}
