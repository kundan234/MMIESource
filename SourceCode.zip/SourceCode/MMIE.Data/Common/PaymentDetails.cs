﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : PaymentDetails                      
  
  Description of the class	    : 
  
  Created datetime					: 1 Dec 2011  
  
  Developer						: Kundan Singh jeena
  
  Modify datetime					: 1/12/2011  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.Data.Common
{
    
    [Serializable]
    public class PaymentDetails : BaseData
    {


        // Loan and Salary Related Fields
        public int EmployeeID { get; set; }
        public string ConvertTo{ get; set; }
        public bool IsPayroll { get; set; }
        public int SalaryID { get; set; }
        public bool IsLoan { get; set; }
        public int LoanID { get; set; }


        public int PaymentDetailsId { get; set; }
        public int CurrencyID { get; set; }
        public int PurchaseOrderID { get; set; }
        public decimal CurrencyRate { get; set; }
        public string  PaymentMode { get; set; }
        public int PaymentSourceID { get; set; } // added by ankit: for sourceid detail
        public string PaymentModeNo { get; set; }
        public decimal PaymentAmountUSD { get; set; }
        public decimal PaymentAmount { get; set; }

        public DateTime Expirationdate  { get; set; }
        public int AuthorizationNo { get; set; }
        //public bool IsActive { get; set; }
        //public string AddedBy { get; set; }
        
        //public string LastModBy { get; set; }

        public int FinancialYearID { get; set; }
        public int CompanyID { get; set; }
        
        public   string TType  { get; set; }
      
        
        public int BankID { get; set; }
        
        
        public int CustomerID { get; set; }
        public int BillHeaderID { get; set; }
        
        public string OrderNumber { get; set; }
        public int ParentID { get; set; }

        public decimal SafeBoxAmount { get; set; }
        public decimal SafeBoxAmountUSD { get; set; }
        
        public string Remarks { get; set; }

        public DateTime ExpDate { get; set; }
        public string Expdatetime { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
      

        public bool IsChecked { get; set; }
        public bool IsSafeBox { get; set; }
        public string TransactionType { get; set; }
        public string RemarksCheck { get; set; }
        public string UserName { get; set; }


        public int SalesStatus { get; set; }
        public string ShipID { get; set; }
        public decimal PaidUSDAmt { get; set; }
        public decimal DueUSDAmt { get; set; }

        public decimal PaidGourdesAmt  { get; set; }
        public decimal DueGourdesAmt { get; set; }


        public bool IsPurchase { get; set; }
        public bool IsSales { get; set; }
        public bool IsOthers { get; set; }
        
        /// New Properties Added For Invoice and Others
        /// 

        
        
        
        public int PONumber { get; set; }
        public string InvoiceNo { get; set; }
        public int OtherRefNo { get; set; }  



    }
}
