﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Country                      
  
  Description of the class	    : 
  
  Created Date					: 19-Oct-2011
  
  Developer						: Mithlesh
  
  Modify Date					: 19-Oct-2011

  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.Data.Common
{
   
    [Serializable]
    public class Store  : BaseData
    {
              
        
public Int32   StoreID  { get; set; }
public Int32   StoreTypeID  { get; set; }
public string StoreName  { get; set; }
public string StoreAddress  { get; set; }
public string StoreStreet  { get; set; }
public int StoreCityID  { get; set; }
public int StoreCountryID { get; set; }
public string StorePhone  { get; set; }
public string StoreMobile  { get; set; }
public string StoreFax  { get; set; }
public string StoreEmail  { get; set; }
public string StoreWebsite  { get; set; }
public string StorePostal  { get; set; }
public string ContactPersonName  { get; set; }
public string ContactPersonAddress  { get; set; }
public string ContactPersonStreet  { get; set; }
public Int32 ContactPersonCityID { get; set; }
public Int32 ContactPersonCountryID { get; set; }
public string ContactPersonPhone  { get; set; }
public string ContactPersonMobile  { get; set; }
public string ContactPersonFax  { get; set; }
public string ContactPersonEmail  { get; set; }
public string ContactPersonWebsite  { get; set; }
public string ContactPersonPostal  { get; set; }
public string StoreDocID  { get; set; }
public string StoreDocDetail { get; set; }
public string StoreType { get; set; }
public bool StatusType { get; set; }
//----------------new property for city and country-----
public string CityName { get; set; }
public string CountryName { get; set; }
public int Zip_Code { get; set; }
public int CountryID { get; set; }
public int CityID { get; set; }
public string CityName1 { get; set; }
public string CountryName1 { get; set; }
       

    }
}
