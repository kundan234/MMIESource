﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

namespace MMIE.Data.Common
{
    [Serializable]
    
    public class Company : BaseData
    {
        //
        //public string CompanyID { get; set; }

        
        public string CompanyCode { get; set; }

        
        public string CompanyName { get; set; }

        
        public string CompanyDescription { get; set; }

        
        public int CompanyTypeID { get; set; }

        
        public string CompanyAddress { get; set; }

        
        public string CompanyLandMark { get; set; }

        
        public decimal NightCharge { get; set; }

        
        public decimal EmergencyCharge { get; set; }

        
        public string EmergencyChargePercentage { get; set; }

        
        public string NightChargePercentage { get; set; }

        
        //public int LocationID { get; set; }

        
        public int LocationTypeID { get; set; }

        
        public int CompanyGroupID { get; set; }

        
        public string CompanyPhoneSTDCode { get; set; }

        
        public string CompanyPhoneNo { get; set; }

        
        public string CompanyPhoneAltNo { get; set; }

        
        public string CompanyMobileNo { get; set; }

        
        public string CompanyFaxNo { get; set; }

        
        public string CompanyFaxAltNo { get; set; }

        
        public string CompanyEmailID { get; set; }
        public string CompanyStreet { get; set; }
        
        public string CompanyWebsite { get; set; }

        
        public string CompanyPANNo { get; set; }

        
        public string CompanyTANNo { get; set; }

        
        public string CompanyREGNo { get; set; }

        
        public string CompanyVATNo { get; set; }

        
        public string CompanyCSTNo { get; set; }

        
        public string CompanyTDSNo { get; set; }

        
        public string CompanyEXICENo { get; set; }

        
        public string CompanyDLNo { get; set; }

        
        public string CompanyLicexceNo { get; set; }

        
        public int CityID { get; set; }

        
        public int DistrictID { get; set; }

        
        public int StateID { get; set; }

        
        public string CompanyValidRegistration { get; set; }

        
        public string CompanyITNo { get; set; }  
        
       public string PinNo { get; set; }        
       public DateTime ExpiryDate { get; set; }
       public string Acronym	{ get; set; }
       public string  Ville	{ get; set; }
       public string  Commune	{ get; set; }
       public string Department	{ get; set; }
       public string FiscalYear	{ get; set; }
       public string CompanyType { get; set; }
       public bool IsActive { get; set; }
      // public string PinNo { get; set; }
    }
}
