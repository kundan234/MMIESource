﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Country                      
  
  Description of the class	    : 
  
  Created Date					: 14-Nov-2011
  
  Developer						: Mithlesh
  
  Modify Date					: 14-Nov-2011

  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.Data.Common
{
   
    [Serializable]
    public class Street :BaseData 
    {
      public int ID { get; set; }
      public int StreetID { get; set; }
      public int ProductID { get; set; }
      public string StreetName { get; set; }
      public string ProductName { get; set; }
      public decimal   ChargePrice { get; set; }
      public decimal ChargePrice1 { get; set; }
      public decimal ChargePrice2 { get; set; }
      public decimal ChargePrice3 { get; set; }
      public bool IsActive { get; set; }
      public string AddedBy { get; set; }
      public string LastModBy { get; set; }
      public int ActionType { get; set; }
      public int CompanyID { get; set; }
      public int FinancialYearID { get; set; }
 
      public int CityID { get; set; }
      public int StateID { get; set; }
      public int CountryID { get; set; }
      public string CityName { get; set; }
      public string CountryName { get; set; }
      public string  StateCode { get; set; }



    }
}
