﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Role                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.Data.Common
{

    [Serializable]
    public class Order : BaseData
    {
        public bool IsPriceVisible { get; set; }
        public int MaximumDueDays { get; set; }
        public int ID { get; set; }
        public decimal EquivalentUnit { get; set; }
        public int PendingQty { get; set; }
        public double AvailableQty { get; set; }
        public double AdjustQty { get; set; }
        public int InvoiceID { get; set; }
        public int ToStore { get; set; }
        public Int64 ProductDeliveryID { get; set; }
        public int RefundQty { get; set; }
        public Int64 VehicalPOID { get; set; }
        
        public string StreetName { get; set; }
        public string Color { get; set; }
        public Int64  BillHeaderID { get; set; }
        public string  InvoiceNo { get; set; }
        public string OrderNumber { get; set; }
        public string ShipmentNumber { get; set; }

        public decimal GrandTotalAmount { get; set; }
        public decimal GrandTotalAmountDue { get; set; }
        public decimal GrandTotalAmountPaid { get; set; }

        public decimal TotalUSDAmount { get; set; }
        public decimal TotalGourdesAmount { get; set; }
        public decimal TotalGrandTotalUSD { get; set; }
        public decimal TotalGrandTotalGourdes { get; set; }


        public decimal TotalSalesTaxUSD { get; set; }
        public decimal TotalSalesTaxGourdes { get; set; }
        public decimal TotalDeliveryChargesUSD { get; set; }
        public decimal TotalDeliveryChargesGourdes { get; set; }


         public DateTime  InvoiceDate { get; set; }
         public int GroupType { get; set; }
         public int CustomerID { get; set; }
         public int SalesStatus { get; set; }
         public decimal PaidUSDAmount { get; set; }
         public decimal PaidGourdesAmount { get; set; }
         public decimal DueUSDAmount { get; set; }
         public decimal DueGrourdesAmount { get; set; }
         public decimal DeliveryCharges { get; set; }
         public int StreetID { get; set; }
         public string Remarks { get; set; }
     
         public string PaymentMode { get; set; }
         public int StoreID { get; set; }
         public string  StoreName { get; set; }
         public Int64  ProductSaleID { get; set; }
         public int ProductID { get; set; }
         public string  VinNo { get; set; }
         public string  EngineNo { get; set; }
         public Int32 IssuedQty { get; set; }
         public int UnitID { get; set; }
         public decimal  Rate { get; set; }
         public decimal  Amount { get; set; }
         public decimal UnitPriceGourdes { get; set; }
         public decimal UnitPriceUSD { get; set; }
         public Int64 ProductReceivedTransID { get; set; }
         public decimal DeliveryChargeUSD { get; set; }
         public decimal DeliveryChargeGourdes { get; set; }
         public decimal SaleTaxUSD { get; set; }
         public decimal SaleTaxGourdes { get; set; }
         public decimal SalesTaxGourdes { get; set; }
         public decimal SalesTaxUSD { get; set; }
         public decimal TaxRate { get; set; }

         public decimal TotalProductAmount { get; set; }
         public int DeliveryQty { get; set; }
         public int Qty { get; set; }
         public int ChargedID { get; set; }
      //   public int VehicleRecevingID { get; set; }
     //    public decimal USDAmt { get; set; }
    //     public decimal GourdesAmt { get; set; }
         //public int ChargeCategory { get; set; }
         //public string  GourdesDescription { get; set; }               
        // public int IsActive { get; set; }
         public string CustomerName { get; set; }
         public string CustomerAddress { get; set; }
         public string CustomerStreet { get; set; }
         public int CustomerCityID { get; set; }
         public int CustomerCountryID { get; set; }
         public string CustomerPhone { get; set; }
         public string CustomerMobile { get; set; }
         public string CustomerFax { get; set; }
         public string CustomerEmail { get; set; }
         public string CustomerWebsite { get; set; }
         public string CustReferenceName { get; set; }
         public string CustReferenceAddress { get; set; }
         public string CustReferenceStreet { get; set; }
         public int CustReferenceCityID { get; set; }
         public int CustReferenceCountryID { get; set; }
         public string CustReferencePhone { get; set; }
         public string CustReferenceMobile { get; set; }
         public string CustReferenceFax { get; set; }
         public string CustReferenceEmail { get; set; }
         public string CustReferenceWebsite { get; set; }
         public string  model { get; set; }       
         public string ProductName { get; set; }
         public decimal  TotalAmount { get; set; }
         
         public Int64 ChargePrice { get; set; }
         public decimal OpeningBalance { get; set; }
         public decimal OpeningBalanceUSD { get; set; }
         public decimal MaxCreditLimit { get; set; }
         public decimal MaxCreditLimitUSD { get; set; }
         public string CityName { get; set; }
         public string CountryName { get; set; }
         public string RemarksCheckOut { get; set; }
         public string RemarksDelivery { get; set; }

         public int CurrencyID { get; set; }
         public decimal CurrencyRate { get; set; }
         public decimal DebtAmountGourdes { get; set; }
         public decimal DebtAmountUSD { get; set; }
         public string CertificateCorrectionID { get; set; }
         public string Brand { get; set; }
         public DateTime CertificateDate { get; set; }
         public string ModelNO { get; set; }
         public DateTime BillDueDate { get; set; }
         public string UnitName { get; set; }
         public string OrderDueDate { get; set; }
         public decimal CancelAmt { get; set; }
         public int CancelQty { get; set; }

    }
}
