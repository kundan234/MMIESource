﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
//using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : LookupItem                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    
    [Serializable]
    public class LookupItemCE : BaseData
    {
        public List<LookupItem> LookupItemList1 { get; set; }
        public List<LookupItem> LookupItemList2 { get; set; }
        public List<LookupItem> LookupItemList3 { get; set; }
        public List<LookupItem> LookupItemList4 { get; set; }
      
    }
}

