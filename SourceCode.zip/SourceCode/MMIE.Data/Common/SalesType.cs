﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : SalesType                      
  
  Description of the class	    : 
  
  Created Date					: 30th Nov 2011  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 30/11/2010  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{

    [Serializable]
  public  class SalesType:BaseData
    {
        public int SalesTypeID { get; set; }
        public string  SalesTypeName { get; set; }
        //public decimal SalesTypeRate { get; set; }
        public bool IsActive { get; set; }
        public string AddedBy { get; set; }
       
        public string LastModBy { get; set; }
       
        public int FinancialYearID { get; set; }
        public int CompanyID { get; set; }

        public int ActionType { get; set; }

    }
}
