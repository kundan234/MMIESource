﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Charge                      
  
  Description of the class	    : 
  
  Created Date					: 1 Dec 2011  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 1/12/2011  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.Data.Common
{
    [Serializable]
    public class OtherCharges : BaseData
    {

        public int CurrencyID { get; set; }
        public decimal CurrencyRate { get; set; }
        public int ChargeID { get; set; }
        public string ChargeName { get; set; }
        public decimal ChargeRate { get; set; }
        public string AddedBy { get; set; }

        public string LastModBy { get; set; }

        public bool IsActive { get; set; }
        public int CompanyID { get; set; }
        public int FinancialYearID { get; set; }


    }
}
