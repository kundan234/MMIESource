﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
//using System.ServiceModel;
/*************************************************************************************************  
  
  Name of the Class			    : Lookups                     
  
  Description of the class	    : This enun have all available lookups
  
  Created Date					: 23 Dec 2010  
  
  Developer						: Prem
  
  Modify Date					: 23/12/2010  
  
  Modified By Developer		    : Prem
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.Data.Common
{
   // [DataContract(Name = "LookupNames")]
    public enum LookupNames
    {
        [EnumMember]
        Allowance,
        [EnumMember]
        PayGroup,

        [EnumMember]
        FinancialYear,

        [EnumMember]
        Company,

        [EnumMember]
        CompanyType,

        [EnumMember]
        Location,

        [EnumMember]
        LocationType,

        [EnumMember]
        CompanyGroup,

        [EnumMember]
        City,

        [EnumMember]
        State,

        [EnumMember]
        District,

        [EnumMember]
        Country,
        [EnumMember]
        Group,
        [EnumMember]
        Unit,
        [EnumMember]
        AccountType,

        [EnumMember]
        Salutation,

        [EnumMember]
        Sex,

        [EnumMember]
        BloodGroup,

        [EnumMember]
        Education,

        [EnumMember]
        Designation,

        [EnumMember]
        Department,

        [EnumMember]
        MaritalStatus,

        [EnumMember]
        Employee,

        [EnumMember]
        EmployeeType,

        [EnumMember]
        EmployeeCategory,

        [EnumMember]
        Religion,

        [EnumMember]
        Nationality,

        [EnumMember]
        ScheduleType,

        [EnumMember]
        RelativeType,

        [EnumMember]
        RelationType,

        [EnumMember]
        DesignationType,

        [EnumMember]
        Form,

        [EnumMember]
        Occupation,

        [EnumMember]
        PatientType,

        [EnumMember]
        Ledger,
        [EnumMember]
        PatientCategory,

        [EnumMember]
        PaymentType,

        [EnumMember]
        TarifCategory,

        [EnumMember]
        ExemptionCategory,

        [EnumMember]
        LedgerRefTo,

        [EnumMember]
        LedgerRefToInv,

        [EnumMember]
        LedgerRefToMed,

        [EnumMember]
        LedgerRefToHos,
        [EnumMember]
        LedgerType,

        [EnumMember]
        LedgerGroup,

        //Bed,
        [EnumMember]
        MaterialGroup,
        [EnumMember]
        AccountHead,

        [EnumMember]
        AccountGroup,

        //Room,
        [EnumMember]
        RoomGroup,

        [EnumMember]
        RoomType,

        [EnumMember]
        AccType,

        [EnumMember]
        BedType,

        [EnumMember]
        BedCategory,

        //NursingStation,
        [EnumMember]
        Floor,

        //Block,
        //Wing,
        //Section,
        [EnumMember]
        FoodType,

        [EnumMember]
        FoodGroup,

        [EnumMember]
        FoodCategory,

        [EnumMember]
        ServicesGroup,

        [EnumMember]
        ServicesType,

        [EnumMember]
        TestType,

        //ServicesSubGroup,
        //Disease,
        //Product,
        [EnumMember]
        CaseType,

        [EnumMember]
        DepartmentGroup,

        [EnumMember]
        DiseaseGroup,

        [EnumMember]
        DiseaseSubGroup,

        [EnumMember]
        DiseaseICDCode,

        [EnumMember]
        DiseaseICDCodeSearch,

        [EnumMember]
        DiseaseICDCodeName,

        [EnumMember]
        DiseaseType,

        [EnumMember]
        UOM,
        //Size,
        //Weight,
        [EnumMember]
        ProductType,

        [EnumMember]
        ProductGroup,

        [EnumMember]
        ProductSubGroup,

        [EnumMember]
        ProductCategory,
        [EnumMember]
        ClinicMaster,

        [EnumMember]
        TransactionType,

        [EnumMember]
        Hospital,

        [EnumMember]
        ReferHospital,

        [EnumMember]
        UOMType,
        [EnumMember]
        Clinic,

        [EnumMember]
        ReferEmployee,

        [EnumMember]
        OccupaiedBed,

        [EnumMember]
        DepositType,

        [EnumMember]
        AdmissionDoctor,

        [EnumMember]
        ConsultationDoctor,
        [EnumMember]
        RequiredBed,

        [EnumMember]
        BedNo,

        [EnumMember]
        BillingType,
       
        [EnumMember]
        ConsultantDisease,

        [EnumMember]
        Role,
        
        [EnumMember]
        CardType,
        [EnumMember]
        AttandanceType,

        [EnumMember]
        UserType,

        [EnumMember]
        IncomeGroup,

        [EnumMember]
        AdmissionSource,

        [EnumMember]
        NursingStation,

        [EnumMember]
        RoomMST,

        [EnumMember]
        Counter,

        [EnumMember]
        DiseaseCategory,

        [EnumMember]
        VendorClassification,

        [EnumMember]
        Material,

        [EnumMember]
        VendorType,

        [EnumMember]
        Supplier,

        [EnumMember]
        Service,

        [EnumMember]
        ServiceGroup,

        [EnumMember]
        ServiceSubGroup,

        [EnumMember]
        DoctorsComponent,

        [EnumMember]
        PrimaryDesease,

        [EnumMember]
        SecondaryDesease,

        [EnumMember]
        TechnicianComponent,

        [EnumMember]
        CreditCompany,

        [EnumMember]
        TransferType,

        [EnumMember]
        WardName,

        [EnumMember]
        MISSubGroup,

        [EnumMember]
        ServiceComponent,

        [EnumMember]
        ServiceType,

        [EnumMember]
        BedClass,

        [EnumMember]
        TestLab,

        [EnumMember]
        TestPanel,

        [EnumMember]
        Dischargtype,

        [EnumMember]
        Dischargingdoctor,

        [EnumMember]
        Dischargedestination,

        [EnumMember]
        Patientcategorylist,
        [EnumMember]
        EmploymentType,

        [EnumMember]
        BankType,

        [EnumMember]
        MaterialSubGroupID,
        [EnumMember]
        MaterialSubGropu,

        [EnumMember]
        GrnMST,

        [EnumMember]
        CostHeadName,

        [EnumMember]
        CostHead,

        [EnumMember]
        PurchaseUnitsID,
        [EnumMember]
        PurchaseUnits,

        [EnumMember]
        StockUnits,

        [EnumMember]
        StoreLocation,

        [EnumMember]
        MaterialFormID,
        [EnumMember]
        MaterialForm,
        
        [EnumMember]
        Schedule,

        [EnumMember]
        Manufacturer,

        [EnumMember]
        Noof,

        [EnumMember]
        DiscountCategoryID,
        [EnumMember]
        DiscountCategory,

        [EnumMember]
        CreditAuthorisedID,

        [EnumMember]
        DiscountAuthorisedID,

        [EnumMember]
        PrescribedByID,

        [EnumMember]
        StoreID,

        [EnumMember]
        MaterialGroupID,

        [EnumMember]
        GenericName,

        [EnumMember]
        ManufacturerID,

        [EnumMember]
        ScheduleID,

        [EnumMember]
        NoofID,

        [EnumMember]
        UserLoginIDs,

        [EnumMember]
        DepositTypeID,
        [EnumMember]
        MaterialGroupName,

        [EnumMember]
        CreditAuthorised,
        
        [EnumMember]
        UnitDescription,
        [EnumMember]
        SupplierTypeName,
        [EnumMember]
        UserList,

        [EnumMember]
        SupplierClassificationName,
         [EnumMember]
         StoreName,
          [EnumMember]
         ClassTrack,
          [EnumMember]
          EmployeerType,
          [EnumMember]
          PONumber,
    }
}
