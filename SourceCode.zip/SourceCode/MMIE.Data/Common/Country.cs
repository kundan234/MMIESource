﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Country                      
  
  Description of the class	    : 
  
  Created Date					: 7th Dec 2010  
  
  Developer						: 
  
  Modify Date					: 07/12/2010  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
    
    [Serializable]
    public class Country : BaseData
    {
        
        public int CountryID { get; set; }

        
        public string CountryCode { get; set; }
        
        
        public string CountryName { get; set; }

      
    }
}

