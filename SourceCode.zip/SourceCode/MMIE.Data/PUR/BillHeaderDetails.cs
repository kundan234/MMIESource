﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;

/*************************************************************************************************  
  
  Name of the Class			    : City                      
  
  Description of the class	    : 
  
  Created Date					: 16th Dec 2010  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 16/12/2011  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()

  *************************************************************************************************/

namespace MMIE.Data.PUR
{
    class BillHeaderDetails:BaseData
    {

        public Int64 BillHeaderID { get; set; }
        public string InvoiceNo { get; set; }
        public string OrderNumber { get; set; }
        public string ShipmentNumber { get; set; }
        public decimal TotalUSDAmount { get; set; }
        public decimal TotalGourdesAmount { get; set; }
        public DateTime InvoiceDate { get; set; }
        public int GroupType { get; set; }
        public int CustomerID { get; set; }
        public int SalesStatus { get; set; }
        public decimal PaidUSDAmount { get; set; }
        public decimal PaidGourdesAmount { get; set; }
        public decimal DueUSDAmount { get; set; }
        public decimal DueGrourdesAmount { get; set; }
        public decimal TotalDeliveryChargesGrourdes { get; set; }
        public decimal TotalDeliveryChargesUSD { get; set; }
        public decimal TotalSalesTaxGrourdes { get; set; }
        public decimal TotalSalesTaxUSD { get; set; }
        public decimal TotalGrandTotalGourdes { get; set; }
        public decimal TotalGrandTotalUSD { get; set; }
        public int StreetID { get; set; }
        public string Remarks { get; set; }
        public string PaymentMode { get; set; }

        public int StoreID { get; set; }


        public string RemarksCheckOut { get; set; }
        public string RemarksDelivery { get; set; }
        public int CurrencyID { get; set; }
        public decimal CurrencyRate { get; set; }  



    }
}
