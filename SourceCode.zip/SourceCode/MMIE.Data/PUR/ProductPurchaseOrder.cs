﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;

/*************************************************************************************************  
  
  Name of the Class			    : City                      
  
  Description of the class	    : 
  
  Created Date					: 16th Dec 2010  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 16/12/2011  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()

  *************************************************************************************************/


namespace MMIE.Data.PUR
{
    [Serializable]
    public   class ProductPurchaseOrder:BaseData
    {

        public int ID { get; set; }
        public int StoreID { get; set; }
        public string StoreName { get; set; }
        public string Remarks { get; set; }
        public int GroupType { get; set; }
        public int InvoiceHeaderID { get; set; }
        public string UnitName { get; set; }
        public string  PONumber { get; set; }
        public string Model { get; set; }
        public string Color { get; set; }
        public int Qty { get; set; }
        public int PendingQty { get; set; }
        public int RecievedQty { get; set; }
        public string Unit { get; set; }
        public string ENName { get; set; }
        public string ProductName { get; set; }
        //public string RaisedBy { get; set; }
        //public DateTime RaisedDate { get; set; }
        public string OrderDate { get; set; }
        public int ProductType { get; set; }
        public int CompanyID { get; set; }
        public int FinancialYearID { get; set; }
        public string AddedBy { get; set; }

        public string LastModBy { get; set; }
        
        public bool IsPending { get; set; }
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public string Details { get; set; }
        public bool IsActive { get; set; }
        public int ActionType { get; set; }
        public int ApprovedQty { get; set; }
        public int ProductID { get; set; }

    
    }
}
