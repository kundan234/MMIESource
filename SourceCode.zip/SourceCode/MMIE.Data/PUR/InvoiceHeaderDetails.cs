﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.Common;

/*************************************************************************************************  
  
  Name of the Class			    : City                      
  
  Description of the class	    : 
  
  Created Date					: 16th Dec 2010  
  
  Developer						: Kundan Singh jeena
  
  Modify Date					: 16/12/2011  
  
  Modified By Developer			: Kundan Singh jeena
  
  Comments						: ()

  *************************************************************************************************/


namespace MMIE.Data.PUR
{
        [Serializable]
   public class InvoiceHeaderDetails : BaseData
    {

        //Common Fields
        public string Result { get; set; }
        public string XMLCharges { get; set; }
        public string XMLItems { get; set; }
        public int ID { get; set; }
        public string InvoiceNo { get; set; }
        public int ProductID { get; set; }
        public int InvoiceHeaderID { get; set; }
        public int PONumber { get; set; }
        public int StoreID { get; set; }
        //End Common Fields

        public int InvoiceItemID { get; set; }
        
        public decimal CostPrice { get; set; }
        public decimal PerUnitCharges { get; set; }

            

        public int RecievedQty { get; set; }
        public string UNIT { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Amount { get; set; }
  


        //Invoice Header Fields

   
        public decimal TotalUSDAmount { get; set; }
        public decimal TotalGourdesAmount { get; set; }
        public DateTime InvoiceDate { get; set; }
        public int SupplierID { get; set; }
        public int GroupTypeID { get; set; }

        public decimal TotalCostPrice { get; set; }
        public decimal TotalInsurance { get; set; }
        public decimal TotalFrieght { get; set; }
        
        public decimal TotalOtherCharges { get; set; }
        public int GroupType { get; set; }
        public decimal TotalInvoiceAmount { get; set; }
        public decimal PaidAmount { get; set; }
        public string Remarks { get; set; }
        public bool IsActive { get; set; }
        public int FinancialYearID { get; set; }
        public int CurrencyID { get; set; }
        public decimal CurrencyRate { get; set; }
        public DateTime InvoiceDueDate { get; set; }
        public string ContainerNumber { get; set; }
        public string ShipmentNumber { get; set; }


        public int TotalQty { get; set; }
            // Field To contain Supplier Details  public string CustomerName { get; set; }
        public string CustomerName { get; set; }    
        public string CustomerAddress { get; set; }
        public string CustomerStreet { get; set; }
        public string CityName { get; set; }
        public string CountryName { get; set; }
        public string CustomerPhone { get; set; }
        public string CustomerMobile { get; set; }
        public string CustomerType { get; set; }
        public string CustomerEmail { get; set; }

        public string OtherChargeAmount { get; set; }
        public string OtherChargeID { get; set; }
        public string OtherChargeDesc { get; set; }




    }
}
