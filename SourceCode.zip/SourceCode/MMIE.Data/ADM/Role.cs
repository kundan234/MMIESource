﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Role                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/



namespace MMIE.Data.Common
{
   
    [Serializable]
    public class Role : BaseData
    {
        
        public int RoleId { get; set; }

        
        public string RoleName { get; set; }

        
        public string RoleCode { get; set; }

        public Boolean  IsAddOn { get; set; }
        public Boolean IsModify { get; set; }
        public Boolean IsCancelOn { get; set; }
        public Boolean IsDeleteOn { get; set; }
        public Boolean IsPrintOn { get; set; }
        public Boolean IsPrintExportOn { get; set; }

        public Boolean IsChangeDateOn { get; set; }
        public Boolean IsChangeBranchOn { get; set; }
        public Boolean IsApproverReturnOn { get; set; }
        public Boolean IsApproverReimbursementOn { get; set; } 
        public Boolean IsApproverRecievedOn { get; set; }
        public Boolean IsRateChangeOn { get; set; }
        public Boolean IsPartialCancellationOn { get; set; }
        public Boolean IsCreditLimitChangeAllowed { get; set; }
        

    }
}

