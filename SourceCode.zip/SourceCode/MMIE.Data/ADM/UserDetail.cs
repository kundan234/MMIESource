﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : UserCE                      
  
  Description of the class	    : 
  
  Created Date					: 5th Dec 2010  
  
  Developer						: 
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common

{
    [Serializable]
    public class UserDetail : BaseData
    {
        
        public int UserDetailID { get; set; }

        
        public string FirstName { get; set; }

        
        public string LastName { get; set; }

        
        public string UserCode { get; set; }

        
        public int DesignationID { get; set; }

        
        public int DepartmentID { get; set; }

        
        public int MaritalStatusID { get; set; }

        public string FullName { get; set; }
       
    }
}

