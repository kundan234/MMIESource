﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using System.Data;

/*************************************************************************************************  
  
  Name of the Class			    : UserCE                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
   
    [Serializable]
    public class UserCE : BaseData
    {
        
        public UserLogin UserLogin { get; set; }

        
        public UserDetail UserDetail { get; set; }

        
        public List<Role> RoleList { get; set; }

        
        public List<SiteMap> SiteMapList
        {
            get;
            set;
        }

        
        public DataTable SiteMapDT
        {
            get;
            set;
        }  

        
    }
}

