﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : Role                      
  
  Description of the class	    : 
  
  Created Date					: 5th Dec 2010  
  
  Developer						: Shubhakaran
  
  Modify Date					: 
  
  Modified By Developer			: 
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.Data.Common
{
   
    [Serializable]
    public class SiteMap : BaseData
    {

        
        public int SiteMapID
        {
            get;
            set;
        }        

        
        public string Title
        {
            get;
            set;
        }

        
        public string Text
        {
            get;  set;
        }

        
        public string Description
        { get; set; }

        
        public string Url
        { get; set; }

        
        public int ParentID
        { get; set; }       

    }
}
