﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;

/*************************************************************************************************  
  
  Name of the Class			    : User                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Budha Singh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Budha Singh 
  
  Comments						: ()
 
  *************************************************************************************************/


namespace MMIE.Data.Common
{
   
    [Serializable]
    public class UserLogin : BaseData
    {
        
        public int UserLoginId { get; set; }

        
        public int UserTypeID { get; set; }

        
        public string UserTypeCode { get; set; }

        
        public string UserTypeName { get; set; }

        
        public string LoginId { get; set; }

        
        public Guid LoginUniqueId { get; set; }

        
        public string Password { get; set; }

        
        public int Status { get; set; }

        
        public string FinancialYearCode { get; set; }

        
        public string FinancialYearName { get; set; }

        
        public string CompanyCode { get; set; }

        
        public string CompanyName { get; set; }

        
        public string CompanyAddress { get; set; }

        
        public string CompanyPhoneSTDCode { get; set; }

        
        public string CompanyPhoneNo { get; set; }

        
        public string CompanyEmailID { get; set; }

        
        public string CompanyFaxNo { get; set; }

        
        public string CompanyPhoneAltNo { get; set; }

        
        public string CompanyMobileNo { get; set; }

        
        public string CompanyWebsite { get; set; }
        
        public string MonStartTime { get; set; }
        public string MonEndTime{ get; set; }
        public string TueStartTime { get; set; }
        public string TueEndTime { get; set; }
        public string WedStartTime { get; set; }
        public string WedEndTime { get; set; }
        public string ThurStartTime { get; set; }
        public string ThurEndTime { get; set; }

        public string FriStartTime { get; set; }
        public string FriEndTime { get; set; }
        public string SatStartTime { get; set; }
        public string SatEndTime { get; set; }
        public string SunStartTime { get; set; }
        public string SunEndTime { get; set; }
        public string UserName { get; set; }
        public bool IsCheckOut { get; set; }
  

   
    }
}

