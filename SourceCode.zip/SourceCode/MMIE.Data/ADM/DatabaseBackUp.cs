﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;


/*************************************************************************************************  
  
  Name of the Class			    :      DatabaseBackUp                 
  
  Description of the class	    : 
  
  Created Date					: 20/2/2012 
  
  Developer						: Ankit
  
  Modify Date					: 20/2/2012 
  
  Modified By Developer			: Budha Singh Ankit
  
  Comments						: ()
 
  *************************************************************************************************/
namespace MMIE.Data.Common
{
    [Serializable]
    public class DatabaseBackUp : BaseData
    {
        public string Path { get; set; }
        public string name { get; set; }
        public int BackupID { get; set; }
        public string BackupName { get; set; }
        public string BackupFileName { get; set; }
        public DateTime BackupDateTime { get; set; }
        public string AddedBy { get; set; }
        public DateTime AddedDTM { get; set; }
    }
}
