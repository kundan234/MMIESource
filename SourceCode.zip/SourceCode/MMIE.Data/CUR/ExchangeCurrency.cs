﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMIE.Data.CUR
{
    public class ExchangeCurrency
    {

        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public int PurchaseCurrencyID { get; set; }
        public int EquivalentCurrencyId { get; set; }
        public string PurchaseCurrencyName { get; set; }
        public string EquivalentCurrencyName { get; set; }
        public string InvoiceNo { get; set; }
        public string PurchaseDate { get; set; }
        public string PurchaseOrderNo { get; set; }
        public string PurchaseId { get; set; }
        public Decimal Rate { get; set; }
        public Decimal PurchaseCurrencyAmount { get; set; }
        public Decimal EquiCurrencyAmount { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int LastModBy { get; set; }
        public int AddedBy { get; set; }
        public string DocumentID { get; set; }
        public string xmlPurchaseCurrency { get; set; }
        public int CompanyID { get; set; }
    }
}
