﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.PRL;
using MMIE.Data.Common;
/*************************************************************************************************  
  
  Name of the Class			    : Loan                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Kundan Singh
  
  Modify Date					: 05/15/2012  
  
  Modified By Developer			: Kundan Singh
  
  Comments						: ()
 
  *************************************************************************************************/

namespace MMIE.Data.PRL
{
    [Serializable]
   public class Loan : BaseData
    {
        public int LoanID { get; set; }
        public int EmployeeID { get; set; }
        public string  LoanDetails { get; set; }
        public int LoanTypeID { get; set; }
        public decimal LoanAmount { get; set; }
        public decimal PaidLoanAmount { get; set; }
        public DateTime LoanDate { get; set; }
        public DateTime LoanDueDate { get; set; }
        public decimal DeductionAmount { get; set; }

        public string Details { get; set; }
        
        public bool IsPending { get; set; }
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime ApprovedDTM { get; set; }
        public string RejectedBy { get; set; }
        public DateTime RejectedDTM { get; set; }  
        public int TotalInstallments { get; set; }
        public int PaidInstallments { get; set; }

        public string PaidOnDTM { get; set; }  


    }
}
