﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
////using System.ServiceModel;
using System.Text;
using MMIE.Data.PRL;
using MMIE.Data.Common;
/*************************************************************************************************  
  
  Name of the Class			    : Role                      
  
  Description of the class	    : 
  
  Created Date					: 2nd Dec 2010  
  
  Developer						: Mithlesh
  
  Modify Date					: 02/12/2010  
  
  Modified By Developer			: Mithlesh
  
  Comments						: ()
 
  *************************************************************************************************/
namespace MMIE.Data.PRL
{

    [Serializable]
    public class Employee : BaseData
    {
        public int ID { get; set; }
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Boolean Gender { get; set; }
        public string DOB { get; set; }
        public string Address { get; set; }
        public string Street { get; set; }
        public int CountryID { get; set; }
        public int CityID { get; set; }
        public string PostalCode { get; set; }
        public string PhoneNo { get; set; }
        public string CellNo { get; set; }
        public string AlternativePhoneNo { get; set; }
        public string Email { get; set; }
        public string SacnIdType { get; set; }
        public string ScanIDNo { get; set; }
        public string IdScanIDDetail { get; set; }
        public string HireDate { get; set; }
        public string ReleaseDate { get; set; }
        public string EanringType { get; set; }
        public int EarningRate { get; set; }
        public Boolean EmployeeStatus { get; set; }
        public string CountryName { get; set; }
        public string CityName { get; set; }
        public int DesignationID { get; set; }
        public int DepartmentID { get; set; }
        public string AccountNo { get; set; }
        public bool EmployeeTaxes { get; set; }
        public bool RetirementPlan { get; set; }
        public bool CompanyPaid { get; set; }

        public bool Insurance { get; set; }
        public int BranchCode { get; set; }
        public string EmployementType { get; set; }
        public string ClassTrack { get; set; }
        public int EmployeeTypeID { get; set; }
        public int ClassTrackID { get; set; }
        public string DepartmentName { get; set; }
        public string DesignationName { get; set; }
        public string PayFreequency { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public decimal SickAllownces { get; set; }
        public decimal VacationAllownces { get; set; }
        public decimal Bonous { get; set; }
        public decimal Allownces { get; set; }

        //Salary Calculation


     
        
        public string  PayFrequency { get; set; }
 
        public decimal GrossSalary { get; set; }
        public decimal Adjustment { get; set; }
        public decimal AdjustGrossSalary { get; set; }
        public decimal Bonus { get; set; }
        public decimal ONAEmployer { get; set; }
        public decimal ONAEmployee { get; set; }
        public decimal NonTaxableGrossSalary { get; set; }
        public decimal TaxableGrossSalary { get; set; }
        public decimal IRI { get; set; }
        public decimal CFGDCT { get; set; }
     
        public decimal CashRecievedFromMomphat { get; set; }
        public decimal ONAReimbursement { get; set; }
        public decimal NetSalary { get; set; }
     
           
     // Adde by Kundan : for multiple currency support and Loan Feature
        public bool IsPaid { get; set; }
        public decimal PaidSalary { get; set; }
        public int CurrencyID { get; set; }
        public decimal CurrencyRate { get; set; }
        public decimal LoanAmount { get; set; }
        public decimal PaidLoadAmount { get; set; }
        public decimal TotalLoanAmount { get; set; } //added by ankit
        public decimal TotalDeduction { get; set; }  //added by ankit



    }
}
